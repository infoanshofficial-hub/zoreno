package com.zoreno.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.zoreno.app.billing.BillingManager
import com.zoreno.app.ui.screens.*
import com.zoreno.app.ui.components.*

sealed class AppScreen {
    object ChatList : AppScreen()
    object AiChat : AppScreen()
    data class DirectChat(val userId: String, val userName: String, val avatar: String) : AppScreen()
    object FocusMusic : AppScreen()
    object Subscription : AppScreen()
    object Settings : AppScreen()
    object Profile : AppScreen()
    object AccountCenter : AppScreen()
}

@Composable
fun MainScreen(
    billingManager: BillingManager,
    onSecureChange: (Boolean) -> Unit
) {
    var currentScreen by remember { mutableStateOf<AppScreen>(AppScreen.ChatList) }
    val userTier by billingManager.userTier.collectAsState()

    // Screen security check for FLAG_SECURE
    LaunchedEffect(currentScreen) {
        when (currentScreen) {
            is AppScreen.DirectChat -> onSecureChange(true)
            AppScreen.Profile -> onSecureChange(true)
            else -> onSecureChange(false)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF080C14))
            .safeDrawingPadding() // Camera Notch and Status Bar safe padding
    ) {
        when (val screen = currentScreen) {
            is AppScreen.ChatList -> ChatListScreen(
                onOpenAiChat = { currentScreen = AppScreen.AiChat },
                onOpenDm = { uid, name, avatar -> currentScreen = AppScreen.DirectChat(uid, name, avatar) },
                onOpenProfile = { currentScreen = AppScreen.Profile }
            )
            is AppScreen.AiChat -> AiChatScreen(
                userTier = userTier,
                onBack = { currentScreen = AppScreen.ChatList }
            )
            is AppScreen.DirectChat -> DirectMessageScreen(
                userId = screen.userId,
                userName = screen.userName,
                avatarUrl = screen.avatar,
                onBack = { currentScreen = AppScreen.ChatList }
            )
            is AppScreen.FocusMusic -> FocusMusicScreen(
                onBack = { currentScreen = AppScreen.ChatList }
            )
            is AppScreen.Subscription -> SubscriptionScreen(
                userTier = userTier,
                billingManager = billingManager,
                onBack = { currentScreen = AppScreen.ChatList }
            )
            is AppScreen.Settings -> SettingsScreen(
                onBack = { currentScreen = AppScreen.ChatList },
                onOpenAccountCenter = { currentScreen = AppScreen.AccountCenter },
                onOpenSubscription = { currentScreen = AppScreen.Subscription }
            )
            is AppScreen.Profile -> ProfileScreen(
                userTier = userTier,
                onBack = { currentScreen = AppScreen.ChatList },
                onOpenSubscription = { currentScreen = AppScreen.Subscription }
            )
            is AppScreen.AccountCenter -> AccountCenterScreen(
                userTier = userTier,
                onBack = { currentScreen = AppScreen.Settings },
                onOpenSubscription = { currentScreen = AppScreen.Subscription }
            )
        }

        // 4-Tab Floating Apple-Style Frosted Glass Bottom Navigation
        if (currentScreen is AppScreen.ChatList || currentScreen is AppScreen.Subscription ||
            currentScreen is AppScreen.FocusMusic || currentScreen is AppScreen.Settings) {
            FloatingBottomNav(
                currentScreen = currentScreen,
                onTabSelect = { s -> currentScreen = s }
            )
        }
    }
}
