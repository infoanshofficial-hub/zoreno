package com.zoreno.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

class ZorenoBgNotifService : Service() {

    private var scheduler: ScheduledExecutorService? = null

    override fun onCreate() {
        super.onCreate()
        startPolling()
    }

    private fun startPolling() {
        if (scheduler != null) return
        scheduler = Executors.newSingleThreadScheduledExecutor()
        scheduler?.scheduleAtFixedRate({
            var wl: PowerManager.WakeLock? = null
            try {
                val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
                wl = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Zoreno:BgNotifLock")?.apply { acquire(6000) }

                val prefs = getSharedPreferences("ZorenoQuotaPrefs", Context.MODE_PRIVATE)
                val myUid = prefs.getString("zorenoActiveUid", "") ?: ""
                if (myUid.isEmpty()) return@scheduleAtFixedRate

                val url = URL("https://firestore.googleapis.com/v1/projects/zeraai-ans/databases/(default)/documents:runQuery")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    connectTimeout = 6500
                    readTimeout = 6500
                    doOutput = true
                }
                val q = """{"structuredQuery":{"from":[{"collectionId":"chats"}],"where":{"fieldFilter":{"field":{"fieldPath":"participants"},"op":"ARRAY_CONTAINS","value":{"stringValue":"$myUid"}}}}}"""
                conn.outputStream.use { it.write(q.toByteArray(Charsets.UTF_8)) }

                if (conn.responseCode == 200) {
                    val responseStr = BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { it.readText() }
                    val arr = JsonParser.parseString(responseStr).asJsonArray
                    for (el in arr) {
                        if (!el.isJsonObject) continue
                        val obj = el.asJsonObject
                        if (!obj.has("document")) continue
                        val doc = obj.getAsJsonObject("document")
                        if (!doc.has("fields")) continue
                        val fields = doc.getAsJsonObject("fields")
                        val lastSenderId = getStr(fields, "lastSenderId")
                        val lastSenderName = getStr(fields, "lastSenderName")
                        val lastMsg = getStr(fields, "lastMessage")
                        val msgTimeMs = getLong(fields, "lastMessageAtMs")
                        if (lastSenderId.isNotEmpty() && lastSenderId != myUid && msgTimeMs > 0L) {
                            val nKey = "bgNotif_" + doc.get("name").asString
                            val prev = prefs.getLong(nKey, 0L)
                            if (prev == 0L) {
                                prefs.edit().putLong(nKey, msgTimeMs).apply()
                            } else if (msgTimeMs > prev) {
                                prefs.edit().putLong(nKey, msgTimeMs).apply()
                                fireNotif(
                                    if (lastSenderName.isEmpty()) "Zoreno Message" else lastSenderName,
                                    if (lastMsg.isEmpty()) "New message" else lastMsg
                                )
                            }
                        }
                    }
                }
            } catch (_: Exception) {
            } finally {
                try {
                    if (wl?.isHeld == true) wl.release()
                } catch (_: Exception) {}
            }
        }, 5, 10, TimeUnit.SECONDS)
    }

    private fun getStr(f: JsonObject, k: String): String {
        return try {
            if (f.has(k) && f.getAsJsonObject(k).has("stringValue")) f.getAsJsonObject(k).get("stringValue").asString else ""
        } catch (_: Exception) { "" }
    }

    private fun getLong(f: JsonObject, k: String): Long {
        return try {
            if (f.has(k)) {
                val v = f.getAsJsonObject(k)
                when {
                    v.has("integerValue") -> v.get("integerValue").asString.toLong()
                    v.has("doubleValue") -> v.get("doubleValue").asDouble.toLong()
                    else -> 0L
                }
            } else 0L
        } catch (_: Exception) { 0L }
    }

    private fun fireNotif(title: String, body: String) {
        Handler(Looper.getMainLooper()).post {
            try {
                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                val chId = "zoreno_dm_channel_v5"
                if (Build.VERSION.SDK_INT >= 26) {
                    val ch = NotificationChannel(chId, "Zoreno Messages", NotificationManager.IMPORTANCE_HIGH)
                    ch.enableVibration(true)
                    nm.createNotificationChannel(ch)
                }
                val intent = Intent(this@ZorenoBgNotifService, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                }
                val pi = PendingIntent.getActivity(
                    this@ZorenoBgNotifService, 0, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                val b = NotificationCompat.Builder(this@ZorenoBgNotifService, chId)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setDefaults(NotificationCompat.DEFAULT_ALL)
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                nm.notify((System.currentTimeMillis() and 0xfffffff).toInt(), b.build())
            } catch (_: Exception) {}
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startPolling()
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        scheduleRestart()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        scheduleRestart()
        super.onDestroy()
    }

    private fun scheduleRestart() {
        try {
            val ri = Intent(applicationContext, ZorenoBgNotifService::class.java).apply { setPackage(packageName) }
            val pi = PendingIntent.getService(
                applicationContext, 101, ri,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val am = getSystemService(Context.ALARM_SERVICE) as? AlarmManager
            am?.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + 2500L, pi)
        } catch (_: Exception) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
