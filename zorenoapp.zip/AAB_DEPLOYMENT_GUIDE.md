# Zoreno — Android App Bundle (.aab) & Release Guide

This guide explains the native Android Studio wrapper architecture and how to build, sign, and export the `.aab` file for the Google Play Store.

---

## 1. Architecture Overview

Your application runs inside an accelerated Android WebView with two-way native bridges:

```
┌────────────────────────────────────────────────────────┐
│                   Web App (assets/)                    │
│   • index.html • style.css • app.js                    │
└───────────────────────────┬────────────────────────────┘
                            │
               JavaScript Interfaces (window)
                            │
            ┌───────────────┴───────────────┐
            ▼                               ▼
┌─────────────────────────┐   ┌─────────────────────────┐
│     AndroidBilling      │   │      AndroidAdMob       │
│ • purchaseSubscription  │   │ • showRewardedAd        │
└───────────┬─────────────┘   └─────────────┬───────────┘
            │                               │
            ▼                               ▼
┌─────────────────────────┐   ┌─────────────────────────┐
│ Play Billing Client 7.x │   │   Google Mobile Ads     │
│ • zoreno_plus_monthly   │   │ • Rewarded Video Unit   │
│ • zoreno_pro_monthly    │   │ • Automated Preload     │
└───────────┬─────────────┘   └─────────────┬───────────┘
            │                               │
            ▼                               ▼
┌───────────────────────────────────────────────────────┐
│                 Callbacks to Web DOM                  │
│ • window.onPlayBillingSuccess(tier, token)            │
│ • window.onAdMobRewardGranted()                       │
└───────────────────────────────────────────────────────┘
```

---

## 2. Key Native Files Created

1. **`app/src/main/java/com/example/MainActivity.java`**:
   - `AndroidBillingBridge`: Exposes `purchaseSubscription(skuId, targetTier)` to JavaScript.
   - `AndroidAdMobBridge`: Exposes `showRewardedAd(adUnitId)` to JavaScript.
   - `AndroidAppBridge`: Exposes `isAndroid()` and native toasts.
   - Subscriptions query: `BillingClient.ProductType.SUBS` with offer token resolution.
   - Purchase acknowledgement: Automatically acknowledges purchases and invokes `window.onPlayBillingSuccess(tier, purchaseToken)`.
   - AdMob: Handles reward callbacks and automatically preloads the next video ad.
   - `WebChromeClient`: Full support for profile picture uploads (`<input type="file">`).

2. **`app/src/main/AndroidManifest.xml`**:
   - Declares `INTERNET`, `ACCESS_NETWORK_STATE`, and `com.android.vending.BILLING`.
   - Registers AdMob Application ID (`ca-app-pub-5825754850490611~6362976717`).
   - Configured with `hardwareAccelerated="true"` and `windowSoftInputMode="adjustResize"`.

3. **`app/build.gradle.kts`**:
   - Application ID: `com.aistudio.zoreno.zstdy`
   - Play Billing SDK: `com.android.billingclient:billing:7.1.1`
   - AdMob SDK: `com.google.android.gms:play-services-ads:23.6.0`
   - AndroidX WebKit: `androidx.webkit:webkit:1.12.1`

4. **`app/src/main/assets/`**:
   - Complete bundled offline web assets (`index.html`, `app.js`, `style.css`).

---

## 3. Zero-Setup Mobile Workflow (No Laptop Needed)

If you are on a phone without a laptop, you do **NOT** need to configure any GitHub secrets manually!

1. **Push your code to GitHub** (or open your GitHub repository in your phone's browser).
2. Go to the **Actions** tab in your repository.
3. Select **"Build Signed Android App Bundle (AAB) & APK"** and tap **"Run workflow"**.
4. GitHub Actions will automatically:
   - Detect that no `KEYSTORE_BASE64` secret exists.
   - Run `keytool` to generate a production-ready 2048-bit RSA `release.jks`.
   - Sign both **`app-release.aab`** and **`app-release.apk`**.
   - Package `app-release.aab`, `app-release.apk`, `release.jks`, and `KEYSTORE_CREDENTIALS.txt` together.
5. When the build finishes (takes ~2 minutes), scroll down to **Artifacts** and download:
   **`zoreno-mobile-release-package.zip`**
6. Extract the zip on your phone:
   - **`app-release.aab`**: Upload this directly to Google Play Console.
   - **`app-release.apk`**: Install it on your Android phone immediately for testing.
   - **`release.jks`**: Keep this safe in Google Drive. It is your permanent release signing key for all future app updates.

---

### Optional: Using Your Own Custom Keystore
If you already have a custom release keystore and want to use it instead of the auto-generated one, add these secrets under **Settings → Secrets and variables → Actions**:

| Secret Name | Value Description |
| :--- | :--- |
| `KEYSTORE_BASE64` | Base64-encoded string of your `.jks` file |
| `KEYSTORE_PASSWORD` | Password for your keystore |
| `KEY_ALIAS` | Key alias name (e.g., `upload`) |
| `KEY_PASSWORD` | Password for your private key |

---

## 4. Building Locally in Terminal or Android Studio

- **Build Release Bundle (.aab):**
  ```bash
  gradle :app:bundleRelease
  ```
  The generated bundle is located at:
  `app/build/outputs/bundle/release/app-release.aab`

- **Build Test APK (.apk):**
  ```bash
  gradle :app:assembleRelease
  ```
  The generated APK is located at:
  `app/build/outputs/apk/release/app-release.apk`
