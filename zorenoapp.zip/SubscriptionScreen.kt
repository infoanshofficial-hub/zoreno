package com.zoreno.app.ui.screens

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zoreno.app.billing.BillingManager

@Composable
fun SubscriptionScreen(
    userTier: Int,
    billingManager: BillingManager,
    onBack: () -> Unit
) {
    var selectedPlan by remember { mutableStateOf(if (userTier == 1) 2 else 1) }
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF080C14))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text("Zoreno Plans", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (userTier >= 2) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF10B981))
                    .padding(16.dp)
            ) {
                Text("Zoreno Pro Active ✓ (1 Month Plan)", color = Color.White, fontWeight = FontWeight.Bold)
            }
        } else {
            // Plus Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF151E32))
                    .border(2.dp, if (selectedPlan == 1) Color(0xFFA855F7) else Color.Transparent, RoundedCornerShape(20.dp))
                    .clickable { selectedPlan = 1 }
                    .padding(16.dp)
            ) {
                Column {
                    Text("₹249 / Month (Plus)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Expanded AI Usage Limits • 1 Month Validity", color = Color.Gray, fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Pro Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF151E32))
                    .border(2.dp, if (selectedPlan == 2) Color(0xFFA855F7) else Color.Transparent, RoundedCornerShape(20.dp))
                    .clickable { selectedPlan = 2 }
                    .padding(16.dp)
            ) {
                Column {
                    Text("₹349 / Month (Pro)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Maximum AI Limits • NVIDIA Voice • Vision AI", color = Color.Gray, fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = {
                    val activity = context as? Activity ?: return@Button
                    val sku = if (selectedPlan == 2) "zoreno_pro_monthly" else "zoreno_plus_monthly"
                    billingManager.launchSubscriptionFlow(activity, sku)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(26.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED))
            ) {
                Text(if (selectedPlan == 2) "Upgrade to Pro (₹349 / Month)" else "Upgrade to Plus (₹249 / Month)", fontWeight = FontWeight.Bold)
            }
        }
        Spacer(modifier = Modifier.height(80.dp))
    }
}
