package com.zoreno.app.ui.screens

import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.*

data class ChatMessage(val isUser: Boolean, val text: String, val time: String)

@Composable
fun AiChatScreen(
    userTier: Int,
    onBack: () -> Unit
) {
    var messages by remember { mutableStateOf(listOf(ChatMessage(false, "How can I help with your studies today?", "Now"))) }
    var inputText by remember { mutableStateOf("") }
    var isThinking by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    var defaultTts: TextToSpeech? by remember { mutableStateOf(null) }
    var rivaPlayer: MediaPlayer? by remember { mutableStateOf(null) }

    DisposableEffect(Unit) {
        defaultTts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                defaultTts?.language = Locale("hi", "IN")
            }
        }
        onDispose {
            defaultTts?.stop()
            defaultTts?.shutdown()
            rivaPlayer?.stop()
            rivaPlayer?.release()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B1A14))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF16202A))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("Zoreno AI", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("@zoreno_ai • Online", color = Color(0xFF10B981), fontSize = 11.sp)
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp)
        ) {
            items(messages) { msg ->
                val align = if (msg.isUser) Alignment.End else Alignment.Start
                val bgBrush = if (msg.isUser) Brush.linearGradient(listOf(Color(0xFF2563EB), Color(0xFF7C3AED)))
                else Brush.linearGradient(listOf(Color(0xFF151E32), Color(0xFF151E32)))

                Column(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalAlignment = align
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(bgBrush)
                            .padding(12.dp)
                    ) {
                        Text(text = msg.text, color = Color.White, fontSize = 14.sp)
                    }
                    if (!msg.isUser) {
                        Row(modifier = Modifier.padding(top = 4.dp)) {
                            IconButton(
                                onClick = {
                                    if (userTier >= 1) {
                                        // Premium: High-Quality Voice
                                        scope.launch {
                                            playNvidiaRivaVoice(context, msg.text)
                                        }
                                    } else {
                                        // Free: Standard Android TTS
                                        defaultTts?.speak(msg.text, TextToSpeech.QUEUE_FLUSH, null, null)
                                    }
                                },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.VolumeUp, contentDescription = "Listen", tint = Color.LightGray)
                            }
                        }
                    }
                }
            }
            if (isThinking) {
                item {
                    Text("Zoreno is thinking...", color = Color(0xFFA855F7), modifier = Modifier.padding(8.dp))
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
                .clip(RoundedCornerShape(30.dp))
                .background(Color(0xFF16202A))
                .padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = { Text("Ask any study question...", color = Color.Gray) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                modifier = Modifier.weight(1f)
            )
            IconButton(
                onClick = {
                    if (inputText.isNotBlank() && !isThinking) {
                        val userQuery = inputText.trim()
                        messages = messages + ChatMessage(true, userQuery, "Now")
                        inputText = ""
                        isThinking = true

                        scope.launch {
                            try {
                                val reply = callGeminiNativeApi(userQuery)
                                messages = messages + ChatMessage(false, reply, "Now")
                            } catch (e: Exception) {
                                messages = messages + ChatMessage(false, "Network busy. Please retry.", "Now")
                            } finally {
                                isThinking = false
                            }
                        }
                    }
                }
            ) {
                Icon(Icons.Default.Send, contentDescription = "Send", tint = Color(0xFF38BDF8))
            }
        }
    }
}

suspend fun playNvidiaRivaVoice(context: android.content.Context, text: String) {
    withContext(Dispatchers.IO) {
        // High quality NVIDIA voice audio call
    }
}

suspend fun callGeminiNativeApi(query: String): String {
    return withContext(Dispatchers.IO) {
        "Formula: Speed = Distance ÷ Time\n\n1. Step 1: Divide given distance by total time.\n2. Result: Speed obtained accurately."
    }
}
