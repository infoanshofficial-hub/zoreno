package com.zoreno.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ZorenoBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try {
            context.startService(Intent(context, ZorenoBgNotifService::class.java))
        } catch (_: Exception) {}
    }
}
