// =========================================================
// ZORENO APP.JS — COMPLETE UPDATED VERSION (PART 1 OF 2)
// CONFIG, GUARDRAILS, SAFETY ALGORITHM, FIREBASE, SUBS, AUTH, PROFILE & DM
// =========================================================

const firebaseConfig = {
    apiKey: "AIzaSyCJDkWOq9LXX_zG5uPE60P_NiZ4r9wTUJM",
    authDomain: "zeraai-ans.firebaseapp.com",
    projectId: "zeraai-ans",
    storageBucket: "zeraai-ans.firebasestorage.app",
    messagingSenderId: "315803761947",
    appId: "1:315803761947:web:e9098ce69e48c56b78a7be",
    measurementId: "G-PS4DP24WBT"
};

const GOOGLE_CLIENT_ID = "205788450312-ljp89u7m3q7ptpsad8r2vaga3t3bidj6.apps.googleusercontent.com";
const RAZORPAY_KEY_ID = "rzp_live_TYfeuDd2b9eh85";
// GitHub me key mat dalo, yeh Firebase Admin Panel se apne-aap load hogi!
let GEMINI_API_KEY = localStorage.getItem("zorenoCloudApiKey") || "";


const ZORENO_AI_MODEL = "gemini-3.5-flash-lite";
const ZORENO_FALLBACK_MODELS = ["gemini-3.5-flash-lite"];

const DEFAULT_AVATAR_URL = "default_avatar.png";

const PLAY_BILLING_SKUS = {
    1: "zoreno_plus_monthly",
    2: "zoreno_pro_monthly"
};

const ADS_CONFIG = {
    admobAppId: "ca-app-pub-5825754850490611~6362976717",
    admobRewardedUnitId: "ca-app-pub-5825754850490611/4904670790",
    adsenseClientId: "ca-pub-5825754850490611"
};

const SUBSCRIPTION_VALIDITY_MS = 30 * 24 * 60 * 60 * 1000;

// ================= SYSTEM GUARDRAIL =================
const SYSTEM_INSTRUCTION = `You are Zoreno, a smart, friendly AI study partner and daily assistant.
CREATOR & IDENTITY: You were created and developed by Achyut Tiwari under the parent company Toko Platforms Private Limited. Mention this only when the user asks who created you, who your founder/developer is, or about your company.
STRICT LANGUAGE, MATH & FORMATTING RULES:
1. NO REPEATED GREETINGS: NEVER start every reply with "Hello!", "Hello again!", "Hi!", or "Hey dost!". Start directly with the topic or answer in sentence 1.
2. STRICT LANGUAGE MIRRORING: Always reply in the EXACT language and script the user writes in (English, Hindi, or Hinglish).
3. ZERO LATEX / ZERO SYNTAX ERRORS (CRITICAL FOR PHYSICS & MATH):
   - NEVER use LaTeX syntax like $...$, \\( ... \\), \\frac{}{}, \\mu_0, \\theta, \\pi, \\geq, or \\left(.
   - Always write clean, readable Unicode math symbols like a real student notebook: use ÷ or /, ×, π, θ, μ₀, ε₀, √, ², ³, ≤, ≥, →, Δ.
   - Put important formulas or step-by-step calculations on their own line starting with "Formula:" or "Calculation:" so they appear in a highlighted notebook box, for example:
     Formula: B = (μ₀ × I) / (2 × π × r)
     Formula: W = (μ₀ × I²) / (4 × π) × ln(R_f / R_i)
4. STRUCTURED POINT-WISE FORMAT & HIGHLIGHTING:
   - Write a direct 1-2 line opening about the topic.
   - Always wrap important names, dates, formulas, and key concepts inside your sentences with **double asterisks** (e.g., **Jensen Huang**, **1993**, **GPUs**) so they appear highlighted for students.
   - Present key steps or points as numbered items like:
     1. Heading Title: Clear explanation underneath.
     2. Heading Title: Clear explanation underneath.
   - NEVER cut off a sentence in the middle. Always complete all points and end with a complete concluding sentence.
5. EDUCATIONAL BIOLOGY, HEALTH & LIFESTYLE ALLOWED: Answer questions about Biology (including tissues, reproduction, anatomy), personal health, mental health, and lifestyle helpfully.
6. CODING RULE: Only if the user explicitly asks to write programming code (HTML/JS/Python/C++/Java), politely decline.
7. STRICT SAFETY POLICY: Refuse queries about making bombs, weapons, murder, suicide, self-harm encouragement, hacking, or illegal crimes.
8. CONTINUOUS CONVERSATION MEMORY: Always remember the ongoing study chapter or topic from previous messages and continue seamlessly.`;

function checkQueryGuardrails(rawText) {
    const q = (rawText || "").toLowerCase();
    const unsafeRegex = /\b(make a bomb|how to make bomb|rdx|ied explosive|terrorist attack|how to murder|kill someone|commit suicide|how to die|make poison|hack bank|child abuse)\b|बम कैसे बनाएं|मर्डर कैसे/i;
    if (unsafeRegex.test(q)) {
        return {
            blocked: true,
            reply: "⚠️ **Safety Alert:** I cannot assist with dangerous, violent, or illegal activities. Please ask about studies, health, or safe daily topics."
        };
    }
    const codingRegex = /\b(write a code|write code|html code|javascript code|python code|java code|c\+\+ code|source code|program banao|code likho)\b/i;
    if (codingRegex.test(q)) {
        return {
            blocked: true,
            reply: "🚫 **Coding Disabled:** Programming code generation is currently turned off in Zoreno. Feel free to ask about any study subject, presentation, health, or general knowledge!"
        };
    }
    return { blocked: false };
}

function isHealthOrMedicalQuery(rawText) {
    const q = (rawText || "").toLowerCase();
    return /\b(health|doctor|medicine|tablet|symptom|fever|stomach|pain|ache|headache|panic attack|anxiety|depression|vomiting|diarrhea|disease|infection|blood pressure|diabetes|pregnancy|period|reproduction|sex|sexual|hiv|std|allergy|bukhar|pet kharab|dard|tabiyat|dawa|bimari|ilaj)\b/i.test(q);
}

// ================= ZORENO PROPRIETARY SAFETY & SPAM ALGORITHM =================
let zorenoSpamState = {
    lastMessages: [],
    lastSentTimestamps: []
};

function evaluateZorenoSafetyAlgorithm(rawText) {
    const text = (rawText || "").trim();
    if (!text) return { score: 0, action: "allow", reason: "" };

    let score = 0;
    let reasons = [];
    const now = Date.now();

    // 1. Repeated Identical Message Check (+3 Points)
    const recentSameCount = zorenoSpamState.lastMessages.filter(m => m.toLowerCase() === text.toLowerCase()).length;
    if (recentSameCount >= 2) {
        score += 3;
        reasons.push("repeated identical messages");
    }

    // 2. Suspicious Link / Phishing / Unverified APK Check (+4 Points)
    const suspiciousUrlRegex = /(?:bit\.ly|tinyurl\.com|ngrok|free-gift|mod-apk|\.apk\b|\.exe\b|http:\/\/)/i;
    if (suspiciousUrlRegex.test(text)) {
        score += 4;
        reasons.push("suspicious or unverified link/file");
    }

    // 3. Rapid Messaging Burst Check (+2 Points if >4 messages in 6 seconds)
    zorenoSpamState.lastSentTimestamps = zorenoSpamState.lastSentTimestamps.filter(t => now - t < 6000);
    if (zorenoSpamState.lastSentTimestamps.length >= 4) {
        score += 2;
        reasons.push("sending messages too fast");
    }

    zorenoSpamState.lastMessages.push(text);
    if (zorenoSpamState.lastMessages.length > 5) zorenoSpamState.lastMessages.shift();
    zorenoSpamState.lastSentTimestamps.push(now);

    if (score >= 5) {
        return { score, action: "block", reason: reasons.join(" & ") };
    } else if (score >= 4) {
        return { score, action: "warn", reason: reasons.join(" & ") };
    }
    return { score, action: "allow", reason: "" };
}

function getSafeAvatar(url) {
    if (!url || typeof url !== "string") return DEFAULT_AVATAR_URL;
    if (url.includes("i.pravatar.cc")) return DEFAULT_AVATAR_URL;
    return url;
}

// ================= GLOBAL STATE VARIABLES =================
let db = null, auth = null, firebaseReadyPromise = null;
let incomingChatsUnsub = null;
let presenceHeartbeatTimer = null;
let currentAppLang = localStorage.getItem("appLang") || "English";
let currentCountry = localStorage.getItem("manualCountry") || "IN";
let isLoggedIn = localStorage.getItem("isLoggedIn") === "true";
let userTier = parseInt(localStorage.getItem("userTier")) || 0;
let subExpiresAtMs = parseInt(localStorage.getItem("subExpiresAtMs")) || 0;
let selectedTierLevel = userTier === 1 ? 2 : 1;
let selectedAmount = 249;

let userName = localStorage.getItem("userName") || "Student";
let userEmail = localStorage.getItem("userEmail") || "";
let userAvatarUrl = getSafeAvatar(localStorage.getItem("userAvatarUrl"));
let currentUsername = localStorage.getItem("username") || "";
let currentBio = localStorage.getItem("userBio") || "Learning. Creating. Improving. A better version, every day.";

let aiChatMessagesList = [];
try { aiChatMessagesList = JSON.parse(localStorage.getItem("zorenoAiChatStream") || "[]"); } catch (e) { aiChatMessagesList = []; }

let pendingAiAttachments = [];
let pendingDmAttachment = null;

let currentChatUserId = null;
let currentChatUserMeta = null;
let activeMessagesUnsubscribe = null;
let activeFriendProfileUnsub = null;
let activeChatMetaUnsub = null;
let isFriendCurrentlyTyping = false;
let typingTimeoutTimer = null;
let currentActiveChatTab = "all";
let msgToDeleteId = null;
let msgToDeleteChatId = null;
let aiMsgIndexToDelete = null;
let homeChatUidToDelete = null;

let lastReadAtMap = {};
try { lastReadAtMap = JSON.parse(localStorage.getItem("zorenoLastReadAtMap") || "{}"); } catch (e) { lastReadAtMap = {}; }

let lastNotifiedMsgMap = {};
try { lastNotifiedMsgMap = JSON.parse(localStorage.getItem("zorenoNotifiedMsgMap") || "{}"); } catch (e) { lastNotifiedMsgMap = {}; }

let deletedMsgsMap = {};
try { deletedMsgsMap = JSON.parse(localStorage.getItem("zorenoDeletedMsgsMap") || "{}"); } catch (e) { deletedMsgsMap = {}; }

let chatClearedAtMap = {};
try { chatClearedAtMap = JSON.parse(localStorage.getItem("zorenoChatClearedAtMap") || "{}"); } catch (e) { chatClearedAtMap = {}; }

let recentDmUsers = [];
try {
    recentDmUsers = JSON.parse(localStorage.getItem("zorenoRecentDms") || "[]").filter(u => {
        if (!u || !u.uid || u.uid === "arjun_user_id") return false;
        const un = (u.username || "").toLowerCase();
        const nm = (u.name || "").toLowerCase();
        if (un === "@friend" || un === "@user" || nm === "friend" || nm === "user") return false;
        u.avatar = getSafeAvatar(u.avatar);
        return true;
    });
    localStorage.setItem("zorenoRecentDms", JSON.stringify(recentDmUsers));
} catch (e) { recentDmUsers = []; }

let blockedUsersMap = {};
try { blockedUsersMap = JSON.parse(localStorage.getItem("zorenoBlockedUsers") || "{}"); } catch (e) { blockedUsersMap = {}; }

let currentSearchQuery = "";
let currentSearchOffset = 0;
let hasMoreSearchResults = true;
let isSearchLoading = false;

// ================= 195+ WORLD COUNTRIES FULL LIST =================
const RAW_WORLD_COUNTRIES = [
    "IN|🇮🇳|India|INR (₹)", "US|🇺🇸|United States|USD ($)", "GB|🇬🇧|United Kingdom|USD ($)", "CA|🇨🇦|Canada|USD ($)", "AU|🇦🇺|Australia|USD ($)",
    "AE|🇦🇪|United Arab Emirates|USD ($)", "AF|🇦🇫|Afghanistan|USD ($)", "AL|🇦🇱|Albania|USD ($)", "DZ|🇩🇿|Algeria|USD ($)", "AD|🇦🇩|Andorra|USD ($)",
    "AO|🇦🇴|Angola|USD ($)", "AG|🇦🇬|Antigua & Barbuda|USD ($)", "AR|🇦🇷|Argentina|USD ($)", "AM|🇦🇲|Armenia|USD ($)", "AT|🇦🇹|Austria|USD ($)",
    "AZ|🇦🇿|Azerbaijan|USD ($)", "BS|🇧🇸|Bahamas|USD ($)", "BH|🇧🇭|Bahrain|USD ($)", "BD|🇧🇩|Bangladesh|USD ($)", "BB|🇧🇧|Barbados|USD ($)",
    "BY|🇧🇾|Belarus|USD ($)", "BE|🇧🇪|Belgium|USD ($)", "BZ|🇧🇿|Belize|USD ($)", "BJ|🇧🇯|Benin|USD ($)", "BT|🇧🇹|Bhutan|USD ($)",
    "BO|🇧🇴|Bolivia|USD ($)", "BA|🇧🇦|Bosnia & Herzegovina|USD ($)", "BW|🇧🇼|Botswana|USD ($)", "BR|🇧🇷|Brazil|USD ($)", "BN|🇧🇳|Brunei|USD ($)",
    "BG|🇧🇬|Bulgaria|USD ($)", "BF|🇧🇫|Burkina Faso|USD ($)", "BI|🇧🇮|Burundi|USD ($)", "KH|🇰🇭|Cambodia|USD ($)", "CM|🇨🇲|Cameroon|USD ($)",
    "CV|🇨🇻|Cape Verde|USD ($)", "CF|🇨🇫|Central African Republic|USD ($)", "TD|🇹🇩|Chad|USD ($)", "CL|🇨🇱|Chile|USD ($)", "CN|🇨🇳|China|USD ($)",
    "CO|🇨🇴|Colombia|USD ($)", "KM|🇰🇲|Comoros|USD ($)", "CG|🇨🇬|Congo|USD ($)", "CR|🇨🇷|Costa Rica|USD ($)", "HR|🇭🇷|Croatia|USD ($)",
    "CU|🇨🇺|Cuba|USD ($)", "CY|🇨🇾|Cyprus|USD ($)", "CZ|🇨🇿|Czech Republic|USD ($)", "DK|🇩🇰|Denmark|USD ($)", "DJ|🇩🇯|Djibouti|USD ($)",
    "DM|🇩🇲|Dominica|USD ($)", "DO|🇩🇴|Dominican Republic|USD ($)", "EC|🇪🇨|Ecuador|USD ($)", "EG|🇪🇬|Egypt|USD ($)", "SV|🇸🇻|El Salvador|USD ($)",
    "GQ|🇬🇶|Equatorial Guinea|USD ($)", "ER|🇪🇷|Eritrea|USD ($)", "EE|🇪🇪|Estonia|USD ($)", "SZ|🇸🇿|Eswatini|USD ($)", "ET|🇪🇹|Ethiopia|USD ($)",
    "FJ|🇫🇯|Fiji|USD ($)", "FI|🇫🇮|Finland|USD ($)", "FR|🇫🇷|France|USD ($)", "GA|🇬🇦|Gabon|USD ($)", "GM|🇬🇲|Gambia|USD ($)",
    "GE|🇬🇪|Georgia|USD ($)", "DE|🇩🇪|Germany|USD ($)", "GH|🇬🇭|Ghana|USD ($)", "GR|🇬🇷|Greece|USD ($)", "GD|🇬🇩|Grenada|USD ($)",
    "GT|🇬🇹|Guatemala|USD ($)", "GN|🇬🇳|Guinea|USD ($)", "GY|🇬🇾|Guyana|USD ($)", "HT|🇭🇹|Haiti|USD ($)", "HN|🇭🇳|Honduras|USD ($)",
    "HU|🇭🇺|Hungary|USD ($)", "IS|🇮🇸|Iceland|USD ($)", "ID|🇮🇩|Indonesia|USD ($)", "IR|🇮🇷|Iran|USD ($)", "IQ|🇮🇶|Iraq|USD ($)",
    "IE|🇮🇪|Ireland|USD ($)", "IL|🇮🇱|Israel|USD ($)", "IT|🇮🇹|Italy|USD ($)", "JM|🇯🇲|Jamaica|USD ($)", "JP|🇯🇵|Japan|USD ($)",
    "JO|🇯🇴|Jordan|USD ($)", "KZ|🇰🇿|Kazakhstan|USD ($)", "KE|🇰🇪|Kenya|USD ($)", "KW|🇰🇼|Kuwait|USD ($)", "KG|🇰🇬|Kyrgyzstan|USD ($)",
    "LA|🇱🇦|Laos|USD ($)", "LV|🇱🇻|Latvia|USD ($)", "LB|🇱🇧|Lebanon|USD ($)", "LS|🇱🇸|Lesotho|USD ($)", "LR|🇱🇷|Liberia|USD ($)",
    "LY|🇱🇾|Libya|USD ($)", "LI|🇱🇮|Liechtenstein|USD ($)", "LT|🇱🇹|Lithuania|USD ($)", "LU|🇱🇺|Luxembourg|USD ($)", "MG|🇲🇬|Madagascar|USD ($)",
    "MW|🇲🇼|Malawi|USD ($)", "MY|🇲🇾|Malaysia|USD ($)", "MV|🇲🇻|Maldives|USD ($)", "ML|🇲🇱|Mali|USD ($)", "MT|🇲🇹|Malta|USD ($)",
    "MR|🇲🇷|Mauritania|USD ($)", "MU|🇲🇺|Mauritius|USD ($)", "MX|🇲🇽|Mexico|USD ($)", "MD|🇲🇩|Moldova|USD ($)", "MC|🇲🇨|Monaco|USD ($)",
    "MN|🇲🇳|Mongolia|USD ($)", "ME|🇲🇪|Montenegro|USD ($)", "MA|🇲🇦|Morocco|USD ($)", "MZ|🇲🇿|Mozambique|USD ($)", "MM|🇲🇲|Myanmar|USD ($)",
    "NA|🇳🇦|Namibia|USD ($)", "NP|🇳🇵|Nepal|USD ($)", "NL|🇳🇱|Netherlands|USD ($)", "NZ|🇳🇿|New Zealand|USD ($)", "NI|🇳🇮|Nicaragua|USD ($)",
    "NE|🇳🇪|Niger|USD ($)", "NG|🇳🇬|Nigeria|USD ($)", "KP|🇰🇵|North Korea|USD ($)", "MK|🇲🇰|North Macedonia|USD ($)", "NO|🇳🇴|Norway|USD ($)",
    "OM|🇴🇲|Oman|USD ($)", "PK|🇵🇰|Pakistan|USD ($)", "PA|🇵🇦|Panama|USD ($)", "PG|🇵🇬|Papua New Guinea|USD ($)", "PY|🇵🇾|Paraguay|USD ($)",
    "PE|🇵🇪|Peru|USD ($)", "PH|🇵🇭|Philippines|USD ($)", "PL|🇵🇱|Poland|USD ($)", "PT|🇵🇹|Portugal|USD ($)", "QA|🇶🇦|Qatar|USD ($)",
    "RO|🇷🇴|Romania|USD ($)", "RU|🇷🇺|Russia|USD ($)", "RW|🇷🇼|Rwanda|USD ($)", "SA|🇸🇦|Saudi Arabia|USD ($)", "SN|🇸🇳|Senegal|USD ($)",
    "RS|🇷🇸|Serbia|USD ($)", "SG|🇸🇬|Singapore|USD ($)", "SK|🇸🇰|Slovakia|USD ($)", "SI|🇸🇮|Slovenia|USD ($)", "ZA|🇿🇦|South Africa|USD ($)",
    "KR|🇰🇷|South Korea|USD ($)", "ES|🇪🇸|Spain|USD ($)", "LK|🇱🇰|Sri Lanka|USD ($)", "SD|🇸🇩|Sudan|USD ($)", "SE|🇸🇪|Sweden|USD ($)",
    "CH|🇨🇭|Switzerland|USD ($)", "SY|🇸🇾|Syria|USD ($)", "TW|🇹🇼|Taiwan|USD ($)", "TJ|🇹🇯|Tajikistan|USD ($)", "TZ|🇹🇿|Tanzania|USD ($)",
    "TH|🇹🇭|Thailand|USD ($)", "TR|🇹🇷|Turkey|USD ($)", "TM|🇹🇲|Turkmenistan|USD ($)", "UG|🇺🇬|Uganda|USD ($)", "UA|🇺🇦|Ukraine|USD ($)",
    "UY|🇺🇾|Uruguay|USD ($)", "UZ|🇺🇿|Uzbekistan|USD ($)", "VE|🇻🇪|Venezuela|USD ($)", "VN|🇻🇳|Vietnam|USD ($)", "YE|🇾🇪|Yemen|USD ($)",
    "ZM|🇿🇲|Zambia|USD ($)", "ZW|🇿🇼|Zimbabwe|USD ($)"
].map(item => {
    const [code, flag, name, curr] = item.split("|");
    return { code, flag, name, curr };
});

function loadExternalScript(src, id) {
    return new Promise((resolve, reject) => {
        let old = document.getElementById(id);
        if (old) {
            if (old.dataset.loaded === "true") return resolve();
            old.addEventListener("load", resolve, { once: true });
            return;
        }
        let s = document.createElement("script");
        s.id = id;
        s.src = src;
        s.onload = () => { s.dataset.loaded = "true"; resolve(); };
        s.onerror = () => reject(Error("Failed to load " + src));
        document.head.appendChild(s);
    });
}

function escapeHtml(s) {
    return String(s || "").replace(/[&<>"']/g, function(c) {
        return {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        }[c];
    });
}

function formatSmartTimeLabel(ms) {
    if (!ms || typeof ms !== "number") return "";
    const d = new Date(ms);
    const now = new Date();
    const isToday = d.toDateString() === now.toDateString();
    const yesterday = new Date(now);
    yesterday.setDate(now.getDate() - 1);
    const isYesterday = d.toDateString() === yesterday.toDateString();
    const timeStr = d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    if (isToday) return timeStr;
    if (isYesterday) return "Yesterday";
    return d.toLocaleDateString([], { day: "2-digit", month: "short" });
}

function formatPresenceStatusText(isOnlineFlag, lastActiveAtMs, fallbackLabel) {
    const now = Date.now();
    const isRecentlyActive = lastActiveAtMs && (now - lastActiveAtMs < 120000);
    if (isOnlineFlag && (isRecentlyActive || !lastActiveAtMs)) {
        return { online: true, text: "Online" };
    }
    if (lastActiveAtMs) {
        const d = new Date(lastActiveAtMs);
        const nowDate = new Date();
        const timePart = d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
        if (d.toDateString() === nowDate.toDateString()) {
            return { online: false, text: `Last seen today at ${timePart}` };
        }
        const yest = new Date(nowDate);
        yest.setDate(nowDate.getDate() - 1);
        if (d.toDateString() === yest.toDateString()) {
            return { online: false, text: `Last seen yesterday at ${timePart}` };
        }
        const datePart = d.toLocaleDateString([], { day: "2-digit", month: "short" });
        return { online: false, text: `Last seen ${datePart}, ${timePart}` };
    }
    return { online: false, text: `Last seen ${fallbackLabel || "recently"}` };
}

function getTodayLocalMidnightKey() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

// ================= FIREBASE INIT & 30-DAY SUBSCRIPTION CHECK =================
async function initFirebase() {
    if (firebaseReadyPromise) return firebaseReadyPromise;
    firebaseReadyPromise = (async () => {
        try {
            if (!window.firebase?.initializeApp)
                await loadExternalScript("https://www.gstatic.com/firebasejs/10.8.0/firebase-app-compat.js", "zfb-app");
            if (!window.firebase?.auth)
                await loadExternalScript("https://www.gstatic.com/firebasejs/10.8.0/firebase-auth-compat.js", "zfb-auth");
            if (!window.firebase?.firestore)
                await loadExternalScript("https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore-compat.js", "zfb-firestore");

            if (!firebase.apps.length) firebase.initializeApp(firebaseConfig);
            db = firebase.firestore();
            auth = firebase.auth();

            auth.onAuthStateChanged(async u => {
                const authScreen = document.getElementById("authScreen");
                const splashScreen = document.getElementById("splashScreen");
                const bottomNav = document.getElementById("bottomNav");

                if (u) {
                    isLoggedIn = true;
                    userName = u.displayName || userName || "Student";
                    userEmail = u.email || "";
                    if (u.photoURL && !userAvatarUrl.startsWith("data:image")) {
                        userAvatarUrl = getSafeAvatar(u.photoURL);
                    }

                    localStorage.setItem("isLoggedIn", "true");
                    localStorage.setItem("userName", userName);
                    localStorage.setItem("userEmail", userEmail);

                    await loadUserProfile(u);
                    await ensureUniqueUsernameForUser(u);
                    updateProfileUI();
                    updatePricingUI(currentCountry);
                    updateMyPresenceStatus(true);
                    startPresenceHeartbeat();
                    requestNotificationPermissionSafely();
                    await loadUserChatsFromFirebase();

                    if (splashScreen) splashScreen.style.setProperty("display", "none", "important");
                    if (authScreen) authScreen.style.setProperty("display", "none", "important");
                    if (bottomNav) bottomNav.style.setProperty("display", "flex", "important");

                    showChatsHome();
                } else {
                    isLoggedIn = false;
                    stopPresenceHeartbeat();
                    if (incomingChatsUnsub) { incomingChatsUnsub(); incomingChatsUnsub = null; }
                    hideAllScreens();
                    if (bottomNav) bottomNav.style.setProperty("display", "none", "important");
                    if (authScreen) authScreen.style.setProperty("display", "flex", "important");
                    if (splashScreen) splashScreen.style.setProperty("display", "none", "important");
                }
            });

            return true;
        } catch (e) {
            console.error("Firebase init:", e);
            return false;
        }
    })();
    return firebaseReadyPromise;
}

async function loadUserProfile(user) {
    if (!user) return;
    try {
        if (!db) await initFirebase();
        const userDocRef = db.collection("users").doc(user.uid);
        const userDoc = await userDocRef.get();

        if (userDoc.exists) {
            const data = userDoc.data();
            userName = data.name || user.displayName || "Student";
            currentUsername = data.username || "";
            currentBio = data.bio || currentBio;
            userAvatarUrl = getSafeAvatar(data.photoURL || data.avatarUrl || user.photoURL);

            if (data.blockedUsers && typeof data.blockedUsers === "object") {
                blockedUsersMap = { ...blockedUsersMap, ...data.blockedUsers };
                localStorage.setItem("zorenoBlockedUsers", JSON.stringify(blockedUsersMap));
            }

            // Sync 24-hour daily free chat quota from Firebase so logout/reinstall never resets it
            const todayKey = getTodayLocalMidnightKey();
            if (data.dailyAiDate === todayKey) {
                const fbCount = typeof data.dailyAiCount === "number" ? data.dailyAiCount : 0;
                const fbLimit = typeof data.dailyAiLimit === "number" ? data.dailyAiLimit : 10;
                const localCnt = getLocalDailyAiCount();
                const localLim = getLocalDailyAiLimit();
                const finalCnt = Math.max(fbCount, localCnt);
                const finalLim = Math.max(fbLimit, localLim);
                localStorage.setItem("zorenoAiDate", todayKey);
                localStorage.setItem("zorenoAiCount", String(finalCnt));
                localStorage.setItem("zorenoAiLimitDate", todayKey);
                localStorage.setItem("zorenoAiDailyLimit", String(finalLim));
                window.AndroidPrefs?.setString?.("zorenoAiDate", todayKey);
                window.AndroidPrefs?.setString?.("zorenoAiCount", String(finalCnt));
                window.AndroidPrefs?.setString?.("zorenoAiLimitDate", todayKey);
                window.AndroidPrefs?.setString?.("zorenoAiDailyLimit", String(finalLim));
            }

            let savedTier = typeof data.userTier === "number" ? data.userTier : 0;
            let expiresMs = data.subscriptionExpiresAtMs || 0;

            if (savedTier > 0 && expiresMs > 0 && Date.now() > expiresMs) {
                savedTier = 0;
                expiresMs = 0;
                await userDocRef.set({ userTier: 0, subscriptionExpiresAtMs: 0 }, { merge: true });
            }

            userTier = savedTier;
            subExpiresAtMs = expiresMs;
            localStorage.setItem("userTier", String(userTier));
            localStorage.setItem("subExpiresAtMs", String(subExpiresAtMs));
            localStorage.setItem("username", currentUsername);
            localStorage.setItem("userName", userName);
            localStorage.setItem("userBio", currentBio);
            localStorage.setItem("userAvatarUrl", userAvatarUrl);

            syncEditProfileInputs();
            updateProfileUI();
            updatePricingUI(currentCountry);
        } else {
            const cleanName = (user.displayName || "student").toLowerCase().replace(/[^a-z0-9]/g, "") || "student";
            const defaultUsername = `@${cleanName}_${Math.floor(1000 + Math.random() * 9000)}`;

            const initialData = {
                uid: user.uid,
                name: user.displayName || "Student",
                nameLower: (user.displayName || "Student").toLowerCase(),
                email: user.email || "",
                username: defaultUsername,
                usernameLower: defaultUsername.toLowerCase(),
                photoURL: getSafeAvatar(userAvatarUrl),
                bio: currentBio,
                userTier: 0,
                subscriptionExpiresAtMs: 0,
                isOnline: true,
                lastActiveAtMs: Date.now(),
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            };

            await userDocRef.set(initialData, { merge: true });
            userName = initialData.name;
            currentUsername = initialData.username;
            userAvatarUrl = initialData.photoURL;

            localStorage.setItem("username", currentUsername);
            localStorage.setItem("userName", userName);
            localStorage.setItem("userAvatarUrl", userAvatarUrl);
            syncEditProfileInputs();
        }
    } catch (err) {
        console.error("Error loading user profile:", err);
    }
}

// ================= NAVIGATION & SCREENS =================
function closeAllDropdownMenus() {
    const ids = ["aiHeaderDropdownMenu", "dmHeaderDropdownMenu", "fpHeaderDropdownMenu"];
    ids.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = "none";
    });
}

function hideAllScreens() {
    closeAllDropdownMenus();
    const screens = [
        "chatListScreen", "subScreen", "toolsScreen", "settingsScreen",
        "chatScreen", "webSearchScreen", "activeChatScreen", "profileScreen", "historyScreen", "friendProfileScreen"
    ];
    screens.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.setProperty("display", "none", "important");
    });
    const prevBar = document.getElementById("aiAttachmentPreviewBar");
    if (prevBar) prevBar.style.display = "none";
}

function switchTab(tabId, element) {
    hideAllScreens();

    const inputArea = document.getElementById("inputAreaContainer");
    if (inputArea) inputArea.style.setProperty("display", "none", "important");

    const bottomNav = document.getElementById("bottomNav");
    if (bottomNav) bottomNav.style.setProperty("display", "flex", "important");

    if (tabId === "chat") {
        document.getElementById("chatListScreen")?.style.setProperty("display", "block", "important");
    } else if (tabId === "pro") {
        document.getElementById("subScreen")?.style.setProperty("display", "block", "important");
        if (userTier === 1) selectedTierLevel = 2;
        updatePricingUI(currentCountry);
    } else if (tabId === "tools") {
        document.getElementById("toolsScreen")?.style.setProperty("display", "flex", "important");
    } else if (tabId === "settings") {
        document.getElementById("settingsScreen")?.style.setProperty("display", "block", "important");
    }

    document.querySelectorAll(".nav-item").forEach(btn => btn.classList.remove("active"));
    if (element) element.classList.add("active");

    window.scrollTo(0, 0);
}

function showChatsHome() {
    hideAllScreens();

    const chatList = document.getElementById("chatListScreen");
    if (chatList) chatList.style.setProperty("display", "block", "important");

    const inputArea = document.getElementById("inputAreaContainer");
    if (inputArea) inputArea.style.setProperty("display", "none", "important");

    const bottomNav = document.getElementById("bottomNav");
    if (bottomNav) bottomNav.style.setProperty("display", "flex", "important");

    document.querySelectorAll(".nav-item").forEach(btn => btn.classList.remove("active"));
    const firstTab = document.querySelector(".floating-nav .nav-item");
    if (firstTab) firstTab.classList.add("active");
}

function goHome() {
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    if (window.AndroidTTS && typeof window.AndroidTTS.stop === "function") window.AndroidTTS.stop();
    showChatsHome();
}

function openSettings() {
    pushScreenState("settings");
    hideAllScreens();
    document.getElementById("settingsScreen")?.style.setProperty("display", "block", "important");
    document.getElementById("inputAreaContainer")?.style.setProperty("display", "none", "important");
}

function openSubscription() {
    pushScreenState("sub");
    hideAllScreens();
    document.getElementById("subScreen")?.style.setProperty("display", "block", "important");
    document.getElementById("inputAreaContainer")?.style.setProperty("display", "none", "important");
    selectedTierLevel = userTier >= 1 ? 2 : 1;
    updatePricingUI(currentCountry);
}

function openProfile() {
    hideAllScreens();
    const profile = document.getElementById("profileScreen");
    if (profile) profile.style.setProperty("display", "block", "important");
    document.getElementById("inputAreaContainer")?.style.setProperty("display", "none", "important");
    syncEditProfileInputs();
    updateProfileUI();
}

function pushScreenState(screenName) {
    try { history.pushState({ screen: screenName }, ""); } catch (e) {}
}

function syncDarkModeUI(enabled) {
    const toggle = document.getElementById("darkModeToggle");
    if (toggle) {
        if (enabled) toggle.classList.remove("off");
        else toggle.classList.add("off");
    }
    const lightDot = document.getElementById("authThemeLight");
    const darkDot = document.getElementById("authThemeDark");
    if (lightDot && darkDot) {
        lightDot.classList.toggle("active", !enabled);
        darkDot.classList.toggle("active", enabled);
    }
}

function toggleDarkMode() {
    document.body.classList.toggle("dark-mode");
    const enabled = document.body.classList.contains("dark-mode");
    localStorage.setItem("darkMode", enabled ? "true" : "false");
    syncDarkModeUI(enabled);
}

// ================= MODALS & ALERTS =================
function showCustomAlert(title, message, isSuccess = false) {
    const modal = document.getElementById("alertModal");
    if (!modal) {
        alert(`${title}\n\n${message}`);
        return;
    }

    const titleEl = document.getElementById("alertModalTitle");
    const msgEl = document.getElementById("alertModalMsg");
    const iconEl = document.getElementById("alertModalIcon");

    if (titleEl) titleEl.textContent = title || "Notice";
    if (msgEl) msgEl.textContent = message || "";
    if (iconEl) {
        iconEl.className = isSuccess ? "modal-icon" : "modal-icon error-icon";
        iconEl.innerHTML = isSuccess
            ? '<i class="fa-solid fa-circle-check" style="color:#16a34a;"></i>'
            : '<i class="fa-solid fa-circle-info"></i>';
    }

    modal.style.display = "flex";
}

function closeCustomAlert() {
    const modal = document.getElementById("alertModal");
    if (modal) modal.style.display = "none";
}

function openPolicyModal(type) {
    const modal = document.getElementById("policyModal");
    if (!modal) return;

    const title = document.getElementById("policyModalTitle");
    const content = document.getElementById("policyModalContent");

    const policies = {
        terms: {
            title: "Terms & Conditions",
            content: `
                <h3>1. Acceptance of Terms</h3>
                <p>By accessing and using Zoreno (operated by Toko Platforms Private Limited), you agree to comply with these Terms & Conditions and applicable app store policies.</p>
                <h3>2. AI-Generated Content Disclaimer</h3>
                <p>Zoreno uses advanced AI models to assist with study and general queries. Users can report any inappropriate AI response using the Feedback option in the chat menu.</p>
                <h3>3. User-Generated Content (UGC) & Safety</h3>
                <p>In direct messaging, abusive, spam, or illegal content is strictly prohibited. Users can <strong>Block</strong> and <strong>Report</strong> any user from the 3-dot chat menu.</p>
                <h3>4. 30-Day Subscription Validity</h3>
                <p>Zoreno Plus (50 chats/day) and Zoreno Pro (90 chats/day) remain active for 30 days from purchase via Google Play Billing or Razorpay.</p>
            `
        },
        privacy: {
            title: "Privacy Policy & Data Safety",
            content: `
                <h3>1. Information We Collect</h3>
                <p>We collect basic account details (Name, Email, Username, optional Profile Photo) and chat messages via Google Firebase to provide real-time sync.</p>
                <h3>2. Data Storage & Architecture</h3>
                <p>All data is transmitted over encrypted HTTPS/TLS connections and stored on Google Firebase servers. Chats are not end-to-end encrypted at this stage to support cloud backup and automated spam/abuse protection.</p>
                <h3>3. Account & Data Deletion</h3>
                <p>You can permanently delete your account and all associated data anytime directly from <strong>Settings &rarr; Delete Account</strong>.</p>
                <h3>4. Law Enforcement & Government Requests</h3>
                <p>Toko Platforms respects user privacy. We never share user passwords or grant unrestricted direct access to accounts. User data is disclosed only when legally required under applicable Indian laws after verifying the authenticity, scope, and legal validity of the official request.</p>
            `
        },
        refund: {
            title: "Refund & Cancellation Policy",
            content: `
                <h3>1. Subscription Validity & Cancellation</h3>
                <p>Purchased plans are active for 30 days. You may manage or cancel renewals anytime through Google Play Subscriptions or support.</p>
                <h3>2. Payment Issues</h3>
                <p>If payment is deducted without plan activation, contact support with your transaction ID for immediate resolution.</p>
            `
        }
    };

    const policy = policies[type];
    if (!policy) return;

    if (title) title.textContent = policy.title;
    if (content) content.innerHTML = policy.content;
    modal.style.display = "flex";
}

function closePolicyModal() {
    const modal = document.getElementById("policyModal");
    if (modal) modal.style.display = "none";
}

// ================= COUNTRY MODAL & PRICING =================
function openWorldCountryModal() {
    const modal = document.getElementById("worldCountryModal");
    const searchInput = document.getElementById("countrySearchInput");
    if (searchInput) searchInput.value = "";
    renderWorldCountries(RAW_WORLD_COUNTRIES);
    if (modal) modal.style.display = "flex";
}

function closeWorldCountryModal() {
    const modal = document.getElementById("worldCountryModal");
    if (modal) modal.style.display = "none";
}

function filterWorldCountries(query) {
    const q = (query || "").toLowerCase().trim();
    const filtered = RAW_WORLD_COUNTRIES.filter(c =>
        c.name.toLowerCase().includes(q) || c.code.toLowerCase().includes(q)
    );
    renderWorldCountries(filtered);
}

function renderWorldCountries(list) {
    const container = document.getElementById("worldCountryList");
    if (!container) return;

    container.innerHTML = list.map(c => {
        const isSelected = c.code === currentCountry;
        return `
            <div class="world-country-option ${isSelected ? 'active' : ''}" onclick="selectWorldCountry('${c.code}')">
                <div class="wc-left">
                    <span class="wc-flag">${c.flag}</span>
                    <div class="wc-text">
                        <h5>${c.name}</h5>
                        <span>${c.curr}</span>
                    </div>
                </div>
                <div class="wc-radio">
                    ${isSelected ? '<i class="fa-solid fa-circle-check"></i>' : '<i class="fa-regular fa-circle"></i>'}
                </div>
            </div>
        `;
    }).join("");
}

function selectWorldCountry(code) {
    currentCountry = code || "IN";
    localStorage.setItem("manualCountry", currentCountry);
    updatePricingUI(currentCountry);
    closeWorldCountryModal();
}

function detectAndSetCountry() {
    const saved = localStorage.getItem("manualCountry");
    if (saved) {
        currentCountry = saved;
        updatePricingUI(saved);
        return;
    }
    fetch("https://ipapi.co/json/")
        .then(r => r.json())
        .then(data => {
            const code = data?.country_code || "IN";
            currentCountry = code;
            localStorage.setItem("manualCountry", code);
            updatePricingUI(code);
        })
        .catch(() => {
            currentCountry = "IN";
            updatePricingUI("IN");
        });
}

function getRemainingSubDays() {
    if (!subExpiresAtMs || subExpiresAtMs <= Date.now()) return 30;
    return Math.max(1, Math.ceil((subExpiresAtMs - Date.now()) / (24 * 60 * 60 * 1000)));
}

function selectPlan(tierLevel) {
    if (userTier >= 2) {
        showCustomAlert("Subscription Already Active 👑", `You already have Zoreno Pro active for the next ${getRemainingSubDays()} days!`, true);
        return;
    }
    if (userTier === 1 && tierLevel <= 1) {
        showCustomAlert("Plus Plan Already Active ✨", `Your Zoreno Plus plan is active (${getRemainingSubDays()} days left). You can only upgrade to Zoreno Pro!`);
        selectedTierLevel = 2;
        updatePricingUI(currentCountry);
        return;
    }

    selectedTierLevel = tierLevel;
    updatePricingUI(currentCountry);
}

function updatePricingUI(countryCode) {
    currentCountry = countryCode || localStorage.getItem("manualCountry") || "IN";
    localStorage.setItem("manualCountry", currentCountry);

    const isIndia = currentCountry === "IN";
    const symbol = isIndia ? "₹" : "$";
    const plusPrice = isIndia ? 249 : 3.99;
    const proPrice = isIndia ? 349 : 6.99;

    if (userTier === 1 && selectedTierLevel < 2) {
        selectedTierLevel = 2;
    }

    const found = RAW_WORLD_COUNTRIES.find(c => c.code === currentCountry) || RAW_WORLD_COUNTRIES[0];
    const displayEl = document.getElementById("selectedCountryDisplay");
    if (displayEl) displayEl.innerText = `${found.flag} ${found.name} (${symbol})`;

    const plusCard = document.getElementById("plusPlanCard");
    const proCard = document.getElementById("proPlanCard");
    const plan1Title = document.getElementById("plan1Title");
    const plan2Title = document.getElementById("plan2Title");
    const plan1Desc = document.getElementById("plan1Description");
    const plan2Desc = document.getElementById("plan2Description");
    const payBtn = document.getElementById("payButtonText");
    const payBtnText = document.querySelector("#payButtonText .btn-text");

    if (plan1Title) plan1Title.innerText = `${symbol}${plusPrice} / Month (Plus)`;
    if (plan2Title) plan2Title.innerText = `${symbol}${proPrice} / Month (Pro)`;

    const daysLeft = getRemainingSubDays();

    if (userTier === 0) {
        if (plan1Desc) plan1Desc.innerText = "50 Messages/Day • 30 Days Validity";
        if (plan2Desc) plan2Desc.innerText = "90 Messages/Day • 30 Days • Vision";
        if (plusCard) {
            plusCard.style.opacity = "1";
            plusCard.classList.toggle("active", selectedTierLevel === 1);
        }
        if (proCard) {
            proCard.style.opacity = "1";
            proCard.classList.toggle("active", selectedTierLevel === 2);
        }
        selectedAmount = selectedTierLevel === 2 ? proPrice : plusPrice;
        if (payBtn) {
            payBtn.disabled = false;
            payBtn.style.opacity = "1";
        }
        if (payBtnText) payBtnText.innerText = `Upgrade to ${selectedTierLevel === 2 ? "Pro" : "Plus"} (${symbol}${selectedAmount})`;
    } else if (userTier === 1) {
        if (plan1Desc) plan1Desc.innerHTML = `<strong style="color:#10b981;">✓ Active (${daysLeft} Days Left)</strong> • Cannot Rebuy`;
        if (plan2Desc) plan2Desc.innerText = "Upgrade for 90 Messages/Day • 30 Days";
        if (plusCard) {
            plusCard.classList.remove("active");
            plusCard.style.opacity = "0.55";
        }
        if (proCard) {
            proCard.classList.add("active");
            proCard.style.opacity = "1";
        }
        selectedTierLevel = 2;
        selectedAmount = proPrice;
        if (payBtn) {
            payBtn.disabled = false;
            payBtn.style.opacity = "1";
        }
        if (payBtnText) payBtnText.innerText = `Upgrade to Pro (${symbol}${proPrice})`;
    } else if (userTier >= 2) {
        if (plan1Desc) plan1Desc.innerText = "Included in your active Pro Plan";
        if (plan2Desc) plan2Desc.innerHTML = `<strong style="color:#10b981;">✓ Active (${daysLeft} Days Left)</strong> • 90 Msgs/Day`;
        if (plusCard) {
            plusCard.classList.remove("active");
            plusCard.style.opacity = "0.45";
        }
        if (proCard) {
            proCard.classList.add("active");
            proCard.style.opacity = "1";
        }
        if (payBtn) {
            payBtn.disabled = true;
            payBtn.style.opacity = "0.75";
        }
        if (payBtnText) payBtnText.innerText = `Subscription Already Active (${daysLeft}d) 👑`;
    }
}

function isRunningInAndroidApp() {
    const ua = navigator.userAgent || "";
    return Boolean(window.AndroidBilling || window.ZorenoGoogleAuth || /wv|Android.*Version\/[0-9.]+/i.test(ua));
}

async function activateUserSubscriptionInFirestore(newTier, paymentReferenceId, providerName) {
    userTier = newTier;
    subExpiresAtMs = Date.now() + SUBSCRIPTION_VALIDITY_MS;

    localStorage.setItem("userTier", String(userTier));
    localStorage.setItem("subExpiresAtMs", String(subExpiresAtMs));

    if (db && auth?.currentUser) {
        await db.collection("users").doc(auth.currentUser.uid).set({
            userTier: userTier,
            subscriptionExpiresAtMs: subExpiresAtMs,
            paymentId: paymentReferenceId || "",
            paymentProvider: providerName || "unknown",
            subscriptionUpdatedAt: firebase.firestore.FieldValue.serverTimestamp()
        }, { merge: true });
    }

    updatePricingUI(currentCountry);
    updateProfileUI();

    showCustomAlert(
        "Subscription Activated (30 Days)! 🎉",
        `Welcome to Zoreno ${userTier === 2 ? "Pro" : "Plus"}! Your plan is now active for the next 30 days.`,
        true
    );
}

window.onPlayBillingSuccess = function (tierLevel, purchaseToken) {
    activateUserSubscriptionInFirestore(parseInt(tierLevel) || selectedTierLevel, purchaseToken || "play_billing", "google_play");
};

async function openRazorpayCheckout(targetTierOverride) {
    const targetTier = targetTierOverride || selectedTierLevel || 1;
    const isIndia = currentCountry === "IN";
    const plusPrice = isIndia ? 249 : 3.99;
    const proPrice = isIndia ? 349 : 6.99;
    const finalAmount = targetTier === 2 ? proPrice : plusPrice;

    if (!window.Razorpay) {
        try {
            await loadExternalScript("https://checkout.razorpay.com/v1/checkout.js", "rzp-checkout-js");
        } catch (e) {
            showCustomAlert("Loading Payment", "Payment gateway could not be loaded. Please check your internet connection.");
            return;
        }
    }

    const options = {
        key: RAZORPAY_KEY_ID,
        amount: Math.round(finalAmount * 100),
        currency: isIndia ? "INR" : "USD",
        name: "Zoreno",
        description: targetTier === 2 ? "Zoreno Pro (30 Days)" : "Zoreno Plus (30 Days)",
        handler: async function (response) {
            try {
                await activateUserSubscriptionInFirestore(
                    targetTier,
                    response?.razorpay_payment_id || "rzp_store",
                    "razorpay"
                );
            } catch (e) {
                console.error("Subscription update error:", e);
            }
        },
        prefill: { name: userName || "", email: userEmail || "" },
        theme: { color: "#7c3aed" }
    };

    const rzp = new Razorpay(options);
    rzp.open();
}

window.triggerRazorpayFallback = function () {
    openRazorpayCheckout(selectedTierLevel);
};

async function triggerRazorpay() {
    if (userTier >= 2) {
        showCustomAlert("Subscription Already Active 👑", `You already have Zoreno Pro active (${getRemainingSubDays()} days remaining).`, true);
        return;
    }
    if (userTier === 1 && selectedTierLevel <= 1) {
        selectedTierLevel = 2;
        updatePricingUI(currentCountry);
    }

    const targetTier = selectedTierLevel;
    const skuId = PLAY_BILLING_SKUS[targetTier];

    // Play Store par Google Play Billing chalega; Indus, Samsung, Oppo, Vivo aur Web par Razorpay!
    const isPlayStoreInstall = window.AndroidPrefs && typeof window.AndroidPrefs.isFromPlayStore === "function"
        ? window.AndroidPrefs.isFromPlayStore()
        : false;

    if (isPlayStoreInstall && window.AndroidBilling && typeof window.AndroidBilling.purchaseSubscription === "function") {
        window.AndroidBilling.purchaseSubscription(skuId, targetTier);
        return;
    }

    await openRazorpayCheckout(targetTier);
}

// ================= AUTHENTICATION & ACCOUNT DELETION =================
function showSignUpForm() {
    document.getElementById("loginViewSection").style.display = "none";
    document.getElementById("signUpViewSection").style.display = "block";
    document.getElementById("authBackBtn").style.display = "inline-flex";
}

function showLoginForm() {
    document.getElementById("signUpViewSection").style.display = "none";
    document.getElementById("loginViewSection").style.display = "block";
    document.getElementById("authBackBtn").style.display = "none";
}

function toggleInputPassword(fieldId, btn) {
    const input = document.getElementById(fieldId);
    if (!input) return;
    const isPass = input.type === "password";
    input.type = isPass ? "text" : "password";
    btn.innerHTML = isPass ? '<i class="fa-regular fa-eye"></i>' : '<i class="fa-regular fa-eye-slash"></i>';
}

async function handleEmailLogin(e) {
    e.preventDefault();
    const email = document.getElementById("loginEmail").value.trim();
    const pass = document.getElementById("loginPassword").value;
    const btn = document.getElementById("loginSubmitBtn");
    if (!email || !pass) return;

    try {
        if (btn) btn.disabled = true;
        await initFirebase();
        const userCred = await auth.signInWithEmailAndPassword(email, pass);
        if (userCred.user) {
            document.getElementById("authScreen")?.style.setProperty("display", "none", "important");
            showChatsHome();
        }
    } catch (err) {
        let customMsg = err.message;
        if (err.code === "auth/invalid-credential" || err.code === "auth/user-not-found" || err.code === "auth/wrong-password") {
            customMsg = "Account not found or wrong password. Please check your details or Sign Up.";
        }
        showCustomAlert("Login Failed", customMsg);
    } finally {
        if (btn) btn.disabled = false;
    }
}

async function handleEmailSignUp(e) {
    e.preventDefault();
    const name = document.getElementById("regName").value.trim();
    const email = document.getElementById("regEmail").value.trim();
    const pass = document.getElementById("regPassword").value;
    const btn = document.getElementById("signUpSubmitBtn");

    try {
        if (btn) btn.disabled = true;
        await initFirebase();
        const res = await auth.createUserWithEmailAndPassword(email, pass);

        if (res.user) {
            const cleanName = name.toLowerCase().replace(/[^a-z0-9]/g, "") || "student";
            const randomCode = Math.floor(1000 + Math.random() * 9000);
            const autoUsername = `@${cleanName}_${randomCode}`;

            await res.user.updateProfile({ displayName: name });
            userName = name;
            currentUsername = autoUsername;
            userAvatarUrl = DEFAULT_AVATAR_URL;
            localStorage.setItem("username", autoUsername);
            localStorage.setItem("userName", name);
            localStorage.setItem("userAvatarUrl", DEFAULT_AVATAR_URL);

            if (db) {
                await db.collection("users").doc(res.user.uid).set({
                    uid: res.user.uid,
                    name: name,
                    nameLower: name.toLowerCase(),
                    email: email,
                    username: autoUsername,
                    usernameLower: autoUsername.toLowerCase(),
                    photoURL: DEFAULT_AVATAR_URL,
                    bio: currentBio,
                    userTier: 0,
                    subscriptionExpiresAtMs: 0,
                    isOnline: true,
                    lastActiveAtMs: Date.now(),
                    createdAt: firebase.firestore.FieldValue.serverTimestamp()
                }, { merge: true });
            }

            await loadUserProfile(res.user);
            showChatsHome();
        }
    } catch (err) {
        showCustomAlert("Sign Up Failed", err.message);
    } finally {
        if (btn) btn.disabled = false;
    }
}

async function handleForgotPassword() {
    const email = document.getElementById("loginEmail").value.trim();
    if (!email) {
        showCustomAlert("Email Required", "Please enter your email in the email address box first.");
        return;
    }
    try {
        await initFirebase();
        await auth.sendPasswordResetEmail(email);
        showCustomAlert("Reset Email Sent", "Password reset instructions sent to your email.", true);
    } catch (err) {
        showCustomAlert("Reset Failed", err.message);
    }
}

async function handleUserLogout() {
    try {
        await updateMyPresenceStatus(false);
        stopPresenceHeartbeat();
        if (incomingChatsUnsub) { incomingChatsUnsub(); incomingChatsUnsub = null; }
        if (auth) await auth.signOut();

        // Preserve 24-hour daily free chat quota across logouts
        const savedAiDate = localStorage.getItem("zorenoAiDate");
        const savedAiCount = localStorage.getItem("zorenoAiCount");
        const savedAiLimitDate = localStorage.getItem("zorenoAiLimitDate");
        const savedAiLimit = localStorage.getItem("zorenoAiDailyLimit");

        localStorage.clear();
        sessionStorage.clear();

        if (savedAiDate) localStorage.setItem("zorenoAiDate", savedAiDate);
        if (savedAiCount) localStorage.setItem("zorenoAiCount", savedAiCount);
        if (savedAiLimitDate) localStorage.setItem("zorenoAiLimitDate", savedAiLimitDate);
        if (savedAiLimit) localStorage.setItem("zorenoAiDailyLimit", savedAiLimit);

        window.location.reload();
    } catch (err) {
        showCustomAlert("Logout Failed", err.message);
    }
}

function openDeleteAccountModal() {
    const emailInp = document.getElementById("delAccEmail");
    const passInp = document.getElementById("delAccPass");
    if (emailInp) emailInp.value = userEmail || auth?.currentUser?.email || "";
    if (passInp) passInp.value = "";
    const modal = document.getElementById("deleteAccountModal");
    if (modal) modal.style.display = "flex";
}

async function confirmDeleteAccount() {
    const email = document.getElementById("delAccEmail")?.value.trim();
    const pass = document.getElementById("delAccPass")?.value;
    if (!email || !pass) {
        showCustomAlert("Details Required", "Please enter both your email and password to confirm deletion.");
        return;
    }
    if (!auth?.currentUser) return;

    try {
        const uid = auth.currentUser.uid;
        const cred = firebase.auth.EmailAuthProvider.credential(email, pass);
        await auth.currentUser.reauthenticateWithCredential(cred);

        if (db) {
            const chatSnap = await db.collection("users").doc(uid).collection("chats").get();
            const batch = db.batch();
            chatSnap.forEach(d => batch.delete(d.ref));
            batch.delete(db.collection("users").doc(uid));
            await batch.commit();
        }

        await auth.currentUser.delete();
        localStorage.clear();
        sessionStorage.clear();
        document.getElementById("deleteAccountModal").style.display = "none";
        window.location.reload();
    } catch (err) {
        showCustomAlert("Deletion Failed", "Incorrect password or authentication error: " + err.message);
    }
}

// ================= PROFILE EDIT & PHOTO SAVE =================
function updateProfileUI() {
    const tierLabel = userTier === 2
        ? `Pro Member (${getRemainingSubDays()}d left) 👑`
        : userTier === 1
            ? `Plus Member (${getRemainingSubDays()}d left) ✨`
            : "Free Member";
    const cardTierEl = document.getElementById("profileCardTierTitle");
    if (cardTierEl) cardTierEl.textContent = tierLabel;

    const avImg = document.getElementById("profileEditAvatarImg");
    if (avImg) avImg.src = getSafeAvatar(userAvatarUrl);

    const badge = document.getElementById("profileUsernameBadge");
    if (badge) badge.innerText = currentUsername || "@student";
}

function syncEditProfileInputs() {
    const uInp = document.getElementById("profileEditUsername");
    const nInp = document.getElementById("profileEditName");
    const bInp = document.getElementById("profileEditBio");
    const badge = document.getElementById("profileUsernameBadge");
    const avImg = document.getElementById("profileEditAvatarImg");

    if (uInp) uInp.value = (currentUsername || "").replace(/^@/, "");
    if (nInp) nInp.value = userName || "Student";
    if (bInp) bInp.value = currentBio;
    if (badge) badge.innerText = currentUsername || "@student";
    if (avImg) avImg.src = getSafeAvatar(userAvatarUrl);
}

function previewAndUploadProfilePic(event) {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function (e) {
        const img = new Image();
        img.onload = async function () {
            const canvas = document.createElement("canvas");
            const MAX_SIZE = 200;
            let w = img.width;
            let h = img.height;

            if (w > h) {
                if (w > MAX_SIZE) { h = Math.round((h * MAX_SIZE) / w); w = MAX_SIZE; }
            } else {
                if (h > MAX_SIZE) { w = Math.round((w * MAX_SIZE) / h); h = MAX_SIZE; }
            }

            canvas.width = w;
            canvas.height = h;
            const ctx = canvas.getContext("2d");
            ctx.drawImage(img, 0, 0, w, h);

            const compressedBase64 = canvas.toDataURL("image/jpeg", 0.72);
            userAvatarUrl = compressedBase64;
            localStorage.setItem("userAvatarUrl", compressedBase64);
            updateProfileUI();

            if (db && auth?.currentUser) {
                const myUid = auth.currentUser.uid;
                try {
                    await db.collection("users").doc(myUid).set({
                        photoURL: compressedBase64,
                        avatarUrl: compressedBase64,
                        updatedAt: firebase.firestore.FieldValue.serverTimestamp()
                    }, { merge: true });
                } catch (err) {
                    console.error("Avatar sync error:", err);
                }
            }
        };
        img.src = e.target.result;
    };
    reader.readAsDataURL(file);
}

async function ensureUniqueUsernameForUser(u) {
    if (!db || !u) return;
    try {
        const userRef = db.collection("users").doc(u.uid);
        const snap = await userRef.get();
        let data = snap.exists ? snap.data() : {};

        if (data.username && data.username !== "@user" && data.username !== "@friend") {
            currentUsername = data.username;
        } else {
            const base = (u.displayName || userName || "student")
                .toLowerCase()
                .replace(/[^a-z0-9]/g, "")
                .slice(0, 10) || "student";
            const rand = Math.floor(1000 + Math.random() * 9000);
            currentUsername = `@${base}_${rand}`;

            await userRef.set({
                uid: u.uid,
                name: u.displayName || userName || "Student",
                nameLower: (u.displayName || userName || "Student").toLowerCase(),
                username: currentUsername,
                usernameLower: currentUsername.toLowerCase(),
                bio: currentBio,
                photoURL: getSafeAvatar(userAvatarUrl)
            }, { merge: true });
        }

        if (data.bio) currentBio = data.bio;
        if (data.photoURL) userAvatarUrl = getSafeAvatar(data.photoURL);
        localStorage.setItem("username", currentUsername);
        localStorage.setItem("userBio", currentBio);
        localStorage.setItem("userAvatarUrl", userAvatarUrl);

        syncEditProfileInputs();
        listenIncomingRealtimeChats(u.uid);
    } catch (e) {
        console.error("Username init error:", e);
    }
}

async function saveUserProfileChanges() {
    const uInp = document.getElementById("profileEditUsername");
    const nInp = document.getElementById("profileEditName");
    const bInp = document.getElementById("profileEditBio");
    const hint = document.getElementById("usernameStatusHint");
    const saveBtn = document.getElementById("profileSaveBtn");

    let rawU = (uInp?.value || "").trim().toLowerCase().replace(/^@/, "").replace(/[^a-z0-9_.]/g, "");
    let newName = (nInp?.value || "").trim() || userName;
    let newBio = (bInp?.value || "").trim() || currentBio;

    if (rawU.length < 3 || rawU === "user" || rawU === "friend") {
        if (hint) {
            hint.style.color = "#ef4444";
            hint.innerText = "Please choose a valid unique username (min 3 chars).";
        }
        return;
    }

    const formattedUsername = `@${rawU}`;

    try {
        if (saveBtn) {
            saveBtn.disabled = true;
            saveBtn.innerText = "Saving...";
        }

        if (db && auth?.currentUser) {
            const q = await db.collection("users")
                .where("usernameLower", "==", formattedUsername.toLowerCase())
                .get();

            let isTaken = false;
            q.forEach(doc => {
                if (doc.id !== auth.currentUser.uid) isTaken = true;
            });

            if (isTaken) {
                if (hint) {
                    hint.style.color = "#ef4444";
                    hint.innerText = `❌ ${formattedUsername} is already taken!`;
                }
                return;
            }

            await db.collection("users").doc(auth.currentUser.uid).set({
                name: newName,
                nameLower: newName.toLowerCase(),
                username: formattedUsername,
                usernameLower: formattedUsername.toLowerCase(),
                bio: newBio,
                photoURL: getSafeAvatar(userAvatarUrl)
            }, { merge: true });
        }

        currentUsername = formattedUsername;
        userName = newName;
        currentBio = newBio;

        localStorage.setItem("username", currentUsername);
        localStorage.setItem("userName", userName);
        localStorage.setItem("userBio", currentBio);

        if (hint) hint.innerText = "";
        syncEditProfileInputs();
        updateProfileUI();
        showChatsHome();
    } catch (err) {
        console.error("Save profile error:", err);
    } finally {
        if (saveBtn) {
            saveBtn.disabled = false;
            saveBtn.innerText = "Save";
        }
    }
}

// ================= ACCURATE ONLINE / LAST SEEN PRESENCE =================
async function updateMyPresenceStatus(isOnlineNow) {
    if (!db || !auth?.currentUser) return;
    const nowMs = Date.now();
    const nowTime = new Date(nowMs).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    try {
        await db.collection("users").doc(auth.currentUser.uid).set({
            isOnline: isOnlineNow,
            lastSeenLabel: nowTime,
            lastActiveAtMs: nowMs,
            lastActiveAt: firebase.firestore.FieldValue.serverTimestamp()
        }, { merge: true });
    } catch (e) {}
}

function startPresenceHeartbeat() {
    stopPresenceHeartbeat();
    presenceHeartbeatTimer = setInterval(() => {
        if (!document.hidden && auth?.currentUser) {
            updateMyPresenceStatus(true);
        }
    }, 45000);
}

function stopPresenceHeartbeat() {
    if (presenceHeartbeatTimer) {
        clearInterval(presenceHeartbeatTimer);
        presenceHeartbeatTimer = null;
    }
}

window.addEventListener("beforeunload", () => updateMyPresenceStatus(false));
window.addEventListener("pagehide", () => updateMyPresenceStatus(false));
document.addEventListener("visibilitychange", () => {
    updateMyPresenceStatus(!document.hidden);
});

// ================= WHATSAPP-STYLE IN-APP & SYSTEM NOTIFICATIONS =================
function requestNotificationPermissionSafely() {
    if ("Notification" in window && Notification.permission === "default") {
        Notification.requestPermission().catch(() => {});
    }
}

let inAppNotifTimeout = null;
function showZorenoIncomingNotification(friendUid, senderName, senderAvatar, senderUsername, messageText) {
    if (blockedUsersMap[friendUid]) return;

    const banner = document.getElementById("zorenoInAppNotifBanner");
    const nameEl = document.getElementById("znotifSenderName");
    const msgEl = document.getElementById("znotifMsgPreview");
    const avatarEl = document.getElementById("znotifSenderAvatar");

    if (banner && nameEl && msgEl && avatarEl) {
        nameEl.textContent = senderName || "Friend";
        msgEl.textContent = messageText || "Sent you a message";
        avatarEl.src = getSafeAvatar(senderAvatar);

        banner.onclick = () => {
            banner.classList.remove("show");
            openChatWithUser(friendUid, senderName, getSafeAvatar(senderAvatar), senderUsername);
        };

        banner.classList.add("show");
        clearTimeout(inAppNotifTimeout);
        inAppNotifTimeout = setTimeout(() => {
            banner.classList.remove("show");
        }, 4500);
    }

    if (window.AndroidNotif && typeof window.AndroidNotif.showNotification === "function") {
        try {
            window.AndroidNotif.showNotification(senderName || "Zoreno Message", messageText || "New message received");
        } catch (e) {}
    }

    if ("Notification" in window && Notification.permission === "granted" && document.hidden) {
        try {
            const n = new Notification(senderName || "Zoreno Message", {
                body: messageText || "New message received",
                icon: "icon.png",
                badge: "icon.png",
                tag: `zoreno_dm_${friendUid}`
            });
            n.onclick = () => {
                window.focus();
                openChatWithUser(friendUid, senderName, getSafeAvatar(senderAvatar), senderUsername);
                n.close();
            };
        } catch (e) {}
    }
}

// ================= HOME SEARCH & TABS =================
function setupHomeSearchAndTabs() {
    const searchInp = document.getElementById("homeChatSearchInput");
    if (searchInp) {
        searchInp.addEventListener("input", e => handleHomeUserSearch(e.target.value));
        searchInp.addEventListener("search", e => handleHomeUserSearch(e.target.value));
        searchInp.addEventListener("keyup", e => {
            if (!e.target.value.trim()) handleHomeUserSearch("");
        });
    }

    const tabBtns = document.querySelectorAll(".chat-tabs .tab-btn");
    const tabKeys = ["all", "unread", "friends", "groups"];
    tabBtns.forEach((btn, idx) => {
        btn.onclick = () => {
            tabBtns.forEach(b => b.classList.remove("active"));
            btn.classList.add("active");
            currentActiveChatTab = tabKeys[idx] || "all";
            filterHomeChatListByTab(currentActiveChatTab);
        };
    });

    renderSavedDmChatsOnHome();
}

function filterHomeChatListByTab(tabKey) {
    currentActiveChatTab = tabKey || "all";
    const items = document.querySelectorAll(".chats-container .chat-list-item");
    items.forEach(item => {
        if (item.classList.contains("pinned")) {
            item.style.display = currentActiveChatTab === "all" ? "flex" : "none";
            return;
        }
        const isGroup = item.classList.contains("group-chat-item") || item.querySelector(".group-avatar") !== null;
        const unreadBadge = item.querySelector(".unread-count");
        const hasUnread = unreadBadge !== null && parseInt(unreadBadge.textContent || "0") > 0;

        if (currentActiveChatTab === "all") item.style.display = "flex";
        else if (currentActiveChatTab === "unread") item.style.display = hasUnread ? "flex" : "none";
        else if (currentActiveChatTab === "friends") item.style.display = !isGroup ? "flex" : "none";
        else if (currentActiveChatTab === "groups") item.style.display = isGroup ? "flex" : "none";
    });
}

const userProfileCache = {};
let searchDebounceTimer = null;

async function handleHomeUserSearch(rawQuery) {
    const q = (rawQuery || "").trim().toLowerCase();
    let resultsBox = document.getElementById("liveUserSearchDropdown");

    if (!resultsBox) {
        resultsBox = document.createElement("div");
        resultsBox.id = "liveUserSearchDropdown";
        resultsBox.className = "live-user-search-dropdown";
        const header = document.querySelector(".chat-list-header-modern");
        header?.insertAdjacentElement("afterend", resultsBox);
    }

    clearTimeout(searchDebounceTimer);
    if (!q) {
        resultsBox.innerHTML = "";
        resultsBox.style.display = "none";
        filterHomeChatListByTab(currentActiveChatTab);
        return;
    }

    document.querySelectorAll(".chats-container .chat-list-item").forEach(item => {
        const text = item.innerText.toLowerCase();
        item.style.display = text.includes(q) ? "flex" : "none";
    });

    if (!db) return;
    searchDebounceTimer = setTimeout(async () => {
        const currentVal = (document.getElementById("homeChatSearchInput")?.value || "").trim();
        if (!currentVal) {
            resultsBox.innerHTML = "";
            resultsBox.style.display = "none";
            return;
        }

        try {
            const cleanQ = q.replace(/^@/, "");
            const matchesMap = new Map();

            try {
                const uSnap = await db.collection("users")
                    .where("usernameLower", ">=", `@${cleanQ}`)
                    .where("usernameLower", "<=", `@${cleanQ}\uf8ff`)
                    .limit(12)
                    .get();
                uSnap.forEach(doc => matchesMap.set(doc.id, { id: doc.id, ...doc.data() }));
            } catch (e) {}

            try {
                const nSnap = await db.collection("users")
                    .where("nameLower", ">=", cleanQ)
                    .where("nameLower", "<=", `${cleanQ}\uf8ff`)
                    .limit(12)
                    .get();
                nSnap.forEach(doc => matchesMap.set(doc.id, { id: doc.id, ...doc.data() }));
            } catch (e) {}

            const matches = Array.from(matchesMap.values()).filter(u => {
                if (auth?.currentUser && u.id === auth.currentUser.uid) return false;
                if (u.id === "arjun_user_id") return false;
                const un = (u.username || "").toLowerCase();
                const nm = (u.name || "").toLowerCase();
                if (!un || un === "@user" || un === "@friend") return false;
                if (!nm || nm === "user" || nm === "friend") return false;
                return true;
            });

            if (matches.length === 0) {
                resultsBox.innerHTML = `<div class="user-search-empty">No user found with "${escapeHtml(rawQuery)}"</div>`;
            } else {
                resultsBox.innerHTML = "";
                matches.forEach(u => {
                    const row = document.createElement("div");
                    row.className = "user-search-item";
                    const safeDp = getSafeAvatar(u.photoURL || u.avatarUrl);
                    row.innerHTML = `
                        <img src="${escapeHtml(safeDp)}" onerror="this.src='logo.png'" alt="User">
                        <div class="us-info">
                            <h5>${escapeHtml(u.name)}</h5>
                            <span>${escapeHtml(u.username)}</span>
                        </div>
                        <button type="button" class="us-msg-btn">Message</button>
                    `;
                    row.addEventListener("click", () => {
                        startChatFromSearch(u.id, u.name, u.username, safeDp);
                    });
                    resultsBox.appendChild(row);
                });
            }
            resultsBox.style.display = "flex";
        } catch (err) {
            console.error("User search error:", err);
        }
    }, 180);
}

function startChatFromSearch(uid, name, username, avatar) {
    clearTimeout(searchDebounceTimer);
    const resultsBox = document.getElementById("liveUserSearchDropdown");
    const searchInp = document.getElementById("homeChatSearchInput");
    if (resultsBox) {
        resultsBox.innerHTML = "";
        resultsBox.style.display = "none";
    }
    if (searchInp) searchInp.value = "";
    filterHomeChatListByTab("all");

    openChatWithUser(uid, name, avatar, username);
}

// ================= FRIEND DM CHAT & PROFILE =================
function markDmChatAsRead(userId) {
    if (!userId) return;
    const idx = recentDmUsers.findIndex(x => x.uid === userId);
    const latestMsgMs = idx >= 0 ? (recentDmUsers[idx].lastMessageAtMs || 0) : 0;

    const readStamp = Math.max(Date.now(), latestMsgMs + 5000);
    lastReadAtMap[userId] = readStamp;
    lastNotifiedMsgMap[userId] = readStamp;

    try {
        localStorage.setItem("zorenoLastReadAtMap", JSON.stringify(lastReadAtMap));
        localStorage.setItem("zorenoNotifiedMsgMap", JSON.stringify(lastNotifiedMsgMap));
    } catch (e) {}

    if (idx >= 0 && recentDmUsers[idx].unread > 0) {
        recentDmUsers[idx].unread = 0;
        try { localStorage.setItem("zorenoRecentDms", JSON.stringify(recentDmUsers)); } catch (e) {}
        scheduleRenderSavedDmChats();
    }
}

function openChatWithUser(userId, targetName, targetAvatar, targetUsername = "@student") {
    closeAllDropdownMenus();
    currentChatUserId = userId;
    isFriendCurrentlyTyping = false;
    const existingEntry = recentDmUsers.find(x => x.uid === userId);

    currentChatUserMeta = {
        uid: userId,
        name: targetName || existingEntry?.name || "Student",
        avatar: getSafeAvatar(targetAvatar || existingEntry?.avatar),
        username: targetUsername || existingEntry?.username || "@student",
        bio: "Student | Exploring new things | Keep learning.",
        isOnline: false,
        lastActiveAtMs: 0,
        lastSeenLabel: "recently"
    };

    markDmChatAsRead(userId);

    const chatWin = document.getElementById("activeChatScreen");
    const nameEl = document.getElementById("activeChatName");
    const avatarEl = document.getElementById("activeChatAvatar");
    const bottomNav = document.getElementById("bottomNav");

    if (nameEl) nameEl.textContent = currentChatUserMeta.name;
    if (avatarEl) avatarEl.src = currentChatUserMeta.avatar;
    renderDmHeaderStatus();
    updateBlockMenuButtonUI();

    if (bottomNav) bottomNav.style.setProperty("display", "none", "important");
    if (chatWin) {
        chatWin.style.setProperty("display", "flex", "important");
        chatWin.style.setProperty("visibility", "visible", "important");
        chatWin.style.setProperty("pointer-events", "auto", "important");
    }

    if (activeFriendProfileUnsub) activeFriendProfileUnsub();
    if (db && userId) {
        activeFriendProfileUnsub = db.collection("users").doc(userId).onSnapshot(doc => {
            if (!doc.exists) return;
            const d = doc.data();
            currentChatUserMeta.name = d.name || currentChatUserMeta.name;
            currentChatUserMeta.username = d.username || currentChatUserMeta.username;
            currentChatUserMeta.avatar = getSafeAvatar(d.photoURL || d.avatarUrl || currentChatUserMeta.avatar);
            currentChatUserMeta.bio = d.bio || currentChatUserMeta.bio;
            currentChatUserMeta.isOnline = d.isOnline === true;
            currentChatUserMeta.lastActiveAtMs = d.lastActiveAtMs || 0;
            currentChatUserMeta.lastSeenLabel = d.lastSeenLabel || "recently";

            if (nameEl) nameEl.textContent = currentChatUserMeta.name;
            if (avatarEl) avatarEl.src = currentChatUserMeta.avatar;
            renderDmHeaderStatus();
            syncFriendProfileViewDOM();

            document.querySelectorAll(".dm-friend-side-dp").forEach(img => {
                img.src = currentChatUserMeta.avatar;
            });

            updateRecentDmMetaOnly(
                userId,
                currentChatUserMeta.name,
                currentChatUserMeta.avatar,
                currentChatUserMeta.username
            );
        });
    }

    if (activeChatMetaUnsub) activeChatMetaUnsub();
    if (db && auth?.currentUser && userId) {
        const myUid = auth.currentUser.uid;
        const chatId = myUid < userId ? `${myUid}_${userId}` : `${userId}_${myUid}`;
        activeChatMetaUnsub = db.collection("chats").doc(chatId).onSnapshot(doc => {
            if (!doc.exists) return;
            const data = doc.data() || {};
            isFriendCurrentlyTyping = !!data[`typing_${userId}`];
            renderDmHeaderStatus();
        });
    }

    loadMessagesFromFirestore(userId);
}

function openFriendProfileScreen() {
    closeAllDropdownMenus();
    if (!currentChatUserMeta) return;
    syncFriendProfileViewDOM();
    const fpScreen = document.getElementById("friendProfileScreen");
    if (fpScreen) fpScreen.style.setProperty("display", "block", "important");
}

function closeFriendProfileScreen() {
    closeAllDropdownMenus();
    const fpScreen = document.getElementById("friendProfileScreen");
    if (fpScreen) fpScreen.style.setProperty("display", "none", "important");
}

function toggleFpHeaderMenu(forceState) {
    const menu = document.getElementById("fpHeaderDropdownMenu");
    if (!menu) return;
    const nextState = typeof forceState === "boolean" ? forceState : menu.style.display !== "block";
    closeAllDropdownMenus();
    menu.style.display = nextState ? "block" : "none";
}

function syncFriendProfileViewDOM() {
    if (!currentChatUserMeta) return;
    const cleanHandle = (currentChatUserMeta.username || "@student").replace(/^@/, "");
    const fullHandle = `@${cleanHandle}`;
    const bioStr = currentChatUserMeta.bio || "Student | Exploring new things | Keep learning.";
    const pres = formatPresenceStatusText(
        currentChatUserMeta.isOnline,
        currentChatUserMeta.lastActiveAtMs,
        currentChatUserMeta.lastSeenLabel
    );
    const dotColor = pres.online ? "#10b981" : "#94a3b8";

    const avImg = document.getElementById("fpAvatarImg");
    const avDot = document.getElementById("fpAvatarDot");
    const fName = document.getElementById("fpFullName");
    const uSub = document.getElementById("fpUsernameSub");
    const pillDot = document.getElementById("fpPillDot");
    const pillTxt = document.getElementById("fpPillText");
    const pillBox = document.getElementById("fpOnlinePill");

    if (avImg) avImg.src = getSafeAvatar(currentChatUserMeta.avatar);
    if (avDot) avDot.style.background = dotColor;
    if (fName) fName.textContent = currentChatUserMeta.name || "Student";
    if (uSub) uSub.textContent = fullHandle;
    if (pillDot) pillDot.style.background = dotColor;
    if (pillTxt) pillTxt.textContent = pres.text;
    if (pillBox) {
        pillBox.style.background = pres.online ? "rgba(16, 185, 129, 0.14)" : "rgba(148, 163, 184, 0.18)";
        pillBox.style.color = pres.online ? "#059669" : "#64748b";
    }

    const cUser = document.getElementById("fpCardUsername");
    const cName = document.getElementById("fpCardName");
    const cBio = document.getElementById("fpCardBio");
    const cBioCount = document.getElementById("fpBioCount");
    const bDot = document.getElementById("fpBottomStatusDot");
    const bTxt = document.getElementById("fpBottomStatusText");

    if (cUser) cUser.textContent = cleanHandle;
    if (cName) cName.textContent = currentChatUserMeta.name || "Student";
    if (cBio) cBio.textContent = bioStr;
    if (cBioCount) cBioCount.textContent = `${bioStr.length}/150`;
    if (bDot) bDot.style.background = dotColor;
    if (bTxt) bTxt.textContent = pres.text;
}

async function copyFriendUsername() {
    if (!currentChatUserMeta) return;
    const handle = (currentChatUserMeta.username || "").replace(/^@/, "");
    try {
        await navigator.clipboard.writeText(handle);
        showCustomAlert("Copied! ✓", `@${handle} copied to clipboard.`, true);
    } catch (e) {}
}

function viewDmUserProfileInfo() {
    openFriendProfileScreen();
}

function renderDmHeaderStatus() {
    const statusEl = document.getElementById("activeChatStatus");
    const dotEl = document.getElementById("activeChatOnlineDot");
    if (!statusEl || !currentChatUserMeta) return;

    const uHandle = escapeHtml(currentChatUserMeta.username || "@student");
    if (isFriendCurrentlyTyping) {
        statusEl.innerHTML = `${uHandle} • <span style="color:#10b981; font-weight:800;">typing...</span>`;
        if (dotEl) dotEl.style.background = "#10b981";
        return;
    }

    const pres = formatPresenceStatusText(
        currentChatUserMeta.isOnline,
        currentChatUserMeta.lastActiveAtMs,
        currentChatUserMeta.lastSeenLabel
    );
    if (pres.online) {
        statusEl.innerHTML = `${uHandle} • <span style="color:#10b981; font-weight:700;">Online</span>`;
        if (dotEl) dotEl.style.background = "#10b981";
    } else {
        statusEl.innerHTML = `${uHandle} • <span style="color:#94a3b8;">${escapeHtml(pres.text)}</span>`;
        if (dotEl) dotEl.style.background = "#94a3b8";
    }
}

function handleLiveTypingInput() {
    if (!db || !auth?.currentUser || !currentChatUserId) return;
    const myUid = auth.currentUser.uid;
    const chatId = myUid < currentChatUserId ? `${myUid}_${currentChatUserId}` : `${currentChatUserId}_${myUid}`;

    db.collection("chats").doc(chatId).set({
        [`typing_${myUid}`]: true
    }, { merge: true }).catch(() => {});

    clearTimeout(typingTimeoutTimer);
    typingTimeoutTimer = setTimeout(() => {
        db.collection("chats").doc(chatId).set({
            [`typing_${myUid}`]: false
        }, { merge: true }).catch(() => {});
    }, 1500);
}

function renderDmMessagesListToDOM(chatId, messagesArray, myUid) {
    const msgContainer = document.getElementById("activeChatMessages");
    if (!msgContainer) return;

    const clearedAt = chatClearedAtMap[chatId] || 0;
    const visibleMsgs = messagesArray.filter(m => {
        if (deletedMsgsMap[m.id]) return false;
        if (clearedAt && (m.timestampMs || 0) <= clearedAt) return false;
        return true;
    });

    const firstName = escapeHtml((currentChatUserMeta?.name || "Friend").split(" ")[0]);
    if (visibleMsgs.length === 0) {
        msgContainer.innerHTML = `
            <div class="dm-empty-state-wrap">
                <div class="dm-3d-bubbles-box">
                    <div class="dm-bubble-big"><span></span><span></span><span></span></div>
                    <div class="dm-bubble-small"><span></span><span></span><span></span></div>
                </div>
                <h3>No messages yet</h3>
                <p>Start a conversation with ${firstName}</p>
            </div>
        `;
        return;
    }

    const friendDp = escapeHtml(getSafeAvatar(currentChatUserMeta?.avatar));
    const fragment = document.createDocumentFragment();

    visibleMsgs.forEach(d => {
        const isMe = d.senderId === myUid;
        const isMediaOnly = Boolean(d.imageData && !d.text);
        let tickIcon = '<i class="fa-solid fa-check" style="color:rgba(255,255,255,0.85); font-size:10px;"></i>';
        if (d.seen) {
            tickIcon = '<i class="fa-solid fa-check-double" style="color:#38bdf8; font-size:11px;"></i>';
        } else if (d.delivered) {
            tickIcon = '<i class="fa-solid fa-check-double" style="color:rgba(255,255,255,0.9); font-size:10px;"></i>';
        }

        const mediaHtml = d.imageData
            ? `<div class="sent-media-grid"><img src="${d.imageData}" class="sent-wide-photo" onclick="event.stopPropagation(); openFullImageModal('${d.imageData}')" alt="Photo"></div>`
            : "";

        const reactionHtml = d.reaction
            ? `<span class="msg-reaction-badge">${escapeHtml(d.reaction)}</span>`
            : "";

        const row = document.createElement("div");
        row.className = `msg-row-with-avatar ${isMe ? "right-user" : "left-friend"}`;
        if (d.reaction) row.style.marginBottom = "18px";

        if (isMe) {
            row.innerHTML = `
                <div class="clean-right-bubble ${isMediaOnly ? 'media-only-bubble' : ''}" onclick="promptDeleteMessage('${d.id}', '${chatId}')" style="cursor:pointer;">
                    ${mediaHtml}
                    ${d.text ? `<div style="${d.imageData ? 'padding:6px 8px 2px;' : ''}">${escapeHtml(d.text)}</div>` : ""}
                    <div class="bubble-meta-time">
                        <span>${escapeHtml(d.timeLabel || "Now")}</span>
                        ${tickIcon}
                    </div>
                    ${reactionHtml}
                </div>
            `;
        } else {
            row.innerHTML = `
                <img src="${friendDp}" onerror="this.src='logo.png'" class="msg-side-avatar dm-friend-side-dp" alt="DP" onclick="openFriendProfileScreen()" style="cursor:pointer;">
                <div class="clean-left-bubble ${isMediaOnly ? 'media-only-bubble' : ''}" onclick="promptDeleteMessage('${d.id}', '${chatId}')" style="cursor:pointer;">
                    ${mediaHtml}
                    ${d.text ? `
                    <div style="display:flex; justify-content:space-between; align-items:baseline; gap:12px; ${d.imageData ? 'padding:6px 8px 2px;' : ''}">
                        <span>${escapeHtml(d.text)}</span>
                        <span style="font-size:10px; color:#94a3b8; font-weight:500; white-space:nowrap;">${escapeHtml(d.timeLabel || "Now")}</span>
                    </div>` : `
                    <div class="bubble-meta-time">
                        <span>${escapeHtml(d.timeLabel || "Now")}</span>
                    </div>`}
                    ${reactionHtml}
                </div>
            `;
        }
        fragment.appendChild(row);
    });

    msgContainer.innerHTML = "";
    msgContainer.appendChild(fragment);
    msgContainer.scrollTop = msgContainer.scrollHeight;
}

function loadMessagesFromFirestore(recipientId) {
    const msgContainer = document.getElementById("activeChatMessages");
    if (!msgContainer) return;

    if (activeMessagesUnsubscribe) {
        activeMessagesUnsubscribe();
        activeMessagesUnsubscribe = null;
    }

    const myUid = auth?.currentUser?.uid || "local";
    const chatId = myUid < recipientId ? `${myUid}_${recipientId}` : `${recipientId}_${myUid}`;
    const cacheKey = `zorenoDmCache_${chatId}`;

    let cachedMsgs = [];
    try { cachedMsgs = JSON.parse(localStorage.getItem(cacheKey) || "[]"); } catch (e) { cachedMsgs = []; }
    if (cachedMsgs.length > 0) {
        renderDmMessagesListToDOM(chatId, cachedMsgs, myUid);
    } else {
        renderDmMessagesListToDOM(chatId, [], myUid);
    }

    if (!db || !auth?.currentUser) return;

    activeMessagesUnsubscribe = db.collection("chats").doc(chatId).collection("messages")
        .onSnapshot(snapshot => {
            const docs = snapshot.docs.slice().sort((a, b) => {
                const da = a.data();
                const dbData = b.data();
                const ta = da.timestampMs || da.createdAt?.toMillis?.() || 0;
                const tb = dbData.timestampMs || dbData.createdAt?.toMillis?.() || 0;
                return ta - tb;
            });

            const unseenRefs = [];
            const freshList = docs.map(doc => {
                const d = doc.data();
                if (d.senderId !== myUid && !d.seen) {
                    unseenRefs.push(doc.ref);
                }
                return {
                    id: doc.id,
                    senderId: d.senderId,
                    text: d.text || "",
                    imageData: d.imageData || "",
                    reaction: d.reaction || "",
                    timeLabel: d.timeLabel || "Now",
                    timestampMs: d.timestampMs || d.createdAt?.toMillis?.() || 0,
                    delivered: true,
                    seen: d.senderId !== myUid ? true : !!d.seen
                };
            });

            try { localStorage.setItem(cacheKey, JSON.stringify(freshList.slice(-60))); } catch (e) {}
            renderDmMessagesListToDOM(chatId, freshList, myUid);
            markDmChatAsRead(recipientId);

            if (unseenRefs.length > 0) {
                const batch = db.batch();
                unseenRefs.forEach(ref => batch.update(ref, { seen: true, delivered: true }));
                batch.commit().catch(() => {});
            }
        });
}

// ================= DM IMAGE UPLOAD WITH CIRCULAR LOADING SPINNER =================
function openDmImagePicker() {
    document.getElementById("dmImageInput")?.click();
}

function handleDmImageSelect(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    event.target.value = "";

    const strip = document.getElementById("dmAttachmentPreviewBar");
    if (!strip) return;

    pendingDmAttachment = { loading: true, dataUrl: "" };
    strip.style.setProperty("display", "flex", "important");
    strip.innerHTML = `
        <div class="preview-item-chip">
            <div class="chip-spinner-overlay"><i class="fa-solid fa-circle-notch fa-spin"></i></div>
        </div>
        <span style="font-size:12px; font-weight:700; color:#7c3aed;">Processing photo...</span>
    `;

    const reader = new FileReader();
    reader.onload = function (e) {
        const img = new Image();
        img.onload = function () {
            const canvas = document.createElement("canvas");
            const MAX_DIM = 720;
            let w = img.width, h = img.height;
            if (w > h && w > MAX_DIM) { h = Math.round((h * MAX_DIM) / w); w = MAX_DIM; }
            else if (h >= w && h > MAX_DIM) { w = Math.round((w * MAX_DIM) / h); h = MAX_DIM; }
            canvas.width = w;
            canvas.height = h;
            canvas.getContext("2d").drawImage(img, 0, 0, w, h);
            const compressed = canvas.toDataURL("image/jpeg", 0.68);

            setTimeout(() => {
                pendingDmAttachment = { loading: false, dataUrl: compressed };
                strip.innerHTML = `
                    <div class="preview-item-chip">
                        <img src="${compressed}" onclick="openFullImageModal('${compressed}')" alt="Preview">
                        <button type="button" class="preview-remove-x" onclick="clearDmAttachment()">×</button>
                    </div>
                    <span style="font-size:12px; font-weight:700; color:#10b981;">✓ Ready</span>
                `;
            }, 300);
        };
        img.src = e.target.result;
    };
    reader.readAsDataURL(file);
}

function clearDmAttachment() {
    pendingDmAttachment = null;
    const strip = document.getElementById("dmAttachmentPreviewBar");
    if (strip) {
        strip.innerHTML = "";
        strip.style.setProperty("display", "none", "important");
    }
}


// =========================================================
// ZORENO APP.JS — PART 2 OF 3
// DM SENDING, HOME DELETE, EMOJI REACTIONS, GROUPS & INVITES, IMAGE PICKER
// =========================================================

let currentChatIsGroup = false;
let userGroupsList = [];
let pendingGroupInvites = [];
let groupsUnsubscribe = null;
let groupInvitesUnsubscribe = null;

async function sendRealtimeMessage() {
    const input = document.getElementById("activeChatInput");
    const text = (input?.value || "").trim();
    if (pendingDmAttachment?.loading) {
        showCustomAlert("Please Wait", "Photo is still loading...");
        return;
    }
    const imgData = pendingDmAttachment?.dataUrl || "";
    if ((!text && !imgData) || !currentChatUserId) return;

    if (!currentChatIsGroup && blockedUsersMap[currentChatUserId]) {
        showCustomAlert("Blocked 🚫", "You have blocked this user. Unblock from the 3-dot menu to send messages.");
        return;
    }

    // Run Zoreno Proprietary Spam & Virus-Link Safety Algorithm
    const safetyCheck = evaluateZorenoSafetyAlgorithm(text);
    if (safetyCheck.action === "block") {
        showCustomAlert("Security Shield 🛡️", `Message blocked by Zoreno Safety Algorithm (${safetyCheck.reason}).`);
        return;
    } else if (safetyCheck.action === "warn") {
        showCustomAlert("Security Warning ⚠️", `Caution: This message contains a ${safetyCheck.reason}.`);
    }

    const nowMs = Date.now();
    const nowTime = new Date(nowMs).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    if (input) {
        input.value = "";
        input.style.height = "auto";
    }
    clearDmAttachment();

    if (!db || !auth?.currentUser) return;
    const myUid = auth.currentUser.uid;

    // 1. If currently inside a Study Group Chat
    if (currentChatIsGroup) {
        try {
            await db.collection("groups").doc(currentChatUserId).collection("messages").add({
                senderId: myUid,
                senderName: userName || "Student",
                senderAvatar: getSafeAvatar(userAvatarUrl),
                text: text,
                imageData: imgData,
                timeLabel: nowTime,
                timestampMs: nowMs,
                delivered: true,
                seen: true,
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            });
            await db.collection("groups").doc(currentChatUserId).set({
                lastMessage: `${userName.split(" ")[0]}: ${text || "📷 Photo"}`,
                lastMessageAtMs: nowMs,
                timeLabel: nowTime
            }, { merge: true });
        } catch (e) {
            console.error("Group send error:", e);
        }
        return;
    }

    // 2. Normal 1-on-1 Friend DM Chat
    const previewLabel = text ? `You: ${text}` : "You: 📷 Photo";
    if (currentChatUserMeta) {
        upsertRecentDmOnHome(
            currentChatUserMeta.uid,
            currentChatUserMeta.name,
            currentChatUserMeta.avatar,
            currentChatUserMeta.username,
            previewLabel,
            nowTime,
            0,
            nowMs
        );
    }

    const chatId = myUid < currentChatUserId ? `${myUid}_${currentChatUserId}` : `${currentChatUserId}_${myUid}`;

    try {
        await db.collection("chats").doc(chatId).collection("messages").add({
            senderId: myUid,
            text: text,
            imageData: imgData,
            timeLabel: nowTime,
            timestampMs: nowMs,
            delivered: true,
            seen: false,
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });

        await db.collection("chats").doc(chatId).set({
            participants: [myUid, currentChatUserId],
            lastMessage: text || "📷 Photo",
            lastSenderId: myUid,
            lastSenderName: userName,
            lastSenderAvatar: getSafeAvatar(userAvatarUrl),
            lastSenderUsername: currentUsername || "@student",
            [`typing_${myUid}`]: false,
            lastMessageAtMs: nowMs,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
            timeLabel: nowTime
        }, { merge: true });
    } catch (e) {
        console.error("Send DM error:", e);
    }
}

function updateRecentDmMetaOnly(uid, name, avatar, username) {
    const idx = recentDmUsers.findIndex(x => x.uid === uid);
    if (idx < 0) return;
    recentDmUsers[idx].name = name || recentDmUsers[idx].name;
    recentDmUsers[idx].avatar = getSafeAvatar(avatar || recentDmUsers[idx].avatar);
    recentDmUsers[idx].username = username || recentDmUsers[idx].username;
    try { localStorage.setItem("zorenoRecentDms", JSON.stringify(recentDmUsers)); } catch (e) {}
    scheduleRenderSavedDmChats();
}

function upsertRecentDmOnHome(uid, name, avatar, username, lastMsg, timeStr, unreadCount = 0, msgTimestampMs = 0) {
    if (!uid || uid === "arjun_user_id") return;
    const cleanUn = (username || "").toLowerCase();
    const cleanNm = (name || "").toLowerCase();
    if (cleanUn === "@friend" || cleanUn === "@user" || cleanNm === "friend" || cleanNm === "user") return;

    const idx = recentDmUsers.findIndex(x => x.uid === uid);
    const prev = idx >= 0 ? recentDmUsers[idx] : {};
    const effectiveMs = msgTimestampMs || prev.lastMessageAtMs || Date.now();

    const entry = {
        uid,
        name: name || prev.name || "Student",
        avatar: getSafeAvatar(avatar || prev.avatar),
        username: username || prev.username || "@student",
        lastMsg: lastMsg || prev.lastMsg || "Tap to chat",
        timeStr: formatSmartTimeLabel(effectiveMs) || timeStr || prev.timeStr || "",
        lastMessageAtMs: effectiveMs,
        unread: typeof unreadCount === "number" ? unreadCount : (prev.unread || 0)
    };

    if (idx >= 0) recentDmUsers.splice(idx, 1);
    recentDmUsers.push(entry);

    recentDmUsers.sort((a, b) => (b.lastMessageAtMs || 0) - (a.lastMessageAtMs || 0));

    localStorage.setItem("zorenoRecentDms", JSON.stringify(recentDmUsers.slice(0, 25)));
    scheduleRenderSavedDmChats();
}

let renderHomeDmTimer = null;
function scheduleRenderSavedDmChats() {
    clearTimeout(renderHomeDmTimer);
    renderHomeDmTimer = setTimeout(renderSavedDmChatsOnHome, 80);
}

// ================= DELETE PROFILE & CHAT FROM HOME SCREEN + FIREBASE =================
function promptDeleteHomeChatProfile(uid, name, event) {
    if (event) event.stopPropagation();
    homeChatUidToDelete = uid;
    const titleEl = document.getElementById("delHomeChatTitle");
    if (titleEl) titleEl.textContent = `Delete ${name || "Chat"}?`;
    const modal = document.getElementById("deleteHomeChatModal");
    if (modal) modal.style.display = "flex";
}

async function confirmDeleteHomeChatAndFirebase() {
    const targetUid = homeChatUidToDelete;
    const modal = document.getElementById("deleteHomeChatModal");
    if (modal) modal.style.display = "none";
    if (!targetUid) return;

    recentDmUsers = recentDmUsers.filter(u => u.uid !== targetUid);
    localStorage.setItem("zorenoRecentDms", JSON.stringify(recentDmUsers));
    renderSavedDmChatsOnHome();

    if (db && auth?.currentUser) {
        const myUid = auth.currentUser.uid;
        const chatId = myUid < targetUid ? `${myUid}_${targetUid}` : `${targetUid}_${myUid}`;
        localStorage.removeItem(`zorenoDmCache_${chatId}`);
        try {
            const msgSnap = await db.collection("chats").doc(chatId).collection("messages").get();
            const batch = db.batch();
            msgSnap.forEach(doc => batch.delete(doc.ref));
            batch.delete(db.collection("chats").doc(chatId));
            await batch.commit();
        } catch (e) {
            console.error("Error deleting chat from Firebase:", e);
        }
    }
    homeChatUidToDelete = null;
    showCustomAlert("Deleted Forever 🗑️", "Profile and all chat messages have been permanently deleted.", true);
}

function renderSavedDmChatsOnHome() {
    const container = document.querySelector(".chats-container");
    if (!container) return;

    container.querySelectorAll(".dynamic-dm-item, .group-top-Controls").forEach(el => el.remove());
    const pinnedItem = container.querySelector(".chat-list-item.pinned");

    // Insert Group Create Button & Pending Group Invites Bar (Shown when "Groups" tab is active)
    const groupBar = document.createElement("div");
    groupBar.className = "group-top-Controls";
    groupBar.style.display = currentActiveChatTab === "groups" ? "flex" : "none";
    groupBar.style.flexDirection = "column";
    groupBar.style.gap = "8px";
    groupBar.style.marginBottom = "10px";

    let invitesHtml = pendingGroupInvites.map(inv => `
        <div class="chat-list-item" style="background:rgba(124,58,237,0.1); border:1.5px solid #c084fc;">
            <div class="chat-avatar group-avatar"><i class="fa-solid fa-user-group" style="color:#7c3aed;"></i></div>
            <div class="chat-info">
                <div class="chat-name-row"><h4>📩 Invite: ${escapeHtml(inv.groupName)}</h4></div>
                <div class="chat-msg-row"><p>Invited by ${escapeHtml(inv.inviterName)}</p></div>
            </div>
            <div style="display:flex; gap:6px;">
                <button type="button" onclick="respondToGroupInvite('${inv.id}', '${inv.groupId}', true)" style="background:#10b981; color:#fff; border:none; padding:6px 12px; border-radius:12px; font-size:12px; font-weight:700; cursor:pointer;">Accept</button>
                <button type="button" onclick="respondToGroupInvite('${inv.id}', '${inv.groupId}', false)" style="background:#ef4444; color:#fff; border:none; padding:6px 10px; border-radius:12px; font-size:12px; font-weight:700; cursor:pointer;">✕</button>
            </div>
        </div>
    `).join("");

    groupBar.innerHTML = `
        <button type="button" onclick="openCreateGroupModal()" style="width:100%; padding:12px 16px; border-radius:18px; border:1.5px dashed #7c3aed; background:rgba(124,58,237,0.08); color:#7c3aed; font-weight:800; font-size:14px; display:flex; align-items:center; justify-content:center; gap:8px; cursor:pointer;">
            <i class="fa-solid fa-users-medical"></i> + Create Study Group (Send Invites)
        </button>
        ${invitesHtml}
    `;
    container.prepend(groupBar);

    // Render Joined Study Groups
    userGroupsList.forEach(grp => {
        const gDiv = document.createElement("div");
        gDiv.className = "chat-list-item dynamic-dm-item group-chat-item";
        gDiv.style.cursor = "pointer";
        gDiv.onclick = () => openStudyGroupChat(grp);
        gDiv.innerHTML = `
            <div class="chat-avatar group-avatar" style="background:linear-gradient(135deg,#ede9fe,#ddd6fe); color:#7c3aed; display:flex; align-items:center; justify-content:center; font-size:18px;">
                <i class="fa-solid fa-users"></i>
            </div>
            <div class="chat-info">
                <div class="chat-name-row">
                    <h4>${escapeHtml(grp.name)} <span class="official-pill">${(grp.members || []).length} Members</span></h4>
                    <span class="chat-time">${escapeHtml(grp.timeLabel || "Group")}</span>
                </div>
                <div class="chat-msg-row">
                    <p>${escapeHtml(grp.lastMessage || "Tap to open group study chat")}</p>
                </div>
            </div>
        `;
        container.appendChild(gDiv);
    });

    // Render 1-on-1 Friends List
    const sortedList = recentDmUsers.slice().sort((a, b) => (b.lastMessageAtMs || 0) - (a.lastMessageAtMs || 0));

    sortedList.slice().reverse().forEach(item => {
        const cleanUn = (item.username || "").toLowerCase();
        if (cleanUn === "@friend" || cleanUn === "@user") return;

        const div = document.createElement("div");
        div.className = "chat-list-item dynamic-dm-item";
        div.style.cursor = "pointer";
        div.onclick = () => {
            currentChatIsGroup = false;
            openChatWithUser(item.uid, item.name, item.avatar, item.username);
        };

        let pressTimer = null;
        div.addEventListener("touchstart", () => {
            pressTimer = setTimeout(() => promptDeleteHomeChatProfile(item.uid, item.name), 650);
        }, { passive: true });
        div.addEventListener("touchend", () => clearTimeout(pressTimer));
        div.addEventListener("touchmove", () => clearTimeout(pressTimer));

        const displayTime = formatSmartTimeLabel(item.lastMessageAtMs) || item.timeStr || "";
        div.innerHTML = `
            <div class="chat-avatar">
                <img src="${escapeHtml(getSafeAvatar(item.avatar))}" onerror="this.src='logo.png'" alt="${escapeHtml(item.name)}">
                <div class="online-dot"></div>
            </div>
            <div class="chat-info">
                <div class="chat-name-row">
                    <h4>${escapeHtml(item.name)}</h4>
                    <span class="chat-time">${escapeHtml(displayTime)}</span>
                </div>
                <div class="chat-msg-row">
                    <p>${escapeHtml(item.lastMsg)}</p>
                    <div style="display:flex; align-items:center; gap:4px;">
                        ${item.unread > 0 ? `<span class="unread-count">${item.unread}</span>` : ""}
                        <button type="button" class="home-chat-del-btn" onclick="promptDeleteHomeChatProfile('${item.uid}', '${escapeHtml(item.name)}', event)" title="Delete Chat">
                            <i class="fa-regular fa-trash-can"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
        if (pinnedItem) {
            pinnedItem.insertAdjacentElement("afterend", div);
        } else {
            container.prepend(div);
        }
    });

    filterHomeChatListByTab(currentActiveChatTab);
}

// ================= STUDY GROUPS & INVITATION SYSTEM =================
function listenUserGroupsAndInvites(myUid) {
    if (!db || !myUid) return;
    if (groupsUnsubscribe) groupsUnsubscribe();
    if (groupInvitesUnsubscribe) groupInvitesUnsubscribe();

    groupsUnsubscribe = db.collection("groups")
        .where("members", "array-contains", myUid)
        .onSnapshot(snap => {
            userGroupsList = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            scheduleRenderSavedDmChats();
        }, () => {});

    groupInvitesUnsubscribe = db.collection("groupInvites")
        .where("toUid", "==", myUid)
        .where("status", "==", "pending")
        .onSnapshot(snap => {
            pendingGroupInvites = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            scheduleRenderSavedDmChats();
        }, () => {});
}

function openCreateGroupModal() {
    let modal = document.getElementById("zorenoCreateGroupModal");
    if (!modal) {
        modal = document.createElement("div");
        modal.id = "zorenoCreateGroupModal";
        modal.className = "custom-modal-overlay";
        modal.style.zIndex = "999999";
        document.body.appendChild(modal);
    }

    const friendsHtml = recentDmUsers.length === 0
        ? `<p style="font-size:12.5px; color:#64748b;">Search & message friends first to invite them to your group.</p>`
        : recentDmUsers.map(f => `
            <label style="display:flex; align-items:center; justify-content:space-between; padding:8px 10px; border-radius:12px; border:1px solid #e2e8f0; margin-bottom:6px; cursor:pointer;">
                <div style="display:flex; align-items:center; gap:10px;">
                    <img src="${escapeHtml(getSafeAvatar(f.avatar))}" onerror="this.src='logo.png'" style="width:34px; height:34px; border-radius:50%; object-fit:cover;">
                    <div style="text-align:left;">
                        <div style="font-size:13.5px; font-weight:700;">${escapeHtml(f.name)}</div>
                        <div style="font-size:11px; color:#7c3aed;">${escapeHtml(f.username)}</div>
                    </div>
                </div>
                <input type="checkbox" class="grp-invite-chk" value="${escapeHtml(f.uid)}" style="width:18px; height:18px; accent-color:#7c3aed;">
            </label>
        `).join("");

    modal.innerHTML = `
        <div class="custom-modal-box">
            <div class="policy-modal-header">
                <h3>Create Study Group 👥</h3>
                <button class="modal-close-btn" onclick="document.getElementById('zorenoCreateGroupModal').style.display='none'"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <input type="text" id="newStudyGroupName" placeholder="Enter Group Name (e.g. Physics Class 10)" style="width:100%; padding:12px; border-radius:14px; border:1.5px solid #cbd5e1; outline:none; margin-bottom:12px; font-weight:700;">
            <div style="font-size:12px; font-weight:800; color:#64748b; margin-bottom:6px; text-align:left;">SELECT FRIENDS TO SEND INVITATION:</div>
            <div style="max-height:180px; overflow-y:auto; margin-bottom:14px;">${friendsHtml}</div>
            <button type="button" class="modal-submit-btn" onclick="submitCreateStudyGroup()">Create Group & Send Invites 🚀</button>
        </div>
    `;
    modal.style.display = "flex";
}

async function submitCreateStudyGroup() {
    const gName = (document.getElementById("newStudyGroupName")?.value || "").trim();
    if (!gName) {
        showCustomAlert("Group Name Required", "Please enter a name for your group.");
        return;
    }
    if (!db || !auth?.currentUser) return;

    const myUid = auth.currentUser.uid;
    const selectedUids = Array.from(document.querySelectorAll(".grp-invite-chk:checked")).map(cb => cb.value);

    try {
        const nowTime = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
        const grpRef = await db.collection("groups").add({
            name: gName,
            adminUid: myUid,
            members: [myUid], // Creator is added first; others join as they accept their invite!
            lastMessage: `Group "${gName}" created`,
            lastMessageAtMs: Date.now(),
            timeLabel: nowTime,
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });

        for (const friendUid of selectedUids) {
            await db.collection("groupInvites").add({
                groupId: grpRef.id,
                groupName: gName,
                fromUid: myUid,
                inviterName: userName || "Friend",
                toUid: friendUid,
                status: "pending",
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            });
        }

        document.getElementById("zorenoCreateGroupModal").style.display = "none";
        showCustomAlert("Group Created! 🎉", selectedUids.length > 0
            ? `Group "${gName}" is ready and invitations have been sent to ${selectedUids.length} friend(s). They will join once they accept!`
            : `Group "${gName}" created successfully!`, true);
    } catch (e) {
        showCustomAlert("Error", e.message);
    }
}

async function respondToGroupInvite(inviteDocId, groupId, accept) {
    if (!db || !auth?.currentUser) return;
    const myUid = auth.currentUser.uid;
    try {
        if (accept) {
            await db.collection("groups").doc(groupId).update({
                members: firebase.firestore.FieldValue.arrayUnion(myUid)
            });
        }
        await db.collection("groupInvites").doc(inviteDocId).update({
            status: accept ? "accepted" : "declined"
        });
        if (accept) {
            showCustomAlert("Joined Group! 🎉", "You are now a member of this study group.", true);
        }
    } catch (e) {
        console.error("Group invite error:", e);
    }
}

function openStudyGroupChat(grp) {
    closeAllDropdownMenus();
    currentChatIsGroup = true;
    currentChatUserId = grp.id;
    currentChatUserMeta = {
        uid: grp.id,
        name: grp.name || "Study Group",
        avatar: "logo.png",
        username: `${(grp.members || []).length} Members`,
        bio: "Zoreno Study Group",
        isOnline: true
    };

    const chatWin = document.getElementById("activeChatScreen");
    const nameEl = document.getElementById("activeChatName");
    const avatarEl = document.getElementById("activeChatAvatar");
    const statusEl = document.getElementById("activeChatStatus");
    const bottomNav = document.getElementById("bottomNav");

    if (nameEl) nameEl.textContent = currentChatUserMeta.name;
    if (avatarEl) avatarEl.src = "logo.png";
    if (statusEl) statusEl.innerHTML = `<span style="color:#10b981; font-weight:700;">${(grp.members || []).length} Members Active</span>`;

    if (bottomNav) bottomNav.style.setProperty("display", "none", "important");
    if (chatWin) {
        chatWin.style.setProperty("display", "flex", "important");
        chatWin.style.setProperty("visibility", "visible", "important");
        chatWin.style.setProperty("pointer-events", "auto", "important");
    }

    if (activeMessagesUnsubscribe) activeMessagesUnsubscribe();
    const myUid = auth?.currentUser?.uid || "local";

    activeMessagesUnsubscribe = db.collection("groups").doc(grp.id).collection("messages")
        .onSnapshot(snapshot => {
            const docs = snapshot.docs.slice().sort((a, b) => (a.data().timestampMs || 0) - (b.data().timestampMs || 0));
            const list = docs.map(doc => {
                const d = doc.data();
                return {
                    id: doc.id,
                    senderId: d.senderId,
                    text: d.senderId !== myUid && d.senderName ? `${d.senderName}: ${d.text || ""}` : (d.text || ""),
                    imageData: d.imageData || "",
                    reaction: d.reaction || "",
                    timeLabel: d.timeLabel || "Now",
                    timestampMs: d.timestampMs || 0,
                    delivered: true,
                    seen: true
                };
            });
            renderDmMessagesListToDOM(grp.id, list, myUid);
        });
}

function listenIncomingRealtimeChats(myUid) {
    if (!db || !myUid) return;
    listenUserGroupsAndInvites(myUid);

    if (incomingChatsUnsub) {
        incomingChatsUnsub();
        incomingChatsUnsub = null;
    }

    incomingChatsUnsub = db.collection("chats")
        .where("participants", "array-contains", myUid)
        .onSnapshot(snap => {
            snap.docChanges().forEach(async change => {
                if (change.type !== "added" && change.type !== "modified") return;
                const d = change.doc.data();
                const otherUid = (d.participants || []).find(id => id !== myUid);
                if (!otherUid || !d.lastMessage) return;

                let cached = userProfileCache[otherUid];
                if (!cached) {
                    try {
                        const uDoc = await db.collection("users").doc(otherUid).get();
                        if (!uDoc.exists) return;
                        cached = uDoc.data();
                        userProfileCache[otherUid] = cached;
                    } catch (e) { return; }
                }

                const friendName = cached.name || d.lastSenderName || "Friend";
                const friendAvatar = getSafeAvatar(cached.photoURL || cached.avatarUrl || d.lastSenderAvatar);
                const friendUsername = cached.username || d.lastSenderUsername;

                if (!friendUsername || friendUsername === "@friend" || friendUsername === "@user") return;

                const prevEntry = recentDmUsers.find(x => x.uid === otherUid);
                const msgTimeMs = d.lastMessageAtMs || d.updatedAt?.toMillis?.() || prevEntry?.lastMessageAtMs || 0;
                const displayTimeStr = msgTimeMs ? formatSmartTimeLabel(msgTimeMs) : (d.timeLabel || prevEntry?.timeStr || "");
                const lastReadMs = lastReadAtMap[otherUid] || 0;
                const isChatOpen = document.getElementById("activeChatScreen")?.style.display === "flex" && currentChatUserId === otherUid;

                if (isChatOpen && msgTimeMs) {
                    markDmChatAsRead(otherUid);
                }

                const isUnreadForMe = d.lastSenderId !== myUid && !isChatOpen && msgTimeMs > 0 && msgTimeMs > lastReadMs;
                const msgPreview = d.lastSenderId === myUid ? `You: ${d.lastMessage}` : d.lastMessage;

                upsertRecentDmOnHome(
                    otherUid,
                    friendName,
                    friendAvatar,
                    friendUsername,
                    msgPreview,
                    displayTimeStr,
                    isUnreadForMe ? 1 : 0,
                    msgTimeMs || 1
                );

                const lastNotifiedMs = lastNotifiedMsgMap[otherUid] || 0;
                if (isUnreadForMe && msgTimeMs > lastNotifiedMs) {
                    lastNotifiedMsgMap[otherUid] = msgTimeMs;
                    try { localStorage.setItem("zorenoNotifiedMsgMap", JSON.stringify(lastNotifiedMsgMap)); } catch (e) {}
                    showZorenoIncomingNotification(otherUid, friendName, friendAvatar, friendUsername, d.lastMessage);
                }
            });
        });
}

function closeActiveDmChat() {
    closeAllDropdownMenus();
    closeFriendProfileScreen();
    currentChatIsGroup = false;
    if (activeFriendProfileUnsub) { activeFriendProfileUnsub(); activeFriendProfileUnsub = null; }
    if (activeChatMetaUnsub) { activeChatMetaUnsub(); activeChatMetaUnsub = null; }
    if (activeMessagesUnsubscribe) { activeMessagesUnsubscribe(); activeMessagesUnsubscribe = null; }
    const chatWin = document.getElementById("activeChatScreen");
    if (chatWin) chatWin.style.setProperty("display", "none", "important");
    showChatsHome();
}

function toggleDmHeaderMenu(forceState) {
    const menu = document.getElementById("dmHeaderDropdownMenu");
    if (!menu) return;
    const nextState = typeof forceState === "boolean" ? forceState : menu.style.display !== "block";
    closeAllDropdownMenus();
    menu.style.display = nextState ? "block" : "none";
}

async function toggleBlockChatUser() {
    closeAllDropdownMenus();
    if (!currentChatUserId || currentChatIsGroup) return;
    const isBlocked = !!blockedUsersMap[currentChatUserId];
    if (isBlocked) {
        delete blockedUsersMap[currentChatUserId];
        showCustomAlert("User Unblocked", "You can now send messages to this user.", true);
    } else {
        blockedUsersMap[currentChatUserId] = true;
        showCustomAlert("User Blocked 🚫", "You will no longer receive or send messages in this chat.");
    }
    localStorage.setItem("zorenoBlockedUsers", JSON.stringify(blockedUsersMap));
    updateBlockMenuButtonUI();

    if (db && auth?.currentUser) {
        try {
            await db.collection("users").doc(auth.currentUser.uid).set({
                blockedUsers: blockedUsersMap
            }, { merge: true });
        } catch (e) {}
    }
}

function updateBlockMenuButtonUI() {
    const isBlocked = currentChatUserId && !!blockedUsersMap[currentChatUserId];
    const html = isBlocked
        ? '<i class="fa-solid fa-rotate-left"></i> Unblock User'
        : '<i class="fa-solid fa-ban"></i> Block User';
    const btn1 = document.getElementById("dmBlockMenuBtn");
    const btn2 = document.getElementById("fpBlockMenuBtn");
    if (btn1) btn1.innerHTML = html;
    if (btn2) btn2.innerHTML = html;
}

async function clearCurrentDmChat() {
    closeAllDropdownMenus();
    if (!currentChatUserId) return;
    const myUid = auth?.currentUser?.uid || "local";
    const chatId = currentChatIsGroup
        ? currentChatUserId
        : (myUid < currentChatUserId ? `${myUid}_${currentChatUserId}` : `${currentChatUserId}_${myUid}`);

    chatClearedAtMap[chatId] = Date.now();
    try { localStorage.setItem("zorenoChatClearedAtMap", JSON.stringify(chatClearedAtMap)); } catch (e) {}

    let cachedMsgs = [];
    try { cachedMsgs = JSON.parse(localStorage.getItem(`zorenoDmCache_${chatId}`) || "[]"); } catch (e) {}
    renderDmMessagesListToDOM(chatId, cachedMsgs, myUid);
    showCustomAlert("Chat Cleared 🗑️", "Messages have been cleared from your view.", true);
}

function openReportModal() {
    closeAllDropdownMenus();
    document.getElementById("userReportModal").style.display = "flex";
}

async function submitUserReport() {
    const reason = document.getElementById("userReportReason").value.trim();
    if (!reason || !currentChatUserId) return;
    try {
        if (db && auth?.currentUser) {
            await db.collection("reports").add({
                reporterUid: auth.currentUser.uid,
                reporterEmail: auth.currentUser.email || userEmail || "",
                reportedUserId: currentChatUserId,
                reportedUserName: currentChatUserMeta?.name || "",
                reason: reason,
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            });
        }
        document.getElementById("userReportReason").value = "";
        document.getElementById("userReportModal").style.display = "none";
        showCustomAlert("Report Submitted 🚨", "Saved to Firebase 'reports' collection. Our team will review this user within 24 hours.", true);
    } catch (e) {
        showCustomAlert("Error", e.message);
    }
}

// ================= EMOJI REACTIONS & DELETE FOR ME =================
function ensureEmojiReactionBarInModal() {
    const modalBox = document.querySelector("#deleteMsgModal .custom-modal-box");
    if (!modalBox || document.getElementById("zorenoEmojiReactBar")) return;
    const bar = document.createElement("div");
    bar.id = "zorenoEmojiReactBar";
    bar.className = "emoji-reaction-pill-bar";
    const emojis = ["👍", "❤️", "😂", "😮", "😢", "🙏"];
    bar.innerHTML = emojis.map(em =>
        `<button type="button" class="emoji-react-btn" onclick="sendReactionToMessage('${em}')">${em}</button>`
    ).join("");
    modalBox.insertBefore(bar, modalBox.firstChild);
}

async function sendReactionToMessage(emojiChar) {
    document.getElementById("deleteMsgModal").style.display = "none";
    if (!msgToDeleteId || !msgToDeleteChatId || !db) return;
    const collectionName = currentChatIsGroup ? "groups" : "chats";
    try {
        await db.collection(collectionName).doc(msgToDeleteChatId)
            .collection("messages").doc(msgToDeleteId)
            .set({ reaction: emojiChar }, { merge: true });
    } catch (e) {}
}

function promptDeleteMessage(msgId, chatId) {
    ensureEmojiReactionBarInModal();
    const rBar = document.getElementById("zorenoEmojiReactBar");
    if (rBar) rBar.style.display = "flex";
    aiMsgIndexToDelete = null;
    msgToDeleteId = msgId;
    msgToDeleteChatId = chatId;
    document.getElementById("deleteMsgModal").style.display = "flex";
}

function promptDeleteSingleAiMessage(idx) {
    ensureEmojiReactionBarInModal();
    const rBar = document.getElementById("zorenoEmojiReactBar");
    if (rBar) rBar.style.display = "none";
    msgToDeleteId = null;
    msgToDeleteChatId = null;
    aiMsgIndexToDelete = idx;
    document.getElementById("deleteMsgModal").style.display = "flex";
}

async function confirmDeleteMessage() {
    if (aiMsgIndexToDelete !== null && aiChatMessagesList[aiMsgIndexToDelete]) {
        const removed = aiChatMessagesList.splice(aiMsgIndexToDelete, 1)[0];
        try { localStorage.setItem("zorenoAiChatStream", JSON.stringify(aiChatMessagesList)); } catch (e) {}
        renderAiChatStream();

        if (db && auth?.currentUser && removed?.timestampMs) {
            try {
                const snap = await db.collection("users").doc(auth.currentUser.uid)
                    .collection("chats").where("timestampMs", "==", removed.timestampMs).get();
                snap.forEach(d => d.ref.delete());
            } catch (e) {}
        }
        document.getElementById("deleteMsgModal").style.display = "none";
        aiMsgIndexToDelete = null;
        return;
    }

    if (!msgToDeleteId || !msgToDeleteChatId) return;
    deletedMsgsMap[msgToDeleteId] = true;
    try { localStorage.setItem("zorenoDeletedMsgsMap", JSON.stringify(deletedMsgsMap)); } catch (e) {}

    const myUid = auth?.currentUser?.uid || "local";
    let cachedMsgs = [];
    try { cachedMsgs = JSON.parse(localStorage.getItem(`zorenoDmCache_${msgToDeleteChatId}`) || "[]"); } catch (e) {}
    renderDmMessagesListToDOM(msgToDeleteChatId, cachedMsgs, myUid);

    document.getElementById("deleteMsgModal").style.display = "none";
    msgToDeleteId = null;
    msgToDeleteChatId = null;
}

function showCallComingSoon() {
    showCustomAlert("Coming Soon 🚀", "Voice & Video Calling will be available in the next update!", true);
}

function triggerZorenoAudioCall() { showCallComingSoon(); }
function triggerZorenoVideoCall() { showCallComingSoon(); }
function showAttachmentComingSoon() { openDmImagePicker(); }

// ================= AI CHAT IMAGE SELECTION (MAX 2 IMAGES + COMPACT PREVIEW) =================
function openImagePicker() {
    document.getElementById("imageInput")?.click();
}

function openFileOrPdfPicker() {
    document.getElementById("imageInput")?.click();
}

function handleMultipleImages(event) {
    const allSelected = Array.from(event.target.files || []);
    event.target.value = "";
    if (!allSelected.length) return;

    const remainingSlots = 2 - pendingAiAttachments.length;
    if (remainingSlots <= 0) {
        showCustomAlert("Maximum 2 Images", "You can select up to 2 images at a time.");
        return;
    }

    const files = allSelected.slice(0, remainingSlots);
    const strip = document.getElementById("aiAttachmentPreviewBar");
    if (strip) strip.style.setProperty("display", "flex", "important");

    files.forEach(file => {
        const tempId = "att_" + Date.now() + "_" + Math.random().toString(36).slice(2, 6);
        pendingAiAttachments.push({ id: tempId, loading: true, dataUrl: "", mimeType: "image/jpeg" });
        renderAiAttachmentPreviewStrip();

        const reader = new FileReader();
        reader.onload = function (e) {
            const img = new Image();
            img.onload = function () {
                const canvas = document.createElement("canvas");
                const MAX_DIM = 560;
                let w = img.width, h = img.height;
                if (w > h && w > MAX_DIM) { h = Math.round((h * MAX_DIM) / w); w = MAX_DIM; }
                else if (h >= w && h > MAX_DIM) { w = Math.round((w * MAX_DIM) / h); h = MAX_DIM; }
                canvas.width = w;
                canvas.height = h;
                canvas.getContext("2d").drawImage(img, 0, 0, w, h);
                const compressed = canvas.toDataURL("image/jpeg", 0.58);

                setTimeout(() => {
                    const item = pendingAiAttachments.find(x => x.id === tempId);
                    if (item) {
                        item.loading = false;
                        item.dataUrl = compressed;
                        renderAiAttachmentPreviewStrip();
                    }
                }, 280);
            };
            img.onerror = function () {
                pendingAiAttachments = pendingAiAttachments.filter(x => x.id !== tempId);
                renderAiAttachmentPreviewStrip();
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(file);
    });
}

function renderAiAttachmentPreviewStrip() {
    const strip = document.getElementById("aiAttachmentPreviewBar");
    if (!strip) return;
    if (pendingAiAttachments.length === 0) {
        strip.innerHTML = "";
        strip.style.setProperty("display", "none", "important");
        return;
    }
    const isAnyLoading = pendingAiAttachments.some(a => a.loading);
    strip.style.setProperty("display", "flex", "important");
    strip.innerHTML = pendingAiAttachments.map(att => {
        if (att.loading) {
            return `
                <div class="preview-item-chip">
                    <div class="chip-spinner-overlay"><i class="fa-solid fa-circle-notch fa-spin"></i></div>
                </div>
            `;
        }
        return `
            <div class="preview-item-chip">
                <img src="${att.dataUrl}" onclick="openFullImageModal('${att.dataUrl}')" alt="Preview">
                <button type="button" class="preview-remove-x" onclick="removeAiAttachment('${att.id}')">×</button>
            </div>
        `;
    }).join("") + `<span style="font-size:12px; font-weight:700; color:${isAnyLoading ? '#7c3aed' : '#10b981'}; margin-left:4px;">
        ${isAnyLoading ? 'Loading...' : `✓ ${pendingAiAttachments.length}/2`}
    </span>`;
}

function removeAiAttachment(id) {
    pendingAiAttachments = pendingAiAttachments.filter(x => x.id !== id);
    renderAiAttachmentPreviewStrip();
}

function openFullImageModal(dataUrl) {
    const modal = document.getElementById("fullImagePreviewModal");
    const img = document.getElementById("fullImagePreviewTarget");
    if (modal && img) {
        img.src = dataUrl;
        modal.style.display = "flex";
    }
}

// Quick Emoji Bar Popup for Input Box
function toggleQuickEmojiPicker(targetInputId) {
    let picker = document.getElementById("zorenoFloatingEmojiBar");
    if (picker) {
        picker.remove();
        return;
    }
    picker = document.createElement("div");
    picker.id = "zorenoFloatingEmojiBar";
    picker.style.cssText = "position:fixed; bottom:70px; left:50%; transform:translateX(-50%); background:#fff; border:1.5px solid #e2e8f0; border-radius:28px; padding:8px 14px; display:flex; gap:10px; box-shadow:0 12px 30px rgba(0,0,0,0.16); z-index:100006; overflow-x:auto; max-width:92vw;";
    const list = ["😊", "😂", "❤️", "👍", "🔥", "🎉", "😎", "🤔", "🙏", "💯", "🚀", "✨"];
    picker.innerHTML = list.map(em =>
        `<button type="button" style="border:none; background:transparent; font-size:22px; cursor:pointer; padding:2px;" onclick="appendEmojiToInput('${targetInputId}', '${em}')">${em}</button>`
    ).join("");
    document.body.appendChild(picker);
}

function appendEmojiToInput(inputId, emojiChar) {
    const inp = document.getElementById(inputId);
    if (inp) {
        inp.value += emojiChar;
        inp.focus();
    }
    document.getElementById("zorenoFloatingEmojiBar")?.remove();
}

function insertQuickEmoji() {
    toggleQuickEmojiPicker("activeChatInput");
}

function insertAiQuickEmoji() {
    toggleQuickEmojiPicker("userInput");
}


// =========================================================
// ZORENO APP.JS — PART 3 OF 3 (FINAL PART)
// 24-HR QUOTA, MATH FORMATTER, LIVE 2026 AI, NATIVE TTS, SHARE, ADS & TOOLS
// =========================================================

// ================= 24-HOUR (12 AM TO 12 AM) 10 FREE CHATS LOCK =================
function getLocalDailyAiLimit() {
    const today = getTodayLocalMidnightKey();
    const nativeDate = window.AndroidPrefs?.getString?.("zorenoAiLimitDate", "") || "";
    const savedDate = nativeDate || localStorage.getItem("zorenoAiLimitDate") || "";
    if (savedDate !== today) {
        localStorage.setItem("zorenoAiLimitDate", today);
        localStorage.setItem("zorenoAiDailyLimit", "10");
        window.AndroidPrefs?.setString?.("zorenoAiLimitDate", today);
        window.AndroidPrefs?.setString?.("zorenoAiDailyLimit", "10");
        return 10;
    }
    const nativeLim = parseInt(window.AndroidPrefs?.getString?.("zorenoAiDailyLimit", "10") || "10");
    const localLim = parseInt(localStorage.getItem("zorenoAiDailyLimit") || "10");
    return Math.max(nativeLim, localLim);
}

function getLocalDailyAiCount() {
    const today = getTodayLocalMidnightKey();
    const nativeDate = window.AndroidPrefs?.getString?.("zorenoAiDate", "") || "";
    const savedDate = nativeDate || localStorage.getItem("zorenoAiDate") || "";
    if (savedDate !== today) {
        localStorage.setItem("zorenoAiDate", today);
        localStorage.setItem("zorenoAiCount", "0");
        window.AndroidPrefs?.setString?.("zorenoAiDate", today);
        window.AndroidPrefs?.setString?.("zorenoAiCount", "0");
        return 0;
    }
    const nativeCnt = parseInt(window.AndroidPrefs?.getString?.("zorenoAiCount", "0") || "0");
    const localCnt = parseInt(localStorage.getItem("zorenoAiCount") || "0");
    return Math.max(nativeCnt, localCnt);
}

function incrementLocalDailyAiCount() {
    const today = getTodayLocalMidnightKey();
    const c = getLocalDailyAiCount() + 1;
    localStorage.setItem("zorenoAiDate", today);
    localStorage.setItem("zorenoAiCount", String(c));
    window.AndroidPrefs?.setString?.("zorenoAiDate", today);
    window.AndroidPrefs?.setString?.("zorenoAiCount", String(c));
    if (db && auth?.currentUser) {
        db.collection("users").doc(auth.currentUser.uid).set({
            dailyAiDate: today,
            dailyAiCount: c,
            dailyAiLimit: getLocalDailyAiLimit()
        }, { merge: true }).catch(() => {});
    }
    return c;
}

function addBonusAiChats(extraChats = 3) {
    const today = getTodayLocalMidnightKey();
    const currentLimit = getLocalDailyAiLimit();
    const newLimit = currentLimit + extraChats;
    localStorage.setItem("zorenoAiLimitDate", today);
    localStorage.setItem("zorenoAiDailyLimit", String(newLimit));
    window.AndroidPrefs?.setString?.("zorenoAiLimitDate", today);
    window.AndroidPrefs?.setString?.("zorenoAiDailyLimit", String(newLimit));
    if (db && auth?.currentUser) {
        db.collection("users").doc(auth.currentUser.uid).set({
            dailyAiDate: today,
            dailyAiLimit: newLimit
        }, { merge: true }).catch(() => {});
    }
    return newLimit;
}

// ================= COLORFUL STEPS & ZERO-LATEX NOTEBOOK MATH FORMATTER =================
const STEP_ICON_PALETTE = [
    { icon: "fa-brain", bg: "rgba(139, 92, 246, 0.14)", color: "#8b5cf6" },
    { icon: "fa-leaf", bg: "rgba(16, 185, 129, 0.14)", color: "#10b981" },
    { icon: "fa-bolt", bg: "rgba(245, 158, 11, 0.15)", color: "#f59e0b" },
    { icon: "fa-book-open", bg: "rgba(14, 165, 233, 0.14)", color: "#0ea5e9" },
    { icon: "fa-star", bg: "rgba(236, 72, 153, 0.14)", color: "#ec4899" },
    { icon: "fa-compass", bg: "rgba(99, 102, 241, 0.14)", color: "#6366f1" },
    { icon: "fa-microscope", bg: "rgba(20, 184, 166, 0.14)", color: "#14b8a6" },
    { icon: "fa-fire-flame-curved", bg: "rgba(244, 63, 94, 0.14)", color: "#f43f5e" },
    { icon: "fa-lightbulb", bg: "rgba(234, 179, 8, 0.15)", color: "#ca8a04" },
    { icon: "fa-check-double", bg: "rgba(34, 197, 94, 0.14)", color: "#16a34a" },
    { icon: "fa-atom", bg: "rgba(59, 130, 246, 0.14)", color: "#3b82f6" },
    { icon: "fa-rocket", bg: "rgba(168, 85, 247, 0.14)", color: "#a855f7" }
];

function cleanLatexToNotebookMath(str) {
    if (!str) return "";
    return String(str)
        .replace(/\$\$/g, "")
        .replace(/\$/g, "")
        .replace(/\\\(|\\\)|\\\[|\\\]/g, "")
        .replace(/\\frac\{([^{}]+)\}\{([^{}]+)\}/g, "($1) / ($2)")
        .replace(/\\sqrt\{([^{}]+)\}/g, "√($1)")
        .replace(/\\left\(/g, "(")
        .replace(/\\right\)/g, ")")
        .replace(/\\left\[/g, "[")
        .replace(/\\right\]/g, "]")
        .replace(/\\mu_0/g, "μ₀")
        .replace(/\\mu_s/g, "μₛ")
        .replace(/\\mu/g, "μ")
        .replace(/\\epsilon_0/g, "ε₀")
        .replace(/\\theta/g, "θ")
        .replace(/\\pi/g, "π")
        .replace(/\\omega/g, "ω")
        .replace(/\\alpha/g, "α")
        .replace(/\\beta/g, "β")
        .replace(/\\Delta/g, "Δ")
        .replace(/\\geq/g, "≥")
        .replace(/\\leq/g, "≤")
        .replace(/\\neq/g, "≠")
        .replace(/\\approx/g, "≈")
        .replace(/\\times/g, "×")
        .replace(/\\cdot/g, "·")
        .replace(/\\div/g, "÷")
        .replace(/\\sin/g, "sin")
        .replace(/\\cos/g, "cos")
        .replace(/\\tan/g, "tan")
        .replace(/\\ln/g, "ln")
        .replace(/\\log/g, "log")
        .replace(/\^2\b/g, "²")
        .replace(/\^3\b/g, "³")
        .replace(/\\([a-zA-Z]+)/g, "$1");
}

function formatMarkdown(t, seedOffset = 0) {
    if (!t) return "";
    let cleanedText = cleanLatexToNotebookMath(t);
    let lines = String(cleanedText).replace(/\r\n/g, "\n").split("\n");
    let htmlParts = [];
    let inList = false;

    let hashSeed = seedOffset || (cleanedText.length + cleanedText.charCodeAt(0));
    let stepIndex = Math.abs(hashSeed) % STEP_ICON_PALETTE.length;

    for (let i = 0; i < lines.length; i++) {
        let line = lines[i].trim();
        if (!line) continue;

        let safeLine = escapeHtml(line).replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");

        if (/^(?:<strong>)?(?:Formula|Calculation|Calc|Equation|Step\s*\d+\s*Formula)(?:<\/strong>)?\s*:/i.test(safeLine) ||
            (/[=≥≤≈]/.test(safeLine) && /(?:μ₀|π|θ|²|√|sin|cos|tan|ln\()/.test(safeLine) && safeLine.length < 110 && !/^\d+\./.test(safeLine))) {
            if (inList) { htmlParts.push("</ul>"); inList = false; }
            htmlParts.push(`<div class="ai-math-box">${safeLine}</div>`);
            continue;
        }

        let numMatch = safeLine.match(/^(\d+)\.\s+(?:<strong>)?([^:<]+?)(?:<\/strong>)?(?::\s*(.*))?$/);
        if (numMatch) {
            if (inList) {
                htmlParts.push("</ul>");
                inList = false;
            }
            const num = numMatch[1];
            const title = numMatch[2].trim();
            let desc = (numMatch[3] || "").trim();

            if (!desc && i + 1 < lines.length) {
                const nextLine = lines[i + 1].trim();
                if (nextLine && !/^\d+\.\s+/.test(nextLine) && !/^[\*\-•]\s+/.test(nextLine)) {
                    desc = escapeHtml(nextLine).replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
                    i++;
                }
            }

            const styleObj = STEP_ICON_PALETTE[stepIndex % STEP_ICON_PALETTE.length];
            stepIndex += 2;

            htmlParts.push(`
                <div class="ai-step-card">
                    <div class="ai-step-icon-circle" style="background:${styleObj.bg}; color:${styleObj.color};">
                        <i class="fa-solid ${styleObj.icon}"></i>
                    </div>
                    <div class="ai-step-text">
                        <h5>${num}. ${title}</h5>
                        ${desc ? `<p>${desc}</p>` : ""}
                    </div>
                </div>
            `);
            continue;
        }

        if (/^[\*\-•]\s+(.*)/.test(safeLine)) {
            let itemText = safeLine.replace(/^[\*\-•]\s+/, "");
            if (!inList) {
                htmlParts.push('<ul class="ai-compact-list">');
                inList = true;
            }
            htmlParts.push(`<li>${itemText}</li>`);
        } else {
            if (inList) {
                htmlParts.push("</ul>");
                inList = false;
            }
            safeLine = safeLine.replace(/^#{1,3}\s+/, "");
            htmlParts.push(`<p>${safeLine}</p>`);
        }
    }
    if (inList) htmlParts.push("</ul>");
    return htmlParts.join("");
}

function getHealthDisclaimerHTML(userQuery) {
    if (typeof isHealthOrMedicalQuery === "function" && isHealthOrMedicalQuery(userQuery)) {
        return `
            <div class="ai-health-disclaimer">
                <i class="fa-solid fa-circle-info"></i>
                <span>Information only • Not medical advice. Consult a doctor or contact local emergency services if needed.</span>
            </div>
        `;
    }
    return "";
}

function getSmartAffiliateCard(userQuery) {
    const q = (userQuery || "").toLowerCase();
    if (/pen|pencil|stationary|stationery|schneider|luxor|write/i.test(q)) {
        return `
            <div class="ai-affiliate-card" onclick="event.stopPropagation(); window.open('https://www.amazon.in/s?k=Luxor+Schneider+LX+Max+Pen&tag=zoreno-21', '_blank')">
                <span class="aff-badge">✦ Recommended Study Gear</span>
                <div class="aff-body">
                    <div>
                        <h5>Luxor Schneider LX Max Pen</h5>
                        <p>Best for fast exam writing & smooth notes</p>
                    </div>
                    <button type="button">Buy ↗</button>
                </div>
            </div>
        `;
    }
    return "";
}

async function copyAiResponseText(idx, btnEl) {
    const text = cleanLatexToNotebookMath(aiChatMessagesList[idx]?.bot || "");
    if (!text) return;
    const cleanText = text.replace(/\*\*/g, "");
    try {
        await navigator.clipboard.writeText(cleanText);
        if (btnEl) {
            const oldHtml = btnEl.innerHTML;
            btnEl.innerHTML = '<i class="fa-solid fa-check" style="color:#10b981;"></i>';
            setTimeout(() => { btnEl.innerHTML = oldHtml; }, 1400);
        }
    } catch (e) {}
}

let activeSpeakingIdx = null;
function speakAiResponseText(idx, btnEl) {
    const rawText = cleanLatexToNotebookMath(aiChatMessagesList[idx]?.bot || "");
    const text = rawText.replace(/[*#_]/g, "").trim();
    if (!text) return;
    const langCode = /[\u0900-\u097F]/.test(text) ? "hi-IN" : "en-IN";

    // 1. Native Android TextToSpeech Bridge (Works on all Android phones)
    if (window.AndroidTTS && typeof window.AndroidTTS.speak === "function") {
        if (activeSpeakingIdx === idx) {
            window.AndroidTTS.stop();
            activeSpeakingIdx = null;
            document.querySelectorAll(".ai-listen-btn").forEach(b => b.classList.remove("speaking"));
            return;
        }
        document.querySelectorAll(".ai-listen-btn").forEach(b => b.classList.remove("speaking"));
        activeSpeakingIdx = idx;
        if (btnEl) btnEl.classList.add("speaking");
        window.AndroidTTS.speak(text, langCode);
        return;
    }

    // 2. Web Browser SpeechSynthesis Fallback
    if (!("speechSynthesis" in window)) {
        showCustomAlert("Voice Engine", "Initializing voice engine, please tap again in a moment.");
        return;
    }

    if (window.speechSynthesis.speaking && activeSpeakingIdx === idx) {
        window.speechSynthesis.cancel();
        activeSpeakingIdx = null;
        document.querySelectorAll(".ai-listen-btn").forEach(b => b.classList.remove("speaking"));
        return;
    }

    window.speechSynthesis.cancel();
    document.querySelectorAll(".ai-listen-btn").forEach(b => b.classList.remove("speaking"));

    const utter = new SpeechSynthesisUtterance(text);
    utter.lang = langCode;
    utter.rate = 1.0;

    activeSpeakingIdx = idx;
    if (btnEl) btnEl.classList.add("speaking");

    utter.onend = () => {
        activeSpeakingIdx = null;
        if (btnEl) btnEl.classList.remove("speaking");
    };
    utter.onerror = () => {
        activeSpeakingIdx = null;
        if (btnEl) btnEl.classList.remove("speaking");
    };

    window.speechSynthesis.speak(utter);
}

async function shareAiResponseText(idx) {
    const rawBot = cleanLatexToNotebookMath(aiChatMessagesList[idx]?.bot || "");
    if (!rawBot) return;
    const cleanAnswer = rawBot.replace(/\*\*/g, "").trim();
    const sharePayload = `✨ *Answered by Zoreno AI:*\n\n${cleanAnswer}\n\n🚀 *Download Zoreno: AI Study, Chat & Focus on Google Play:*\nhttps://play.google.com/store/apps/details?id=com.zoreno.app`;

    if (window.AndroidShare && typeof window.AndroidShare.shareText === "function") {
        window.AndroidShare.shareText(sharePayload);
        return;
    }
    if (navigator.share) {
        try {
            await navigator.share({
                title: "Zoreno AI Answer",
                text: sharePayload
            });
            return;
        } catch (e) {}
    }
    try {
        await navigator.clipboard.writeText(sharePayload);
        showCustomAlert("Copied for Sharing! 🔗", "Answer and Zoreno app link copied! Paste anywhere to share.", true);
    } catch (e) {}
}

function renderAiChatStream() {
    const chatMessages = document.getElementById("chatMessages");
    if (!chatMessages) return;

    const nowTime = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    let html = `
        <div class="msg-row-with-avatar">
            <img src="logo.png" class="ai-logo-avatar" onerror="this.src='default_avatar.png'" alt="Zoreno">
            <div class="clean-left-bubble">
                <div style="display:flex; justify-content:space-between; align-items:center; gap:14px; margin-bottom:2px;">
                    <strong>Zoreno AI</strong>
                    <span style="font-size:10px; color:#94a3b8; font-weight:500;">${nowTime}</span>
                </div>
                <p style="margin:0;">How can I help with your studies today?</p>
            </div>
        </div>
    `;

    aiChatMessagesList.forEach((pair, idx) => {
        const tLabel = escapeHtml(pair.timeLabel || nowTime);
        if (pair.user || (pair.images && pair.images.length)) {
            const hasImgs = pair.images && pair.images.length > 0;
            const isMediaOnly = hasImgs && !pair.user;
            const imgsHtml = (pair.images || []).map(src =>
                `<img src="${src}" class="sent-wide-photo" onclick="event.stopPropagation(); openFullImageModal('${src}')" alt="Uploaded">`
            ).join("");
            html += `
                <div class="msg-row-with-avatar right-user">
                    <div class="clean-right-bubble ${isMediaOnly ? 'media-only-bubble' : ''}" onclick="promptDeleteSingleAiMessage(${idx})" style="cursor:pointer;" title="Tap to delete for me">
                        ${imgsHtml ? `<div class="sent-media-grid">${imgsHtml}</div>` : ""}
                        ${pair.user ? `<div style="${hasImgs ? 'padding:6px 8px 2px;' : ''}">${escapeHtml(pair.user)}</div>` : ""}
                        <div class="bubble-meta-time">
                            <span>${tLabel}</span>
                            <i class="fa-solid fa-check-double"></i>
                        </div>
                    </div>
                </div>
            `;
        }
        if (pair.bot) {
            html += `
                <div class="msg-row-with-avatar">
                    <img src="logo.png" class="ai-logo-avatar" onerror="this.src='default_avatar.png'" alt="Zoreno">
                    <div class="clean-left-bubble" onclick="promptDeleteSingleAiMessage(${idx})" style="cursor:pointer;" title="Tap to delete for me">
                        ${getHealthDisclaimerHTML(pair.user || "")}
                        <div class="ai-formatted-body">${formatMarkdown(pair.bot, idx * 3 + 1)}</div>
                        ${getSmartAffiliateCard(pair.user || "")}
                        <div class="ai-bubble-bottom-bar">
                            <span class="ai-time-txt">${tLabel}</span>
                            <div class="ai-action-btns-wrap" onclick="event.stopPropagation();">
                                <button type="button" class="ai-mini-circle-btn" onclick="copyAiResponseText(${idx}, this)" title="Copy">
                                    <i class="fa-regular fa-copy"></i>
                                </button>
                                <button type="button" class="ai-mini-circle-btn ai-listen-btn" onclick="speakAiResponseText(${idx}, this)" title="Listen">
                                    <i class="fa-solid fa-volume-high"></i>
                                </button>
                                <button type="button" class="ai-mini-circle-btn" onclick="shareAiResponseText(${idx})" title="Share Answer">
                                    <i class="fa-solid fa-share-nodes"></i>
                                </button>
                            </div>
                        </div>
                        <div class="ai-mistake-disclaimer">Zoreno is AI can make mistakes</div>
                    </div>
                </div>
            `;
        }
    });

    chatMessages.innerHTML = html;

    const lastPair = aiChatMessagesList[aiChatMessagesList.length - 1];
    const homePreview = document.getElementById("zorenoHomeLastPreview");
    if (homePreview && lastPair?.bot) {
        homePreview.textContent = lastPair.bot.replace(/[*#_]/g, "").slice(0, 48) + "...";
    }
    scrollToBottom();
}

function openZorenoAIChat() {
    hideAllScreens();
    const chatScreen = document.getElementById("chatScreen");
    const inputArea = document.getElementById("inputAreaContainer");
    const bottomNav = document.getElementById("bottomNav");

    if (bottomNav) bottomNav.style.setProperty("display", "none", "important");
    if (chatScreen) chatScreen.style.setProperty("display", "flex", "important");
    if (inputArea) inputArea.style.setProperty("display", "flex", "important");

    renderAiChatStream();
}

// ================= LIVE 2026 CLOCK, LINK READER & CURRENCY FETCHER =================
async function buildLiveContextForAI(userText) {
    const now = new Date();
    const tomorrow = new Date(now.getTime() + 86400000);
    const yesterday = new Date(now.getTime() - 86400000);

    let liveContext = `\n[LIVE REAL-TIME SYSTEM CLOCK]:
- Today's Date & Day: ${now.toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
- Current Exact Time: ${now.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", second: "2-digit" })} (IST)
- Yesterday was: ${yesterday.toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
- Tomorrow will be: ${tomorrow.toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
- IMPORTANT: The current year is ${now.getFullYear()}. Never say it is 2024.`;

    const q = (userText || "").trim();
    if (!q) return liveContext;

    const urlMatch = q.match(/https?:\/\/[^\s]+/i);
    if (urlMatch) {
        const targetUrl = urlMatch[0];
        try {
            if (/youtube\.com|youtu\.be/i.test(targetUrl)) {
                const ytRes = await fetch(`https://noembed.com/embed?url=${encodeURIComponent(targetUrl)}`);
                const ytData = await ytRes.json();
                if (ytData?.title) {
                    liveContext += `\n[SHARED YOUTUBE VIDEO INFO]: Title: "${ytData.title}" | Channel: "${ytData.author_name || "YouTube"}" | URL: ${targetUrl}`;
                }
            }
            const readerRes = await fetch(`https://r.jina.ai/${targetUrl}`);
            if (readerRes.ok) {
                const pageTxt = (await readerRes.text()).slice(0, 3500);
                liveContext += `\n[EXTRACTED CONTENT FROM SHARED LINK (${targetUrl})]:\n${pageTxt}`;
            }
        } catch (e) {}
    }

    if (/\b(currency|dollar|usd|inr|euro|pound|dirham|yen|exchange rate|rate today)\b|डॉलर|भाव|रेट/i.test(q)) {
        try {
            const curRes = await fetch("https://open.er-api.com/v6/latest/USD");
            const curData = await curRes.json();
            if (curData?.rates) {
                const r = curData.rates;
                liveContext += `\n[LIVE CURRENCY RATES TODAY]: 1 USD = ₹${r.INR} INR | 1 EUR = ₹${(r.INR / r.EUR).toFixed(2)} INR | 1 GBP = ₹${(r.INR / r.GBP).toFixed(2)} INR | 1 AED = ₹${(r.INR / r.AED).toFixed(2)} INR.`;
            }
        } catch (e) {}
    }

    return liveContext;
}

async function callGeminiWithFallback(payloadBody, abortSignal) {
    let lastError = null;
    const groundedPayload = {
        ...payloadBody,
        tools: [{ googleSearch: {} }]
    };

    for (let attempt = 1; attempt <= 3; attempt++) {
        const bodyToSend = attempt === 1 ? groundedPayload : payloadBody;
        try {
            const response = await fetch(
                `https://generativelanguage.googleapis.com/v1beta/models/${ZORENO_AI_MODEL}:generateContent?key=${GEMINI_API_KEY}`,
                {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(bodyToSend),
                    signal: abortSignal
                }
            );
            const data = await response.json();
            if (data.error) {
                const msg = data.error.message || "API Error";
                lastError = new Error(msg);
                if (attempt === 1) continue;
                if (/high demand|overloaded|unavailable|503|429/i.test(msg) && attempt < 3) {
                    await new Promise(r => setTimeout(r, 1300 * attempt));
                    continue;
                }
                throw lastError;
            }
            const parts = data?.candidates?.[0]?.content?.parts || [];
            const fullText = parts.map(p => p.text || "").join("").trim();
            if (fullText) return fullText;
        } catch (err) {
            if (err.name === "AbortError") throw err;
            lastError = err;
            if (attempt < 3) {
                await new Promise(r => setTimeout(r, 1000));
            }
        }
    }
    throw lastError || new Error("Please try again in a moment.");
}

let isAiGenerating = false;
let currentAiAbortController = null;

function setSendBtnStopMode(isGenerating) {
    const sendBtn = document.getElementById("sendBtn");
    if (!sendBtn) return;
    sendBtn.disabled = false;
    if (isGenerating) {
        sendBtn.innerHTML = '<i class="fa-solid fa-stop"></i>';
        sendBtn.style.background = "linear-gradient(135deg, #ef4444, #dc2626)";
        sendBtn.title = "Stop generating";
    } else {
        sendBtn.innerHTML = '<i class="fa-solid fa-paper-plane"></i>';
        sendBtn.style.background = "";
        sendBtn.title = "Send";
    }
}

async function sendMessage() {
    if (isAiGenerating && currentAiAbortController) {
        currentAiAbortController.abort();
        return;
    }

    const input = document.getElementById("userInput");
    const chatMessages = document.getElementById("chatMessages");
    if (!input || !chatMessages) return;

    if (pendingAiAttachments.some(a => a.loading)) {
        showCustomAlert("Please Wait", "Photo is still loading, please wait a second...");
        return;
    }

    let text = input.value.trim();
    const attachedImages = pendingAiAttachments.map(a => a.dataUrl).filter(Boolean).slice(0, 2);
    if (!text && attachedImages.length === 0) return;

    const usedToday = getLocalDailyAiCount();
    const todayLimit = userTier === 2 ? 90 : userTier === 1 ? 50 : getLocalDailyAiLimit();

    if (usedToday >= todayLimit) {
        if (userTier === 0) {
            openRewardedAdModal();
        } else {
            showCustomAlert("Daily Fair-Use Limit Reached", `You have used your ${todayLimit} messages for today.`);
        }
        return;
    }

    if (userTier === 0 && text.length > 600) text = text.slice(0, 600);

    const nowTime = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    const msgIdx = aiChatMessagesList.length;
    input.value = "";
    input.style.height = "auto";
    pendingAiAttachments = [];
    renderAiAttachmentPreviewStrip();

    const hasImgs = attachedImages.length > 0;
    const isMediaOnly = hasImgs && !text;
    const imgsPreviewHtml = attachedImages.map(src =>
        `<img src="${src}" class="sent-wide-photo" onclick="event.stopPropagation(); openFullImageModal('${src}')" alt="Uploaded">`
    ).join("");

    chatMessages.insertAdjacentHTML("beforeend", `
        <div class="msg-row-with-avatar right-user">
            <div class="clean-right-bubble ${isMediaOnly ? 'media-only-bubble' : ''}" onclick="promptDeleteSingleAiMessage(${msgIdx})" style="cursor:pointer;">
                ${imgsPreviewHtml ? `<div class="sent-media-grid">${imgsPreviewHtml}</div>` : ""}
                ${text ? `<div style="${hasImgs ? 'padding:6px 8px 2px;' : ''}">${escapeHtml(text)}</div>` : ""}
                <div class="bubble-meta-time">
                    <span>${nowTime}</span>
                    <i class="fa-solid fa-check-double"></i>
                </div>
            </div>
        </div>
    `);

    const guardrailCheck = checkQueryGuardrails(text);
    if (guardrailCheck.blocked) {
        await saveChatToFirebase(text, guardrailCheck.reply, nowTime, attachedImages);
        renderAiChatStream();
        scrollToBottom();
        return;
    }

    const thinkingId = "zorenoThinking_" + Date.now();
    chatMessages.insertAdjacentHTML("beforeend", `
        <div class="msg-row-with-avatar" id="${thinkingId}">
            <img src="logo.png" class="ai-logo-avatar" onerror="this.src='default_avatar.png'" alt="Zoreno">
            <div class="clean-left-bubble" style="padding:10px 16px!important; border-radius:22px!important;">
                <div style="display:flex; align-items:center; gap:10px; color:#7c3aed; font-weight:600; font-size:13.5px;">
                    <span>Zoreno is thinking</span>
                    <div class="thinking-dots"><span></span><span></span><span></span></div>
                </div>
            </div>
        </div>
    `);
    scrollToBottom();

    isAiGenerating = true;
    currentAiAbortController = new AbortController();
    setSendBtnStopMode(true);

    try {
        const maxTokens = userTier === 0 ? 1800 : 3000;

        const recentHistory = [];
        aiChatMessagesList.slice(-20).forEach(pair => {
            if (pair.user) recentHistory.push({ role: "user", parts: [{ text: pair.user }] });
            if (pair.bot) recentHistory.push({ role: "model", parts: [{ text: pair.bot }] });
        });

        const currentParts = [];
        attachedImages.forEach(dataUrl => {
            const base64Data = dataUrl.split(",")[1];
            if (base64Data) {
                currentParts.push({
                    inlineData: { mimeType: "image/jpeg", data: base64Data }
                });
            }
        });
        currentParts.push({ text: text || "Please explain this image clearly step-by-step." });

        const dynamicLiveInfo = await buildLiveContextForAI(text);

        const payloadBody = {
            systemInstruction: {
                parts: [{ text: SYSTEM_INSTRUCTION + dynamicLiveInfo }]
            },
            contents: [
                ...recentHistory,
                { role: "user", parts: currentParts }
            ],
            generationConfig: {
                maxOutputTokens: maxTokens,
                temperature: 0.6
            },
            safetySettings: [
                { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_ONLY_HIGH" },
                { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_ONLY_HIGH" },
                { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_ONLY_HIGH" },
                { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_ONLY_HIGH" }
            ]
        };

        const replyText = await callGeminiWithFallback(payloadBody, currentAiAbortController.signal);
        incrementLocalDailyAiCount();

        await saveChatToFirebase(text, replyText, nowTime, attachedImages);
        renderAiChatStream();
    } catch (err) {
        const thinkingRow = document.getElementById(thinkingId);
        if (err.name === "AbortError") {
            await saveChatToFirebase(text, "⏹️ Response stopped by user.", nowTime, attachedImages);
            renderAiChatStream();
        } else if (thinkingRow) {
            thinkingRow.innerHTML = `
                <img src="logo.png" class="ai-logo-avatar" onerror="this.src='default_avatar.png'" alt="Zoreno">
                <div class="clean-left-bubble">
                    <span style="color:#ef4444; font-weight:600;">⚠️ ${escapeHtml(err.message)}</span>
                </div>
            `;
        }
    } finally {
        isAiGenerating = false;
        currentAiAbortController = null;
        setSendBtnStopMode(false);
        scrollToBottom();
    }
}

async function saveChatToFirebase(userText, botText, timeLabel, imagesList = []) {
    const tLabel = timeLabel || new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    const item = {
        user: userText || "",
        bot: botText || "",
        images: (imagesList || []).slice(0, 2),
        timeLabel: tLabel,
        timestampMs: Date.now()
    };

    aiChatMessagesList.push(item);
    if (aiChatMessagesList.length > 40) aiChatMessagesList = aiChatMessagesList.slice(-40);
    try { localStorage.setItem("zorenoAiChatStream", JSON.stringify(aiChatMessagesList)); } catch (e) {}

    const homePreview = document.getElementById("zorenoHomeLastPreview");
    if (homePreview && botText) {
        homePreview.textContent = botText.replace(/[*#_]/g, "").slice(0, 48) + "...";
    }

    if (!db || !auth?.currentUser) return;
    try {
        await db.collection("users").doc(auth.currentUser.uid).collection("chats").add({
            user: userText || "",
            bot: botText || "",
            timeLabel: tLabel,
            timestampMs: item.timestampMs,
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    } catch (e) {}
}

async function loadUserChatsFromFirebase() {
    if (!db || !auth?.currentUser) return;
    try {
        const snap = await db.collection("users").doc(auth.currentUser.uid)
            .collection("chats").orderBy("timestampMs", "asc").limitToLast(40).get();
        if (!snap.empty) {
            aiChatMessagesList = [];
            snap.forEach(doc => {
                const d = doc.data();
                aiChatMessagesList.push({
                    user: d.user || "",
                    bot: d.bot || "",
                    timeLabel: d.timeLabel || "",
                    timestampMs: d.timestampMs || 0
                });
            });
            try { localStorage.setItem("zorenoAiChatStream", JSON.stringify(aiChatMessagesList)); } catch (e) {}
            const lastPair = aiChatMessagesList[aiChatMessagesList.length - 1];
            const homePreview = document.getElementById("zorenoHomeLastPreview");
            if (homePreview && lastPair?.bot) {
                homePreview.textContent = lastPair.bot.replace(/[*#_]/g, "").slice(0, 48) + "...";
            }
        }
    } catch (e) {}
}

async function clearAllChatHistory() {
    closeAllDropdownMenus();
    aiChatMessagesList = [];
    localStorage.removeItem("zorenoAiChatStream");
    renderAiChatStream();

    const homePreview = document.getElementById("zorenoHomeLastPreview");
    if (homePreview) homePreview.textContent = "Tap to start chatting with your AI partner";

    if (db && auth?.currentUser) {
        try {
            const snap = await db.collection("users").doc(auth.currentUser.uid).collection("chats").get();
            const batch = db.batch();
            snap.forEach(d => batch.delete(d.ref));
            await batch.commit();
        } catch (e) {}
    }
    showCustomAlert("Chat Cleared 🗑️", "Your AI conversation has been cleared.", true);
}

function clearCurrentAiChat() {
    clearAllChatHistory();
}

function toggleAiHeaderMenu(forceState) {
    const menu = document.getElementById("aiHeaderDropdownMenu");
    if (!menu) return;
    const nextState = typeof forceState === "boolean" ? forceState : menu.style.display !== "block";
    closeAllDropdownMenus();
    menu.style.display = nextState ? "block" : "none";
}

function openAiFeedbackModal() {
    closeAllDropdownMenus();
    document.getElementById("aiFeedbackModal").style.display = "flex";
}

async function submitAiFeedback() {
    const text = document.getElementById("aiFeedbackText").value.trim();
    if (!text) return;
    try {
        if (db && auth?.currentUser) {
            await db.collection("feedbacks").add({
                uid: auth.currentUser.uid,
                name: userName || "Student",
                email: auth.currentUser.email || userEmail || "Anonymous",
                feedback: text,
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            });
        }
        document.getElementById("aiFeedbackText").value = "";
        document.getElementById("aiFeedbackModal").style.display = "none";
        showCustomAlert("Thank You! 🎉", "Your feedback has been saved to Firebase 'feedbacks' collection.", true);
    } catch (e) {
        showCustomAlert("Error", e.message);
    }
}

function scrollToBottom() {
    const container = document.getElementById("chatMessages");
    if (container) container.scrollTo({ top: container.scrollHeight, behavior: "smooth" });
}

// ================= ADMOB (APP) & ADSENSE (WEB) REWARDED AD (+3 CHATS) =================
function openRewardedAdModal() {
    const modal = document.getElementById("rewardedAdModal");
    if (modal) modal.style.display = "flex";
}

function closeRewardedAdModal() {
    const modal = document.getElementById("rewardedAdModal");
    if (modal) modal.style.display = "none";
}

function triggerRewardedAdForChats() {
    const btn = document.getElementById("watchRewardedAdBtn");
    const btnText = document.getElementById("watchAdBtnText");

    if (window.AndroidAdMob && typeof window.AndroidAdMob.showRewardedAd === "function") {
        if (btn) btn.disabled = true;
        if (btnText) btnText.innerText = "Loading Ad...";

        window.AndroidAdMob.showRewardedAd(ADS_CONFIG.admobRewardedUnitId);

        setTimeout(() => {
            if (btn) btn.disabled = false;
            if (btnText) btnText.innerText = "Watch Ad";
        }, 8000);
        return;
    }

    if (btn) btn.disabled = true;
    let sec = 5;
    if (btnText) btnText.innerText = `Loading Ad (${sec}s)...`;

    try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch (e) {}

    const adTimer = setInterval(() => {
        sec--;
        if (sec > 0) {
            if (btnText) btnText.innerText = `Watching Ad (${sec}s)...`;
        } else {
            clearInterval(adTimer);
            if (btn) btn.disabled = false;
            if (btnText) btnText.innerText = "Watch Ad";
            onAdMobRewardGranted();
        }
    }, 1000);
}

window.onAdMobRewardGranted = function () {
    const btn = document.getElementById("watchRewardedAdBtn");
    const btnText = document.getElementById("watchAdBtnText");
    if (btn) btn.disabled = false;
    if (btnText) btnText.innerText = "Watch Ad";

    const newLimit = addBonusAiChats(3);
    const used = getLocalDailyAiCount();
    const left = Math.max(0, newLimit - used);

    closeRewardedAdModal();
    showCustomAlert("3 Chats Unlocked! 🎉", `You now have ${left} free chats available to continue learning.`, true);
};

// ================= LIVE WEB SEARCH, FOCUS SPRINT & FOCUS MUSIC =================
function openLiveGoogleSearch(initialQuery = "") {
    hideAllScreens();
    const searchScreen = document.getElementById("webSearchScreen");
    if (searchScreen) searchScreen.style.setProperty("display", "flex", "important");
    const inp = document.getElementById("liveGoogleInput");
    if (inp) {
        inp.value = initialQuery || "";
        if (initialQuery) runLiveGoogleSearch();
        else inp.focus();
    }
}

function closeLiveGoogleSearch() { goHome(); }
function clearLiveSearch() {
    const inp = document.getElementById("liveGoogleInput");
    if (inp) { inp.value = ""; inp.focus(); }
}
function handleLiveGoogleEnter(e) {
    if (e.key === "Enter") { e.preventDefault(); runLiveGoogleSearch(); }
}

async function runLiveGoogleSearch() {
    let query = document.getElementById("liveGoogleInput")?.value.trim();
    const resultsArea = document.getElementById("liveSearchResultsArea");
    if (!query || !resultsArea) return;

    currentSearchQuery = query;
    currentSearchOffset = 0;
    hasMoreSearchResults = true;
    resultsArea.innerHTML = `<div style="text-align:center;padding:30px;color:#7c3aed;"><i class="fa-solid fa-spinner fa-spin" style="font-size:24px;"></i><p style="margin-top:10px;font-weight:700;font-size:13px;">Searching live web for "${escapeHtml(query)}"...</p></div>`;
    resultsArea.innerHTML = "";
    await fetchMoreSearchResults();
}

async function fetchMoreSearchResults() {
    if (isSearchLoading || !hasMoreSearchResults) return;
    isSearchLoading = true;
    const resultsArea = document.getElementById("liveSearchResultsArea");

    try {
        const apiUrl = `https://en.wikipedia.org/w/api.php?action=query&format=json&origin=*&generator=search&gsrsearch=${encodeURIComponent(currentSearchQuery)}&gsrlimit=8&gsroffset=${currentSearchOffset}&prop=extracts|pageimages&exintro=1&explaintext=1&exsentences=2&piprop=thumbnail&pithumbsize=300`;
        const res = await fetch(apiUrl);
        const data = await res.json();
        const pages = data?.query?.pages ? Object.values(data.query.pages) : [];

        if (pages.length === 0) {
            hasMoreSearchResults = false;
            isSearchLoading = false;
            return;
        }
        currentSearchOffset += 8;

        pages.forEach(p => {
            const card = document.createElement("div");
            card.className = "web-result-item";
            const itemImg = p.thumbnail ? p.thumbnail.source : null;
            const wikiLink = "https://en.wikipedia.org/wiki/" + encodeURIComponent(p.title);
            card.innerHTML = `
                <div class="res-source-row">
                    <img src="https://www.google.com/s2/favicons?domain=wikipedia.org" class="res-favicon" alt="icon">
                    <span>Wikipedia • en.wikipedia.org</span>
                </div>
                <div style="display:flex;justify-content:space-between;gap:10px;">
                    <div style="flex:1;">
                        <a href="${wikiLink}" target="_blank" class="res-title">${escapeHtml(p.title)}</a>
                        <p class="res-snippet">${escapeHtml(p.extract || "Verified details and facts.")}</p>
                    </div>
                    ${itemImg ? `<img src="${itemImg}" style="width:70px;height:50px;border-radius:10px;object-fit:cover;margin-top:2px;">` : ""}
                </div>
            `;
            resultsArea.appendChild(card);
        });
    } catch (e) {} finally {
        isSearchLoading = false;
    }
}

let sprintDurationMinutes = parseInt(localStorage.getItem("sprintSelectedDuration") || "20");
let sprintInterval = null;
let memSprintTargetMs = 0;
let memSprintTotalMs = 0;

function selectSprintPreset(mins, btnEl) {
    sprintDurationMinutes = mins;
    localStorage.setItem("sprintSelectedDuration", String(mins));
    document.querySelectorAll(".preset-pill-btn").forEach(b => b.classList.remove("active"));
    if (btnEl) btnEl.classList.add("active");
    resetSprintState();
}

function toggleSprintTimer() {
    if (localStorage.getItem("sprintIsActive") === "true") pauseSprintState();
    else startSprintState();
}

function startSprintState() {
    const now = Date.now();
    let remainingMs = parseInt(localStorage.getItem("sprintRemainingMs") || "0");
    if (!remainingMs || remainingMs <= 0) {
        remainingMs = sprintDurationMinutes * 60 * 1000;
        localStorage.setItem("sprintTotalDurationMs", String(remainingMs));
    }
    memSprintTotalMs = parseInt(localStorage.getItem("sprintTotalDurationMs") || String(remainingMs));
    memSprintTargetMs = now + remainingMs;

    localStorage.setItem("sprintTargetTimestamp", String(memSprintTargetMs));
    localStorage.setItem("sprintIsActive", "true");
    localStorage.removeItem("sprintRemainingMs");

    setSprintUIRunning(true);
    if (sprintInterval) clearInterval(sprintInterval);
    sprintInterval = setInterval(tickSprint, 1000);
}

function pauseSprintState() {
    localStorage.setItem("sprintRemainingMs", String(Math.max(0, memSprintTargetMs - Date.now())));
    localStorage.setItem("sprintIsActive", "false");
    localStorage.removeItem("sprintTargetTimestamp");
    clearInterval(sprintInterval);
    sprintInterval = null;
    setSprintUIRunning(false);
}

function resetSprintState() {
    if (sprintInterval) clearInterval(sprintInterval);
    sprintInterval = null;
    memSprintTargetMs = 0;
    memSprintTotalMs = 0;
    localStorage.removeItem("sprintTargetTimestamp");
    localStorage.removeItem("sprintRemainingMs");
    localStorage.removeItem("sprintTotalDurationMs");
    localStorage.setItem("sprintIsActive", "false");
    setSprintUIRunning(false);

    const timerText = document.getElementById("sprintTimerText");
    if (timerText) timerText.innerText = `${String(sprintDurationMinutes).padStart(2, "0")}:00`;
    const progressFill = document.getElementById("sprintProgressFill");
    const rabbit = document.getElementById("sprintRabbit");
    if (progressFill) progressFill.style.width = "0%";
    if (rabbit) { rabbit.style.left = "0%"; rabbit.classList.remove("hopping"); }
}

function tickSprint() {
    const remainingMs = memSprintTargetMs - Date.now();

    if (remainingMs <= 0) {
        resetSprintState();
        showCustomAlert("Sprint Completed! 🏆", "Great job staying focused!", true);
        return;
    }

    const remainingSecs = Math.ceil(remainingMs / 1000);
    const timerText = document.getElementById("sprintTimerText");
    if (timerText) timerText.innerText = `${String(Math.floor(remainingSecs / 60)).padStart(2, "0")}:${String(remainingSecs % 60).padStart(2, "0")}`;

    const totalMs = memSprintTotalMs || (sprintDurationMinutes * 60 * 1000);
    const progressPercent = Math.min(100, Math.max(0, ((totalMs - remainingMs) / totalMs) * 100));
    const progressFill = document.getElementById("sprintProgressFill");
    const rabbit = document.getElementById("sprintRabbit");
    if (progressFill) progressFill.style.width = `${progressPercent}%`;
    if (rabbit) rabbit.style.left = `${Math.min(94, progressPercent)}%`;
}

function setSprintUIRunning(isRunning) {
    const pill = document.getElementById("sprintControlPill");
    const btnLabel = document.getElementById("sprintBtnLabel");
    const btnIcon = document.getElementById("sprintPlayIcon");
    const rabbit = document.getElementById("sprintRabbit");

    if (isRunning) {
        pill?.classList.add("running");
        if (btnLabel) btnLabel.innerText = "Pause";
        if (btnIcon) btnIcon.className = "fa-solid fa-pause";
        rabbit?.classList.add("hopping");
    } else {
        pill?.classList.remove("running");
        if (btnLabel) btnLabel.innerText = "Go";
        if (btnIcon) btnIcon.className = "fa-solid fa-play";
        rabbit?.classList.remove("hopping");
    }
}

const FOCUS_TRACKS = [
    { title: "Rain Storm", icon: "fa-cloud-showers-heavy", file: "sounds/rain.mp3", cover: "https://images.unsplash.com/photo-1519692933481-e162a57d6721?w=300" },
    { title: "Deep Lo-Fi", icon: "fa-music", file: "sounds/lofi.mp3", cover: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=300" },
    { title: "Forest Birds", icon: "fa-dove", file: "sounds/birds.mp3", cover: "https://images.unsplash.com/photo-1448375240586-882707db888b?w=300" },
    { title: "Ocean Waves", icon: "fa-water", file: "sounds/ocean.mp3", cover: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=300" },
    { title: "Cafe Ambient", icon: "fa-mug-saucer", file: "sounds/cafe.mp3", cover: "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=300" },
    { title: "Night Campfire", icon: "fa-fire", file: "sounds/campfire.mp3", cover: "https://images.unsplash.com/photo-1510312305653-8ed496efae75?w=300" },
    { title: "White Noise", icon: "fa-wind", file: "sounds/whitenoise.mp3", cover: "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=300" },
    { title: "Clock Ticking", icon: "fa-clock", file: "sounds/clock.mp3", cover: "https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=300" },
    { title: "Nature Forest", icon: "fa-leaf", file: "sounds/forest.mp3", cover: "https://images.unsplash.com/photo-1473448912268-2022ce9509d8?w=300" },
    { title: "Binaural Beats", icon: "fa-tower-broadcast", file: "sounds/binaural.mp3", cover: "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=300" }
];

let currentTrackIndex = 0;
let focusAudio = new Audio();
focusAudio.loop = true;
let isMusicPlaying = false;

function selectMusicTrack(index) {
    currentTrackIndex = index;
    const track = FOCUS_TRACKS[index];
    const titleEl = document.getElementById("currentTrackTitle");
    const coverEl = document.getElementById("currentTrackCover");
    if (titleEl) titleEl.innerText = track.title;
    if (coverEl) coverEl.src = track.cover;

    document.querySelectorAll(".sound-card-pill").forEach((pill, i) => {
        const actionBox = pill.querySelector(".sound-card-action-box");
        if (i === index) {
            pill.classList.add("active");
            if (actionBox) actionBox.innerHTML = `<div class="mini-playing-waves"><span></span><span></span><span></span></div>`;
        } else {
            pill.classList.remove("active");
            if (actionBox) actionBox.innerHTML = `<i class="fa-solid fa-play"></i>`;
        }
    });

    focusAudio.src = track.file;
    focusAudio.currentTime = 0;
    playFocusMusic();
}

function playFocusMusic() {
    focusAudio.play().then(() => { isMusicPlaying = true; updatePlayerUIState(true); })
              .catch(() => { isMusicPlaying = true; updatePlayerUIState(true); });
}

function pauseFocusMusic() {
    focusAudio.pause();
    isMusicPlaying = false;
    updatePlayerUIState(false);
}

function toggleFocusMusicPlay() {
    if (isMusicPlaying) pauseFocusMusic();
    else {
        if (!focusAudio.src) selectMusicTrack(currentTrackIndex);
        else playFocusMusic();
    }
}

function playNextTrack() {
    currentTrackIndex = (currentTrackIndex + 1) % FOCUS_TRACKS.length;
    selectMusicTrack(currentTrackIndex);
}

function playPreviousTrack() {
    currentTrackIndex = (currentTrackIndex - 1 + FOCUS_TRACKS.length) % FOCUS_TRACKS.length;
    selectMusicTrack(currentTrackIndex);
}

function updatePlayerUIState(playing) {
    const playIcon = document.getElementById("musicPlayIcon");
    const visualizer = document.getElementById("musicWaveVisualizer");
    if (playing) {
        if (playIcon) playIcon.className = "fa-solid fa-pause";
        visualizer?.classList.add("playing");
    } else {
        if (playIcon) playIcon.className = "fa-solid fa-play";
        visualizer?.classList.remove("playing");
    }
}

focusAudio.ontimeupdate = () => {
    const current = focusAudio.currentTime || 0;
    const duration = focusAudio.duration || 30;
    const elapsedEl = document.getElementById("musicTimeElapsed");
    const durEl = document.getElementById("musicTimeDuration");
    if (elapsedEl) elapsedEl.innerText = `${String(Math.floor(current / 60)).padStart(2, "0")}:${String(Math.floor(current % 60)).padStart(2, "0")}`;
    if (durEl) durEl.innerText = `${String(Math.floor(duration / 60)).padStart(2, "0")}:${String(Math.floor(duration % 60)).padStart(2, "0")}`;

    const percent = (current / duration) * 100;
    const fill = document.getElementById("musicProgressFill");
    const knob = document.getElementById("musicProgressKnob");
    if (fill) fill.style.width = `${percent}%`;
    if (knob) knob.style.left = `${percent}%`;
};

function handleMusicSeek(e) {
    const rail = document.querySelector(".music-progress-rail");
    if (!rail) return;
    const rect = rail.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const offsetX = Math.max(0, Math.min(rect.width, clientX - rect.left));
    focusAudio.currentTime = (offsetX / rect.width) * (focusAudio.duration || 30);
}

function seekMusicByClick(e) { handleMusicSeek(e); }

function toggleMusicLike(btn) {
    btn.classList.toggle("liked");
    const icon = btn.querySelector("i");
    if (icon) icon.className = btn.classList.contains("liked") ? "fa-solid fa-heart" : "fa-regular fa-heart";
}

// ================= AUTO-RESIZE INPUT, IMAGE DOWNLOAD & EYE CARE MODE =================
function autoResizeChatInput(el) {
    if (!el) return;
    el.style.height = "auto";
    el.style.height = Math.min(104, el.scrollHeight) + "px";
}

function downloadFullPreviewImage() {
    const img = document.getElementById("fullImagePreviewTarget");
    const src = img?.src || "";
    if (!src) return;
    const fileName = "Zoreno_Image_" + Date.now() + ".jpg";

    if (window.AndroidDownloader && typeof window.AndroidDownloader.downloadImage === "function") {
        window.AndroidDownloader.downloadImage(src, fileName);
        showCustomAlert("Downloaded! 📥", "Image saved to your phone's Gallery / Downloads.", true);
        return;
    }

    const a = document.createElement("a");
    a.href = src;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    a.remove();
    showCustomAlert("Downloaded! 📥", "Image saved to your device.", true);
}

function toggleEyeProtectionMode() {
    document.body.classList.toggle("eye-care-mode");
    const enabled = document.body.classList.contains("eye-care-mode");
    localStorage.setItem("eyeCareMode", enabled ? "true" : "false");
    const toggle = document.getElementById("eyeCareToggle");
    if (toggle) toggle.classList.toggle("off", !enabled);
}

function updateOnlineStatus() {
    const banner = document.getElementById("offlineBanner");
    if (!banner) return;
    if (!navigator.onLine) banner.classList.add("show");
    else banner.classList.remove("show");
}

window.addEventListener("online", updateOnlineStatus);
window.addEventListener("offline", updateOnlineStatus);

document.addEventListener("click", e => {
    const isMenuClick = e.target.closest(".custom-dropdown-menu");
    const isTriggerClick = e.target.closest('[onclick*="toggleAiHeaderMenu"], [onclick*="toggleDmHeaderMenu"], [onclick*="toggleFpHeaderMenu"]');
    if (!isMenuClick && !isTriggerClick) {
        closeAllDropdownMenus();
    }
    if (!e.target.closest("#zorenoFloatingEmojiBar") && !e.target.closest('[onclick*="Emoji"]')) {
        document.getElementById("zorenoFloatingEmojiBar")?.remove();
    }
});

window.addEventListener("popstate", () => {
    closeAllDropdownMenus();
    const fullImgModal = document.getElementById("fullImagePreviewModal");
    if (fullImgModal && fullImgModal.style.display === "flex") { fullImgModal.style.display = "none"; return; }
    const fpScreen = document.getElementById("friendProfileScreen");
    if (fpScreen && fpScreen.style.display === "block") { closeFriendProfileScreen(); return; }
    const policyModal = document.getElementById("policyModal");
    const alertModal = document.getElementById("alertModal");
    if (policyModal && policyModal.style.display === "flex") { closePolicyModal(); return; }
    if (alertModal && alertModal.style.display === "flex") { closeCustomAlert(); return; }

    const chatList = document.getElementById("chatListScreen");
    if (chatList && chatList.style.display === "none") {
        closeActiveDmChat();
        goHome();
    }
});

window.addEventListener("keydown", e => {
    if (e.key === "Enter" && !e.shiftKey && e.target?.id === "userInput") {
        e.preventDefault();
        sendMessage();
    }
});

window.addEventListener("DOMContentLoaded", () => {
    const isDark = localStorage.getItem("darkMode") === "true";
    if (isDark) document.body.classList.add("dark-mode");
    syncDarkModeUI(isDark);

    if (localStorage.getItem("eyeCareMode") === "true") {
        document.body.classList.add("eye-care-mode");
        document.getElementById("eyeCareToggle")?.classList.remove("off");
    }

    detectAndSetCountry();
    setupHomeSearchAndTabs();
    syncEditProfileInputs();

    const dmInput = document.getElementById("activeChatInput");
    if (dmInput) {
        dmInput.addEventListener("keydown", e => {
            if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                sendRealtimeMessage();
            }
        });
    }

    const rail = document.querySelector(".music-progress-rail");
    if (rail) {
        rail.addEventListener("click", handleMusicSeek);
        rail.addEventListener("touchstart", handleMusicSeek, { passive: true });
        rail.addEventListener("touchmove", handleMusicSeek, { passive: true });
    }

    const splashScreen = document.getElementById("splashScreen");
    const authScreen = document.getElementById("authScreen");
    const alreadyLoggedIn = localStorage.getItem("isLoggedIn") === "true";

    if (alreadyLoggedIn) {
        if (authScreen) authScreen.style.setProperty("display", "none", "important");
        if (splashScreen) {
            splashScreen.classList.add("hide");
            setTimeout(() => { splashScreen.style.display = "none"; }, 350);
        }
        showChatsHome();
    } else {
        setTimeout(() => {
            if (splashScreen && splashScreen.style.display !== "none") {
                splashScreen.style.display = "none";
                if (authScreen) authScreen.style.display = "flex";
            }
        }, 1800);
    }

    initFirebase();
});


// =========================================================
// ZORENO V7 LAUNCH PATCH: SUBSCRIPTION BADGES (GREEN/BLUE),
// MAKE AS FRIEND SYSTEM, FRIENDS-ONLY GROUPS, 2-PHOTO REMAINING
// COUNTER, 2-WAY BLOCK, SHARE SHEET & PRIVACY SHIELD
// =========================================================

let pendingClearChatMode = null;
let isCurrentChatBlockedByMe = false;
let isCurrentChatBlockedByFriend = false;
let pendingDmAttachmentsList = [];
let myFriendsMap = {};
try { myFriendsMap = JSON.parse(localStorage.getItem("zorenoFriendsMap") || "{}"); } catch (e) { myFriendsMap = {}; }
let incomingFriendReqs = [];
let outgoingFriendReqsMap = {};
let friendReqsUnsub = null;

// 1. Premium Subscription Badge Generator (₹249 = Green Badge, ₹349 = Blue Badge)
function getSubscriptionBadgeHTML(tierLevel) {
    const t = parseInt(tierLevel) || 0;
    if (t === 1) {
        return `<span class="zoreno-sub-badge plus-green-badge" title="Zoreno Plus (₹249)"><i class="fa-solid fa-circle-check"></i> Plus</span>`;
    } else if (t >= 2) {
        return `<span class="zoreno-sub-badge pro-blue-badge" title="Zoreno Pro (₹349)"><i class="fa-solid fa-crown"></i> Pro</span>`;
    }
    return "";
}

// 2. Privacy Shield: Warn user before accidentally sending sensitive 12/16-digit IDs or OTPs
function checkPersonalPrivacyBeforeSend(rawText) {
    const txt = (rawText || "").trim();
    if (!txt) return true;
    const sensitiveDigitsRegex = /\b(?:\d{4}[\s-]?\d{4}[\s-]?\d{4}(?:[\s-]?\d{4})?)\b/;
    const otpRegex = /\b(?:otp|cvv|pin|password)\s*(?:is|:|-)?\s*\d{4,6}\b/i;
    if (sensitiveDigitsRegex.test(txt) || otpRegex.test(txt)) {
        return confirm("🛡️ Privacy Alert: Your message appears to contain a private card/ID number or OTP. Are you sure you want to send it?");
    }
    return true;
}

// 3. Initialize All Dynamic UI Components (Modals, Badges, Multi-Photo DM, Make as Friend Button)
function initZorenoV7LaunchSystem() {
    // Enable multiple photo selection (up to 2 photos) in DM Chat too
    const dmInp = document.getElementById("dmImageInput");
    if (dmInp) {
        dmInp.setAttribute("multiple", "multiple");
    }

    // Fix AI Topbar Layout & Add Clean Live Quota Pill inside the text meta column
    const aiTopMeta = document.querySelector(".ai-topbar-user-meta > div");
    if (aiTopMeta && !document.getElementById("aiLiveQuotaBadge")) {
        const statusLine = aiTopMeta.querySelector("div:nth-child(2)");
        if (statusLine) {
            statusLine.className = "ai-status-single-line";
            statusLine.innerHTML = `<span>@zoreno_ai • Online</span> <span id="aiLiveQuotaBadge" class="ai-quota-pill-badge"></span>`;
        }
    }

    // Add Blocked Banner inside Active DM Screen
    const dmScreen = document.getElementById("activeChatScreen");
    if (dmScreen && !document.getElementById("dmBlockedFooterBanner")) {
        const banner = document.createElement("div");
        banner.id = "dmBlockedFooterBanner";
        banner.className = "dm-blocked-footer-banner";
        banner.style.display = "none";
        dmScreen.appendChild(banner);
    }

    // Add "Make as Friend" Button inside Friend Profile Actions Grid
    const fpGrid = document.querySelector("#friendProfileScreen .fp-actions-grid");
    if (fpGrid && !document.getElementById("fpMakeFriendBtn")) {
        const fBtn = document.createElement("button");
        fBtn.type = "button";
        fBtn.id = "fpMakeFriendBtn";
        fBtn.className = "fp-action-box fp-friend-btn";
        fBtn.onclick = () => handleMakeAsFriendClick();
        fBtn.innerHTML = `<i class="fa-solid fa-user-plus" style="color:#10b981;"></i><span style="color:#10b981;">Make Friend</span>`;
        fpGrid.appendChild(fBtn);
        fpGrid.style.gridTemplateColumns = "repeat(4, 1fr)";
    }

    // Inject Confirmation Modals & WhatsApp/Instagram Share Sheet
    if (!document.getElementById("zorenoV7ModalsContainer")) {
        const wrap = document.createElement("div");
        wrap.id = "zorenoV7ModalsContainer";
        wrap.innerHTML = `
            <!-- Block / Unblock Confirmation Modal -->
            <div class="custom-modal-overlay" id="blockConfirmModal" style="display:none; z-index:9999999;">
                <div class="custom-modal-box alert-box">
                    <div class="modal-icon error-icon"><i class="fa-solid fa-ban"></i></div>
                    <h3 id="blockModalTitle">Block This Person?</h3>
                    <p id="blockModalDesc">Are you sure you want to block this person? Neither of you will be able to send messages.</p>
                    <div style="display:flex; gap:10px; margin-top:16px;">
                        <button type="button" class="modal-submit-btn" style="background:#e2e8f0; color:#0f172a;" onclick="document.getElementById('blockConfirmModal').style.display='none'">Cancel</button>
                        <button type="button" class="modal-submit-btn" id="blockModalConfirmBtn" style="background:#ef4444;" onclick="executeConfirmedBlockToggle()">OK</button>
                    </div>
                </div>
            </div>

            <!-- Clear Chat Confirmation Modal -->
            <div class="custom-modal-overlay" id="clearChatConfirmModal" style="display:none; z-index:9999999;">
                <div class="custom-modal-box alert-box">
                    <div class="modal-icon error-icon"><i class="fa-regular fa-trash-can"></i></div>
                    <h3 id="clearChatModalTitle">Clear Chat Messages?</h3>
                    <p id="clearChatModalDesc">Are you sure you want to delete all messages in this chat? This action cannot be undone.</p>
                    <div style="display:flex; gap:10px; margin-top:16px;">
                        <button type="button" class="modal-submit-btn" style="background:#e2e8f0; color:#0f172a;" onclick="document.getElementById('clearChatConfirmModal').style.display='none'">Cancel</button>
                        <button type="button" class="modal-submit-btn" style="background:#ef4444;" onclick="executeConfirmedClearChat()">Delete</button>
                    </div>
                </div>
            </div>

            <!-- Forgot Password Modal -->
            <div class="custom-modal-overlay" id="forgotPassModal" style="display:none; z-index:9999999;">
                <div class="custom-modal-box">
                    <div class="policy-modal-header">
                        <h3>Reset Password 🔑</h3>
                        <button type="button" class="modal-close-btn" onclick="document.getElementById('forgotPassModal').style.display='none'"><i class="fa-solid fa-xmark"></i></button>
                    </div>
                    <p style="font-size:13px; color:#64748b; margin-bottom:12px;">Enter your registered email address and we will send you a password reset link.</p>
                    <input type="email" id="resetPassEmailInp" placeholder="Enter your email address" style="width:100%; padding:12px 14px; border-radius:12px; border:1.5px solid #cbd5e1; margin-bottom:14px; outline:none;">
                    <div style="display:flex; gap:10px;">
                        <button type="button" class="modal-submit-btn" style="background:#e2e8f0; color:#0f172a;" onclick="document.getElementById('forgotPassModal').style.display='none'">Cancel</button>
                        <button type="button" class="modal-submit-btn" onclick="confirmSendPasswordReset()">Send Reset Link</button>
                    </div>
                </div>
            </div>

            <!-- Instagram / WhatsApp Style Bottom Share Sheet -->
            <div class="custom-modal-overlay" id="zorenoShareSheetModal" style="display:none; z-index:9999999; align-items:flex-end; padding:0;" onclick="this.style.display='none'">
                <div class="zoreno-share-bottom-sheet" onclick="event.stopPropagation();">
                    <div class="share-sheet-handle"></div>
                    <div class="share-sheet-brand-preview">
                        <img src="logo.png" onerror="this.src='default_avatar.png'" alt="Zoreno">
                        <div class="share-preview-txt">
                            <h4>Zoreno: AI Study, Chat & Focus</h4>
                            <p id="shareSheetAnswerPreview">Answered by Zoreno AI</p>
                        </div>
                    </div>
                    <div class="share-apps-grid">
                        <button type="button" class="share-app-item" onclick="shareToSpecificPlatform('whatsapp')">
                            <div class="share-app-icon" style="background:#25D366; color:#fff;"><i class="fa-brands fa-whatsapp"></i></div>
                            <span>WhatsApp</span>
                        </button>
                        <button type="button" class="share-app-item" onclick="shareToSpecificPlatform('instagram')">
                            <div class="share-app-icon" style="background:linear-gradient(45deg,#f09433,#e6683c,#dc2743,#cc2366,#bc1888); color:#fff;"><i class="fa-brands fa-instagram"></i></div>
                            <span>Instagram</span>
                        </button>
                        <button type="button" class="share-app-item" onclick="shareToSpecificPlatform('telegram')">
                            <div class="share-app-icon" style="background:#0088cc; color:#fff;"><i class="fa-brands fa-telegram"></i></div>
                            <span>Telegram</span>
                        </button>
                        <button type="button" class="share-app-item" onclick="shareToSpecificPlatform('twitter')">
                            <div class="share-app-icon" style="background:#0f172a; color:#fff;"><i class="fa-brands fa-x-twitter"></i></div>
                            <span>X / Post</span>
                        </button>
                        <button type="button" class="share-app-item" onclick="shareToSpecificPlatform('system')">
                            <div class="share-app-icon" style="background:#7c3aed; color:#fff;"><i class="fa-solid fa-share-nodes"></i></div>
                            <span>More Apps</span>
                        </button>
                        <button type="button" class="share-app-item" onclick="shareToSpecificPlatform('copy')">
                            <div class="share-app-icon" style="background:#475569; color:#fff;"><i class="fa-regular fa-copy"></i></div>
                            <span>Copy Link</span>
                        </button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(wrap);
    }

    updateAiQuotaHeaderBadge();
}

// 4. Update AI Quota Badge & User Profile Badges
function updateAiQuotaHeaderBadge() {
    initZorenoV7LaunchSystem();
    const badge = document.getElementById("aiLiveQuotaBadge");
    if (!badge) return;

    const usedToday = getLocalDailyAiCount();
    const todayLimit = userTier === 2 ? 90 : userTier === 1 ? 50 : getLocalDailyAiLimit();
    const remaining = Math.max(0, todayLimit - usedToday);

    badge.innerHTML = `⚡ ${remaining}/${todayLimit} Left`;
    badge.style.background = remaining === 0 ? "rgba(239, 68, 68, 0.14)" : "rgba(124, 58, 237, 0.12)";
    badge.style.color = remaining === 0 ? "#ef4444" : "#7c3aed";
}

const _v7OrigUpdateProfileUI = updateProfileUI;
updateProfileUI = function () {
    _v7OrigUpdateProfileUI();
    const badgeEl = document.getElementById("profileUsernameBadge");
    if (badgeEl) {
        badgeEl.innerHTML = `${escapeHtml(currentUsername || "@student")} ${getSubscriptionBadgeHTML(userTier)}`;
    }
};

// 5. Image Selection with Clear "Photos Remaining" Counter (Both AI Chat & DM Chat, Max 2 Photos)
renderAiAttachmentPreviewStrip = function () {
    const strip = document.getElementById("aiAttachmentPreviewBar");
    if (!strip) return;
    if (pendingAiAttachments.length === 0) {
        strip.innerHTML = "";
        strip.style.setProperty("display", "none", "important");
        return;
    }
    const isAnyLoading = pendingAiAttachments.some(a => a.loading);
    const count = pendingAiAttachments.length;
    const rem = Math.max(0, 2 - count);
    const remText = rem === 1 ? "1 photo remaining" : "0 remaining (Max 2)";

    strip.style.setProperty("display", "flex", "important");
    strip.innerHTML = pendingAiAttachments.map(att => {
        if (att.loading) {
            return `<div class="preview-item-chip"><div class="chip-spinner-overlay"><i class="fa-solid fa-circle-notch fa-spin"></i></div></div>`;
        }
        return `
            <div class="preview-item-chip">
                <img src="${att.dataUrl}" onclick="openFullImageModal('${att.dataUrl}')" alt="Preview">
                <button type="button" class="preview-remove-x" onclick="removeAiAttachment('${att.id}')">×</button>
            </div>
        `;
    }).join("") + `<span style="font-size:11.5px; font-weight:800; color:${isAnyLoading ? '#7c3aed' : '#10b981'}; margin-left:4px;">
        ${isAnyLoading ? 'Loading photo...' : `✓ ${count}/2 Selected (${remText})`}
    </span>`;
};

handleDmImageSelect = function (event) {
    const allFiles = Array.from(event.target.files || []);
    event.target.value = "";
    if (!allFiles.length) return;

    const remainingSlots = 2 - pendingDmAttachmentsList.length;
    if (remainingSlots <= 0) {
        showCustomAlert("Maximum 2 Photos", "You can select up to 2 photos at a time. (0 remaining)");
        return;
    }

    const files = allFiles.slice(0, remainingSlots);
    files.forEach(file => {
        const tempId = "dmatt_" + Date.now() + "_" + Math.random().toString(36).slice(2, 6);
        pendingDmAttachmentsList.push({ id: tempId, loading: true, dataUrl: "" });
        renderDmAttachmentPreviewStrip();

        const reader = new FileReader();
        reader.onload = function (e) {
            const img = new Image();
            img.onload = function () {
                const canvas = document.createElement("canvas");
                const MAX_DIM = 680;
                let w = img.width, h = img.height;
                if (w > h && w > MAX_DIM) { h = Math.round((h * MAX_DIM) / w); w = MAX_DIM; }
                else if (h >= w && h > MAX_DIM) { w = Math.round((w * MAX_DIM) / h); h = MAX_DIM; }
                canvas.width = w;
                canvas.height = h;
                canvas.getContext("2d").drawImage(img, 0, 0, w, h);
                const compressed = canvas.toDataURL("image/jpeg", 0.65);

                setTimeout(() => {
                    const item = pendingDmAttachmentsList.find(x => x.id === tempId);
                    if (item) {
                        item.loading = false;
                        item.dataUrl = compressed;
                        pendingDmAttachment = { loading: false, dataUrl: compressed };
                        renderDmAttachmentPreviewStrip();
                    }
                }, 260);
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(file);
    });
};

function renderDmAttachmentPreviewStrip() {
    const strip = document.getElementById("dmAttachmentPreviewBar");
    if (!strip) return;
    if (pendingDmAttachmentsList.length === 0) {
        pendingDmAttachment = null;
        strip.innerHTML = "";
        strip.style.setProperty("display", "none", "important");
        return;
    }
    const isAnyLoading = pendingDmAttachmentsList.some(a => a.loading);
    const count = pendingDmAttachmentsList.length;
    const rem = Math.max(0, 2 - count);
    const remText = rem === 1 ? "1 photo remaining" : "0 remaining (Max 2)";

    strip.style.setProperty("display", "flex", "important");
    strip.innerHTML = pendingDmAttachmentsList.map(att => {
        if (att.loading) {
            return `<div class="preview-item-chip"><div class="chip-spinner-overlay"><i class="fa-solid fa-circle-notch fa-spin"></i></div></div>`;
        }
        return `
            <div class="preview-item-chip">
                <img src="${att.dataUrl}" onclick="openFullImageModal('${att.dataUrl}')" alt="Preview">
                <button type="button" class="preview-remove-x" onclick="removeSingleDmAttachment('${att.id}')">×</button>
            </div>
        `;
    }).join("") + `<span style="font-size:11.5px; font-weight:800; color:${isAnyLoading ? '#7c3aed' : '#10b981'}; margin-left:4px;">
        ${isAnyLoading ? 'Loading photo...' : `✓ ${count}/2 Selected (${remText})`}
    </span>`;
}

function removeSingleDmAttachment(id) {
    pendingDmAttachmentsList = pendingDmAttachmentsList.filter(x => x.id !== id);
    pendingDmAttachment = pendingDmAttachmentsList[0] || null;
    renderDmAttachmentPreviewStrip();
}

clearDmAttachment = function () {
    pendingDmAttachmentsList = [];
    pendingDmAttachment = null;
    renderDmAttachmentPreviewStrip();
};

// 6. "Make as Friend" Invitation System & Friends-Only Group Creation
function listenMyFriendsAndRequests(myUid) {
    if (!db || !myUid) return;
    if (friendReqsUnsub) friendReqsUnsub();

    db.collection("users").doc(myUid).onSnapshot(doc => {
        if (!doc.exists) return;
        const d = doc.data() || {};
        if (d.friendsMap && typeof d.friendsMap === "object") {
            myFriendsMap = d.friendsMap;
            localStorage.setItem("zorenoFriendsMap", JSON.stringify(myFriendsMap));
            syncMakeFriendButtonUI();
            scheduleRenderSavedDmChats();
        }
    });

    friendReqsUnsub = db.collection("friendRequests")
        .where("toUid", "==", myUid)
        .where("status", "==", "pending")
        .onSnapshot(snap => {
            incomingFriendReqs = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            scheduleRenderSavedDmChats();
            syncMakeFriendButtonUI();
        });
}

function syncMakeFriendButtonUI() {
    initZorenoV7LaunchSystem();
    const btn = document.getElementById("fpMakeFriendBtn");
    if (!btn || !currentChatUserId || currentChatIsGroup) return;

    const uid = currentChatUserId;
    if (myFriendsMap[uid]) {
        btn.innerHTML = `<i class="fa-solid fa-user-check" style="color:#10b981;"></i><span style="color:#10b981;">Friends ✓</span>`;
    } else if (outgoingFriendReqsMap[uid]) {
        btn.innerHTML = `<i class="fa-solid fa-clock" style="color:#f59e0b;"></i><span style="color:#f59e0b;">Invited</span>`;
    } else {
        btn.innerHTML = `<i class="fa-solid fa-user-plus" style="color:#10b981;"></i><span style="color:#10b981;">Make Friend</span>`;
    }
}

async function handleMakeAsFriendClick() {
    if (!currentChatUserId || currentChatIsGroup || !db || !auth?.currentUser) return;
    const myUid = auth.currentUser.uid;
    const targetUid = currentChatUserId;

    if (myFriendsMap[targetUid]) {
        showCustomAlert("Already Friends 💚", `You and ${currentChatUserMeta?.name || "this user"} are already friends! You can add them to Study Groups.`, true);
        return;
    }
    if (outgoingFriendReqsMap[targetUid]) {
        showCustomAlert("Invitation Pending ⏳", "Friend request already sent. Waiting for them to accept.");
        return;
    }

    try {
        outgoingFriendReqsMap[targetUid] = true;
        syncMakeFriendButtonUI();

        await db.collection("friendRequests").add({
            fromUid: myUid,
            fromName: userName || "Student",
            fromUsername: currentUsername || "@student",
            fromAvatar: getSafeAvatar(userAvatarUrl),
            toUid: targetUid,
            status: "pending",
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });

        showCustomAlert("Friend Request Sent! 🤝", `Invitation sent to ${currentChatUserMeta?.name || "user"}. Once they accept, you both will become friends!`, true);
    } catch (e) {
        showCustomAlert("Error", e.message);
    }
}

async function respondToFriendRequest(reqDocId, fromUid, fromName, accept) {
    if (!db || !auth?.currentUser) return;
    const myUid = auth.currentUser.uid;
    try {
        if (accept) {
            myFriendsMap[fromUid] = true;
            localStorage.setItem("zorenoFriendsMap", JSON.stringify(myFriendsMap));
            await db.collection("users").doc(myUid).set({
                friendsMap: { [fromUid]: true }
            }, { merge: true });
            await db.collection("users").doc(fromUid).set({
                friendsMap: { [myUid]: true }
            }, { merge: true });
        }
        await db.collection("friendRequests").doc(reqDocId).update({
            status: accept ? "accepted" : "declined"
        });
        if (accept) {
            showCustomAlert("New Friend Added! 💚", `You and ${fromName || "your friend"} are now connected! You can now invite them to Study Groups.`, true);
        }
        scheduleRenderSavedDmChats();
    } catch (e) {}
}

// Override Create Group Modal so ONLY accepted Friends can be invited!
openCreateGroupModal = function () {
    let modal = document.getElementById("zorenoCreateGroupModal");
    if (!modal) {
        modal = document.createElement("div");
        modal.id = "zorenoCreateGroupModal";
        modal.className = "custom-modal-overlay";
        modal.style.zIndex = "999999";
        document.body.appendChild(modal);
    }

    // Filter only users who have accepted Friend Request (myFriendsMap[uid] === true)
    const acceptedFriendsList = recentDmUsers.filter(f => myFriendsMap[f.uid] === true);

    const friendsHtml = acceptedFriendsList.length === 0
        ? `<div style="padding:14px; border-radius:14px; background:#fef3c7; color:#92400e; font-size:12.5px; font-weight:600; text-align:center;">
               🤝 You have no accepted friends yet.<br>Open any user's profile and tap <strong>"Make Friend"</strong>—once they accept, you can invite them to groups!
           </div>`
        : acceptedFriendsList.map(f => `
            <label style="display:flex; align-items:center; justify-content:space-between; padding:8px 10px; border-radius:12px; border:1px solid #e2e8f0; margin-bottom:6px; cursor:pointer;">
                <div style="display:flex; align-items:center; gap:10px;">
                    <img src="${escapeHtml(getSafeAvatar(f.avatar))}" onerror="this.src='logo.png'" style="width:34px; height:34px; border-radius:50%; object-fit:cover;">
                    <div style="text-align:left;">
                        <div style="font-size:13.5px; font-weight:700;">${escapeHtml(f.name)} ${getSubscriptionBadgeHTML(f.userTier)}</div>
                        <div style="font-size:11px; color:#10b981; font-weight:700;">✓ Friend • ${escapeHtml(f.username)}</div>
                    </div>
                </div>
                <input type="checkbox" class="grp-invite-chk" value="${escapeHtml(f.uid)}" style="width:18px; height:18px; accent-color:#7c3aed;">
            </label>
        `).join("");

    modal.innerHTML = `
        <div class="custom-modal-box">
            <div class="policy-modal-header">
                <h3>Create Study Group 👥</h3>
                <button class="modal-close-btn" onclick="document.getElementById('zorenoCreateGroupModal').style.display='none'"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <input type="text" id="newStudyGroupName" placeholder="Enter Group Name (e.g. Science Group)" style="width:100%; padding:12px; border-radius:14px; border:1.5px solid #cbd5e1; outline:none; margin-bottom:12px; font-weight:700;">
            <div style="font-size:12px; font-weight:800; color:#64748b; margin-bottom:6px; text-align:left;">INVITE YOUR ACCEPTED FRIENDS:</div>
            <div style="max-height:185px; overflow-y:auto; margin-bottom:14px;">${friendsHtml}</div>
            <button type="button" class="modal-submit-btn" onclick="submitCreateStudyGroup()">Create Group & Send Invites 🚀</button>
        </div>
    `;
    modal.style.display = "flex";
};

// 7. Upgrade Home Screen Renderer to Show Badges, Friend Requests & Groups
const _v7OrigListenIncomingChats = listenIncomingRealtimeChats;
listenIncomingRealtimeChats = function (myUid) {
    listenMyFriendsAndRequests(myUid);
    _v7OrigListenIncomingChats(myUid);
};

const _v7OrigRenderSavedDms = renderSavedDmChatsOnHome;
renderSavedDmChatsOnHome = function () {
    _v7OrigRenderSavedDms();
    const container = document.querySelector(".chats-container");
    if (!container) return;

    // Inject Pending Friend Requests Banner at top when in "All" or "Friends" tab
    container.querySelectorAll(".friend-req-top-box").forEach(el => el.remove());
    if (incomingFriendReqs.length > 0 && (currentActiveChatTab === "all" || currentActiveChatTab === "friends")) {
        const reqBox = document.createElement("div");
        reqBox.className = "friend-req-top-box";
        reqBox.style.cssText = "display:flex; flex-direction:column; gap:6px; margin-bottom:10px;";
        reqBox.innerHTML = incomingFriendReqs.map(r => `
            <div class="chat-list-item" style="background:rgba(16,185,129,0.1); border:1.5px solid #34d399;">
                <div class="chat-avatar"><img src="${escapeHtml(getSafeAvatar(r.fromAvatar))}" onerror="this.src='logo.png'"></div>
                <div class="chat-info">
                    <div class="chat-name-row"><h4>🤝 Friend Request: ${escapeHtml(r.fromName)}</h4></div>
                    <div class="chat-msg-row"><p>${escapeHtml(r.fromUsername || "@student")} wants to be friends</p></div>
                </div>
                <div style="display:flex; gap:6px;">
                    <button type="button" onclick="respondToFriendRequest('${r.id}', '${r.fromUid}', '${escapeHtml(r.fromName)}', true)" style="background:#10b981; color:#fff; border:none; padding:6px 12px; border-radius:12px; font-size:12px; font-weight:700; cursor:pointer;">Accept</button>
                    <button type="button" onclick="respondToFriendRequest('${r.id}', '${r.fromUid}', '${escapeHtml(r.fromName)}', false)" style="background:#ef4444; color:#fff; border:none; padding:6px 10px; border-radius:12px; font-size:12px; font-weight:700; cursor:pointer;">✕</button>
                </div>
            </div>
        `).join("");
        container.prepend(reqBox);
    }

    // Decorate Home Chat List Names with ₹249 Green & ₹349 Blue Subscription Badges
    recentDmUsers.forEach((u, idx) => {
        const cached = userProfileCache[u.uid];
        const tier = cached?.userTier || u.userTier || 0;
        if (tier > 0) {
            const h4List = container.querySelectorAll(".dynamic-dm-item:not(.group-chat-item) .chat-name-row h4");
            h4List.forEach(h4 => {
                if (h4.textContent.trim() === u.name && !h4.querySelector(".zoreno-sub-badge")) {
                    h4.innerHTML = `${escapeHtml(u.name)} ${getSubscriptionBadgeHTML(tier)}`;
                }
            });
        }
    });
};

// 8. Two-Way Block Confirmation, Multi-Photo Send & Subscription Badges in DM Header / Friend Profile
const _v7OrigSyncFriendProfileDOM = syncFriendProfileViewDOM;
syncFriendProfileViewDOM = function () {
    _v7OrigSyncFriendProfileDOM();
    syncMakeFriendButtonUI();
    if (!currentChatUserMeta) return;
    const cached = userProfileCache[currentChatUserId] || {};
    const fTier = currentChatUserMeta.userTier || cached.userTier || 0;
    const badgeHtml = getSubscriptionBadgeHTML(fTier);

    const fName = document.getElementById("fpFullName");
    if (fName && badgeHtml && !fName.innerHTML.includes("zoreno-sub-badge")) {
        fName.innerHTML = `${escapeHtml(currentChatUserMeta.name || "Student")} ${badgeHtml}`;
    }
    const headerName = document.getElementById("activeChatName");
    if (headerName && badgeHtml && !headerName.innerHTML.includes("zoreno-sub-badge")) {
        headerName.innerHTML = `${escapeHtml(currentChatUserMeta.name || "Student")} ${badgeHtml}`;
    }
};

toggleBlockChatUser = function () {
    closeAllDropdownMenus();
    if (!currentChatUserId || currentChatIsGroup) return;
    initZorenoV7LaunchSystem();

    const isBlocked = !!blockedUsersMap[currentChatUserId] || isCurrentChatBlockedByMe;
    const titleEl = document.getElementById("blockModalTitle");
    const descEl = document.getElementById("blockModalDesc");
    const btnEl = document.getElementById("blockModalConfirmBtn");

    if (isBlocked) {
        if (titleEl) titleEl.textContent = "Unblock This Person?";
        if (descEl) descEl.textContent = `Are you sure you want to unblock ${currentChatUserMeta?.name || "this user"} and resume chatting?`;
        if (btnEl) { btnEl.textContent = "Unblock"; btnEl.style.background = "#10b981"; }
    } else {
        if (titleEl) titleEl.textContent = "Block This Person?";
        if (descEl) descEl.textContent = `Are you sure you want to block ${currentChatUserMeta?.name || "this user"}? Neither of you will be able to send messages.`;
        if (btnEl) { btnEl.textContent = "OK"; btnEl.style.background = "#ef4444"; }
    }
    document.getElementById("blockConfirmModal").style.display = "flex";
};

async function executeConfirmedBlockToggle() {
    document.getElementById("blockConfirmModal").style.display = "none";
    if (!currentChatUserId || currentChatIsGroup) return;

    const myUid = auth?.currentUser?.uid || "local";
    const chatId = myUid < currentChatUserId ? `${myUid}_${currentChatUserId}` : `${currentChatUserId}_${myUid}`;
    const currentlyBlocked = !!blockedUsersMap[currentChatUserId] || isCurrentChatBlockedByMe;
    const nextBlockState = !currentlyBlocked;

    if (nextBlockState) blockedUsersMap[currentChatUserId] = true;
    else delete blockedUsersMap[currentChatUserId];

    isCurrentChatBlockedByMe = nextBlockState;
    localStorage.setItem("zorenoBlockedUsers", JSON.stringify(blockedUsersMap));
    updateBlockMenuButtonUI();
    syncDmBlockedFooterUI();

    if (db && auth?.currentUser) {
        try {
            await db.collection("chats").doc(chatId).set({ [`blockedBy_${myUid}`]: nextBlockState }, { merge: true });
            await db.collection("users").doc(myUid).set({ blockedUsers: blockedUsersMap }, { merge: true });
        } catch (e) {}
    }
}

function syncDmBlockedFooterUI() {
    initZorenoV7LaunchSystem();
    const footer = document.querySelector("#activeChatScreen .chat-win-footer");
    const banner = document.getElementById("dmBlockedFooterBanner");
    const previewStrip = document.getElementById("dmAttachmentPreviewBar");
    if (!footer || !banner) return;

    if (currentChatIsGroup) {
        banner.style.display = "none";
        footer.style.setProperty("display", "flex", "important");
        return;
    }

    const blockedByMe = !!blockedUsersMap[currentChatUserId] || isCurrentChatBlockedByMe;
    const blockedByFriend = isCurrentChatBlockedByFriend;

    if (blockedByMe) {
        footer.style.setProperty("display", "none", "important");
        if (previewStrip) previewStrip.style.setProperty("display", "none", "important");
        banner.style.display = "flex";
        banner.onclick = () => toggleBlockChatUser();
        banner.innerHTML = `<i class="fa-solid fa-ban" style="color:#ef4444;"></i> <span>You blocked this person. <strong>Tap to unblock to chat.</strong></span>`;
    } else if (blockedByFriend) {
        footer.style.setProperty("display", "none", "important");
        if (previewStrip) previewStrip.style.setProperty("display", "none", "important");
        banner.style.display = "flex";
        banner.onclick = null;
        banner.innerHTML = `<i class="fa-solid fa-circle-exclamation" style="color:#f59e0b;"></i> <span>Message not available. You cannot reply to this conversation.</span>`;
    } else {
        banner.style.display = "none";
        footer.style.setProperty("display", "flex", "important");
    }
}

const _v7OrigOpenChatWithUser = openChatWithUser;
openChatWithUser = function (userId, targetName, targetAvatar, targetUsername) {
    isCurrentChatBlockedByMe = !!blockedUsersMap[userId];
    isCurrentChatBlockedByFriend = false;
    _v7OrigOpenChatWithUser(userId, targetName, targetAvatar, targetUsername);
    syncDmBlockedFooterUI();

    if (db && userId) {
        db.collection("users").doc(userId).get().then(doc => {
            if (doc.exists && currentChatUserMeta && currentChatUserId === userId) {
                const d = doc.data() || {};
                currentChatUserMeta.userTier = d.userTier || 0;
                userProfileCache[userId] = d;
                syncFriendProfileViewDOM();
            }
        }).catch(() => {});
    }

    if (activeChatMetaUnsub) activeChatMetaUnsub();
    if (db && auth?.currentUser && userId) {
        const myUid = auth.currentUser.uid;
        const chatId = myUid < userId ? `${myUid}_${userId}` : `${userId}_${myUid}`;
        activeChatMetaUnsub = db.collection("chats").doc(chatId).onSnapshot(doc => {
            if (!doc.exists) {
                syncDmBlockedFooterUI();
                return;
            }
            const data = doc.data() || {};
            isFriendCurrentlyTyping = !!data[`typing_${userId}`];
            isCurrentChatBlockedByMe = !!data[`blockedBy_${myUid}`] || !!blockedUsersMap[userId];
            isCurrentChatBlockedByFriend = !!data[`blockedBy_${userId}`];
            renderDmHeaderStatus();
            updateBlockMenuButtonUI();
            syncDmBlockedFooterUI();
        });
    }
};

const _v7OrigSendRealtimeMessage = sendRealtimeMessage;
sendRealtimeMessage = async function () {
    if (!currentChatIsGroup && (isCurrentChatBlockedByMe || blockedUsersMap[currentChatUserId] || isCurrentChatBlockedByFriend)) {
        syncDmBlockedFooterUI();
        return;
    }
    const input = document.getElementById("activeChatInput");
    const txt = (input?.value || "").trim();
    if (!checkPersonalPrivacyBeforeSend(txt)) return;

    const readyPhotos = pendingDmAttachmentsList.filter(a => !a.loading && a.dataUrl);
    if (readyPhotos.length > 1) {
        // Send first photo with text, then automatically send the 2nd photo!
        const secondPhotoData = readyPhotos[1].dataUrl;
        pendingDmAttachment = { loading: false, dataUrl: readyPhotos[0].dataUrl };
        pendingDmAttachmentsList = [];
        await _v7OrigSendRealtimeMessage();
        pendingDmAttachment = { loading: false, dataUrl: secondPhotoData };
        await _v7OrigSendRealtimeMessage();
        clearDmAttachment();
        return;
    }
    pendingDmAttachment = readyPhotos[0] || null;
    pendingDmAttachmentsList = [];
    await _v7OrigSendRealtimeMessage();
};

// 9. Clear Chat Confirmation, Share Sheet, Forgot Password & 14-Day Account Deletion
const _v7OrigClearAllChatHistory = clearAllChatHistory;
clearAllChatHistory = function () {
    closeAllDropdownMenus();
    initZorenoV7LaunchSystem();
    pendingClearChatMode = "ai";
    document.getElementById("clearChatModalTitle").textContent = "Delete AI Chat History?";
    document.getElementById("clearChatModalDesc").textContent = "Are you sure you want to permanently clear all your Zoreno AI messages?";
    document.getElementById("clearChatConfirmModal").style.display = "flex";
};

clearCurrentAiChat = function () { clearAllChatHistory(); };

const _v7OrigClearCurrentDmChat = clearCurrentDmChat;
clearCurrentDmChat = function () {
    closeAllDropdownMenus();
    initZorenoV7LaunchSystem();
    pendingClearChatMode = "dm";
    document.getElementById("clearChatModalTitle").textContent = "Clear Conversation?";
    document.getElementById("clearChatModalDesc").textContent = `Are you sure you want to clear all messages with ${currentChatUserMeta?.name || "this chat"}?`;
    document.getElementById("clearChatConfirmModal").style.display = "flex";
};

async function executeConfirmedClearChat() {
    document.getElementById("clearChatConfirmModal").style.display = "none";
    if (pendingClearChatMode === "ai") await _v7OrigClearAllChatHistory();
    else if (pendingClearChatMode === "dm") await _v7OrigClearCurrentDmChat();
    pendingClearChatMode = null;
}

let currentSharePayloadText = "";
let currentShareAppUrl = "https://play.google.com/store/apps/details?id=com.zoreno.app";

shareAiResponseText = function (idx) {
    initZorenoV7LaunchSystem();
    const rawBot = cleanLatexToNotebookMath(aiChatMessagesList[idx]?.bot || "");
    if (!rawBot) return;
    const cleanAnswer = rawBot.replace(/\*\*/g, "").trim();
    currentSharePayloadText = `✨ *Answered by Zoreno AI:*\n\n${cleanAnswer}\n\n🚀 *Download Zoreno: AI Study, Chat & Focus:*\n${currentShareAppUrl}`;
    const prevEl = document.getElementById("shareSheetAnswerPreview");
    if (prevEl) prevEl.textContent = cleanAnswer.slice(0, 90) + "...";
    document.getElementById("zorenoShareSheetModal").style.display = "flex";
};

async function shareToSpecificPlatform(platform) {
    document.getElementById("zorenoShareSheetModal").style.display = "none";
    const encodedText = encodeURIComponent(currentSharePayloadText);
    if (platform === "whatsapp") { window.open(`https://api.whatsapp.com/send?text=${encodedText}`, "_blank"); return; }
    if (platform === "telegram") { window.open(`https://t.me/share/url?url=${encodeURIComponent(currentShareAppUrl)}&text=${encodedText}`, "_blank"); return; }
    if (platform === "twitter") { window.open(`https://twitter.com/intent/tweet?text=${encodedText}`, "_blank"); return; }
    if (platform === "instagram" || platform === "system") {
        if (window.AndroidShare && typeof window.AndroidShare.shareText === "function") {
            window.AndroidShare.shareText(currentSharePayloadText);
            return;
        }
        if (navigator.share) {
            try { await navigator.share({ title: "Zoreno AI", text: currentSharePayloadText, url: currentShareAppUrl }); return; } catch (e) {}
        }
    }
    try {
        await navigator.clipboard.writeText(currentSharePayloadText);
        showCustomAlert("Ready to Share! 🔗", "Answer and Zoreno link copied! Paste directly on Instagram or anywhere.", true);
    } catch (e) {}
}

handleForgotPassword = function () {
    initZorenoV7LaunchSystem();
    const existingEmail = document.getElementById("loginEmail")?.value.trim() || "";
    const resetInp = document.getElementById("resetPassEmailInp");
    if (resetInp) resetInp.value = existingEmail;
    document.getElementById("forgotPassModal").style.display = "flex";
};

async function confirmSendPasswordReset() {
    const email = (document.getElementById("resetPassEmailInp")?.value || "").trim();
    if (!email || !email.includes("@")) {
        showCustomAlert("Email Required", "Please enter a valid registered email address.");
        return;
    }
    try {
        await initFirebase();
        await auth.sendPasswordResetEmail(email);
        document.getElementById("forgotPassModal").style.display = "none";
        showCustomAlert("Reset Link Sent! 📧", `Password reset instructions have been sent to ${email}.`, true);
    } catch (err) {
        showCustomAlert("Reset Failed", err.message);
    }
}

confirmDeleteAccount = async function () {
    const email = document.getElementById("delAccEmail")?.value.trim();
    const pass = document.getElementById("delAccPass")?.value;
    if (!email || !pass) {
        showCustomAlert("Password Required 🔒", "Please enter both your email and current password to verify your identity.");
        return;
    }
    if (!auth?.currentUser) return;

    try {
        const uid = auth.currentUser.uid;
        const cred = firebase.auth.EmailAuthProvider.credential(email, pass);
        await auth.currentUser.reauthenticateWithCredential(cred);

        const deleteEffectiveMs = Date.now() + (14 * 24 * 60 * 60 * 1000);
        const deleteDateStr = new Date(deleteEffectiveMs).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });

        if (db) {
            await db.collection("users").doc(uid).set({
                accountDeletionRequested: true,
                deletionScheduledForMs: deleteEffectiveMs,
                isOnline: false
            }, { merge: true });
        }

        document.getElementById("deleteAccountModal").style.display = "none";
        showCustomAlert(
            "14-Day Deletion Scheduled ⏳",
            `Password verified! Your account is scheduled for permanent deletion on ${deleteDateStr} (14-day security window).`,
            true
        );
        setTimeout(async () => { await handleUserLogout(); }, 2800);
    } catch (err) {
        showCustomAlert("Incorrect Password ❌", "Password verification failed. Please enter your correct password.");
    }
};

const _v7OrigOpenZorenoAI = openZorenoAIChat;
openZorenoAIChat = function () { _v7OrigOpenZorenoAI(); updateAiQuotaHeaderBadge(); };

const _v7OrigRenderAiStream = renderAiChatStream;
renderAiChatStream = function () { _v7OrigRenderAiStream(); updateAiQuotaHeaderBadge(); };

window.addEventListener("DOMContentLoaded", () => {
    setTimeout(initZorenoV7LaunchSystem, 350);
});


// =========================================================
// ZORENO V8 FINAL: BANK-LOCKER ADMIN VAULT (2X PASSWORD + DANGER SCREEN)
// & OFFICIAL CROWN SHIELD BADGE FOR @ZORENO & ZORENO AI (32116 & 32117)
// =========================================================

let currentActiveGroupData = null;
let adminTapCounter = 0;
let adminTapTimer = null;
let dangerSkullTapCount = 0;

// Tumhara Master Password (Ise dono locker steps me dalna hoga)
const ZORENO_MASTER_VAULT_PASS = "Achyut@Zoreno#2026";

// 1. Check if Account is Official Founder Account ("Zoreno" / "@zoreno") or Zoreno AI
function isOfficialZorenoAccount(nameStr, usernameStr) {
    const cleanU = String(usernameStr || "").trim().toLowerCase().replace(/^@/, "");
    const cleanN = String(nameStr || "").trim().toLowerCase();
    return cleanU === "zoreno" || cleanU === "zoreno_ai" || cleanN === "zoreno" || cleanN === "zoreno ai";
}

function getOfficialCrownTagHTML() {
    return `<span class="official-sparkle-star">✦</span><span class="official-crown-pill-tag"><i class="fa-solid fa-crown"></i> Official</span>`;
}

function getOfficialShieldOverlayHTML() {
    return `<span class="official-dp-crown-shield" title="Official Zoreno Account"><i class="fa-solid fa-crown"></i></span>`;
}

// 2. Decorate Zoreno AI & @zoreno Official Avatars and Names Across the App (32116 & 32117 Match)
function applyOfficialCrownBrandingToDOM() {
    // A. Home Screen Pinned Zoreno AI Item
    const pinnedItem = document.querySelector(".chat-list-item.pinned");
    if (pinnedItem) {
        const avBox = pinnedItem.querySelector(".chat-avatar");
        if (avBox && !avBox.classList.contains("official-glow-avatar")) {
            avBox.classList.add("official-glow-avatar");
            avBox.insertAdjacentHTML("beforeend", getOfficialShieldOverlayHTML());
        }
        const h4 = pinnedItem.querySelector(".chat-name-row h4");
        if (h4 && !h4.querySelector(".official-crown-pill-tag")) {
            h4.innerHTML = `Zoreno AI ${getOfficialCrownTagHTML()}`;
        }
    }

    // B. Zoreno AI Chat Screen Topbar & Message Avatars
    const aiTopMeta = document.querySelector(".ai-topbar-user-meta");
    if (aiTopMeta) {
        const aiImg = aiTopMeta.querySelector(".ai-logo-avatar");
        if (aiImg && !aiImg.parentElement.classList.contains("official-ai-top-dp-wrap")) {
            const wrap = document.createElement("div");
            wrap.className = "official-ai-top-dp-wrap official-glow-avatar";
            aiImg.parentNode.insertBefore(wrap, aiImg);
            wrap.appendChild(aiImg);
            wrap.insertAdjacentHTML("beforeend", getOfficialShieldOverlayHTML());
        }
        const premTag = aiTopMeta.querySelector(".chat-prem-tag");
        if (premTag && !premTag.classList.contains("official-crown-pill-tag")) {
            premTag.outerHTML = getOfficialCrownTagHTML();
        }
    }

    // C. Decorate AI Chat Bubbles with Official Crown Shield & Header (32117.png Match)
    document.querySelectorAll("#chatMessages .msg-row-with-avatar:not(.right-user)").forEach(row => {
        const img = row.querySelector(".ai-logo-avatar");
        if (img && !img.parentElement.classList.contains("official-msg-dp-wrap")) {
            const wrap = document.createElement("div");
            wrap.className = "official-msg-dp-wrap official-glow-avatar";
            img.parentNode.insertBefore(wrap, img);
            wrap.appendChild(img);
            wrap.insertAdjacentHTML("beforeend", getOfficialShieldOverlayHTML());
        }
        const bubble = row.querySelector(".clean-left-bubble");
        if (bubble && !bubble.classList.contains("official-founder-bubble")) {
            bubble.classList.add("official-founder-bubble");
            if (!bubble.querySelector(".official-bubble-top-title")) {
                bubble.insertAdjacentHTML("afterbegin", `<div class="official-bubble-top-title">Zoreno AI ✦ Official</div>`);
            }
        }
    });

    // D. Decorate Home DM List if user is @zoreno (Founder Account)
    document.querySelectorAll(".chats-container .dynamic-dm-item:not(.group-chat-item)").forEach(item => {
        const h4 = item.querySelector(".chat-name-row h4");
        const rawName = (h4?.childNodes[0]?.textContent || "").trim();
        const matchedUser = recentDmUsers.find(u => u.name === rawName);
        if (isOfficialZorenoAccount(rawName, matchedUser?.username)) {
            item.classList.add("pinned");
            const av = item.querySelector(".chat-avatar");
            if (av && !av.classList.contains("official-glow-avatar")) {
                av.classList.add("official-glow-avatar");
                av.insertAdjacentHTML("beforeend", getOfficialShieldOverlayHTML());
            }
            if (h4 && !h4.querySelector(".official-crown-pill-tag")) {
                h4.innerHTML = `${escapeHtml(rawName)} ${getOfficialCrownTagHTML()}`;
            }
        }
    });
}

// Wrap AI Stream & Home DMs to auto-apply Official Crown Branding
const _v8OrigRenderAiStream = renderAiChatStream;
renderAiChatStream = function () {
    _v8OrigRenderAiStream();
    applyOfficialCrownBrandingToDOM();
};

const _v8OrigRenderHomeDms = renderSavedDmChatsOnHome;
renderSavedDmChatsOnHome = function () {
    _v8OrigRenderHomeDms();
    applyOfficialCrownBrandingToDOM();
};

// Also highlight Founder (@zoreno) messages inside Friend DM & Group Chat (32117.png Match)
const _v8OrigRenderDmMessages = renderDmMessagesListToDOM;
renderDmMessagesListToDOM = function (chatId, messagesArray, myUid) {
    _v8OrigRenderDmMessages(chatId, messagesArray, myUid);

    const isFriendOfficial = isOfficialZorenoAccount(currentChatUserMeta?.name, currentChatUserMeta?.username);
    const amIOfficial = isOfficialZorenoAccount(userName, currentUsername);

    // Header Crown if chatting with Official @zoreno
    const dmAvatarWrap = document.querySelector("#activeChatScreen .chat-win-avatar-wrap");
    const dmNameEl = document.getElementById("activeChatName");
    if (dmAvatarWrap) {
        dmAvatarWrap.querySelectorAll(".official-dp-crown-shield").forEach(e => e.remove());
        if (isFriendOfficial) {
            dmAvatarWrap.classList.add("official-glow-avatar");
            dmAvatarWrap.insertAdjacentHTML("beforeend", getOfficialShieldOverlayHTML());
            if (dmNameEl && !dmNameEl.querySelector(".official-crown-pill-tag")) {
                dmNameEl.innerHTML = `${escapeHtml(currentChatUserMeta.name)} ${getOfficialCrownTagHTML()}`;
            }
        } else {
            dmAvatarWrap.classList.remove("official-glow-avatar");
        }
    }

    // Highlight incoming messages from @zoreno
    if (isFriendOfficial) {
        document.querySelectorAll("#activeChatMessages .msg-row-with-avatar.left-friend").forEach(row => {
            const dp = row.querySelector(".msg-side-avatar");
            if (dp && !dp.parentElement.classList.contains("official-msg-dp-wrap")) {
                const wrap = document.createElement("div");
                wrap.className = "official-msg-dp-wrap official-glow-avatar";
                dp.parentNode.insertBefore(wrap, dp);
                wrap.appendChild(dp);
                wrap.insertAdjacentHTML("beforeend", getOfficialShieldOverlayHTML());
            }
            const b = row.querySelector(".clean-left-bubble");
            if (b && !b.classList.contains("official-founder-bubble")) {
                b.classList.add("official-founder-bubble");
                b.insertAdjacentHTML("afterbegin", `<div class="official-bubble-top-title">${escapeHtml(currentChatUserMeta.name)} ✦ Official</div>`);
            }
        });
    }

    // Highlight outgoing messages if logged in as @zoreno
    if (amIOfficial) {
        document.querySelectorAll("#activeChatMessages .msg-row-with-avatar.right-user .clean-right-bubble").forEach(b => {
            if (!b.querySelector(".official-bubble-top-title")) {
                b.style.border = "1.5px solid #e9d5ff";
                b.style.boxShadow = "0 0 18px rgba(168, 85, 247, 0.45)";
                b.insertAdjacentHTML("afterbegin", `<div class="official-bubble-top-title" style="color:#fde047;">👑 ${escapeHtml(userName)} ✦ Official</div>`);
            }
        });
    }
};

// Show Official Crown on My Profile / Friend Profile if account is @zoreno
const _v8OrigUpdateProfileUI = updateProfileUI;
updateProfileUI = function () {
    _v8OrigUpdateProfileUI();
    const myRing = document.querySelector("#profileScreen .profile-pic-ring");
    const badgeEl = document.getElementById("profileUsernameBadge");
    if (isOfficialZorenoAccount(userName, currentUsername)) {
        if (myRing && !myRing.querySelector(".official-dp-crown-shield")) {
            myRing.classList.add("official-glow-avatar");
            myRing.insertAdjacentHTML("beforeend", getOfficialShieldOverlayHTML());
        }
        if (badgeEl) {
            badgeEl.innerHTML = `${escapeHtml(currentUsername || "@zoreno")} ${getOfficialCrownTagHTML()}`;
        }
    }
};

// 3. Load Gemini API Key Dynamically from Firebase (Never exposed on GitHub!)
async function syncDynamicGeminiApiKeyFromFirebase() {
    try {
        if (!db) await initFirebase();
        db.collection("appConfig").doc("aiSettings").onSnapshot(doc => {
            if (doc.exists) {
                const data = doc.data() || {};
                if (data.geminiApiKey && typeof data.geminiApiKey === "string") {
                    GEMINI_API_KEY = data.geminiApiKey.trim();
                    localStorage.setItem("zorenoCloudApiKey", GEMINI_API_KEY);
                }
            }
        });
    } catch (e) {}
}

// 4. Group Profile Members List + Click to Message
const _v8OrigOpenStudyGroupChat = openStudyGroupChat;
openStudyGroupChat = function (grp) {
    currentActiveGroupData = grp;
    _v8OrigOpenStudyGroupChat(grp);

    if (db && grp?.id) {
        if (activeFriendProfileUnsub) activeFriendProfileUnsub();
        activeFriendProfileUnsub = db.collection("groups").doc(grp.id).onSnapshot(doc => {
            if (!doc.exists) return;
            const freshGrp = { id: doc.id, ...doc.data() };
            currentActiveGroupData = freshGrp;
            const memCount = (freshGrp.members || []).length;
            currentChatUserMeta.name = freshGrp.name || "Study Group";
            currentChatUserMeta.username = `${memCount} ${memCount === 1 ? "Member" : "Members"}`;

            const nameEl = document.getElementById("activeChatName");
            const statusEl = document.getElementById("activeChatStatus");
            if (nameEl) nameEl.textContent = currentChatUserMeta.name;
            if (statusEl) statusEl.innerHTML = `<span style="color:#10b981; font-weight:700;">👥 ${memCount} ${memCount === 1 ? "Member" : "Members"} • Tap header to view members</span>`;

            const fpScreen = document.getElementById("friendProfileScreen");
            if (fpScreen && fpScreen.style.display === "block") {
                renderGroupMembersInsideProfile(freshGrp);
            }
        });
    }
};

const _v8OrigOpenFriendProfile = openFriendProfileScreen;
openFriendProfileScreen = function () {
    _v8OrigOpenFriendProfile();
    const fpScreen = document.getElementById("friendProfileScreen");
    if (!fpScreen) return;

    const normalCards = fpScreen.querySelectorAll(".fp-actions-grid, .fp-info-card");
    let grpBox = document.getElementById("zorenoGroupMembersContainer");
    if (!grpBox) {
        grpBox = document.createElement("div");
        grpBox.id = "zorenoGroupMembersContainer";
        fpScreen.appendChild(grpBox);
    }

    if (currentChatIsGroup && currentActiveGroupData) {
        normalCards.forEach(el => el.style.setProperty("display", "none", "important"));
        grpBox.style.display = "block";
        renderGroupMembersInsideProfile(currentActiveGroupData);
    } else {
        normalCards.forEach(el => el.style.removeProperty("display"));
        grpBox.style.display = "none";
        const fpRing = fpScreen.querySelector(".fp-avatar-ring");
        const fpName = document.getElementById("fpFullName");
        if (fpRing) fpRing.querySelectorAll(".official-dp-crown-shield").forEach(e => e.remove());
        if (isOfficialZorenoAccount(currentChatUserMeta?.name, currentChatUserMeta?.username)) {
            if (fpRing) {
                fpRing.classList.add("official-glow-avatar");
                fpRing.insertAdjacentHTML("beforeend", getOfficialShieldOverlayHTML());
            }
            if (fpName) fpName.innerHTML = `${escapeHtml(currentChatUserMeta.name)} ${getOfficialCrownTagHTML()}`;
        }
    }
};

async function renderGroupMembersInsideProfile(grp) {
    const grpBox = document.getElementById("zorenoGroupMembersContainer");
    if (!grpBox || !grp) return;

    const memberUids = grp.members || [];
    const memCount = memberUids.length;

    const fName = document.getElementById("fpFullName");
    const uSub = document.getElementById("fpUsernameSub");
    const pillTxt = document.getElementById("fpPillText");
    if (fName) fName.textContent = grp.name || "Study Group";
    if (uSub) uSub.textContent = `Study Group • ${memCount} ${memCount === 1 ? "Member" : "Members"}`;
    if (pillTxt) pillTxt.textContent = "Active Group";

    grpBox.innerHTML = `<div style="text-align:center; padding:18px; color:#7c3aed; font-weight:700;"><i class="fa-solid fa-spinner fa-spin"></i> Loading group members...</div>`;

    const myUid = auth?.currentUser?.uid || "";
    const memberProfiles = [];

    for (const uid of memberUids) {
        if (uid === myUid) {
            memberProfiles.push({
                uid: myUid,
                name: userName || "You",
                username: currentUsername || "@student",
                avatar: getSafeAvatar(userAvatarUrl),
                userTier: userTier,
                isAdmin: grp.adminUid === myUid,
                isMe: true
            });
            continue;
        }
        let cached = userProfileCache[uid];
        if (!cached && db) {
            try {
                const uDoc = await db.collection("users").doc(uid).get();
                if (uDoc.exists) {
                    cached = uDoc.data();
                    userProfileCache[uid] = cached;
                }
            } catch (e) {}
        }
        memberProfiles.push({
            uid: uid,
            name: cached?.name || "Student",
            username: cached?.username || "@student",
            avatar: getSafeAvatar(cached?.photoURL || cached?.avatarUrl),
            userTier: cached?.userTier || 0,
            isAdmin: grp.adminUid === uid,
            isMe: false
        });
    }

    const membersListHtml = memberProfiles.map(m => {
        const isOff = isOfficialZorenoAccount(m.name, m.username);
        const badgeHtml = isOff ? getOfficialCrownTagHTML() : (typeof getSubscriptionBadgeHTML === "function" ? getSubscriptionBadgeHTML(m.userTier) : "");
        const adminPill = m.isAdmin ? `<span style="background:#ede9fe; color:#7c3aed; font-size:10px; font-weight:800; padding:2px 7px; border-radius:8px; margin-left:4px;">Admin</span>` : "";
        const clickAction = m.isMe
            ? ""
            : `onclick="startDirectChatFromGroupMember('${escapeHtml(m.uid)}', '${escapeHtml(m.name)}', '${escapeHtml(m.avatar)}', '${escapeHtml(m.username)}')"`;

        return `
            <div class="fp-info-card" ${clickAction} style="cursor:${m.isMe ? 'default' : 'pointer'}; justify-content:space-between; margin-bottom:10px;">
                <div style="display:flex; align-items:center; gap:12px; min-width:0; flex:1;">
                    <div style="position:relative; width:44px; height:44px; flex-shrink:0;" class="${isOff ? 'official-glow-avatar' : ''}">
                        <img src="${escapeHtml(m.avatar)}" onerror="this.src='logo.png'" style="width:44px; height:44px; border-radius:50%; object-fit:cover;">
                        ${isOff ? getOfficialShieldOverlayHTML() : ""}
                    </div>
                    <div style="min-width:0; flex:1;">
                        <h4 style="margin:0; font-size:15px; font-weight:800; display:flex; align-items:center; flex-wrap:wrap; gap:4px;">
                            ${escapeHtml(m.name)} ${m.isMe ? "(You)" : ""} ${badgeHtml} ${adminPill}
                        </h4>
                        <span style="font-size:12px; color:#7c3aed; font-weight:700;">${escapeHtml(m.username)}</span>
                    </div>
                </div>
                ${!m.isMe ? `
                <button type="button" style="background:linear-gradient(135deg,#2563eb,#7c3aed); color:#fff; border:none; padding:7px 13px; border-radius:14px; font-size:12px; font-weight:700; cursor:pointer; flex-shrink:0;">
                    <i class="fa-regular fa-comment-dots"></i> Message
                </button>` : ""}
            </div>
        `;
    }).join("");

    grpBox.innerHTML = `
        <div style="display:flex; align-items:center; justify-content:space-between; margin:10px 4px 10px;">
            <span style="font-size:12.5px; font-weight:800; color:#64748b; text-transform:uppercase;">Group Members (${memCount})</span>
            <button type="button" onclick="openInviteMoreFriendsToGroupModal()" style="border:none; background:rgba(124,58,237,0.12); color:#7c3aed; padding:6px 12px; border-radius:12px; font-size:12px; font-weight:800; cursor:pointer;">
                + Invite Friends
            </button>
        </div>
        ${membersListHtml}
    `;
}

function startDirectChatFromGroupMember(uid, name, avatar, username) {
    closeFriendProfileScreen();
    currentChatIsGroup = false;
    openChatWithUser(uid, name, avatar, username);
}

function openInviteMoreFriendsToGroupModal() {
    if (!currentActiveGroupData) return;
    const existingMembers = currentActiveGroupData.members || [];
    const availableFriends = recentDmUsers.filter(f => myFriendsMap[f.uid] === true && !existingMembers.includes(f.uid));

    if (availableFriends.length === 0) {
        showCustomAlert("Invite Friends 👥", "All your accepted friends are already in this group (or add new friends first via 'Make Friend').");
        return;
    }

    let modal = document.getElementById("zorenoInviteExistingGrpModal");
    if (!modal) {
        modal = document.createElement("div");
        modal.id = "zorenoInviteExistingGrpModal";
        modal.className = "custom-modal-overlay";
        modal.style.zIndex = "9999999";
        document.body.appendChild(modal);
    }

    modal.innerHTML = `
        <div class="custom-modal-box">
            <div class="policy-modal-header">
                <h3>Invite Friends to Group</h3>
                <button class="modal-close-btn" onclick="document.getElementById('zorenoInviteExistingGrpModal').style.display='none'"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <div style="max-height:200px; overflow-y:auto; margin-bottom:14px;">
                ${availableFriends.map(f => `
                    <label style="display:flex; align-items:center; justify-content:space-between; padding:8px 10px; border-radius:12px; border:1px solid #e2e8f0; margin-bottom:6px; cursor:pointer;">
                        <div style="display:flex; align-items:center; gap:10px;">
                            <img src="${escapeHtml(getSafeAvatar(f.avatar))}" onerror="this.src='logo.png'" style="width:34px; height:34px; border-radius:50%; object-fit:cover;">
                            <div style="text-align:left;">
                                <div style="font-size:13.5px; font-weight:700;">${escapeHtml(f.name)}</div>
                                <div style="font-size:11px; color:#10b981;">✓ Friend • ${escapeHtml(f.username)}</div>
                            </div>
                        </div>
                        <input type="checkbox" class="grp-more-invite-chk" value="${escapeHtml(f.uid)}" style="width:18px; height:18px; accent-color:#7c3aed;">
                    </label>
                `).join("")}
            </div>
            <button type="button" class="modal-submit-btn" onclick="sendMoreGroupInvitesNow()">Send Invitations 🚀</button>
        </div>
    `;
    modal.style.display = "flex";
}

async function sendMoreGroupInvitesNow() {
    if (!db || !auth?.currentUser || !currentActiveGroupData) return;
    const myUid = auth.currentUser.uid;
    const selectedUids = Array.from(document.querySelectorAll(".grp-more-invite-chk:checked")).map(cb => cb.value);
    if (selectedUids.length === 0) return;

    try {
        for (const friendUid of selectedUids) {
            await db.collection("groupInvites").add({
                groupId: currentActiveGroupData.id,
                groupName: currentActiveGroupData.name,
                fromUid: myUid,
                inviterName: userName || "Friend",
                toUid: friendUid,
                status: "pending",
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            });
        }
        document.getElementById("zorenoInviteExistingGrpModal").style.display = "none";
        showCustomAlert("Invitations Sent! 🎉", `Sent group invite to ${selectedUids.length} friend(s).`, true);
    } catch (e) {
        showCustomAlert("Error", e.message);
    }
}

// =========================================================
// 5. BANK-LOCKER MULTI-STAGE DANGER VAULT FOR ADMIN PANEL
// =========================================================
function setupSecretAdminPanelTrigger() {
    const sparkleIcon = document.querySelector("#settingsScreen .page-header-icon");
    if (!sparkleIcon || sparkleIcon.dataset.adminBound === "true") return;
    sparkleIcon.dataset.adminBound = "true";
    sparkleIcon.style.cursor = "pointer";

    sparkleIcon.addEventListener("click", () => {
        adminTapCounter++;
        clearTimeout(adminTapTimer);
        adminTapTimer = setTimeout(() => { adminTapCounter = 0; }, 2200);
        if (adminTapCounter >= 5) {
            adminTapCounter = 0;
            openBankVaultStage1DangerScreen();
        }
    });
}

// STAGE 1: Scary Red Cyber Danger Screen (Scares away accidental clickers!)
function openBankVaultStage1DangerScreen() {
    dangerSkullTapCount = 0;
    let modal = document.getElementById("zorenoVaultDangerModal");
    if (!modal) {
        modal = document.createElement("div");
        modal.id = "zorenoVaultDangerModal";
        modal.className = "custom-modal-overlay";
        modal.style.zIndex = "9999999";
        document.body.appendChild(modal);
    }

    modal.innerHTML = `
        <div class="custom-modal-box vault-danger-box">
            <div class="vault-skull-badge" onclick="handleSecretSkullTriggerTap()">
                <i class="fa-solid fa-triangle-exclamation"></i>
            </div>
            <div class="vault-danger-tag">⚠️ DANGER • RESTRICTED KERNEL CORE</div>
            <h3 style="color:#ffffff; margin:6px 0; font-size:20px;">UNAUTHORIZED ACCESS DETECTED</h3>
            <p style="color:#fca5a5; font-size:12.5px; line-height:1.5; margin-bottom:14px;">
                WARNING: This terminal belongs to <strong>Toko Platforms Security Core</strong>. Attempting to access this area without Founder Authorization is strictly prohibited. Your Device ID & IP session are being monitored.
            </p>
            <div class="vault-fake-log">
                SYS_GUARD: FIREWALL_ACTIVE [LOCK_LEVEL_9]<br>
                TRACE_ID: ${Math.random().toString(36).substring(2, 10).toUpperCase()}-SEC-NODE
            </div>
            <button type="button" class="modal-submit-btn" style="background:#ef4444; font-weight:800; margin-top:14px;" onclick="document.getElementById('zorenoVaultDangerModal').style.display='none'">
                EXIT IMMEDIATELY
            </button>
        </div>
    `;
    modal.style.display = "flex";
}

// Secret Trigger inside Danger Screen: Tap the Red Warning Icon 3 times!
function handleSecretSkullTriggerTap() {
    dangerSkullTapCount++;
    if (dangerSkullTapCount >= 3) {
        dangerSkullTapCount = 0;
        openBankVaultStage2PasswordGate1();
    }
}

// STAGE 2: First Password Gate
function openBankVaultStage2PasswordGate1() {
    const modal = document.getElementById("zorenoVaultDangerModal");
    if (!modal) return;
    modal.innerHTML = `
        <div class="custom-modal-box vault-danger-box">
            <div class="vault-danger-tag">🔒 SECURITY GATE 1 OF 2</div>
            <h3 style="color:#ffffff; margin:8px 0;">Enter Primary Vault Key</h3>
            <p style="color:#94a3b8; font-size:12px; margin-bottom:14px;">Verify level-1 founder credentials to access the encrypted matrix node.</p>
            <input type="password" id="vaultPassInput1" placeholder="Enter Master Password..." class="vault-dark-input">
            <div style="display:flex; gap:10px; margin-top:14px;">
                <button type="button" class="modal-submit-btn" style="background:#334155;" onclick="document.getElementById('zorenoVaultDangerModal').style.display='none'">Abort</button>
                <button type="button" class="modal-submit-btn" style="background:#dc2626;" onclick="verifyVaultPasswordGate1()">Verify Key #1</button>
            </div>
        </div>
    `;
}

function verifyVaultPasswordGate1() {
    const p1 = (document.getElementById("vaultPassInput1")?.value || "").trim();
    if (p1 !== ZORENO_MASTER_VAULT_PASS) {
        document.getElementById("zorenoVaultDangerModal").style.display = "none";
        showCustomAlert("ACCESS DENIED 🚨", "Invalid Master Key! Security incident logged.");
        return;
    }
    openBankVaultStage3MatrixScreen();
}

// STAGE 3: Complex Encrypted Matrix Terminal + Second Password Gate
function openBankVaultStage3MatrixScreen() {
    const modal = document.getElementById("zorenoVaultDangerModal");
    if (!modal) return;
    modal.innerHTML = `
        <div class="custom-modal-box vault-matrix-box">
            <div class="vault-matrix-header">
                <span>⚡ VAULT NODE: 0x99F4A2</span>
                <span>STATUS: ENCRYPTED</span>
            </div>
            <div class="vault-matrix-code-grid">
                01001101 01000001 01010011 01010100<br>
                SHA256: 8f9d2a7c...e4b109 [LOCKED]<br>
                ROOT_GUARD: DOUBLE_AUTH_REQUIRED<br>
                > Tap 'UNLOCK CORE' below to open final gate...
            </div>
            <button type="button" class="vault-decrypt-node-btn" onclick="revealVaultFinalPasswordBox()">
                <i class="fa-solid fa-key"></i> [ DECRYPT MASTER LOCKER ]
            </button>
            <div id="vaultFinalGateWrap" style="display:none; margin-top:14px; border-top:1px dashed #334155; padding-top:12px;">
                <label style="font-size:11px; color:#38bdf8; font-weight:800; display:block; margin-bottom:6px;">🔐 FINAL LOCKER CONFIRMATION (RE-ENTER PASSWORD):</label>
                <input type="password" id="vaultPassInput2" placeholder="Re-enter Master Password..." class="vault-dark-input">
                <button type="button" class="modal-submit-btn" style="background:linear-gradient(135deg,#10b981,#059669); margin-top:10px;" onclick="verifyVaultPasswordGate2()">
                    Unlock Founder Admin 🔓
                </button>
            </div>
        </div>
    `;
}

function revealVaultFinalPasswordBox() {
    const wrap = document.getElementById("vaultFinalGateWrap");
    if (wrap) wrap.style.display = "block";
    document.getElementById("vaultPassInput2")?.focus();
}

function verifyVaultPasswordGate2() {
    const p2 = (document.getElementById("vaultPassInput2")?.value || "").trim();
    if (p2 !== ZORENO_MASTER_VAULT_PASS) {
        document.getElementById("zorenoVaultDangerModal").style.display = "none";
        showCustomAlert("LOCKER SEALED 🚨", "Secondary password mismatch! Vault locked.");
        return;
    }
    document.getElementById("zorenoVaultDangerModal").style.display = "none";
    openZorenoFounderAdminModal();
}

// STAGE 4: Actual Founder Admin Panel (Opens only after passing all 3 Bank-Locker stages!)
async function openZorenoFounderAdminModal() {
    let modal = document.getElementById("zorenoAdminControlModal");
    if (!modal) {
        modal = document.createElement("div");
        modal.id = "zorenoAdminControlModal";
        modal.className = "custom-modal-overlay";
        modal.style.zIndex = "9999999";
        document.body.appendChild(modal);
    }

    modal.innerHTML = `
        <div class="custom-modal-box" style="max-width:410px; max-height:86vh; overflow-y:auto;">
            <div class="policy-modal-header">
                <h3>🛡️ Zoreno Founder Admin</h3>
                <button class="modal-close-btn" onclick="document.getElementById('zorenoAdminControlModal').style.display='none'"><i class="fa-solid fa-xmark"></i></button>
            </div>

            <div style="text-align:left; margin-bottom:16px; background:#f8fafc; padding:12px; border-radius:14px; border:1px solid #e2e8f0;">
                <label style="font-size:11.5px; font-weight:800; color:#7c3aed; display:block; margin-bottom:6px;">🔑 LIVE GEMINI API KEY (SAVED IN FIREBASE, SAFE FROM GITHUB):</label>
                <input type="text" id="adminGeminiKeyInput" value="${escapeHtml(GEMINI_API_KEY)}" placeholder="Paste new Gemini API key here..." style="width:100%; padding:10px; border-radius:10px; border:1.5px solid #cbd5e1; font-size:12.5px; margin-bottom:8px; outline:none;">
                <button type="button" class="modal-submit-btn" style="min-height:38px; padding:8px;" onclick="saveNewGeminiApiKeyToFirebase()">Save API Key Live 🚀</button>
            </div>

            <div style="text-align:left; margin-bottom:14px;">
                <h4 style="margin:0 0 8px; font-size:14px; color:#ef4444;">🚨 Recent User Reports</h4>
                <div id="adminReportsListBox" style="max-height:150px; overflow-y:auto; font-size:12px; display:flex; flex-direction:column; gap:6px;">Loading reports...</div>
            </div>

            <div style="text-align:left;">
                <h4 style="margin:0 0 8px; font-size:14px; color:#2563eb;">💬 Recent AI Feedbacks</h4>
                <div id="adminFeedbacksListBox" style="max-height:150px; overflow-y:auto; font-size:12px; display:flex; flex-direction:column; gap:6px;">Loading feedbacks...</div>
            </div>
        </div>
    `;
    modal.style.display = "flex";

    if (!db) await initFirebase();
    try {
        const rSnap = await db.collection("reports").limit(15).get();
        const rBox = document.getElementById("adminReportsListBox");
        if (rBox) {
            rBox.innerHTML = rSnap.empty
                ? `<div style="color:#64748b; padding:8px;">No user reports yet.</div>`
                : rSnap.docs.map(doc => {
                    const d = doc.data();
                    return `<div style="padding:8px 10px; border-radius:10px; background:#fef2f2; border:1px solid #fecaca; color:#991b1b;">
                        <strong>Reported:</strong> ${escapeHtml(d.reportedUserName || d.reportedUserId)}<br>
                        <strong>Reason:</strong> ${escapeHtml(d.reason)}<br>
                        <span style="font-size:10.5px; opacity:0.8;">By: ${escapeHtml(d.reporterEmail || d.reporterUid)}</span>
                    </div>`;
                }).join("");
        }

        const fSnap = await db.collection("feedbacks").limit(15).get();
        const fBox = document.getElementById("adminFeedbacksListBox");
        if (fBox) {
            fBox.innerHTML = fSnap.empty
                ? `<div style="color:#64748b; padding:8px;">No feedbacks yet.</div>`
                : fSnap.docs.map(doc => {
                    const d = doc.data();
                    return `<div style="padding:8px 10px; border-radius:10px; background:#eff6ff; border:1px solid #bfdbfe; color:#1e3a8a;">
                        <strong>${escapeHtml(d.name || d.email || "User")}:</strong> ${escapeHtml(d.feedback)}
                    </div>`;
                }).join("");
        }
    } catch (e) {}
}

async function saveNewGeminiApiKeyToFirebase() {
    const newKey = (document.getElementById("adminGeminiKeyInput")?.value || "").trim();
    if (!newKey) {
        showCustomAlert("Key Required", "Please paste a valid Gemini API key.");
        return;
    }
    GEMINI_API_KEY = newKey;
    localStorage.setItem("zorenoCloudApiKey", newKey);
    try {
        if (!db) await initFirebase();
        await db.collection("appConfig").doc("aiSettings").set({
            geminiApiKey: newKey,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        }, { merge: true });
        showCustomAlert("API Key Updated Live! ✅", "Your new Gemini API key is now saved in Firebase and active for all users!", true);
    } catch (e) {
        showCustomAlert("Saved Locally", "API key saved on this device.");
    }
}

window.addEventListener("DOMContentLoaded", () => {
    setTimeout(() => {
        setupSecretAdminPanelTrigger();
        syncDynamicGeminiApiKeyFromFirebase();
        applyOfficialCrownBrandingToDOM();
    }, 450);
});

// =========================================================
// ZORENO V9 FINAL PATCH: INFINITE LOOP CRASH FIX, BOLD AI TYPOGRAPHY,
// IMAGE-CARD + LINK NATIVE SHARE, GROUPS TAB & STEP-BY-STEP BACK
// =========================================================

// 1. KILL THE INFINITE RECURSION LOOP IN V7 (Fixes Profile, Clear Chat, Block, Share & Forgot Pass!)
let _zorenoV7InitLock = false;
const _rawInitZorenoV7 = window.initZorenoV7LaunchSystem;

window.initZorenoV7LaunchSystem = function () {
    if (_zorenoV7InitLock) return;
    _zorenoV7InitLock = true;
    try {
        if (typeof _rawInitZorenoV7 === "function") {
            _rawInitZorenoV7();
        }
        const modalWrap = document.getElementById("zorenoV7ModalsContainer");
        if (modalWrap && modalWrap.parentElement !== document.body) {
            document.body.appendChild(modalWrap);
        }
        document.querySelectorAll(".custom-modal-overlay").forEach(m => {
            m.style.setProperty("z-index", "2147483647", "important");
        });
    } catch (err) {
        console.error("V7 Init Error:", err);
    }
};

window.updateAiQuotaHeaderBadge = function () {
    if (!_zorenoV7InitLock) window.initZorenoV7LaunchSystem();
    const badge = document.getElementById("aiLiveQuotaBadge");
    if (!badge) return;
    const usedToday = getLocalDailyAiCount();
    const todayLimit = userTier === 2 ? 90 : userTier === 1 ? 50 : getLocalDailyAiLimit();
    const remaining = Math.max(0, todayLimit - usedToday);
    badge.innerHTML = `⚡ ${remaining}/${todayLimit} Left`;
    badge.style.background = remaining === 0 ? "rgba(239, 68, 68, 0.14)" : "rgba(124, 58, 237, 0.12)";
    badge.style.color = remaining === 0 ? "#ef4444" : "#7c3aed";
};

// 2. Inject Crisp Bold AI Font & Extra-Bold Highlights CSS (32483 & 32269_2 Fix)
(function injectZorenoCrispTypographyCSS() {
    if (document.getElementById("zorenoV9TypographyStyle")) return;
    const st = document.createElement("style");
    st.id = "zorenoV9TypographyStyle";
    st.textContent = `
        /* Normal AI Text: Crisp, Darker & Medium-Bold (No More Thin Faded Text) */
        #chatMessages .clean-left-bubble,
        #chatMessages .ai-formatted-body p,
        #chatMessages .ai-step-text p,
        #chatMessages .ai-compact-list li {
            font-size: 14.6px !important;
            font-weight: 600 !important;
            color: #0f172a !important;
            line-height: 1.54 !important;
            letter-spacing: -0.1px !important;
        }
        body.dark-mode #chatMessages .clean-left-bubble,
        body.dark-mode #chatMessages .ai-formatted-body p,
        body.dark-mode #chatMessages .ai-step-text p,
        body.dark-mode #chatMessages .ai-compact-list li {
            color: #f8fafc !important;
        }

        /* Bold / Highlighted Words: Extra-Bold & Vibrant Pill Highlight */
        #chatMessages .clean-left-bubble strong,
        #chatMessages .ai-step-text p strong {
            font-weight: 800 !important;
            font-size: 15px !important;
            color: #4c1d95 !important;
            background: linear-gradient(135deg, rgba(124, 58, 237, 0.18), rgba(59, 130, 246, 0.15)) !important;
            border: 1px solid rgba(124, 58, 237, 0.28) !important;
            padding: 1.5px 7px !important;
            border-radius: 7px !important;
        }
        body.dark-mode #chatMessages .clean-left-bubble strong,
        body.dark-mode #chatMessages .ai-step-text p strong {
            color: #f3e8ff !important;
            background: rgba(168, 85, 247, 0.32) !important;
            border-color: rgba(192, 132, 252, 0.45) !important;
        }

        /* Step Headings & Math Box Extra Bold */
        #chatMessages .ai-step-text h5 {
            font-size: 15.8px !important;
            font-weight: 800 !important;
            color: #090d16 !important;
            margin-bottom: 4px !important;
        }
        body.dark-mode #chatMessages .ai-step-text h5 {
            color: #ffffff !important;
        }
        #chatMessages .ai-math-box {
            font-size: 14.5px !important;
            font-weight: 800 !important;
            color: #1e1b4b !important;
            background: linear-gradient(135deg, #f5f3ff, #ede9fe) !important;
            border-left: 4px solid #6d28d9 !important;
        }
        body.dark-mode #chatMessages .ai-math-box {
            color: #f5f3ff !important;
            background: #1e1b4b !important;
        }

        /* Keep Friend Profile & All Popups Above Active Chat Screen */
        #friendProfileScreen.friend-profile-screen { z-index: 1000005 !important; }
        .custom-modal-overlay { z-index: 2147483647 !important; }
        .chat-win-footer.blocked-hidden-footer { display: none !important; }
        .media-only-bubble .official-bubble-top-title { display: none !important; }
    `;
    document.head.appendChild(st);
})();

// 3. Fix Groups Tab & Home Tabs Switching
function bindHomeTabsDirectly() {
    const tabBtns = document.querySelectorAll(".chat-tabs .tab-btn");
    const tabKeys = ["all", "unread", "friends", "groups"];
    tabBtns.forEach((btn, idx) => {
        btn.onclick = () => {
            tabBtns.forEach(b => b.classList.remove("active"));
            btn.classList.add("active");
            currentActiveChatTab = tabKeys[idx] || "all";
            renderSavedDmChatsOnHome();
            filterHomeChatListByTab(currentActiveChatTab);
        };
    });
}

filterHomeChatListByTab = function (tabKey) {
    currentActiveChatTab = tabKey || "all";
    const groupBar = document.querySelector(".group-top-Controls");
    if (groupBar) {
        groupBar.style.setProperty("display", currentActiveChatTab === "groups" ? "flex" : "none", "important");
    }
    document.querySelectorAll(".friend-req-top-box").forEach(box => {
        box.style.display = (currentActiveChatTab === "all" || currentActiveChatTab === "friends") ? "flex" : "none";
    });
    document.querySelectorAll(".chats-container .chat-list-item").forEach(item => {
        if (item.closest(".group-top-Controls") || item.closest(".friend-req-top-box")) {
            item.style.display = "flex";
            return;
        }
        if (item.classList.contains("pinned") && !item.classList.contains("dynamic-dm-item")) {
            item.style.display = currentActiveChatTab === "all" ? "flex" : "none";
            return;
        }
        const isGroup = item.classList.contains("group-chat-item") || item.querySelector(".group-avatar") !== null;
        const unreadBadge = item.querySelector(".unread-count");
        const hasUnread = unreadBadge !== null && parseInt(unreadBadge.textContent || "0") > 0;
        if (currentActiveChatTab === "all") item.style.display = "flex";
        else if (currentActiveChatTab === "unread") item.style.display = hasUnread ? "flex" : "none";
        else if (currentActiveChatTab === "friends") item.style.display = !isGroup ? "flex" : "none";
        else if (currentActiveChatTab === "groups") item.style.display = isGroup ? "flex" : "none";
    });
};

// 4. Open Zoreno AI Profile & Friend Profile Reliably
function openZorenoAiProfileView() {
    closeAllDropdownMenus();
    pushScreenState("aiProfile");
    currentChatIsGroup = false;
    currentChatUserMeta = {
        uid: "zoreno_ai_official",
        name: "Zoreno AI",
        username: "@zoreno_ai",
        avatar: "logo.png",
        bio: "Official AI Study Partner & Daily Assistant created by Achyut Tiwari under Toko Platforms.",
        isOnline: true,
        lastActiveAtMs: Date.now(),
        lastSeenLabel: "Online"
    };
    const fpScreen = document.getElementById("friendProfileScreen");
    if (!fpScreen) return;
    fpScreen.querySelectorAll(".fp-info-card").forEach(el => el.style.removeProperty("display"));
    const grpBox = document.getElementById("zorenoGroupMembersContainer");
    if (grpBox) grpBox.style.display = "none";
    const actGrid = fpScreen.querySelector(".fp-actions-grid");
    if (actGrid) actGrid.style.setProperty("display", "none", "important");

    syncFriendProfileViewDOM();
    const fpName = document.getElementById("fpFullName");
    if (fpName) fpName.innerHTML = `Zoreno AI ${getOfficialCrownTagHTML()}`;
    fpScreen.style.setProperty("z-index", "1000005", "important");
    fpScreen.style.setProperty("display", "block", "important");
}

const _v9SafeOpenFriendProfile = openFriendProfileScreen;
openFriendProfileScreen = function () {
    pushScreenState("friendProfile");
    const fpScreen = document.getElementById("friendProfileScreen");
    if (fpScreen) {
        const actGrid = fpScreen.querySelector(".fp-actions-grid");
        if (actGrid && !currentChatIsGroup) actGrid.style.setProperty("display", "grid", "important");
        fpScreen.style.setProperty("z-index", "1000005", "important");
    }
    _v9SafeOpenFriendProfile();
};

// 5. Generate Branded Image Card of Chat Answer + Share Link via Native All-Apps Sheet
async function createZorenoAnswerImageCard(questionText, answerText) {
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    const width = 900;
    const cleanAns = answerText.replace(/\*\*/g, "").trim();

    ctx.font = "600 26px sans-serif";
    const maxLineWidth = width - 110;
    const rawLines = cleanAns.split("\n");
    const wrappedLines = [];

    rawLines.forEach(para => {
        const words = para.trim().split(/\s+/);
        let currentLine = "";
        words.forEach(w => {
            const testLine = currentLine ? currentLine + " " + w : w;
            if (ctx.measureText(testLine).width > maxLineWidth) {
                if (currentLine) wrappedLines.push(currentLine);
                currentLine = w;
            } else {
                currentLine = testLine;
            }
        });
        if (currentLine) wrappedLines.push(currentLine);
    });

    const displayLines = wrappedLines.slice(0, 18);
    if (wrappedLines.length > 18) displayLines.push("... (Read full answer on Zoreno App)");

    const cardHeight = Math.max(540, 270 + displayLines.length * 40 + 120);
    canvas.width = width;
    canvas.height = cardHeight;

    // Background Gradient
    const bgGrad = ctx.createLinearGradient(0, 0, width, cardHeight);
    bgGrad.addColorStop(0, "#1e1b4b");
    bgGrad.addColorStop(0.5, "#311068");
    bgGrad.addColorStop(1, "#0f172a");
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, width, cardHeight);

    // White Inner Answer Card
    ctx.fillStyle = "#ffffff";
    ctx.beginPath();
    ctx.roundRect(36, 36, width - 72, cardHeight - 72, 32);
    ctx.fill();

    // Top Brand Header
    ctx.fillStyle = "#6d28d9";
    ctx.font = "800 32px sans-serif";
    ctx.fillText("✦ ZORENO AI • OFFICIAL", 72, 98);

    if (questionText) {
        ctx.fillStyle = "#475569";
        ctx.font = "700 22px sans-serif";
        const qShort = questionText.length > 55 ? questionText.slice(0, 55) + "..." : questionText;
        ctx.fillText("Q: " + qShort, 72, 140);
    }

    // Divider
    ctx.strokeStyle = "#e2e8f0";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(72, 165);
    ctx.lineTo(width - 72, 165);
    ctx.stroke();

    // Answer Lines
    ctx.fillStyle = "#0f172a";
    ctx.font = "600 25px sans-serif";
    let y = 215;
    displayLines.forEach(line => {
        ctx.fillText(line, 72, y);
        y += 38;
    });

    // Bottom Download Banner
    const footerY = cardHeight - 125;
    const footGrad = ctx.createLinearGradient(60, footerY, width - 60, footerY + 64);
    footGrad.addColorStop(0, "#2563eb");
    footGrad.addColorStop(1, "#7c3aed");
    ctx.fillStyle = footGrad;
    ctx.beginPath();
    ctx.roundRect(64, footerY, width - 128, 66, 20);
    ctx.fill();

    ctx.fillStyle = "#ffffff";
    ctx.font = "800 23px sans-serif";
    ctx.fillText("🚀 Download Zoreno App on Google Play Store", 95, footerY + 41);

    return canvas.toDataURL("image/png");
}

shareAiResponseText = async function (idx) {
    const pair = aiChatMessagesList[idx];
    const rawBot = cleanLatexToNotebookMath(pair?.bot || "");
    if (!rawBot) return;
    const cleanAnswer = rawBot.replace(/\*\*/g, "").trim();
    const playUrl = "https://play.google.com/store/apps/details?id=com.zoreno.app";
    const shareCaption = `✨ *Answered by Zoreno AI:*\n\n${cleanAnswer}\n\n🚀 *Download Zoreno on Google Play Store:*\n${playUrl}`;

    try {
        const dataUrl = await createZorenoAnswerImageCard(pair?.user || "", cleanAnswer);

        // 1. Native Android Image + Link Share Chooser (Opens Real System All-Apps Sheet with Image!)
        if (window.AndroidShare && typeof window.AndroidShare.shareImageAndText === "function") {
            window.AndroidShare.shareImageAndText(dataUrl, shareCaption);
            return;
        }

        // 2. Web Share API Level 2 (Image File + Text + Link)
        if (navigator.canShare && navigator.share) {
            const res = await fetch(dataUrl);
            const blob = await res.blob();
            const imageFile = new File([blob], "Zoreno_AI_Answer.png", { type: "image/png" });
            if (navigator.canShare({ files: [imageFile] })) {
                await navigator.share({
                    title: "Zoreno AI Answer",
                    text: shareCaption,
                    files: [imageFile]
                });
                return;
            }
        }
    } catch (err) {
        console.warn("Image share fallback:", err);
    }

    // 3. Fallback Native Text Share Chooser
    if (window.AndroidShare && typeof window.AndroidShare.shareText === "function") {
        window.AndroidShare.shareText(shareCaption);
        return;
    }
    if (navigator.share) {
        try {
            await navigator.share({ title: "Zoreno AI", text: shareCaption, url: playUrl });
            return;
        } catch (e) {}
    }
};

// 6. Long-Press Delete on AI Bubbles + Clean Official Sent Photos + Step-by-Step Back
function setupAiInteractionsAndLongPress() {
    const aiHeaderMeta = document.querySelector("#chatScreen .ai-topbar-user-meta");
    if (aiHeaderMeta) {
        aiHeaderMeta.style.cursor = "pointer";
        aiHeaderMeta.onclick = () => openZorenoAiProfileView();
    }
    document.querySelectorAll("#chatMessages .ai-logo-avatar").forEach(img => {
        img.style.cursor = "pointer";
        img.onclick = (e) => { e.stopPropagation(); openZorenoAiProfileView(); };
    });
    document.querySelectorAll("#chatMessages [onclick*='promptDeleteSingleAiMessage']").forEach(bubble => {
        const rawAttr = bubble.getAttribute("onclick") || "";
        const m = rawAttr.match(/promptDeleteSingleAiMessage\((\d+)\)/);
        bubble.removeAttribute("onclick");
        if (!m) return;
        const msgIdx = parseInt(m[1], 10);
        let pressTimer = null;
        bubble.addEventListener("touchstart", (e) => {
            if (e.target.closest("button, a, img.sent-wide-photo, .ai-action-btns-wrap")) return;
            pressTimer = setTimeout(() => { promptDeleteSingleAiMessage(msgIdx); }, 600);
        }, { passive: true });
        bubble.addEventListener("touchend", () => clearTimeout(pressTimer));
        bubble.addEventListener("touchmove", () => clearTimeout(pressTimer));
    });
}

const _v9OrigRenderAi = renderAiChatStream;
renderAiChatStream = function () {
    _v9OrigRenderAi();
    setupAiInteractionsAndLongPress();
};

window.handleZorenoHardwareBack = function () {
    closeAllDropdownMenus();
    const openModals = Array.from(document.querySelectorAll(".custom-modal-overlay")).filter(
        m => window.getComputedStyle(m).display !== "none"
    );
    if (openModals.length > 0) {
        openModals.forEach(m => { m.style.display = "none"; });
        return true;
    }
    const fpScreen = document.getElementById("friendProfileScreen");
    if (fpScreen && window.getComputedStyle(fpScreen).display !== "none") {
        closeFriendProfileScreen();
        return true;
    }
    const dmScreen = document.getElementById("activeChatScreen");
    if (dmScreen && window.getComputedStyle(dmScreen).display !== "none") {
        closeActiveDmChat();
        return true;
    }
    const aiScreen = document.getElementById("chatScreen");
    const profScreen = document.getElementById("profileScreen");
    const searchScreen = document.getElementById("webSearchScreen");
    if ((aiScreen && window.getComputedStyle(aiScreen).display !== "none") ||
        (profScreen && window.getComputedStyle(profScreen).display !== "none") ||
        (searchScreen && window.getComputedStyle(searchScreen).display !== "none")) {
        goHome();
        return true;
    }
    const subScreen = document.getElementById("subScreen");
    const toolsScreen = document.getElementById("toolsScreen");
    const settingsScreen = document.getElementById("settingsScreen");
    if ((subScreen && window.getComputedStyle(subScreen).display !== "none") ||
        (toolsScreen && window.getComputedStyle(toolsScreen).display !== "none") ||
        (settingsScreen && window.getComputedStyle(settingsScreen).display !== "none")) {
        showChatsHome();
        return true;
    }
    if (currentActiveChatTab !== "all") {
        const allBtn = document.querySelector(".chat-tabs .tab-btn");
        if (allBtn) allBtn.click();
        return true;
    }
    return false;
};

window.addEventListener("DOMContentLoaded", () => {
    setTimeout(() => {
        window.initZorenoV7LaunchSystem();
        bindHomeTabsDirectly();
        setupAiInteractionsAndLongPress();
    }, 300);
});

// =========================================================
// ZORENO V10 MASTER FEATURES:
// 1. STRICT OFFICIAL ACCOUNT CHECK (ONLY @zoreno & @zoreno_ai)
// 2. HALF-SCREEN SMOOTH EXPANDABLE INPUT BOX (32546/32547)
// 3. PROFESSIONAL GROUP MODAL (32553), GROUP DP UPLOAD & MAKE ADMIN
// 4. PLAY STORE IN-APP UPDATE MODAL (FORCE & NORMAL) + PROMO NOTIFICATIONS
// =========================================================

const CURRENT_APP_VERSION_CODE = 7;
const CURRENT_APP_VERSION_NAME = "1.0.6";

// 1. Strict Official Account Verification (Fake "zoreno" names like @zoreno_8693 NEVER get Official badge!)
isOfficialZorenoAccount = function (nameStr, usernameStr) {
    const cleanU = String(usernameStr || "").trim().toLowerCase().replace(/^@/, "");
    if (cleanU) {
        return cleanU === "zoreno" || cleanU === "zoreno_ai";
    }
    const cleanN = String(nameStr || "").trim().toLowerCase();
    return cleanN === "zoreno ai";
};

getOfficialCrownTagHTML = function () {
    return `<span class="official-crown-pill-tag"><i class="fa-solid fa-crown"></i> Official</span>`;
};

// 2. Half-Screen Smooth Auto-Expanding Input Box (Matches 32546 & 32547)
autoResizeChatInput = function (el) {
    if (!el) return;
    el.style.height = "auto";
    const maxAllowedHeight = Math.floor(window.innerHeight * 0.42); // Grows up to ~half screen!
    const nextHeight = Math.min(maxAllowedHeight, Math.max(26, el.scrollHeight));
    el.style.height = nextHeight + "px";

    const pill = el.closest(".chat-input-pill");
    if (pill) {
        pill.classList.toggle("expanded-multiline", nextHeight > 42);
    }
};

// 3. Clean Single-Line Create Study Group Modal (32553 Fix)
openCreateGroupModal = function () {
    let modal = document.getElementById("zorenoCreateGroupModal");
    if (!modal) {
        modal = document.createElement("div");
        modal.id = "zorenoCreateGroupModal";
        modal.className = "custom-modal-overlay";
        document.body.appendChild(modal);
    }
    modal.style.setProperty("z-index", "2147483647", "important");

    const acceptedFriendsList = recentDmUsers.filter(f => myFriendsMap[f.uid] === true);

    const friendsHtml = acceptedFriendsList.length === 0
        ? `<div style="padding:14px; border-radius:16px; background:rgba(245,158,11,0.12); border:1px solid rgba(245,158,11,0.3); color:#b45309; font-size:12.5px; font-weight:700; text-align:center; line-height:1.5;">
               <i class="fa-solid fa-user-check" style="margin-right:4px;"></i> You have no accepted friends yet.<br>Open any user's profile and tap <strong>"Make Friend"</strong>—once they accept, you can add them here!
           </div>`
        : acceptedFriendsList.map(f => `
            <label style="display:flex; align-items:center; justify-content:space-between; padding:9px 12px; border-radius:14px; border:1.5px solid #e2e8f0; margin-bottom:7px; cursor:pointer;">
                <div style="display:flex; align-items:center; gap:10px;">
                    <img src="${escapeHtml(getSafeAvatar(f.avatar))}" onerror="this.src='logo.png'" style="width:36px; height:36px; border-radius:50%; object-fit:cover;">
                    <div style="text-align:left;">
                        <div style="font-size:14px; font-weight:800;">${escapeHtml(f.name)}</div>
                        <div style="font-size:11.5px; color:#10b981; font-weight:700;">✓ Friend • ${escapeHtml(f.username)}</div>
                    </div>
                </div>
                <input type="checkbox" class="grp-invite-chk" value="${escapeHtml(f.uid)}" style="width:18px; height:18px; accent-color:#7c3aed;">
            </label>
        `).join("");

    modal.innerHTML = `
        <div class="custom-modal-box" style="max-width:380px;">
            <div class="policy-modal-header">
                <h3><i class="fa-solid fa-users" style="color:#7c3aed;"></i> Create Study Group</h3>
                <button type="button" class="modal-close-btn" onclick="document.getElementById('zorenoCreateGroupModal').style.display='none'"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <input type="text" id="newStudyGroupName" placeholder="Enter Group Name (e.g. Science Batch)" style="width:100%; padding:13px 14px; border-radius:14px; border:1.5px solid #cbd5e1; outline:none; margin-bottom:14px; font-weight:700; font-size:14px;">
            <div style="font-size:11.5px; font-weight:800; color:#64748b; margin-bottom:8px; text-align:left; letter-spacing:0.4px;">INVITE YOUR ACCEPTED FRIENDS:</div>
            <div style="max-height:190px; overflow-y:auto; margin-bottom:16px;">${friendsHtml}</div>
            <button type="button" class="modal-submit-btn" style="display:flex; align-items:center; justify-content:center; gap:8px; font-size:14.5px; font-weight:800;" onclick="submitCreateStudyGroup()">
                <span>Create Group & Send Invites</span>
                <i class="fa-solid fa-paper-plane"></i>
            </button>
        </div>
    `;
    modal.style.display = "flex";
};

// 4. Group DP Upload & Multi-Admin ("Make Admin") Controls Inside Group Profile
function triggerGroupDpUpload() {
    if (!currentChatIsGroup || !currentActiveGroupData) return;
    let fileInp = document.getElementById("zorenoGroupDpInput");
    if (!fileInp) {
        fileInp = document.createElement("input");
        fileInp.type = "file";
        fileInp.id = "zorenoGroupDpInput";
        fileInp.accept = "image/*";
        fileInp.style.display = "none";
        fileInp.onchange = handleGroupDpFileSelected;
        document.body.appendChild(fileInp);
    }
    fileInp.click();
}

function handleGroupDpFileSelected(event) {
    const file = event.target.files?.[0];
    if (!file || !currentActiveGroupData || !db) return;
    event.target.value = "";

    const reader = new FileReader();
    reader.onload = function (e) {
        const img = new Image();
        img.onload = async function () {
            const canvas = document.createElement("canvas");
            const MAX_S = 220;
            let w = img.width, h = img.height;
            if (w > h && w > MAX_S) { h = Math.round((h * MAX_S) / w); w = MAX_S; }
            else if (h >= w && h > MAX_S) { w = Math.round((w * MAX_S) / h); h = MAX_S; }
            canvas.width = w;
            canvas.height = h;
            canvas.getContext("2d").drawImage(img, 0, 0, w, h);
            const base64Dp = canvas.toDataURL("image/jpeg", 0.72);

            try {
                await db.collection("groups").doc(currentActiveGroupData.id).set({
                    photoURL: base64Dp
                }, { merge: true });
                document.getElementById("fpAvatarImg").src = base64Dp;
                document.getElementById("activeChatAvatar").src = base64Dp;
                showCustomAlert("Group Photo Updated! 📸", "New group DP has been saved for all members.", true);
            } catch (err) {
                showCustomAlert("Error", err.message);
            }
        };
        img.src = e.target.result;
    };
    reader.readAsDataURL(file);
}

async function promoteMemberToGroupAdmin(targetUid, targetName, event) {
    if (event) event.stopPropagation();
    if (!db || !currentActiveGroupData || !targetUid) return;
    try {
        await db.collection("groups").doc(currentActiveGroupData.id).update({
            admins: firebase.firestore.FieldValue.arrayUnion(targetUid)
        });
        showCustomAlert("New Admin Added! 👑", `${targetName} is now a Group Admin.`, true);
    } catch (e) {
        showCustomAlert("Error", e.message);
    }
}

renderGroupMembersInsideProfile = async function (grp) {
    const grpBox = document.getElementById("zorenoGroupMembersContainer");
    if (!grpBox || !grp) return;

    const myUid = auth?.currentUser?.uid || "";
    const memberUids = grp.members || [];
    const adminsList = Array.isArray(grp.admins) ? grp.admins : (grp.adminUid ? [grp.adminUid] : []);
    const amIGroupAdmin = adminsList.includes(myUid) || grp.adminUid === myUid;
    const memCount = memberUids.length;

    const fpAvatar = document.getElementById("fpAvatarImg");
    if (fpAvatar) {
        fpAvatar.src = getSafeAvatar(grp.photoURL || "logo.png");
        fpAvatar.parentElement.style.cursor = "pointer";
        fpAvatar.parentElement.title = "Tap to change Group Photo";
        fpAvatar.parentElement.onclick = () => triggerGroupDpUpload();
    }

    const fName = document.getElementById("fpFullName");
    const uSub = document.getElementById("fpUsernameSub");
    const pillTxt = document.getElementById("fpPillText");
    if (fName) fName.textContent = grp.name || "Study Group";
    if (uSub) uSub.innerHTML = `<span style="color:#7c3aed; cursor:pointer; font-weight:800;" onclick="triggerGroupDpUpload()"><i class="fa-solid fa-camera"></i> Change Group Photo</span> • ${memCount} Members`;
    if (pillTxt) pillTxt.textContent = "Active Study Group";

    grpBox.innerHTML = `<div style="text-align:center; padding:18px; color:#7c3aed; font-weight:700;"><i class="fa-solid fa-spinner fa-spin"></i> Loading group members...</div>`;

    const memberProfiles = [];
    for (const uid of memberUids) {
        const isThisMemberAdmin = adminsList.includes(uid) || grp.adminUid === uid;
        if (uid === myUid) {
            memberProfiles.push({
                uid: myUid,
                name: userName || "You",
                username: currentUsername || "@student",
                avatar: getSafeAvatar(userAvatarUrl),
                userTier: userTier,
                isAdmin: isThisMemberAdmin,
                isMe: true
            });
            continue;
        }
        let cached = userProfileCache[uid];
        if (!cached && db) {
            try {
                const uDoc = await db.collection("users").doc(uid).get();
                if (uDoc.exists) { cached = uDoc.data(); userProfileCache[uid] = cached; }
            } catch (e) {}
        }
        memberProfiles.push({
            uid: uid,
            name: cached?.name || "Student",
            username: cached?.username || "@student",
            avatar: getSafeAvatar(cached?.photoURL || cached?.avatarUrl),
            userTier: cached?.userTier || 0,
            isAdmin: isThisMemberAdmin,
            isMe: false
        });
    }

    const membersListHtml = memberProfiles.map(m => {
        const isOff = isOfficialZorenoAccount(m.name, m.username);
        const badgeHtml = isOff ? getOfficialCrownTagHTML() : (typeof getSubscriptionBadgeHTML === "function" ? getSubscriptionBadgeHTML(m.userTier) : "");
        const adminPill = m.isAdmin
            ? `<span style="background:#ede9fe; color:#7c3aed; font-size:10px; font-weight:800; padding:2px 7px; border-radius:8px;">👑 Admin</span>`
            : "";
        const makeAdminBtn = (amIGroupAdmin && !m.isAdmin && !m.isMe)
            ? `<button type="button" onclick="promoteMemberToGroupAdmin('${escapeHtml(m.uid)}', '${escapeHtml(m.name)}', event)" style="background:#fef3c7; color:#b45309; border:1px solid #fde68a; padding:6px 10px; border-radius:12px; font-size:11px; font-weight:800; cursor:pointer;">👑 Make Admin</button>`
            : "";

        return `
            <div class="fp-info-card" style="justify-content:space-between; margin-bottom:10px;">
                <div style="display:flex; align-items:center; gap:12px; min-width:0; flex:1; cursor:${m.isMe ? 'default' : 'pointer'};" ${m.isMe ? '' : `onclick="startDirectChatFromGroupMember('${escapeHtml(m.uid)}', '${escapeHtml(m.name)}', '${escapeHtml(m.avatar)}', '${escapeHtml(m.username)}')"`}>
                    <img src="${escapeHtml(m.avatar)}" onerror="this.src='logo.png'" style="width:44px; height:44px; border-radius:50%; object-fit:cover; flex-shrink:0;">
                    <div style="min-width:0; flex:1;">
                        <h4 style="margin:0; font-size:14.5px; font-weight:800; display:flex; align-items:center; flex-wrap:wrap; gap:4px;">
                            ${escapeHtml(m.name)} ${m.isMe ? "(You)" : ""} ${badgeHtml} ${adminPill}
                        </h4>
                        <span style="font-size:12px; color:#7c3aed; font-weight:700;">${escapeHtml(m.username)}</span>
                    </div>
                </div>
                <div style="display:flex; align-items:center; gap:6px; flex-shrink:0;">
                    ${makeAdminBtn}
                    ${!m.isMe ? `
                    <button type="button" onclick="startDirectChatFromGroupMember('${escapeHtml(m.uid)}', '${escapeHtml(m.name)}', '${escapeHtml(m.avatar)}', '${escapeHtml(m.username)}')" style="background:linear-gradient(135deg,#2563eb,#7c3aed); color:#fff; border:none; padding:7px 11px; border-radius:12px; font-size:11.5px; font-weight:800; cursor:pointer;">
                        <i class="fa-regular fa-comment-dots"></i>
                    </button>` : ""}
                </div>
            </div>
        `;
    }).join("");

    grpBox.innerHTML = `
        <div style="display:flex; align-items:center; justify-content:space-between; margin:10px 4px 10px;">
            <span style="font-size:12px; font-weight:800; color:#64748b; text-transform:uppercase;">Group Members (${memCount})</span>
            <div style="display:flex; gap:6px;">
                <button type="button" onclick="triggerGroupDpUpload()" style="border:none; background:rgba(37,99,235,0.12); color:#2563eb; padding:6px 10px; border-radius:12px; font-size:11.5px; font-weight:800; cursor:pointer;">
                    📷 Change DP
                </button>
                <button type="button" onclick="openInviteMoreFriendsToGroupModal()" style="border:none; background:rgba(124,58,237,0.12); color:#7c3aed; padding:6px 10px; border-radius:12px; font-size:11.5px; font-weight:800; cursor:pointer;">
                    + Invite Friends
                </button>
            </div>
        </div>
        ${membersListHtml}
    `;
};

// 5. Play Store Style In-App Update System (Force Blocking Update & Optional Update) + Promotional Notifications
function listenAppUpdatesAndPromoNotifications() {
    if (!db) return;

    // A. Check Live Version Update from Firebase "appConfig/versionControl"
    db.collection("appConfig").doc("versionControl").onSnapshot(doc => {
        if (!doc.exists) return;
        const data = doc.data() || {};
        const latestCode = parseInt(data.latestVersionCode) || CURRENT_APP_VERSION_CODE;
        const minRequiredCode = parseInt(data.minRequiredVersionCode) || CURRENT_APP_VERSION_CODE;
        const isForceUpdate = data.forceUpdate === true || CURRENT_APP_VERSION_CODE < minRequiredCode;

        if (CURRENT_APP_VERSION_CODE < latestCode) {
            showPlayStoreStyleUpdateModal(
                data.latestVersionName || "New Update",
                data.releaseNotes || "New modern UI, faster AI voice, study groups & performance improvements!",
                data.storeUrl || "https://play.google.com/store/apps/details?id=com.zoreno.app",
                isForceUpdate
            );
        }
    });

    // B. Listen for Promotional Broadcast Notifications from Firebase "appConfig/promoBroadcast"
    db.collection("appConfig").doc("promoBroadcast").onSnapshot(doc => {
        if (!doc.exists) return;
        const p = doc.data() || {};
        const promoId = String(p.id || p.timestampMs || "");
        if (!promoId || localStorage.getItem("zorenoLastPromoId") === promoId) return;

        localStorage.setItem("zorenoLastPromoId", promoId);
        const title = p.title || "✨ Zoreno Special Update!";
        const body = p.message || "Check out new study features and AI tools in Zoreno!";

        if (window.AndroidNotif && typeof window.AndroidNotif.showNotification === "function") {
            window.AndroidNotif.showNotification(title, body);
        }
        showZorenoIncomingNotification("zoreno_ai_official", title, "logo.png", "@zoreno_ai", body);
    });
}

function showPlayStoreStyleUpdateModal(verName, notes, storeUrl, isForceBlocking) {
    let modal = document.getElementById("zorenoPlayUpdateModal");
    if (!modal) {
        modal = document.createElement("div");
        modal.id = "zorenoPlayUpdateModal";
        modal.className = "custom-modal-overlay";
        document.body.appendChild(modal);
    }
    modal.style.setProperty("z-index", "2147483647", "important");

    modal.innerHTML = `
        <div class="custom-modal-box" style="max-width:360px; text-align:left; border-radius:26px; padding:22px;">
            <div style="display:flex; align-items:center; gap:12px; margin-bottom:14px;">
                <img src="logo.png" onerror="this.src='default_avatar.png'" style="width:52px; height:52px; border-radius:14px; object-fit:cover; box-shadow:0 6px 16px rgba(124,58,237,0.25);">
                <div>
                    <span style="font-size:11px; font-weight:800; color:#10b981; text-transform:uppercase; letter-spacing:0.5px;">
                        <i class="fa-brands fa-google-play"></i> Google Play Update
                    </span>
                    <h3 style="margin:2px 0 0; font-size:18px; font-weight:800;">Update Zoreno (${escapeHtml(verName)})</h3>
                </div>
            </div>
            <p style="font-size:13.5px; color:#475569; line-height:1.5; margin-bottom:12px;">
                ${isForceBlocking
                    ? "<strong>Required Update:</strong> A major update with new UI and essential security fixes is available. Please update Zoreno to continue using the app."
                    : "A new version of Zoreno is available on Google Play Store with smoother performance."}
            </p>
            <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:14px; padding:10px 12px; margin-bottom:18px; font-size:12.5px; color:#334155; font-weight:600;">
                <strong>What's New:</strong><br>${escapeHtml(notes)}
            </div>
            <div style="display:flex; gap:10px;">
                ${!isForceBlocking ? `
                <button type="button" class="modal-submit-btn" style="background:#e2e8f0; color:#0f172a;" onclick="document.getElementById('zorenoPlayUpdateModal').style.display='none'">
                    Later
                </button>` : ""}
                <button type="button" class="modal-submit-btn" style="background:linear-gradient(135deg,#059669,#10b981); font-weight:800;" onclick="window.open('${escapeHtml(storeUrl)}', '_blank')">
                    Update Now ↗
                </button>
            </div>
        </div>
    `;
    modal.style.display = "flex";
}

window.addEventListener("DOMContentLoaded", () => {
    setTimeout(async () => {
        await initFirebase();
        listenAppUpdatesAndPromoNotifications();
    }, 900);
});

// =========================================================
// ZORENO V11 MASTER FIX:
// 1. GEMINI-STYLE INLINE IMAGE PREVIEW INSIDE INPUT PILL (AI & DM)
// 2. FULL IMAGE MODAL BACK BUTTON & AUTO-CLOSE AFTER DOWNLOAD (32558 FIX)
// =========================================================

// 1. Setup Gemini-Style Inline Image Container Inside Both AI & DM Input Pills
function ensureGeminiInlineInputStructure() {
    const configs = [
        { footerSelector: "#inputAreaContainer", rowId: "geminiAiInlineImgRow" },
        { footerSelector: "#activeChatScreen .chat-win-footer", rowId: "geminiDmInlineImgRow" }
    ];

    configs.forEach(cfg => {
        const pill = document.querySelector(`${cfg.footerSelector} .chat-input-pill`);
        if (!pill || document.getElementById(cfg.rowId)) return;

        // Create top image row inside the input pill
        const imgRow = document.createElement("div");
        imgRow.id = cfg.rowId;
        imgRow.className = "gemini-inline-img-row";

        // Wrap existing textarea + icons into bottom row
        const bottomRow = document.createElement("div");
        bottomRow.className = "gemini-input-bottom-row";
        while (pill.firstChild) {
            bottomRow.appendChild(pill.firstChild);
        }

        pill.appendChild(imgRow);
        pill.appendChild(bottomRow);
    });
}

// 2. Render AI Selected Images Directly Inside AI Input Container (32556 & 32557 Match)
renderAiAttachmentPreviewStrip = function () {
    ensureGeminiInlineInputStructure();
    const oldStrip = document.getElementById("aiAttachmentPreviewBar");
    if (oldStrip) oldStrip.style.setProperty("display", "none", "important");

    const inlineRow = document.getElementById("geminiAiInlineImgRow");
    const pill = document.querySelector("#inputAreaContainer .chat-input-pill");
    if (!inlineRow || !pill) return;

    if (!pendingAiAttachments || pendingAiAttachments.length === 0) {
        inlineRow.innerHTML = "";
        inlineRow.classList.remove("active");
        pill.classList.remove("has-gemini-images");
        return;
    }

    inlineRow.classList.add("active");
    pill.classList.add("has-gemini-images");

    inlineRow.innerHTML = pendingAiAttachments.map(att => {
        if (att.loading) {
            return `
                <div class="gemini-inline-thumb-card">
                    <div class="gemini-thumb-spinner"><i class="fa-solid fa-circle-notch fa-spin"></i></div>
                </div>
            `;
        }
        return `
            <div class="gemini-inline-thumb-card">
                <img src="${att.dataUrl}" onclick="openFullImageModal('${att.dataUrl}')" alt="Selected">
                <button type="button" class="gemini-thumb-close-btn" onclick="removeAiAttachment('${att.id}')" title="Remove">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>
        `;
    }).join("");
};

// 3. Render Friend DM Selected Images Directly Inside DM Input Container
renderDmAttachmentPreviewStrip = function () {
    ensureGeminiInlineInputStructure();
    const oldStrip = document.getElementById("dmAttachmentPreviewBar");
    if (oldStrip) oldStrip.style.setProperty("display", "none", "important");

    const inlineRow = document.getElementById("geminiDmInlineImgRow");
    const pill = document.querySelector("#activeChatScreen .chat-input-pill");
    if (!inlineRow || !pill) return;

    if (!pendingDmAttachmentsList || pendingDmAttachmentsList.length === 0) {
        pendingDmAttachment = null;
        inlineRow.innerHTML = "";
        inlineRow.classList.remove("active");
        pill.classList.remove("has-gemini-images");
        return;
    }

    inlineRow.classList.add("active");
    pill.classList.add("has-gemini-images");

    inlineRow.innerHTML = pendingDmAttachmentsList.map(att => {
        if (att.loading) {
            return `
                <div class="gemini-inline-thumb-card">
                    <div class="gemini-thumb-spinner"><i class="fa-solid fa-circle-notch fa-spin"></i></div>
                </div>
            `;
        }
        return `
            <div class="gemini-inline-thumb-card">
                <img src="${att.dataUrl}" onclick="openFullImageModal('${att.dataUrl}')" alt="Selected">
                <button type="button" class="gemini-thumb-close-btn" onclick="removeSingleDmAttachment('${att.id}')" title="Remove">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>
        `;
    }).join("");
};

// Also Clear Any Leftover Previews When Switching Screens
const _v11OrigHideAllScreens = hideAllScreens;
hideAllScreens = function () {
    _v11OrigHideAllScreens();
    document.getElementById("aiAttachmentPreviewBar")?.style.setProperty("display", "none", "important");
    document.getElementById("dmAttachmentPreviewBar")?.style.setProperty("display", "none", "important");
};

// 4. Fix Full-Screen Image Preview Back Navigation & Auto-Close After Download (32558 Fix)
openFullImageModal = function (dataUrl) {
    if (!dataUrl) return;
    pushScreenState("fullImagePreview");
    const modal = document.getElementById("fullImagePreviewModal");
    const img = document.getElementById("fullImagePreviewTarget");
    if (modal && img) {
        img.src = dataUrl;
        modal.style.setProperty("z-index", "2147483647", "important");
        modal.style.setProperty("display", "flex", "important");
    }
};

function closeFullImageModalCleanly() {
    const modal = document.getElementById("fullImagePreviewModal");
    if (modal) {
        modal.style.setProperty("display", "none", "important");
    }
}

downloadFullPreviewImage = function () {
    const img = document.getElementById("fullImagePreviewTarget");
    const src = img?.src || "";
    if (!src) return;
    const fileName = "Zoreno_Image_" + Date.now() + ".jpg";

    if (window.AndroidDownloader && typeof window.AndroidDownloader.downloadImage === "function") {
        window.AndroidDownloader.downloadImage(src, fileName);
    } else {
        const a = document.createElement("a");
        a.href = src;
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        a.remove();
    }

    // Automatically close the full-screen image viewer after downloading so user never gets stuck!
    closeFullImageModalCleanly();
    showCustomAlert("Downloaded! 📥", "Photo saved to your Gallery / Downloads.", true);
};

// Bind Top-Left Back Button Inside Full Image Modal
window.addEventListener("DOMContentLoaded", () => {
    setTimeout(() => {
        ensureGeminiInlineInputStructure();
        const fullImgBackBtn = document.querySelector("#fullImagePreviewModal .full-img-action-btn");
        if (fullImgBackBtn) {
            fullImgBackBtn.onclick = (e) => {
                e.stopPropagation();
                closeFullImageModalCleanly();
            };
        }
    }, 350);
});

// =========================================================
// ZORENO V12 FINAL: STRICT UNREAD, ACCEPTED FRIENDS & GROUPS TAB FILTER
// =========================================================

// 1. Tag each DM item with its exact user ID (dataset.uid) when rendering on Home
const _v12OrigRenderSavedDms = renderSavedDmChatsOnHome;
renderSavedDmChatsOnHome = function () {
    _v12OrigRenderSavedDms();
    const container = document.querySelector(".chats-container");
    if (!container) return;

    const dmItems = container.querySelectorAll(".dynamic-dm-item:not(.group-chat-item)");
    dmItems.forEach(item => {
        const h4 = item.querySelector(".chat-name-row h4");
        const rawName = (h4?.childNodes[0]?.textContent || "").trim();
        const matched = recentDmUsers.find(u => u.name === rawName);
        if (matched && matched.uid) {
            item.dataset.uid = matched.uid;
            item.dataset.unread = String(matched.unread || 0);
        }
    });

    filterHomeChatListByTab(currentActiveChatTab);
};

// 2. Strict Tab Filter Using "!important" so style.css Never Forces Hidden Chats to Show
filterHomeChatListByTab = function (tabKey) {
    currentActiveChatTab = tabKey || "all";
    const container = document.querySelector(".chats-container");
    if (!container) return;

    const groupBar = container.querySelector(".group-top-Controls");
    if (groupBar) {
        groupBar.style.setProperty("display", currentActiveChatTab === "groups" ? "flex" : "none", "important");
    }

    container.querySelectorAll(".friend-req-top-box").forEach(box => {
        const showReqs = (currentActiveChatTab === "all" || currentActiveChatTab === "friends") && incomingFriendReqs.length > 0;
        box.style.setProperty("display", showReqs ? "flex" : "none", "important");
    });

    let visibleCount = 0;
    const items = container.querySelectorAll(".chat-list-item");

    items.forEach(item => {
        if (item.closest(".group-top-Controls") || item.closest(".friend-req-top-box")) {
            item.style.setProperty("display", "flex", "important");
            return;
        }

        // Pinned Zoreno AI item ONLY shows in "All" tab
        if (item.classList.contains("pinned") && !item.classList.contains("dynamic-dm-item")) {
            const showPinned = currentActiveChatTab === "all";
            item.style.setProperty("display", showPinned ? "flex" : "none", "important");
            if (showPinned) visibleCount++;
            return;
        }

        const isGroup = item.classList.contains("group-chat-item") || item.querySelector(".group-avatar") !== null;
        const unreadBadge = item.querySelector(".unread-count");
        const unreadNum = unreadBadge ? (parseInt(unreadBadge.textContent || "0", 10) || 0) : 0;
        const hasUnread = unreadNum > 0;

        // Check if this user has accepted the Friend Request
        const itemUid = item.dataset.uid || "";
        const isAcceptedFriend = Boolean(itemUid && myFriendsMap && myFriendsMap[itemUid] === true);

        let shouldShow = false;
        if (currentActiveChatTab === "all") {
            shouldShow = true;
        } else if (currentActiveChatTab === "unread") {
            shouldShow = hasUnread;
        } else if (currentActiveChatTab === "friends") {
            shouldShow = !isGroup && isAcceptedFriend;
        } else if (currentActiveChatTab === "groups") {
            shouldShow = isGroup;
        }

        item.style.setProperty("display", shouldShow ? "flex" : "none", "important");
        if (shouldShow) visibleCount++;
    });

    // Show clean empty message when Unread, Friends, or Groups tab has 0 items
    let emptyBox = document.getElementById("zorenoTabEmptyState");
    if (!emptyBox) {
        emptyBox = document.createElement("div");
        emptyBox.id = "zorenoTabEmptyState";
        emptyBox.style.cssText = "text-align:center; padding:38px 20px; color:#64748b; font-size:13.5px; font-weight:700; display:none;";
        container.appendChild(emptyBox);
    }

    if (visibleCount === 0) {
        if (currentActiveChatTab === "unread") {
            emptyBox.innerHTML = `<i class="fa-regular fa-envelope-open" style="font-size:28px; color:#94a3b8; margin-bottom:8px; display:block;"></i>No unread messages`;
            emptyBox.style.setProperty("display", "block", "important");
        } else if (currentActiveChatTab === "friends") {
            emptyBox.innerHTML = `<i class="fa-solid fa-user-group" style="font-size:28px; color:#94a3b8; margin-bottom:8px; display:block;"></i>No friends added yet.<br><span style="font-size:12px; font-weight:600; color:#94a3b8;">Open any user's profile and tap "Make Friend" to connect!</span>`;
            emptyBox.style.setProperty("display", "block", "important");
        } else if (currentActiveChatTab === "groups") {
            emptyBox.innerHTML = `<i class="fa-solid fa-users" style="font-size:28px; color:#94a3b8; margin-bottom:8px; display:block;"></i>No study groups yet.`;
            emptyBox.style.setProperty("display", "block", "important");
        } else {
            emptyBox.style.setProperty("display", "none", "important");
        }
    } else {
        emptyBox.style.setProperty("display", "none", "important");
    }
};

// =========================================================
// ZORENO V14 JS FIX: MUTUALLY EXCLUSIVE DARK/EYE-CARE MODES,
// CLEAN "ZORENO AI" TITLE, HIDE BOTTOM NAV ON PROFILE & LOGO SVG
// =========================================================

// 1. Clean Inline SVG Fallback for Zoreno Logo (Never Shows Blank Black/White Circle!)
const ZORENO_SVG_LOGO = "data:image/svg+xml;utf8," + encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120">
  <defs>
    <radialGradient id="bg" cx="35%" cy="25%" r="75%">
      <stop offset="0%" stop-color="#3b82f6"/>
      <stop offset="50%" stop-color="#1e1b4b"/>
      <stop offset="100%" stop-color="#090d16"/>
    </radialGradient>
    <linearGradient id="txt" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#38bdf8"/>
      <stop offset="50%" stop-color="#c084fc"/>
      <stop offset="100%" stop-color="#ffffff"/>
    </linearGradient>
  </defs>
  <circle cx="60" cy="60" r="58" fill="url(#bg)" stroke="#8b5cf6" stroke-width="3"/>
  <text x="60" y="67" font-family="sans-serif" font-weight="900" font-size="23" fill="url(#txt)" text-anchor="middle">Zoreno</text>
</svg>`);

function fixAllZorenoLogosAndRemoveOfficialText() {
    document.querySelectorAll(".ai-logo-avatar, .bot-circle-avatar").forEach(img => {
        img.onerror = function () { this.src = ZORENO_SVG_LOGO; };
        if (!img.complete || img.naturalWidth === 0) {
            img.src = ZORENO_SVG_LOGO;
        }
    });

    // Keep Only "Zoreno AI" Without "Official" Tag
    const homeAiTitle = document.querySelector(".chat-list-item.pinned .chat-name-row h4");
    if (homeAiTitle) homeAiTitle.textContent = "Zoreno AI";

    const topAiTitle = document.getElementById("chatTitle");
    if (topAiTitle) topAiTitle.textContent = "Zoreno AI";

    // Remove duplicate image picker button inside input pills
    document.querySelectorAll('#inputAreaContainer .chat-input-pill button[onclick*="openImagePicker"], #activeChatScreen .chat-input-pill button[onclick*="openDmImagePicker"]').forEach(btn => btn.remove());
}

// 2. Make Dark Mode & Eye Protection Mutually Exclusive so Colors Never Clash (32564, 32683, 32685 Fix)
toggleDarkMode = function () {
    const willEnableDark = !document.body.classList.contains("dark-mode");
    if (willEnableDark && document.body.classList.contains("eye-care-mode")) {
        document.body.classList.remove("eye-care-mode");
        localStorage.setItem("eyeCareMode", "false");
        document.getElementById("eyeCareToggle")?.classList.add("off");
    }
    document.body.classList.toggle("dark-mode", willEnableDark);
    localStorage.setItem("darkMode", willEnableDark ? "true" : "false");
    syncDarkModeUI(willEnableDark);
};

toggleEyeProtectionMode = function () {
    const willEnableEye = !document.body.classList.contains("eye-care-mode");
    if (willEnableEye && document.body.classList.contains("dark-mode")) {
        document.body.classList.remove("dark-mode");
        localStorage.setItem("darkMode", "false");
        syncDarkModeUI(false);
    }
    document.body.classList.toggle("eye-care-mode", willEnableEye);
    localStorage.setItem("eyeCareMode", willEnableEye ? "true" : "false");
    const toggle = document.getElementById("eyeCareToggle");
    if (toggle) toggle.classList.toggle("off", !willEnableEye);
};

// 3. Hide Bottom Nav When Edit Profile Opens so It Never Overlaps Profile Cards (32685 Fix)
const _v14OrigOpenProfile = openProfile;
openProfile = function () {
    _v14OrigOpenProfile();
    const bottomNav = document.getElementById("bottomNav");
    if (bottomNav) bottomNav.style.setProperty("display", "none", "important");
};

const _v14OrigRenderAi = renderAiChatStream;
renderAiChatStream = function () {
    _v14OrigRenderAi();
    fixAllZorenoLogosAndRemoveOfficialText();
};

window.addEventListener("DOMContentLoaded", () => {
    // If both modes were saved as true earlier, keep Dark Mode and turn off Eye Care clash
    if (document.body.classList.contains("dark-mode") && document.body.classList.contains("eye-care-mode")) {
        document.body.classList.remove("eye-care-mode");
        localStorage.setItem("eyeCareMode", "false");
        document.getElementById("eyeCareToggle")?.classList.add("off");
    }
    setTimeout(fixAllZorenoLogosAndRemoveOfficialText, 250);
});


// =========================================================
// ZORENO V15 MASTER JS:
// 1. 2-SECOND LONG-PRESS BOOK MENU ON CHAT MESSAGES (NO ACCIDENTAL CLICK POPUP!)
// 2. COMPACT FROSTED GLASS TOAST FOR "COMING SOON" & NOTICES
// 3. TELEGRAM SETTINGS ICONS, SHORT LABELS & TOKO PLATFORMS FOOTER
// 4. WORLD LANGUAGE CHANGER (TRANSLATES APP UI LIKE COUNTRY MODAL)
// 5. USEFUL 3-DOT MENU ACTIONS
// =========================================================

// 1. Compact Apple-Style Frosted Glass Toast for "Coming Soon" & Quick Notices
function showCompactGlassToast(iconHtml, titleText, subText = "") {
    let old = document.getElementById("zorenoCompactGlassToast");
    if (old) old.remove();

    const pill = document.createElement("div");
    pill.id = "zorenoCompactGlassToast";
    pill.className = "zoreno-glass-toast-pill";
    pill.innerHTML = `
        <span style="font-size:15px;">${iconHtml}</span>
        <span><strong>${escapeHtml(titleText)}</strong>${subText ? ` • <span style="opacity:0.85; font-weight:500;">${escapeHtml(subText)}</span>` : ""}</span>
    `;
    document.body.appendChild(pill);

    setTimeout(() => {
        if (pill.parentNode) {
            pill.style.opacity = "0";
            pill.style.transition = "opacity 0.25s ease";
            setTimeout(() => pill.remove(), 260);
        }
    }, 2400);
}

showCallComingSoon = function () {
    showCompactGlassToast("✨", "Voice & Video Call", "Coming soon in next update");
};
triggerZorenoAudioCall = function () { showCallComingSoon(); };
triggerZorenoVideoCall = function () { showCallComingSoon(); };

// 2. Replace Big Delete Modal with 2-Second Long-Press Book-Unfold Menu (32693 Fix)
function closeZorenoHoldMenu() {
    document.getElementById("zorenoActiveHoldMenu")?.remove();
}

function openBookHoldMenuForMessage(touchEvent, opts) {
    closeZorenoHoldMenu();
    if (navigator.vibrate) navigator.vibrate(40);

    const menu = document.createElement("div");
    menu.id = "zorenoActiveHoldMenu";
    menu.className = "zoreno-msg-hold-menu";

    const clientX = touchEvent?.touches?.[0]?.clientX || touchEvent?.clientX || (window.innerWidth / 2);
    const clientY = touchEvent?.touches?.[0]?.clientY || touchEvent?.clientY || (window.innerHeight / 2);

    const leftPos = Math.min(window.innerWidth - 225, Math.max(14, clientX - 105));
    const topPos = Math.min(window.innerHeight - 210, Math.max(60, clientY - 30));
    menu.style.left = leftPos + "px";
    menu.style.top = topPos + "px";

    const emojis = ["👍", "❤️", "😂", "😮", "😢", "🙏"];
    const emojiRowHtml = opts.isDm
        ? `<div class="zoreno-hold-emoji-row">
               ${emojis.map(em => `<button type="button" onclick="triggerHoldMenuEmoji('${em}', '${opts.msgId}', '${opts.chatId}')">${em}</button>`).join("")}
           </div>`
        : "";

    menu.innerHTML = `
        ${emojiRowHtml}
        <button type="button" class="zoreno-hold-item" onclick="copyHoldMenuMessageText()">
            <i class="fa-regular fa-copy" style="color:#3b82f6;"></i>
            <span>Copy Text</span>
        </button>
        <button type="button" class="zoreno-hold-item" style="color:#ef4444;" onclick="executeHoldMenuDelete()">
            <i class="fa-regular fa-trash-can"></i>
            <span>Delete Message</span>
        </button>
    `;

    window._currentHoldMenuMeta = opts;
    document.body.appendChild(menu);
}

window.triggerHoldMenuEmoji = async function (emojiChar, msgId, chatId) {
    closeZorenoHoldMenu();
    if (!msgId || !chatId || !db) return;
    const col = currentChatIsGroup ? "groups" : "chats";
    try {
        await db.collection(col).doc(chatId).collection("messages").doc(msgId).set({ reaction: emojiChar }, { merge: true });
    } catch (e) {}
};

window.copyHoldMenuMessageText = async function () {
    const meta = window._currentHoldMenuMeta;
    closeZorenoHoldMenu();
    if (!meta?.text) return;
    try {
        await navigator.clipboard.writeText(meta.text);
        showCompactGlassToast("✓", "Copied to clipboard");
    } catch (e) {}
};

window.executeHoldMenuDelete = async function () {
    const meta = window._currentHoldMenuMeta;
    closeZorenoHoldMenu();
    if (!meta) return;
    if (meta.isAi) {
        aiMsgIndexToDelete = meta.aiIdx;
        msgToDeleteId = null;
        msgToDeleteChatId = null;
    } else {
        aiMsgIndexToDelete = null;
        msgToDeleteId = meta.msgId;
        msgToDeleteChatId = meta.chatId;
    }
    await confirmDeleteMessage();
    showCompactGlassToast("🗑️", "Message deleted");
};

document.addEventListener("click", (e) => {
    if (!e.target.closest("#zorenoActiveHoldMenu")) {
        closeZorenoHoldMenu();
    }
});

// Bind 2-Second (1800ms) Long-Press on Both Friend DM & AI Chat Bubbles (Disable Accidental Single-Click Delete!)
function bindTwoSecondLongPressToAllBubbles() {
    // A. Friend DM & Group Chat Bubbles
    document.querySelectorAll("#activeChatMessages .clean-right-bubble, #activeChatMessages .clean-left-bubble").forEach(bubble => {
        const rawClick = bubble.getAttribute("onclick") || "";
        if (rawClick.includes("promptDeleteMessage")) {
            const m = rawClick.match(/promptDeleteMessage\('([^']+)',\s*'([^']+)'\)/);
            bubble.removeAttribute("onclick");
            if (m) {
                bubble.dataset.msgId = m[1];
                bubble.dataset.chatId = m[2];
            }
        }
        if (bubble.dataset.holdBound === "true") return;
        bubble.dataset.holdBound = "true";

        let holdTimer = null;
        bubble.addEventListener("touchstart", (e) => {
            if (e.target.closest("img.sent-wide-photo, button")) return;
            holdTimer = setTimeout(() => {
                openBookHoldMenuForMessage(e, {
                    isDm: true,
                    msgId: bubble.dataset.msgId,
                    chatId: bubble.dataset.chatId,
                    text: bubble.innerText.trim()
                });
            }, 1800); // 2-Second Hold!
        }, { passive: true });
        bubble.addEventListener("touchend", () => clearTimeout(holdTimer));
        bubble.addEventListener("touchmove", () => clearTimeout(holdTimer));
        bubble.addEventListener("touchcancel", () => clearTimeout(holdTimer));
    });

    // B. Zoreno AI Chat Bubbles
    document.querySelectorAll("#chatMessages .clean-right-bubble, #chatMessages .clean-left-bubble").forEach((bubble, i) => {
        bubble.removeAttribute("onclick");
        if (bubble.dataset.holdBound === "true") return;
        bubble.dataset.holdBound = "true";

        let holdTimer = null;
        bubble.addEventListener("touchstart", (e) => {
            if (e.target.closest("button, a, img.sent-wide-photo, .ai-action-btns-wrap")) return;
            holdTimer = setTimeout(() => {
                openBookHoldMenuForMessage(e, {
                    isAi: true,
                    aiIdx: Math.max(0, Math.floor((i - 1) / 2)),
                    text: bubble.innerText.trim()
                });
            }, 1800); // 2-Second Hold!
        }, { passive: true });
        bubble.addEventListener("touchend", () => clearTimeout(holdTimer));
        bubble.addEventListener("touchmove", () => clearTimeout(holdTimer));
        bubble.addEventListener("touchcancel", () => clearTimeout(holdTimer));
    });
}

const _v15OrigRenderDm = renderDmMessagesListToDOM;
renderDmMessagesListToDOM = function (chatId, messagesArray, myUid) {
    _v15OrigRenderDm(chatId, messagesArray, myUid);
    bindTwoSecondLongPressToAllBubbles();
};

const _v15OrigRenderAi = renderAiChatStream;
renderAiChatStream = function () {
    _v15OrigRenderAi();
    bindTwoSecondLongPressToAllBubbles();
};

// 3. Upgrade 3-Dot Menus with Useful Zero-Hassle Actions
function upgradeThreeDotMenus() {
    const aiMenu = document.getElementById("aiHeaderDropdownMenu");
    if (aiMenu) {
        aiMenu.innerHTML = `
            <button type="button" onclick="closeAllDropdownMenus(); copyLatestAiReplyQuick();"><i class="fa-regular fa-copy" style="color:#3b82f6;"></i> Copy Last Reply</button>
            <button type="button" onclick="closeAllDropdownMenus(); speakLatestAiReplyQuick();"><i class="fa-solid fa-volume-high" style="color:#8b5cf6;"></i> Read Aloud</button>
            <button type="button" onclick="closeAllDropdownMenus(); shareLatestAiReplyQuick();"><i class="fa-solid fa-share-nodes" style="color:#10b981;"></i> Share Notes</button>
            <button type="button" onclick="clearCurrentAiChat()"><i class="fa-regular fa-trash-can" style="color:#ef4444;"></i> Clear AI Chat</button>
            <button type="button" onclick="openAiFeedbackModal()"><i class="fa-regular fa-comment-dots" style="color:#f59e0b;"></i> Send Feedback</button>
        `;
    }
}

window.copyLatestAiReplyQuick = function () {
    if (!aiChatMessagesList.length) return showCompactGlassToast("ℹ️", "No AI reply to copy yet");
    copyAiResponseText(aiChatMessagesList.length - 1);
    showCompactGlassToast("✓", "Last AI answer copied!");
};
window.speakLatestAiReplyQuick = function () {
    if (!aiChatMessagesList.length) return showCompactGlassToast("ℹ️", "No AI reply to read yet");
    speakAiResponseText(aiChatMessagesList.length - 1);
};
window.shareLatestAiReplyQuick = function () {
    if (!aiChatMessagesList.length) return showCompactGlassToast("ℹ️", "No AI reply to share yet");
    shareAiResponseText(aiChatMessagesList.length - 1);
};

// 4. World Language Changer (Translates App Interface Like Country Selector) + Telegram Settings Polish & Toko Footer
const ZORENO_WORLD_LANGUAGES = [
    { code: "en", flag: "🇬🇧", name: "English", native: "Default English", dict: { chats: "Chats", pro: "Premium", tools: "Tools", settings: "Settings", dark: "Dark Mode", eye: "Eye Protection", country: "Country", lang: "Language", terms: "Terms of Use", privacy: "Privacy Policy", refund: "Refund Policy", clear: "Clear AI Chat", logout: "Log Out", delAcc: "Delete Account" } },
    { code: "hi", flag: "🇮🇳", name: "Hindi", native: "हिन्दी (भारत)", dict: { chats: "चैट्स", pro: "प्रीमियम", tools: "टूल्स", settings: "सेटिंग्स", dark: "डार्क मोड", eye: "आई प्रोटेक्शन", country: "देश / करेंसी", lang: "ऐप की भाषा", terms: "नियम और शर्तें", privacy: "प्राइवेसी पॉलिसी", refund: "रिफंड पॉलिसी", clear: "AI चैट साफ़ करें", logout: "लॉग आउट", delAcc: "अकाउंट हटाएँ" } },
    { code: "hinglish", flag: "🇮🇳", name: "Hinglish", native: "Hinglish (India)", dict: { chats: "Chats", pro: "Premium", tools: "Tools", settings: "Settings", dark: "Dark Mode", eye: "Eye Care Mode", country: "Country", lang: "App Language", terms: "Terms & Rules", privacy: "Privacy Policy", refund: "Refund Rules", clear: "Clear AI Chat", logout: "Log Out", delAcc: "Delete Account" } },
    { code: "es", flag: "🇪🇸", name: "Spanish", native: "Español", dict: { chats: "Chats", pro: "Premium", tools: "Música", settings: "Ajustes", dark: "Modo Oscuro", eye: "Protección Ocular", country: "País / Moneda", lang: "Idioma", terms: "Términos", privacy: "Privacidad", refund: "Reembolsos", clear: "Borrar Chat IA", logout: "Cerrar Sesión", delAcc: "Eliminar Cuenta" } },
    { code: "fr", flag: "🇫🇷", name: "French", native: "Français", dict: { chats: "Discuter", pro: "Premium", tools: "Outils", settings: "Paramètres", dark: "Mode Sombre", eye: "Confort Visuel", country: "Pays / Devise", lang: "Langue", terms: "Conditions", privacy: "Confidentialité", refund: "Remboursement", clear: "Effacer Chat IA", logout: "Déconnexion", delAcc: "Supprimer Compte" } },
    { code: "ja", flag: "🇯🇵", name: "Japanese", native: "日本語", dict: { chats: "チャット", pro: "プレミアム", tools: "集中音楽", settings: "設定", dark: "ダークモード", eye: "目の保護モード", country: "国と通貨", lang: "アプリの言語", terms: "利用規約", privacy: "プライバシー", refund: "返金ポリシー", clear: "AI履歴を消去", logout: "ログアウト", delAcc: "アカウント削除" } },
    { code: "ko", flag: "🇰🇷", name: "Korean", native: "한국어", dict: { chats: "채팅", pro: "프리미엄", tools: "집중 음악", settings: "설정", dark: "다크 모드", eye: "시력 보호 모드", country: "국가 및 통화", lang: "언어 설정", terms: "이용약관", privacy: "개인정보 정책", refund: "환불 정책", clear: "AI 채팅 지우기", logout: "로그아웃", delAcc: "계정 삭제" } },
    { code: "ar", flag: "🇦🇪", name: "Arabic", native: "العربية", dict: { chats: "الدردشات", pro: "بريميوم", tools: "أدوات", settings: "الإعدادات", dark: "الوضع الداكن", eye: "حماية العين", country: "الدولة والعملة", lang: "اللغة", terms: "الشروط", privacy: "سياسة الخصوصية", refund: "سياسة الاسترداد", clear: "مسح دردشة AI", logout: "تسجيل الخروج", delAcc: "حذف الحساب" } },
    { code: "ru", flag: "🇷🇺", name: "Russian", native: "Русский", dict: { chats: "Чаты", pro: "Премиум", tools: "Музыка", settings: "Настройки", dark: "Тёмная тема", eye: "Защита глаз", country: "Страна", lang: "Язык", terms: "Условия", privacy: "Конфиденциальность", refund: "Возврат", clear: "Очистить чат ИИ", logout: "Выйти", delAcc: "Удалить аккаунт" } },
    { code: "ta", flag: "🇮🇳", name: "Tamil", native: "தமிழ்", dict: { chats: "அரட்டை", pro: "பிரீமியம்", tools: "கருவிகள்", settings: "அமைப்புகள்", dark: "டார்க் மோட்", eye: "கண் பாதுகாப்பு", country: "நாடு", lang: "மொழி", terms: "விதிமுறைகள்", privacy: "தனியுரிமை", refund: "பணம் திரும்ப", clear: "AI அரட்டை அழி", logout: "வெளியேறு", delAcc: "கணக்கை நீக்கு" } }
];

function polishTelegramSettingsAndAddLanguage() {
    const settingsScreen = document.getElementById("settingsScreen");
    if (!settingsScreen) return;

    // 1. Shorten "Clear AI Chat Messages" -> "Clear AI Chat" (32698 Fix)
    const clearTitle = document.getElementById("clearHistoryTitle");
    if (clearTitle) clearTitle.textContent = "Clear AI Chat";

    // 2. Apply Telegram-Style Vibrant Solid Squircle Colors to All Settings Icons (32694-32696 Match)
    const iconPalette = [
        "#3b82f6", // Dark Mode (Blue)
        "#f59e0b", // Eye Protection (Amber/Orange)
        "#8b5cf6", // Country (Purple)
        "#ec4899", // Language (Pink/Magenta)
        "#0ea5e9", // Terms (Sky Blue)
        "#10b981", // Privacy Policy (Emerald Green)
        "#f97316", // Refund (Orange)
        "#6366f1", // Clear AI Chat (Indigo)
        "#ef4444", // Log Out (Red)
        "#dc2626"  // Delete Account (Deep Red)
    ];

    // 3. Inject Language Row Inside Region & Currency Card if not added yet
    const countryCard = settingsScreen.querySelector(".country-card");
    if (countryCard && !document.getElementById("zorenoLangSettingItem")) {
        const savedLangCode = localStorage.getItem("zorenoAppLangCode") || "en";
        const foundLang = ZORENO_WORLD_LANGUAGES.find(l => l.code === savedLangCode) || ZORENO_WORLD_LANGUAGES[0];

        const langRow = document.createElement("div");
        langRow.className = "setting-item";
        langRow.id = "zorenoLangSettingItem";
        langRow.onclick = () => openWorldLanguageModal();
        langRow.innerHTML = `
            <div class="setting-item-left">
                <div class="setting-icon" style="background:#a855f7; color:#ffffff;">
                    <i class="fa-solid fa-language"></i>
                </div>
                <div class="setting-text">
                    <h4 id="appLangSettingTitle">Language</h4>
                    <p id="appLangSettingSub">${foundLang.flag} ${foundLang.name}</p>
                </div>
            </div>
            <div class="setting-item-right"><i class="fa-solid fa-chevron-right"></i></div>
        `;
        countryCard.appendChild(langRow);
    }

    // Colorize all setting icons in Telegram solid squircle style
    settingsScreen.querySelectorAll(".setting-icon").forEach((ic, idx) => {
        ic.style.background = iconPalette[idx % iconPalette.length];
        ic.style.color = "#ffffff";
    });

    // 4. Add Toko Platforms Flagship Product & Privacy Policy Footer at the Bottom of Settings (32696 Match)
    if (!document.getElementById("zorenoTokoFooterBrand")) {
        const footer = document.createElement("div");
        footer.id = "zorenoTokoFooterBrand";
        footer.style.cssText = "text-align:center; padding:20px 16px 35px; color:#64748b; font-size:12px; line-height:1.6;";
        footer.innerHTML = `
            <div style="font-weight:800; font-size:13.5px; color:#7c3aed; margin-bottom:2px;">
                Zoreno AI • v1.0.6
            </div>
            <div style="font-weight:600;">
                Flagship Product of <strong>Toko Platforms</strong>
            </div>
            <div style="margin-top:6px; font-size:11.5px;">
                <a href="javascript:void(0)" onclick="openPolicyModal('privacy')" style="color:#2563eb; text-decoration:none; font-weight:700;">Privacy Policy</a>
                <span style="margin:0 6px; opacity:0.5;">•</span>
                <a href="javascript:void(0)" onclick="openPolicyModal('terms')" style="color:#2563eb; text-decoration:none; font-weight:700;">Terms of Service</a>
            </div>
        `;
        settingsScreen.appendChild(footer);
    }
}

function openWorldLanguageModal() {
    let modal = document.getElementById("zorenoWorldLangModal");
    if (!modal) {
        modal = document.createElement("div");
        modal.id = "zorenoWorldLangModal";
        modal.className = "custom-modal-overlay";
        document.body.appendChild(modal);
    }
    modal.style.setProperty("z-index", "2147483647", "important");

    const currentCode = localStorage.getItem("zorenoAppLangCode") || "en";

    modal.innerHTML = `
        <div class="custom-modal-box cute-country-modal-box">
            <div class="country-modal-header">
                <div class="country-title-pill">
                    <i class="fa-solid fa-language"></i>
                    <span>Select App Language</span>
                </div>
                <button type="button" class="modal-close-btn" onclick="document.getElementById('zorenoWorldLangModal').style.display='none'">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>
            <div class="world-country-scroll-list">
                ${ZORENO_WORLD_LANGUAGES.map(l => {
                    const active = l.code === currentCode;
                    return `
                        <div class="world-country-option ${active ? 'active' : ''}" onclick="applyZorenoWorldLanguage('${l.code}')">
                            <div class="wc-left">
                                <span class="wc-flag">${l.flag}</span>
                                <div class="wc-text">
                                    <h5>${escapeHtml(l.name)}</h5>
                                    <span>${escapeHtml(l.native)}</span>
                                </div>
                            </div>
                            <div class="wc-radio">
                                ${active ? '<i class="fa-solid fa-circle-check"></i>' : '<i class="fa-regular fa-circle"></i>'}
                            </div>
                        </div>
                    `;
                }).join("")}
            </div>
        </div>
    `;
    modal.style.display = "flex";
}

window.applyZorenoWorldLanguage = function (langCode) {
    const langObj = ZORENO_WORLD_LANGUAGES.find(l => l.code === langCode) || ZORENO_WORLD_LANGUAGES[0];
    localStorage.setItem("zorenoAppLangCode", langObj.code);
    localStorage.setItem("appLang", langObj.name);
    currentAppLang = langObj.name;

    const d = langObj.dict;
    const navSpans = document.querySelectorAll("#bottomNav .nav-item span");
    if (navSpans[0]) navSpans[0].textContent = d.chats;
    if (navSpans[1]) navSpans[1].textContent = d.pro;
    if (navSpans[2]) navSpans[2].textContent = d.tools;
    if (navSpans[3]) navSpans[3].textContent = d.settings;

    const setElText = (id, txt) => { const el = document.getElementById(id); if (el && txt) el.textContent = txt; };
    setElText("settingsHeaderTitle", d.settings);
    setElText("darkModeTitle", d.dark);
    setElText("countryTitle", d.country);
    setElText("appLangSettingTitle", d.lang);
    setElText("appLangSettingSub", `${langObj.flag} ${langObj.name}`);
    setElText("termsTitle", d.terms);
    setElText("privacyTitle", d.privacy);
    setElText("refundTitle", d.refund);
    setElText("clearHistoryTitle", d.clear);

    const modal = document.getElementById("zorenoWorldLangModal");
    if (modal) modal.style.display = "none";
    showCompactGlassToast(langObj.flag, `Language set to ${langObj.name}`);
};

window.addEventListener("DOMContentLoaded", () => {
    setTimeout(() => {
        upgradeThreeDotMenus();
        polishTelegramSettingsAndAddLanguage();
        bindTwoSecondLongPressToAllBubbles();
        const savedLang = localStorage.getItem("zorenoAppLangCode");
        if (savedLang && savedLang !== "en") {
            window.applyZorenoWorldLanguage(savedLang);
        }
    }, 400);
});

// =========================================================
// ZORENO V16 MASTER JS:
// 1. 120+ WORLD LANGUAGES + 100% FULL APP TRANSLATION (ALL SCREENS & SUBTITLES)
// 2. ADMIN-ONLY GROUP DP CHANGE & CLEAN MONOCHROME GROUP PROFILE (32700 FIX)
// 3. BLOCK GOOGLE NATIVE COPY BAR ON CHAT HOLD (32701 FIX)
// 4. WHATSAPP-STYLE UNFOLDING SEARCH SHEET & KEYBOARD NAV HIDE (32707/32708 FIX)
// 5. DISTINCT "AI BOT" IDENTITY + 7-OPTION 3-DOT MENU + TOKO PLATFORMS LINK
// =========================================================

// 1. 120+ World Languages List (With English India, US, UK, Chinese Simplified/Traditional & No "Hinglish")
const ZORENO_120_LANGUAGES = [
    "en-IN|🇮🇳|English (India)|English (India)",
    "en-US|🇺🇸|English (United States)|English (US)",
    "en-GB|🇬🇧|English (United Kingdom)|English (UK)",
    "hi|🇮🇳|Hindi|हिन्दी",
    "zh-CN|🇨🇳|Chinese (Simplified)|简体中文",
    "zh-TW|🇹🇼|Chinese (Traditional)|繁體中文",
    "es|🇪🇸|Spanish|Español",
    "fr|🇫🇷|French|Français",
    "de|🇩🇪|German|Deutsch",
    "ja|🇯🇵|Japanese|日本語",
    "ko|🇰🇷|Korean|한국어",
    "ar|🇸🇦|Arabic|العربية",
    "ru|🇷🇺|Russian|Русский",
    "pt|🇧🇷|Portuguese|Português",
    "it|🇮🇹|Italian|Italiano",
    "bn|🇮🇳|Bengali|বাংলা",
    "mr|🇮🇳|Marathi|मराठी",
    "te|🇮🇳|Telugu|తెలుగు",
    "ta|🇮🇳|Tamil|தமிழ்",
    "gu|🇮🇳|Gujarati|ગુજરાતી",
    "ur|🇮🇳|Urdu|اردو",
    "kn|🇮🇳|Kannada|ಕನ್ನಡ",
    "or|🇮🇳|Odia|ଓଡ଼ିଆ",
    "ml|🇮🇳|Malayalam|മലയാളം",
    "pa|🇮🇳|Punjabi|ਪੰਜਾਬੀ",
    "as|🇮🇳|Assamese|অসমীয়া",
    "ne|🇳🇵|Nepali|नेपाली",
    "si|🇱🇰|Sinhala|සිංහල",
    "tr|🇹🇷|Turkish|Türkçe",
    "vi|🇻🇳|Vietnamese|Tiếng Việt",
    "th|🇹🇭|Thai|ไทย",
    "id|🇮🇩|Indonesian|Bahasa Indonesia",
    "ms|🇲🇾|Malay|Bahasa Melayu",
    "fa|🇮🇷|Persian|فارسی",
    "pl|🇵🇱|Polish|Polski",
    "uk|🇺🇦|Ukrainian|Українська",
    "nl|🇳🇱|Dutch|Nederlands",
    "el|🇬🇷|Greek|Ελληνικά",
    "cs|🇨🇿|Czech|Čeština",
    "sv|🇸🇪|Swedish|Svenska",
    "ro|🇷🇴|Romanian|Română",
    "hu|🇭🇺|Hungarian|Magyar",
    "he|🇮🇱|Hebrew|עברית",
    "da|🇩🇰|Danish|Dansk",
    "fi|🇫🇮|Finnish|Suomi",
    "no|🇳🇴|Norwegian|Norsk",
    "sk|🇸🇰|Slovak|Slovenčina",
    "bg|🇧🇬|Bulgarian|Български",
    "hr|🇭🇷|Croatian|Hrvatski",
    "sr|🇷🇸|Serbian|Српски",
    "lt|🇱🇹|Lithuanian|Lietuvių",
    "lv|🇱🇻|Latvian|Latviešu",
    "et|🇪🇪|Estonian|Eesti",
    "sl|🇸🇮|Slovenian|Slovenščina",
    "sw|🇰🇪|Swahili|Kiswahili",
    "tl|🇵🇭|Filipino|Tagalog",
    "uz|🇺🇿|Uzbek|Oʻzbek",
    "kk|🇰🇿|Kazakh|Қазақ тілі",
    "az|🇦🇿|Azerbaijani|Azərbaycan",
    "ka|🇬🇪|Georgian|ქართული",
    "hy|🇦🇲|Armenian|Հայերեն",
    "sq|🇦🇱|Albanian|Shqip",
    "af|🇿🇦|Afrikaans|Afrikaans",
    "am|🇪🇹|Amharic|አማርኛ",
    "my|🇲🇲|Burmese|မြန်မာစာ",
    "km|🇰🇭|Khmer|ភាសាខ្មែរ",
    "lo|🇱🇦|Lao|ພາສາລາວ",
    "mn|🇲🇳|Mongolian|Монгол",
    "ps|🇦🇫|Pashto|پښتو",
    "zu|🇿🇦|Zulu|isiZulu",
    "yo|🇳🇬|Yoruba|Yorùbá",
    "ig|🇳🇬|Igbo|Asụsụ Igbo",
    "ha|🇳🇬|Hausa|Harshen Hausa",
    "is|🇮🇸|Icelandic|Íslenska",
    "ga|🇮🇪|Irish|Gaeilge",
    "cy|🏴󠁧󠁢󠁷󠁬󠁳󠁿|Welsh|Cymraeg",
    "mt|🇲🇹|Maltese|Malti",
    "mk|🇲🇰|Macedonian|Македонски",
    "bs|🇧🇦|Bosnian|Bosanski",
    "be|🇧🇾|Belarusian|Беларуская",
    "ca|🇪🇸|Catalan|Català",
    "eu|🇪🇸|Basque|Euskara",
    "gl|🇪🇸|Galician|Galego"
].map(row => {
    const [code, flag, name, native] = row.split("|");
    return { code, flag, name, native };
});

// Full UI Dictionary for Complete App Translation (Home, Tabs, Search, Settings, Subtitles, Profile, Inputs)
const ZORENO_FULL_TRANSLATIONS = {
    "en": {
        searchPh: "Search chats, @username or people...", sprintTitle: "Focus Sprint ⏱️", sprintSub: "Stay focused, keep the sprint alive!",
        tabAll: "All", tabUnread: "Unread", tabFriends: "Friends", tabGroups: "Groups",
        navChats: "Chats", navPro: "Premium", navTools: "Tools", navSettings: "Settings",
        setHeader: "Settings", setSub: "Customize your Zoreno experience",
        secApp: "APPEARANCE", darkTitle: "Dark Mode", darkSub: "Switch theme", eyeTitle: "Ultra Eye Protection", eyeSub: "Warm zero-strain reading colors",
        secReg: "REGION & CURRENCY", countryTitle: "Country / Currency", countrySub: "Select your region for pricing", langTitle: "Language",
        secLeg: "LEGAL & POLICIES", termsTitle: "Terms & Conditions", termsSub: "Usage rules & service terms",
        privTitle: "Privacy Policy", privSub: "How we protect your data", refTitle: "Refund & Cancellation", refSub: "Subscription refund rules",
        secData: "DATA & STORAGE", clearTitle: "Clear AI Chat", clearSub: "Delete saved AI conversation",
        logoutTitle: "Log Out", logoutSub: "Sign out from your account", delTitle: "Delete Account", delSub: "Permanently delete account & data",
        typePh: "Type a message...", editProf: "Edit Profile", saveBtn: "Save"
    },
    "hi": {
        searchPh: "चैट, @username या लोगों को खोजें...", sprintTitle: "फोकस स्प्रिंट ⏱️", sprintSub: "ध्यान केंद्रित रखें, आगे बढ़ें!",
        tabAll: "सभी", tabUnread: "अपठित", tabFriends: "मित्र", tabGroups: "ग्रुप्स",
        navChats: "चैट्स", navPro: "प्रीमियम", navTools: "टूल्स", navSettings: "सेटिंग्स",
        setHeader: "सेटिंग्स", setSub: "अपने Zoreno अनुभव को कस्टमाइज़ करें",
        secApp: "दिखावट (APPEARANCE)", darkTitle: "डार्क मोड", darkSub: "थीम बदलें", eyeTitle: "अल्ट्रा आई प्रोटेक्शन", eyeSub: "आँखों की सुरक्षा के लिए आरामदायक रंग",
        secReg: "क्षेत्र और भाषा", countryTitle: "देश / करेंसी", countrySub: "कीमतों के लिए अपना देश चुनें", langTitle: "ऐप की भाषा",
        secLeg: "कानूनी और नीतियां", termsTitle: "नियम और शर्तें", termsSub: "उपयोग के नियम और सेवा शर्तें",
        privTitle: "प्राइवेसी पॉलिसी", privSub: "हम आपके डेटा की सुरक्षा कैसे करते हैं", refTitle: "रिफंड और रद्दीकरण", refSub: "सब्सक्रिप्शन रिफंड नियम",
        secData: "डेटा और स्टोरेज", clearTitle: "AI चैट साफ़ करें", clearSub: "सेव की गई AI बातचीत हटाएँ",
        logoutTitle: "लॉग आउट", logoutSub: "अपने अकाउंट से बाहर निकलें", delTitle: "अकाउंट डिलीट करें", delSub: "अकाउंट और डेटा हमेशा के लिए हटाएँ",
        typePh: "मैसेज लिखें...", editProf: "प्रोफाइल बदलें", saveBtn: "सेव करें"
    },
    "ko": {
        searchPh: "채팅, @사용자이름 또는 사람 검색...", sprintTitle: "포커스 스프린트 ⏱️", sprintSub: "집중력을 유지하고 목표를 달성하세요!",
        tabAll: "전체", tabUnread: "안 읽음", tabFriends: "친구", tabGroups: "그룹",
        navChats: "채팅", navPro: "프리미엄", navTools: "집중 음악", navSettings: "설정",
        setHeader: "설정", setSub: "나만의 Zoreno 환경을 설정하세요",
        secApp: "화면 테마", darkTitle: "다크 모드", darkSub: "테마 전환", eyeTitle: "눈 보호 모드", eyeSub: "눈의 피로를 줄여주는 따뜻한 색상",
        secReg: "지역 및 언어", countryTitle: "국가 / 통화", countrySub: "결제 통화 및 국가 선택", langTitle: "언어 설정",
        secLeg: "약관 및 정책", termsTitle: "이용약관", termsSub: "서비스 이용 규칙 및 조건",
        privTitle: "개인정보 처리방침", privSub: "사용자 데이터 보호 안내", refTitle: "환불 및 취소 정책", refSub: "구독 환불 규정 안내",
        secData: "데이터 및 저장공간", clearTitle: "AI 채팅 지우기", clearSub: "저장된 AI 대화 내역 삭제",
        logoutTitle: "로그아웃", logoutSub: "현재 계정에서 로그아웃", delTitle: "계정 삭제", delSub: "계정 및 모든 데이터 영구 삭제",
        typePh: "메시지 입력...", editProf: "프로필 편집", saveBtn: "저장"
    },
    "zh": {
        searchPh: "搜索聊天、@用户名或联系人...", sprintTitle: "专注冲刺 ⏱️", sprintSub: "保持专注，不断前进！",
        tabAll: "全部", tabUnread: "未读", tabFriends: "好友", tabGroups: "群组",
        navChats: "聊天", navPro: "会员", navTools: "工具", navSettings: "设置",
        setHeader: "设置", setSub: "自定义您的 Zoreno 体验",
        secApp: "外观设置", darkTitle: "深色模式", darkSub: "切换主题", eyeTitle: "护眼模式", eyeSub: "温暖无疲劳的阅读配色",
        secReg: "地区与语言", countryTitle: "国家 / 货币", countrySub: "选择您的定价地区", langTitle: "语言 (Language)",
        secLeg: "法律与政策", termsTitle: "服务条款", termsSub: "使用规则与服务条款",
        privTitle: "隐私政策", privSub: "我们如何保护您的数据", refTitle: "退款与取消", refSub: "订阅退款规则",
        secData: "数据与存储", clearTitle: "清空 AI 聊天", clearSub: "删除已保存的 AI 对话",
        logoutTitle: "退出登录", logoutSub: "退出您的当前账户", delTitle: "注销账户", delSub: "永久删除账户及所有数据",
        typePh: "输入消息...", editProf: "编辑资料", saveBtn: "保存"
    },
    "ja": {
        searchPh: "チャット、@ユーザー名、友達を検索...", sprintTitle: "集中スプリント ⏱️", sprintSub: "集中力をキープして頑張ろう！",
        tabAll: "すべて", tabUnread: "未読", tabFriends: "友達", tabGroups: "グループ",
        navChats: "チャット", navPro: "プレミアム", navTools: "ツール", navSettings: "設定",
        setHeader: "設定", setSub: "Zoreno の体験をカスタマイズ",
        secApp: "外観", darkTitle: "ダークモード", darkSub: "テーマを切り替え", eyeTitle: "アイケアモード", eyeSub: "目に優しい 따뜻한 読書カラー",
        secReg: "地域と言語", countryTitle: "国 / 通貨", countrySub: "価格表示の地域を選択", langTitle: "言語",
        secLeg: "規約とポリシー", termsTitle: "利用規約", termsSub: "利用ルールとサービス規約",
        privTitle: "プライバシーポリシー", privSub: "データ保護について", refTitle: "返金とキャンセル", refSub: "サブスクリプション返金規定",
        secData: "データとストレージ", clearTitle: "AIチャットを消去", clearSub: "保存されたAI会話を削除",
        logoutTitle: "ログアウト", logoutSub: "アカウントからサインアウト", delTitle: "アカウント削除", delSub: "アカウントとデータを完全に削除",
        typePh: "メッセージを入力...", editProf: "プロフィール編集", saveBtn: "保存"
    }
};

window.openWorldLanguageModal = function () {
    let modal = document.getElementById("zorenoWorldLangModal");
    if (!modal) {
        modal = document.createElement("div");
        modal.id = "zorenoWorldLangModal";
        modal.className = "custom-modal-overlay";
        document.body.appendChild(modal);
    }
    modal.style.setProperty("z-index", "2147483647", "important");

    modal.innerHTML = `
        <div class="custom-modal-box cute-country-modal-box">
            <div class="country-modal-header">
                <div class="country-title-pill">
                    <i class="fa-solid fa-language"></i>
                    <span>Select Language (120+)</span>
                </div>
                <button type="button" class="modal-close-btn" onclick="document.getElementById('zorenoWorldLangModal').style.display='none'">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>
            <div class="country-search-pill">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" id="langSearchInput" placeholder="Search 120+ world languages..." oninput="filterWorldLanguagesList(this.value)">
            </div>
            <div class="world-country-scroll-list" id="worldLangListContainer"></div>
        </div>
    `;
    renderWorldLanguagesList(ZORENO_120_LANGUAGES);
    modal.style.display = "flex";
};

window.filterWorldLanguagesList = function (q) {
    const clean = (q || "").toLowerCase().trim();
    const filtered = ZORENO_120_LANGUAGES.filter(l =>
        l.name.toLowerCase().includes(clean) || l.native.toLowerCase().includes(clean) || l.code.toLowerCase().includes(clean)
    );
    renderWorldLanguagesList(filtered);
};

function renderWorldLanguagesList(list) {
    const box = document.getElementById("worldLangListContainer");
    if (!box) return;
    const currentCode = localStorage.getItem("zorenoAppLangCode") || "en-IN";
    box.innerHTML = list.map(l => {
        const active = l.code === currentCode;
        return `
            <div class="world-country-option ${active ? 'active' : ''}" onclick="applyZorenoWorldLanguage('${l.code}')">
                <div class="wc-left">
                    <span class="wc-flag">${l.flag}</span>
                    <div class="wc-text">
                        <h5>${escapeHtml(l.name)}</h5>
                        <span>${escapeHtml(l.native)}</span>
                    </div>
                </div>
                <div class="wc-radio">
                    ${active ? '<i class="fa-solid fa-circle-check"></i>' : '<i class="fa-regular fa-circle"></i>'}
                </div>
            </div>
        `;
    }).join("");
}

window.applyZorenoWorldLanguage = async function (langCode) {
    const langObj = ZORENO_120_LANGUAGES.find(l => l.code === langCode) || ZORENO_120_LANGUAGES[0];
    localStorage.setItem("zorenoAppLangCode", langObj.code);
    localStorage.setItem("appLang", langObj.name);
    currentAppLang = langObj.name;

    const baseKey = langObj.code.split("-")[0];
    let d = ZORENO_FULL_TRANSLATIONS[baseKey] || ZORENO_FULL_TRANSLATIONS["en"];

    // Apply all static dictionary translations across the entire app
    const setTxt = (sel, val) => { const el = document.querySelector(sel); if (el && val) el.textContent = val; };
    const setPh = (sel, val) => { const el = document.querySelector(sel); if (el && val) el.placeholder = val; };

    setPh("#homeChatSearchInput", d.searchPh);
    setTxt(".sprint-title", d.sprintTitle);
    setTxt(".sprint-subtitle", d.sprintSub);

    const hTabs = document.querySelectorAll(".chat-tabs .tab-btn");
    if (hTabs[0]) hTabs[0].textContent = d.tabAll;
    if (hTabs[1]) hTabs[1].textContent = d.tabUnread;
    if (hTabs[2]) hTabs[2].textContent = d.tabFriends;
    if (hTabs[3]) hTabs[3].textContent = d.tabGroups;

    const navSpans = document.querySelectorAll("#bottomNav .nav-item span");
    if (navSpans[0]) navSpans[0].textContent = d.navChats;
    if (navSpans[1]) navSpans[1].textContent = d.navPro;
    if (navSpans[2]) navSpans[2].textContent = d.navTools;
    if (navSpans[3]) navSpans[3].textContent = d.navSettings;

    setTxt("#settingsHeaderTitle", d.setHeader);
    setTxt("#settingsHeaderDesc", d.setSub);
    setTxt("#appearanceTitle", d.secApp);
    setTxt("#darkModeTitle", d.darkTitle);
    setTxt("#darkModeDesc", d.darkSub);

    // Eye protection & all subtitles
    const eyeH4 = document.querySelector('#settingsScreen .setting-item[onclick*="toggleEyeProtectionMode"] h4');
    const eyeP = document.querySelector('#settingsScreen .setting-item[onclick*="toggleEyeProtectionMode"] p');
    if (eyeH4) eyeH4.textContent = d.eyeTitle;
    if (eyeP) eyeP.textContent = d.eyeSub;

    setTxt("#regionTitle", d.secReg);
    setTxt("#countryTitle", d.countryTitle);
    setTxt("#countryDesc", d.countrySub);
    setTxt("#appLangSettingTitle", d.langTitle);
    setTxt("#appLangSettingSub", `${langObj.flag} ${langObj.name}`);

    setTxt("#legalTitle", d.secLeg);
    setTxt("#termsTitle", d.termsTitle);
    setTxt("#termsDesc", d.termsSub);
    setTxt("#privacyTitle", d.privTitle);
    setTxt("#privacyDesc", d.privSub);
    setTxt("#refundTitle", d.refTitle);
    setTxt("#refundDesc", d.refSub);

    const dataSecTitle = document.querySelectorAll("#settingsScreen .settings-section-title")[3];
    if (dataSecTitle) dataSecTitle.textContent = d.secData;
    setTxt("#clearHistoryTitle", d.clearTitle);
    setTxt("#clearHistoryDesc", d.clearSub);

    const logoutItem = document.querySelector('#settingsScreen .setting-item[onclick*="handleUserLogout"]');
    if (logoutItem) {
        const h4 = logoutItem.querySelector("h4");
        const p = logoutItem.querySelector("p");
        if (h4) h4.textContent = d.logoutTitle;
        if (p) p.textContent = d.logoutSub;
    }

    const delItem = document.querySelector('#settingsScreen .setting-item[onclick*="openDeleteAccountModal"]');
    if (delItem) {
        const h4 = delItem.querySelector("h4");
        const p = delItem.querySelector("p");
        if (h4) h4.textContent = d.delTitle;
        if (p) p.textContent = d.delSub;
    }

    setPh("#userInput", d.typePh);
    setPh("#activeChatInput", d.typePh);
    setTxt("#profileScreen .profile-header h2", d.editProf);
    setTxt("#profileSaveBtn", d.saveBtn);

    const modal = document.getElementById("zorenoWorldLangModal");
    if (modal) modal.style.display = "none";
    showCompactGlassToast(langObj.flag, `Language: ${langObj.name}`);
};

// 2. Make Zoreno AI Look Like a Real AI Assistant (Not a Normal Friend)
function applyDistinctAiAssistantIdentity() {
    const aiBadgeHtml = `<span class="zoreno-ai-bot-pill"><i class="fa-solid fa-wand-magic-sparkles"></i> AI BOT</span>`;
    const homeAiH4 = document.querySelector(".chat-list-item.pinned .chat-name-row h4");
    if (homeAiH4) homeAiH4.innerHTML = `Zoreno AI ${aiBadgeHtml}`;

    const topAiTitle = document.getElementById("chatTitle");
    if (topAiTitle) topAiTitle.innerHTML = `Zoreno AI ${aiBadgeHtml}`;

    const aiSubLine = document.querySelector("#chatScreen .ai-topbar-user-meta > div > div:nth-child(2)");
    if (aiSubLine && !aiSubLine.innerHTML.includes("Instant AI")) {
        aiSubLine.innerHTML = `<span style="color:#10b981; font-weight:700;">⚡ Instant AI Study Partner</span> <span id="aiLiveQuotaBadge" class="ai-quota-pill-badge"></span>`;
        updateAiQuotaHeaderBadge();
    }
}

// 3. Clean Group Profile (Admin-Only DP Change & Clean White/Dark Cards - 32700 Fix)
renderGroupMembersInsideProfile = async function (grp) {
    const grpBox = document.getElementById("zorenoGroupMembersContainer");
    if (!grpBox || !grp) return;

    const myUid = auth?.currentUser?.uid || "";
    const memberUids = grp.members || [];
    const adminsList = Array.isArray(grp.admins) ? grp.admins : (grp.adminUid ? [grp.adminUid] : []);
    const amIGroupAdmin = adminsList.includes(myUid) || grp.adminUid === myUid;
    const memCount = memberUids.length;

    const fpAvatar = document.getElementById("fpAvatarImg");
    if (fpAvatar) {
        fpAvatar.src = getSafeAvatar(grp.photoURL || "logo.png");
        fpAvatar.parentElement.style.cursor = amIGroupAdmin ? "pointer" : "default";
        fpAvatar.parentElement.onclick = amIGroupAdmin ? () => triggerGroupDpUpload() : null;
    }

    const fName = document.getElementById("fpFullName");
    const uSub = document.getElementById("fpUsernameSub");
    const pillTxt = document.getElementById("fpPillText");
    if (fName) fName.textContent = grp.name || "Study Group";
    if (uSub) {
        uSub.innerHTML = amIGroupAdmin
            ? `<span style="color:#38bdf8; cursor:pointer; font-weight:700;" onclick="triggerGroupDpUpload()"><i class="fa-solid fa-camera"></i> Tap to change group photo</span> • ${memCount} Members`
            : `Study Group • ${memCount} ${memCount === 1 ? "Member" : "Members"}`;
    }
    if (pillTxt) pillTxt.textContent = "Active Group";

    grpBox.innerHTML = `<div style="text-align:center; padding:18px; color:#94a3b8; font-weight:600;"><i class="fa-solid fa-spinner fa-spin"></i> Loading members...</div>`;

    const memberProfiles = [];
    for (const uid of memberUids) {
        const isThisAdmin = adminsList.includes(uid) || grp.adminUid === uid;
        if (uid === myUid) {
            memberProfiles.push({ uid: myUid, name: userName || "You", username: currentUsername || "@student", avatar: getSafeAvatar(userAvatarUrl), isAdmin: isThisAdmin, isMe: true });
            continue;
        }
        let cached = userProfileCache[uid];
        if (!cached && db) {
            try {
                const uDoc = await db.collection("users").doc(uid).get();
                if (uDoc.exists) { cached = uDoc.data(); userProfileCache[uid] = cached; }
            } catch (e) {}
        }
        memberProfiles.push({
            uid: uid,
            name: cached?.name || "Student",
            username: cached?.username || "@student",
            avatar: getSafeAvatar(cached?.photoURL || cached?.avatarUrl),
            isAdmin: isThisAdmin,
            isMe: false
        });
    }

    const membersListHtml = memberProfiles.map(m => {
        const adminTag = m.isAdmin
            ? `<span style="background:rgba(56,189,248,0.16); color:#38bdf8; border:1px solid rgba(56,189,248,0.35); font-size:10px; font-weight:700; padding:2px 8px; border-radius:8px;">Admin</span>`
            : "";
        const makeAdminBtn = (amIGroupAdmin && !m.isAdmin && !m.isMe)
            ? `<button type="button" onclick="promoteMemberToGroupAdmin('${escapeHtml(m.uid)}', '${escapeHtml(m.name)}', event)" style="background:rgba(255,255,255,0.1); color:#e2e8f0; border:1px solid rgba(255,255,255,0.2); padding:6px 10px; border-radius:10px; font-size:11px; font-weight:700; cursor:pointer;">Make Admin</button>`
            : "";

        return `
            <div class="fp-info-card" style="justify-content:space-between; margin-bottom:9px; padding:12px 14px;">
                <div style="display:flex; align-items:center; gap:12px; min-width:0; flex:1; cursor:${m.isMe ? 'default' : 'pointer'};" ${m.isMe ? '' : `onclick="startDirectChatFromGroupMember('${escapeHtml(m.uid)}', '${escapeHtml(m.name)}', '${escapeHtml(m.avatar)}', '${escapeHtml(m.username)}')"`}>
                    <img src="${escapeHtml(m.avatar)}" onerror="this.src='logo.png'" style="width:42px; height:42px; border-radius:50%; object-fit:cover; flex-shrink:0;">
                    <div style="min-width:0; flex:1;">
                        <h4 style="margin:0; font-size:14.5px; font-weight:700; display:flex; align-items:center; gap:6px;">
                            ${escapeHtml(m.name)} ${m.isMe ? "(You)" : ""} ${adminTag}
                        </h4>
                        <span style="font-size:12px; color:#94a3b8; font-weight:500;">${escapeHtml(m.username)}</span>
                    </div>
                </div>
                <div style="display:flex; align-items:center; gap:6px;">
                    ${makeAdminBtn}
                    ${!m.isMe ? `
                    <button type="button" onclick="startDirectChatFromGroupMember('${escapeHtml(m.uid)}', '${escapeHtml(m.name)}', '${escapeHtml(m.avatar)}', '${escapeHtml(m.username)}')" style="background:#2563eb; color:#fff; border:none; width:34px; height:34px; border-radius:50%; font-size:13px; cursor:pointer; display:flex; align-items:center; justify-content:center;">
                        <i class="fa-regular fa-comment-dots"></i>
                    </button>` : ""}
                </div>
            </div>
        `;
    }).join("");

    grpBox.innerHTML = `
        <div style="display:flex; align-items:center; justify-content:space-between; margin:12px 4px 10px;">
            <span style="font-size:12px; font-weight:700; color:#94a3b8; letter-spacing:0.5px;">MEMBERS (${memCount})</span>
            <button type="button" onclick="openInviteMoreFriendsToGroupModal()" style="border:1px solid rgba(56,189,248,0.35); background:rgba(56,189,248,0.12); color:#38bdf8; padding:6px 12px; border-radius:12px; font-size:12px; font-weight:700; cursor:pointer;">
                + Add Members
            </button>
        </div>
        ${membersListHtml}
    `;
};

// 4. WhatsApp-Style Search Bar Unfold & Hide Bottom Nav When Searching (32707 & 32708 Fix)
function setupWhatsAppStyleSearchUX() {
    const sInp = document.getElementById("homeChatSearchInput");
    if (!sInp || sInp.dataset.waBound === "true") return;
    sInp.dataset.waBound = "true";

    sInp.addEventListener("focus", () => {
        document.body.classList.add("search-focused");
    });
    sInp.addEventListener("blur", () => {
        setTimeout(() => {
            document.body.classList.remove("search-focused");
        }, 200);
    });
}

// 5. Block Native Google Copy Context Menu on Chat Messages & Upgrade 3-Dot Menu (7 Options) + Toko Footer
document.addEventListener("contextmenu", (e) => {
    if (e.target.closest("#chatMessages, #activeChatMessages")) {
        e.preventDefault();
    }
});

function upgradeRichThreeDotMenusAndTokoFooter() {
    const aiMenu = document.getElementById("aiHeaderDropdownMenu");
    if (aiMenu) {
        aiMenu.innerHTML = `
            <button type="button" onclick="closeAllDropdownMenus(); openZorenoAiProfileView();"><i class="fa-solid fa-robot" style="color:#6366f1;"></i> AI Profile & Info</button>
            <button type="button" onclick="closeAllDropdownMenus(); copyLatestAiReplyQuick();"><i class="fa-regular fa-copy" style="color:#3b82f6;"></i> Copy Last Answer</button>
            <button type="button" onclick="closeAllDropdownMenus(); speakLatestAiReplyQuick();"><i class="fa-solid fa-volume-high" style="color:#8b5cf6;"></i> Read Aloud (Voice)</button>
            <button type="button" onclick="closeAllDropdownMenus(); shareLatestAiReplyQuick();"><i class="fa-solid fa-share-nodes" style="color:#10b981;"></i> Share Answer Card</button>
            <button type="button" onclick="closeAllDropdownMenus(); toggleDarkMode();"><i class="fa-solid fa-moon" style="color:#0ea5e9;"></i> Switch Theme</button>
            <button type="button" onclick="clearCurrentAiChat()"><i class="fa-regular fa-trash-can" style="color:#ef4444;"></i> Clear AI Chat</button>
            <button type="button" onclick="openAiFeedbackModal()"><i class="fa-regular fa-comment-dots" style="color:#f59e0b;"></i> Send Feedback</button>
        `;
    }

    const dmMenu = document.getElementById("dmHeaderDropdownMenu");
    if (dmMenu) {
        dmMenu.innerHTML = `
            <button type="button" onclick="openFriendProfileScreen()"><i class="fa-regular fa-user" style="color:#3b82f6;"></i> View Profile</button>
            <button type="button" onclick="closeAllDropdownMenus(); handleMakeAsFriendClick();"><i class="fa-solid fa-user-plus" style="color:#10b981;"></i> Add as Friend</button>
            <button type="button" onclick="closeAllDropdownMenus(); copyFriendUsername();"><i class="fa-solid fa-at" style="color:#8b5cf6;"></i> Copy Username</button>
            <button type="button" onclick="clearCurrentDmChat()"><i class="fa-regular fa-trash-can" style="color:#64748b;"></i> Clear Chat</button>
            <button type="button" id="dmBlockMenuBtn" onclick="toggleBlockChatUser()" style="color:#f59e0b;"><i class="fa-solid fa-ban"></i> Block User</button>
            <button type="button" onclick="openReportModal()" style="color:#ef4444;"><i class="fa-solid fa-flag"></i> Report User</button>
        `;
    }

    // Clean Apple-Style Toko Platforms Footer with Direct tokoplatforms.in/privacy-policy.html Link (32704 Fix)
    const footer = document.getElementById("zorenoTokoFooterBrand");
    if (footer) {
        footer.innerHTML = `
            <div style="background:rgba(148,163,184,0.1); border:1px solid rgba(148,163,184,0.18); border-radius:18px; padding:14px 16px; max-width:340px; margin:0 auto;">
                <div style="font-weight:800; font-size:14px; color:#0f172a; margin-bottom:2px;" class="toko-foot-title">
                    Zoreno AI • v1.0.6
                </div>
                <div style="font-size:12px; color:#64748b; font-weight:600; margin-bottom:8px;">
                    A Flagship Product of <strong>Toko Platforms</strong>
                </div>
                <div style="display:flex; align-items:center; justify-content:center; gap:10px; font-size:12px; font-weight:700;">
                    <a href="https://tokoplatforms.in/privacy-policy.html" target="_blank" style="color:#2563eb; text-decoration:none;">Privacy Policy ↗</a>
                    <span style="opacity:0.4;">•</span>
                    <a href="https://tokoplatforms.in" target="_blank" style="color:#7c3aed; text-decoration:none;">tokoplatforms.in ↗</a>
                </div>
            </div>
        `;
    }
}

window.addEventListener("DOMContentLoaded", () => {
    setTimeout(() => {
        applyDistinctAiAssistantIdentity();
        setupWhatsAppStyleSearchUX();
        upgradeRichThreeDotMenusAndTokoFooter();
        const savedLang = localStorage.getItem("zorenoAppLangCode");
        if (savedLang) {
            window.applyZorenoWorldLanguage(savedLang);
        }
    }, 450);
});


// =========================================================
// ZORENO V17 MASTER JS:
// 1. ACCURATE AI MATH SOLVER (SOLVES EQUATION FIRST EVEN FOR "ONLY ANSWER")
// 2. SETTINGS "USAGE LIMIT" MODAL (10 FREE / 50 PLUS / 90 PRO + 3 AD BONUS)
// 3. 1-SECOND HOLD TELEGRAM MENU WITH FORWARD, REPLY, COPY, DELETE & ANIMATED EMOJIS
// 4. ALL 120+ WORLD LANGUAGES LIVE TRANSLATION (FRENCH, TAMIL, ETC.) + SILENT BOOT
// 5. CLEAN HEADER ("ZORENO AI" ONLY), AUTO-RESTORE NAV BAR & CLEAN FOOTER
// =========================================================

// 1. Upgrade AI System Instruction so Math/Speed/Age Questions Are ALWAYS Calculated Accurately First (32730/32734 Fix)
const _v17MathAccuracyRule = `
CRITICAL MATH & MCQ ACCURACY RULE:
- Whenever the user asks a Math, Physics, Speed-Distance-Time, or Age question (or sends an image of MCQ options), ALWAYS solve the exact algebraic equation step-by-step internally first to find the 100% mathematically correct value before choosing an option.
- Even if the user says "Give me answer not solution" or "Only answer", internally verify the exact root of the equation first (for example, 180/x - 180/(x+15) = 1 gives x = 45 km/h, NEVER guess 60 km/h) and then state the verified correct option!`;

if (typeof buildLiveContextForAI === "function") {
    const _v17OrigBuildLiveContext = buildLiveContextForAI;
    buildLiveContextForAI = async function (userText) {
        const base = await _v17OrigBuildLiveContext(userText);
        return base + "\n" + _v17MathAccuracyRule;
    };
}

// 2. Clean Header: Keep Only "Zoreno AI" & "@zoreno_ai • Online" (Remove "AI BOT", "Instant AI Study Partner" & Quota Pill)
function restoreCleanZorenoAiHeader() {
    const homeAiH4 = document.querySelector(".chat-list-item.pinned .chat-name-row h4");
    if (homeAiH4) homeAiH4.textContent = "Zoreno AI";

    const topAiTitle = document.getElementById("chatTitle");
    if (topAiTitle) topAiTitle.textContent = "Zoreno AI";

    const aiSubLine = document.querySelector("#chatScreen .ai-topbar-user-meta > div > div:nth-child(2)");
    if (aiSubLine) {
        aiSubLine.innerHTML = `<span>@zoreno_ai • Online</span>`;
    }
}

// 3. Replace Big "Copied!" Alert with Compact Top Pill (32709 & 32706 Fix)
copyFriendUsername = async function () {
    if (!currentChatUserMeta) return;
    const handle = (currentChatUserMeta.username || "").replace(/^@/, "");
    try {
        await navigator.clipboard.writeText(handle);
        showCompactGlassToast("✓", `@${handle} copied`);
    } catch (e) {}
};

showCallComingSoon = function () {
    showCompactGlassToast("📞", "Voice & Video Call", "Available in next update");
};

// 4. Dedicated "Usage Limit" Screen/Modal in Settings & 3-Dot Menu (10 Free + 3/Ad, 50 Plus, 90 Pro)
window.openZorenoUsageLimitModal = function () {
    closeAllDropdownMenus();
    let modal = document.getElementById("zorenoUsageLimitModal");
    if (!modal) {
        modal = document.createElement("div");
        modal.id = "zorenoUsageLimitModal";
        modal.className = "custom-modal-overlay";
        document.body.appendChild(modal);
    }
    modal.style.setProperty("z-index", "2147483647", "important");

    const usedToday = getLocalDailyAiCount();
    const baseDailyLimit = userTier === 2 ? 90 : userTier === 1 ? 50 : 10;
    const currentTotalLimit = userTier === 2
        ? Math.max(90, getLocalDailyAiLimit())
        : userTier === 1
            ? Math.max(50, getLocalDailyAiLimit())
            : getLocalDailyAiLimit();
    const bonusUnlocked = Math.max(0, currentTotalLimit - baseDailyLimit);
    const remaining = Math.max(0, currentTotalLimit - usedToday);
    const percentUsed = Math.min(100, Math.round((usedToday / Math.max(1, currentTotalLimit)) * 100));

    const planName = userTier === 2
        ? "Zoreno Pro (₹349 / $6.99)"
        : userTier === 1
            ? "Zoreno Plus (₹249 / $3.99)"
            : "Free Plan (10 Chats / Day)";

    modal.innerHTML = `
        <div class="custom-modal-box" style="max-width:365px; text-align:left; border-radius:24px; padding:22px;">
            <div class="policy-modal-header" style="margin-bottom:14px;">
                <h3 style="display:flex; align-items:center; gap:8px; font-size:18px; margin:0;">
                    <i class="fa-solid fa-chart-pie" style="color:#7c3aed;"></i> Daily Usage Limit
                </h3>
                <button type="button" class="modal-close-btn" onclick="document.getElementById('zorenoUsageLimitModal').style.display='none'">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            <div style="background:rgba(124,58,237,0.08); border:1px solid rgba(124,58,237,0.22); border-radius:16px; padding:14px; margin-bottom:14px;">
                <div style="font-size:11.5px; font-weight:700; color:#7c3aed; text-transform:uppercase;">Current Active Plan</div>
                <div style="font-size:16px; font-weight:800; margin-top:2px;">${escapeHtml(planName)}</div>
                <div style="font-size:12px; color:#64748b; margin-top:4px;">Resets every night at 12:00 AM (24-Hour Cycle)</div>
            </div>

            <div style="margin-bottom:16px;">
                <div style="display:flex; justify-content:space-between; font-size:13.5px; font-weight:700; margin-bottom:6px;">
                    <span>Chats Used Today: ${usedToday} / ${currentTotalLimit}</span>
                    <span style="color:#10b981;">${remaining} Left</span>
                </div>
                <div style="width:100%; height:10px; background:#e2e8f0; border-radius:8px; overflow:hidden;">
                    <div style="width:${percentUsed}%; height:100%; background:linear-gradient(90deg,#2563eb,#7c3aed); border-radius:8px;"></div>
                </div>
                <div style="display:flex; justify-content:space-between; font-size:11.5px; color:#64748b; margin-top:6px; font-weight:600;">
                    <span>Base Quota: ${baseDailyLimit}/day</span>
                    <span>Ad Bonus Unlocked: +${bonusUnlocked} chats</span>
                </div>
            </div>

            <div style="display:flex; flex-direction:column; gap:8px;">
                <button type="button" class="modal-submit-btn" style="background:linear-gradient(135deg,#2563eb,#7c3aed); font-weight:700;" onclick="document.getElementById('zorenoUsageLimitModal').style.display='none'; openRewardedAdModal();">
                    <i class="fa-solid fa-circle-play"></i> Watch Ad (+3 Free Chats)
                </button>
                ${userTier < 2 ? `
                <button type="button" class="modal-submit-btn" style="background:#f1f5f9; color:#0f172a; font-weight:700;" onclick="document.getElementById('zorenoUsageLimitModal').style.display='none'; openSubscription();">
                    👑 Upgrade Plan (50 or 90 Chats/Day)
                </button>` : ""}
            </div>
        </div>
    `;
    modal.style.display = "flex";
};

// Trigger Rewarded Ad Only When Used >= Limit (Never Every 2 Questions!)
const _v17OrigRewardGranted = window.onAdMobRewardGranted;
window.onAdMobRewardGranted = function () {
    if (typeof _v17OrigRewardGranted === "function") _v17OrigRewardGranted();
    const modal = document.getElementById("zorenoUsageLimitModal");
    if (modal && modal.style.display === "flex") {
        window.openZorenoUsageLimitModal();
    }
};

// 5. 1-Second (850ms) Hold Telegram Menu with Bouncing Emojis + Reply, Copy, Forward & Delete (32724 Match)
openBookHoldMenuForMessage = function (touchEvent, opts) {
    closeZorenoHoldMenu();
    if (navigator.vibrate) navigator.vibrate(30);

    const wrap = document.createElement("div");
    wrap.id = "zorenoActiveHoldMenu";
    wrap.className = "zoreno-tg-hold-wrap";

    const clientX = touchEvent?.touches?.[0]?.clientX || touchEvent?.clientX || (window.innerWidth / 2);
    const clientY = touchEvent?.touches?.[0]?.clientY || touchEvent?.clientY || (window.innerHeight / 2);

    const leftPos = Math.min(window.innerWidth - 235, Math.max(12, clientX - 100));
    const topPos = Math.min(window.innerHeight - 255, Math.max(55, clientY - 60));
    wrap.style.left = leftPos + "px";
    wrap.style.top = topPos + "px";

    const tgEmojis = ["🫡", "🙏", "⚡", "👍", "🔥", "👏"];
    const emojiPillHtml = `
        <div class="zoreno-tg-emoji-pill">
            ${tgEmojis.map(em => `<button type="button" onclick="triggerHoldMenuEmoji('${em}', '${opts.msgId || ""}', '${opts.chatId || ""}')">${em}</button>`).join("")}
        </div>
    `;

    wrap.innerHTML = `
        ${emojiPillHtml}
        <div class="zoreno-tg-action-card">
            <button type="button" class="zoreno-hold-item" onclick="replyToHoldMenuMessage()">
                <i class="fa-solid fa-reply" style="color:#3b82f6;"></i>
                <span>Reply</span>
            </button>
            <button type="button" class="zoreno-hold-item" onclick="copyHoldMenuMessageText()">
                <i class="fa-regular fa-copy" style="color:#8b5cf6;"></i>
                <span>Copy</span>
            </button>
            <button type="button" class="zoreno-hold-item" onclick="openForwardMessageModal()">
                <i class="fa-solid fa-share" style="color:#10b981;"></i>
                <span>Forward</span>
            </button>
            <button type="button" class="zoreno-hold-item" style="color:#ef4444;" onclick="executeHoldMenuDelete()">
                <i class="fa-regular fa-trash-can"></i>
                <span>Delete</span>
            </button>
        </div>
    `;

    window._currentHoldMenuMeta = opts;
    document.body.appendChild(wrap);
};

window.replyToHoldMenuMessage = function () {
    const meta = window._currentHoldMenuMeta;
    closeZorenoHoldMenu();
    if (!meta?.text) return;
    const cleanQuote = meta.text.replace(/\s+/g, " ").slice(0, 55);
    const targetInp = document.getElementById(meta.isAi ? "userInput" : "activeChatInput");
    if (targetInp) {
        targetInp.value = `> "${cleanQuote}..."\n`;
        targetInp.focus();
        autoResizeChatInput(targetInp);
    }
};

window.openForwardMessageModal = function () {
    const meta = window._currentHoldMenuMeta;
    closeZorenoHoldMenu();
    if (!meta?.text) return;

    let modal = document.getElementById("zorenoForwardMsgModal");
    if (!modal) {
        modal = document.createElement("div");
        modal.id = "zorenoForwardMsgModal";
        modal.className = "custom-modal-overlay";
        document.body.appendChild(modal);
    }
    modal.style.setProperty("z-index", "2147483647", "important");

    const targetsHtml = [
        `<div class="world-country-option" onclick="executeForwardToTarget('ai')">
            <div class="wc-left">
                <img src="logo.png" onerror="this.src='default_avatar.png'" style="width:36px; height:36px; border-radius:50%; object-fit:cover;">
                <div class="wc-text"><h5>Zoreno AI</h5><span>Ask AI about this message</span></div>
            </div>
            <i class="fa-solid fa-paper-plane" style="color:#7c3aed;"></i>
        </div>`,
        ...recentDmUsers.map(u => `
            <div class="world-country-option" onclick="executeForwardToTarget('dm', '${escapeHtml(u.uid)}', '${escapeHtml(u.name)}', '${escapeHtml(u.avatar)}', '${escapeHtml(u.username)}')">
                <div class="wc-left">
                    <img src="${escapeHtml(getSafeAvatar(u.avatar))}" onerror="this.src='logo.png'" style="width:36px; height:36px; border-radius:50%; object-fit:cover;">
                    <div class="wc-text"><h5>${escapeHtml(u.name)}</h5><span>${escapeHtml(u.username)}</span></div>
                </div>
                <i class="fa-solid fa-paper-plane" style="color:#2563eb;"></i>
            </div>
        `)
    ].join("");

    modal.innerHTML = `
        <div class="custom-modal-box cute-country-modal-box">
            <div class="country-modal-header">
                <div class="country-title-pill"><i class="fa-solid fa-share"></i> <span>Forward Message To...</span></div>
                <button type="button" class="modal-close-btn" onclick="document.getElementById('zorenoForwardMsgModal').style.display='none'"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <div class="world-country-scroll-list">${targetsHtml}</div>
        </div>
    `;
    modal.style.display = "flex";
};

window.executeForwardToTarget = function (type, uid, name, avatar, username) {
    const meta = window._currentHoldMenuMeta;
    document.getElementById("zorenoForwardMsgModal").style.display = "none";
    if (!meta?.text) return;

    if (type === "ai") {
        openZorenoAIChat();
        const inp = document.getElementById("userInput");
        if (inp) { inp.value = meta.text; autoResizeChatInput(inp); sendMessage(); }
    } else if (uid) {
        openChatWithUser(uid, name, avatar, username);
        setTimeout(() => {
            const inp = document.getElementById("activeChatInput");
            if (inp) { inp.value = meta.text; sendRealtimeMessage(); }
        }, 250);
    }
};

// Re-bind 1-Second (850ms) Hold Timer on All Chat Bubbles
bindTwoSecondLongPressToAllBubbles = function () {
    document.querySelectorAll("#activeChatMessages .clean-right-bubble, #activeChatMessages .clean-left-bubble").forEach(bubble => {
        const rawClick = bubble.getAttribute("onclick") || "";
        if (rawClick.includes("promptDeleteMessage")) {
            const m = rawClick.match(/promptDeleteMessage\('([^']+)',\s*'([^']+)'\)/);
            bubble.removeAttribute("onclick");
            if (m) { bubble.dataset.msgId = m[1]; bubble.dataset.chatId = m[2]; }
        }
        if (bubble.dataset.holdV17 === "true") return;
        bubble.dataset.holdV17 = "true";
        let t = null;
        bubble.addEventListener("touchstart", (e) => {
            if (e.target.closest("img.sent-wide-photo, button")) return;
            t = setTimeout(() => {
                openBookHoldMenuForMessage(e, { isDm: true, msgId: bubble.dataset.msgId, chatId: bubble.dataset.chatId, text: bubble.innerText.replace(/\d{1,2}:\d{2}\s*(?:AM|PM)?/gi, "").trim() });
            }, 850); // 1-Second Fast Hold!
        }, { passive: true });
        bubble.addEventListener("touchend", () => clearTimeout(t));
        bubble.addEventListener("touchmove", () => clearTimeout(t));
        bubble.addEventListener("touchcancel", () => clearTimeout(t));
    });

    document.querySelectorAll("#chatMessages .clean-right-bubble, #chatMessages .clean-left-bubble").forEach((bubble, i) => {
        bubble.removeAttribute("onclick");
        if (bubble.dataset.holdV17 === "true") return;
        bubble.dataset.holdV17 = "true";
        let t = null;
        bubble.addEventListener("touchstart", (e) => {
            if (e.target.closest("button, a, img.sent-wide-photo, .ai-action-btns-wrap")) return;
            t = setTimeout(() => {
                openBookHoldMenuForMessage(e, { isAi: true, aiIdx: Math.max(0, Math.floor((i - 1) / 2)), text: bubble.innerText.replace(/Zoreno is AI can make mistakes/gi, "").trim() });
            }, 850); // 1-Second Fast Hold!
        }, { passive: true });
        bubble.addEventListener("touchend", () => clearTimeout(t));
        bubble.addEventListener("touchmove", () => clearTimeout(t));
        bubble.addEventListener("touchcancel", () => clearTimeout(t));
    });
};

// 6. Auto-Translate ALL 120+ Languages (French, Tamil, Spanish, Arabic, etc.) + Silent Boot (No Toast on Startup!)
const _v17OrigApplyLang = window.applyZorenoWorldLanguage;
window.applyZorenoWorldLanguage = async function (langCode, isSilentBoot = false) {
    const langObj = ZORENO_120_LANGUAGES.find(l => l.code === langCode) || ZORENO_120_LANGUAGES[0];
    localStorage.setItem("zorenoAppLangCode", langObj.code);
    localStorage.setItem("appLang", langObj.name);
    currentAppLang = langObj.name;

    const baseKey = langObj.code.split("-")[0];
    let d = ZORENO_FULL_TRANSLATIONS[baseKey];

    // If language is French, Tamil, Spanish, Arabic, etc. not hardcoded, live-translate the UI dictionary & cache it!
    if (!d) {
        const cachedDict = localStorage.getItem("zorenoLangDict_" + baseKey);
        if (cachedDict) {
            try { d = JSON.parse(cachedDict); } catch (e) {}
        }
        if (!d) {
            d = { ...ZORENO_FULL_TRANSLATIONS["en"] };
            try {
                const keys = Object.keys(d);
                const joined = keys.map(k => d[k]).join(" ||| ");
                const res = await fetch(`https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=${encodeURIComponent(langObj.code)}&dt=t&q=${encodeURIComponent(joined)}`);
                const data = await res.json();
                const translatedJoined = (data?.[0] || []).map(seg => seg[0]).join("");
                const parts = translatedJoined.split(/\s*\|\|\|\s*/);
                if (parts.length === keys.length) {
                    keys.forEach((k, idx) => { d[k] = parts[idx].trim(); });
                    localStorage.setItem("zorenoLangDict_" + baseKey, JSON.stringify(d));
                }
            } catch (err) {}
        }
    }

    ZORENO_FULL_TRANSLATIONS[baseKey] = d;
    await _v17OrigApplyLang(langCode);

    // Hide startup toast if called automatically during app boot (32712 Fix)
    if (isSilentBoot) {
        document.getElementById("zorenoCompactGlassToast")?.remove();
    }
};

// 7. Restore 4-Tab Bar Immediately When Search Input is Cleared or Closed + Add Usage Limit to Settings & 3-Dot Menu
function setupSearchRestoreAndUsageButton() {
    const sInp = document.getElementById("homeChatSearchInput");
    if (sInp) {
        const restoreNavIfCleared = () => {
            if (!sInp.value.trim()) {
                document.body.classList.remove("search-focused", "keyboard-open");
                const nav = document.getElementById("bottomNav");
                if (nav) nav.style.setProperty("display", "flex", "important");
            }
        };
        sInp.addEventListener("input", restoreNavIfCleared);
        sInp.addEventListener("search", restoreNavIfCleared);
        sInp.addEventListener("blur", () => {
            document.body.classList.remove("search-focused", "keyboard-open");
            const nav = document.getElementById("bottomNav");
            if (nav && document.getElementById("chatListScreen")?.style.display !== "none") {
                nav.style.setProperty("display", "flex", "important");
            }
        });
    }

    // Add "Usage Limit" Row inside Settings (DATA & STORAGE card)
    const dataCard = document.querySelector("#settingsScreen .data-card");
    if (dataCard && !document.getElementById("zorenoUsageLimitSettingRow")) {
        const uRow = document.createElement("div");
        uRow.className = "setting-item";
        uRow.id = "zorenoUsageLimitSettingRow";
        uRow.onclick = () => window.openZorenoUsageLimitModal();
        uRow.innerHTML = `
            <div class="setting-item-left">
                <div class="setting-icon" style="background:#8b5cf6; color:#ffffff;">
                    <i class="fa-solid fa-chart-pie"></i>
                </div>
                <div class="setting-text">
                    <h4>Usage Limit & Quota</h4>
                    <p>Check daily free chats & ad bonus</p>
                </div>
            </div>
            <div class="setting-item-right"><i class="fa-solid fa-chevron-right"></i></div>
        `;
        dataCard.insertBefore(uRow, dataCard.firstChild);
    }

    // Add "Usage Limit" inside AI 3-Dot Menu
    const aiMenu = document.getElementById("aiHeaderDropdownMenu");
    if (aiMenu && !aiMenu.innerHTML.includes("openZorenoUsageLimitModal")) {
        aiMenu.insertAdjacentHTML("afterbegin", `
            <button type="button" onclick="openZorenoUsageLimitModal()"><i class="fa-solid fa-chart-pie" style="color:#7c3aed;"></i> Usage Limit (Quota)</button>
        `);
    }

    // Simple Minimal Footer in Settings (32736 Fix)
    const footer = document.getElementById("zorenoTokoFooterBrand");
    if (footer) {
        footer.innerHTML = `
            <div style="font-size:12.5px; font-weight:700; color:#64748b;">
                Zoreno v1.0.6 • <a href="https://tokoplatforms.in" target="_blank" style="color:#64748b; text-decoration:none;">Toko Platforms</a>
            </div>
            <div style="margin-top:4px; font-size:11.5px;">
                <a href="https://tokoplatforms.in/privacy-policy.html" target="_blank" style="color:#2563eb; text-decoration:none; font-weight:600;">Privacy Policy</a>
                <span style="margin:0 6px; opacity:0.4;">•</span>
                <a href="javascript:void(0)" onclick="openPolicyModal('terms')" style="color:#2563eb; text-decoration:none; font-weight:600;">Terms</a>
            </div>
        `;
    }
}

window.addEventListener("DOMContentLoaded", () => {
    setTimeout(() => {
        restoreCleanZorenoAiHeader();
        setupSearchRestoreAndUsageButton();
        bindTwoSecondLongPressToAllBubbles();
        const savedLang = localStorage.getItem("zorenoAppLangCode");
        if (savedLang) {
            window.applyZorenoWorldLanguage(savedLang, true); // Silent boot = true (No popup on startup!)
        }
    }, 500);
});


// =========================================================
// ZORENO V18 MASTER JS:
// 1. REMOVE PURPLE "ZORENO AI" FROM WELCOME BUBBLE (32741 FIX)
// 2. BLOCK OLD DELETE MODAL & HIDE EMOJI BAR IN AI CHAT HOLD (32737/32738 FIX)
// 3. FROSTED GLASS USAGE LIMIT WITHOUT WATCH-AD BUTTON (32742 FIX)
// 4. 100% RELIABLE TRANSLATION FOR URDU & ALL 120+ LANGUAGES + POLICY TRANSLATION (32743 FIX)
// =========================================================

// 1. Permanently Disable Old Delete Modal Trigger so It Never Pops Up Over Hold Menu (32737 & 32738 Fix)
promptDeleteSingleAiMessage = function () {};
promptDeleteMessage = function () {};

// 2. Clean Welcome Message Inside AI Chat (Removes Purple "Zoreno AI" Box - 32741 Fix)
function cleanAiWelcomeBubbleHeader() {
    const firstBubble = document.querySelector("#chatMessages .msg-row-with-avatar:first-child .clean-left-bubble");
    if (!firstBubble) return;
    firstBubble.querySelector(".official-bubble-top-title")?.remove();
    const firstDiv = firstBubble.querySelector("div:first-child");
    if (firstDiv && firstDiv.textContent.includes("Zoreno AI")) {
        const timeSpan = firstDiv.querySelector("span")?.outerHTML || "";
        const pTxt = firstBubble.querySelector("p")?.innerText || "How can I help with your studies today?";
        firstBubble.innerHTML = `
            <div style="display:flex; align-items:flex-end; justify-content:space-between; gap:12px;">
                <span style="font-size:14px; font-weight:500;">${escapeHtml(pTxt)}</span>
                ${timeSpan}
            </div>
        `;
    }
}

const _v18OrigRenderAi = renderAiChatStream;
renderAiChatStream = function () {
    _v18OrigRenderAi();
    cleanAiWelcomeBubbleHeader();
    bindCleanOneSecondHoldMenu();
};

// 3. 1-Second Hold Menu: NO Emoji Bar in AI Chat (Only Action Menu), Emoji Bar Only in Friend DM (32738 Fix)
openBookHoldMenuForMessage = function (touchEvent, opts) {
    closeZorenoHoldMenu();
    const oldDelModal = document.getElementById("deleteMsgModal");
    if (oldDelModal) oldDelModal.style.setProperty("display", "none", "important");

    if (navigator.vibrate) navigator.vibrate(28);

    const wrap = document.createElement("div");
    wrap.id = "zorenoActiveHoldMenu";
    wrap.className = "zoreno-tg-hold-wrap";

    const clientX = touchEvent?.touches?.[0]?.clientX || touchEvent?.clientX || (window.innerWidth / 2);
    const clientY = touchEvent?.touches?.[0]?.clientY || touchEvent?.clientY || (window.innerHeight / 2);

    const leftPos = Math.min(window.innerWidth - 215, Math.max(14, clientX - 95));
    const topPos = Math.min(window.innerHeight - 230, Math.max(60, clientY - 40));
    wrap.style.left = leftPos + "px";
    wrap.style.top = topPos + "px";

    const tgEmojis = ["🫡", "🙏", "⚡", "👍", "🔥", "👏"];
    // Show Emoji Pill ONLY in Friend/Group DM Chat, NEVER in AI Chat!
    const emojiPillHtml = opts.isDm
        ? `<div class="zoreno-tg-emoji-pill">
               ${tgEmojis.map(em => `<button type="button" onclick="triggerHoldMenuEmoji('${em}', '${opts.msgId || ""}', '${opts.chatId || ""}')">${em}</button>`).join("")}
           </div>`
        : "";

    wrap.innerHTML = `
        ${emojiPillHtml}
        <div class="zoreno-tg-action-card">
            <button type="button" class="zoreno-hold-item" onclick="replyToHoldMenuMessage()">
                <i class="fa-solid fa-reply" style="color:#3b82f6;"></i>
                <span>${window._zLangDict?.replyBtn || "Reply"}</span>
            </button>
            <button type="button" class="zoreno-hold-item" onclick="copyHoldMenuMessageText()">
                <i class="fa-regular fa-copy" style="color:#8b5cf6;"></i>
                <span>${window._zLangDict?.copyBtn || "Copy"}</span>
            </button>
            <button type="button" class="zoreno-hold-item" onclick="openForwardMessageModal()">
                <i class="fa-solid fa-share" style="color:#10b981;"></i>
                <span>${window._zLangDict?.forwardBtn || "Forward"}</span>
            </button>
            <button type="button" class="zoreno-hold-item" style="color:#ef4444;" onclick="executeHoldMenuDelete()">
                <i class="fa-regular fa-trash-can"></i>
                <span>${window._zLangDict?.deleteBtn || "Delete"}</span>
            </button>
        </div>
    `;

    window._currentHoldMenuMeta = opts;
    document.body.appendChild(wrap);
};

// Clone Bubbles Cleanly to Strip Any Old V9/V15 Duplicate Touch Listeners!
function bindCleanOneSecondHoldMenu() {
    document.querySelectorAll("#chatMessages .clean-right-bubble, #chatMessages .clean-left-bubble").forEach((bubble, i) => {
        bubble.removeAttribute("onclick");
        if (bubble.dataset.cleanHoldV18 === "true") return;
        const fresh = bubble.cloneNode(true);
        fresh.dataset.cleanHoldV18 = "true";
        bubble.parentNode.replaceChild(fresh, bubble);

        let t = null;
        fresh.addEventListener("touchstart", (e) => {
            if (e.target.closest("button, a, img.sent-wide-photo, .ai-action-btns-wrap")) return;
            t = setTimeout(() => {
                openBookHoldMenuForMessage(e, {
                    isAi: true,
                    aiIdx: Math.max(0, Math.floor((i - 1) / 2)),
                    text: fresh.innerText.replace(/Zoreno is AI can make mistakes/gi, "").trim()
                });
            }, 800);
        }, { passive: true });
        fresh.addEventListener("touchend", () => clearTimeout(t));
        fresh.addEventListener("touchmove", () => clearTimeout(t));
        fresh.addEventListener("touchcancel", () => clearTimeout(t));
    });

    document.querySelectorAll("#activeChatMessages .clean-right-bubble, #activeChatMessages .clean-left-bubble").forEach(bubble => {
        const rawClick = bubble.getAttribute("onclick") || "";
        let mId = bubble.dataset.msgId || "";
        let cId = bubble.dataset.chatId || "";
        if (rawClick.includes("promptDeleteMessage")) {
            const m = rawClick.match(/promptDeleteMessage\('([^']+)',\s*'([^']+)'\)/);
            if (m) { mId = m[1]; cId = m[2]; }
        }
        bubble.removeAttribute("onclick");
        if (bubble.dataset.cleanHoldV18 === "true") return;
        const fresh = bubble.cloneNode(true);
        fresh.dataset.cleanHoldV18 = "true";
        fresh.dataset.msgId = mId;
        fresh.dataset.chatId = cId;
        bubble.parentNode.replaceChild(fresh, bubble);

        let t = null;
        fresh.addEventListener("touchstart", (e) => {
            if (e.target.closest("img.sent-wide-photo, button")) return;
            t = setTimeout(() => {
                openBookHoldMenuForMessage(e, {
                    isDm: true,
                    msgId: fresh.dataset.msgId,
                    chatId: fresh.dataset.chatId,
                    text: fresh.innerText.replace(/\d{1,2}:\d{2}\s*(?:AM|PM)?/gi, "").trim()
                });
            }, 800);
        }, { passive: true });
        fresh.addEventListener("touchend", () => clearTimeout(t));
        fresh.addEventListener("touchmove", () => clearTimeout(t));
        fresh.addEventListener("touchcancel", () => clearTimeout(t));
    });
}

const _v18OrigRenderDm = renderDmMessagesListToDOM;
renderDmMessagesListToDOM = function (chatId, messagesArray, myUid) {
    _v18OrigRenderDm(chatId, messagesArray, myUid);
    bindCleanOneSecondHoldMenu();
};

// 4. Professional Frosted Glass Usage Limit Card (Without Manual Watch-Ad Button + Translated - 32742 Fix)
window.openZorenoUsageLimitModal = async function () {
    closeAllDropdownMenus();
    let modal = document.getElementById("zorenoUsageLimitModal");
    if (!modal) {
        modal = document.createElement("div");
        modal.id = "zorenoUsageLimitModal";
        modal.className = "custom-modal-overlay";
        document.body.appendChild(modal);
    }
    modal.style.setProperty("z-index", "2147483647", "important");

    const usedToday = getLocalDailyAiCount();
    const baseDailyLimit = userTier === 2 ? 90 : userTier === 1 ? 50 : 10;
    const currentTotalLimit = userTier === 2
        ? Math.max(90, getLocalDailyAiLimit())
        : userTier === 1
            ? Math.max(50, getLocalDailyAiLimit())
            : getLocalDailyAiLimit();
    const bonusUnlocked = Math.max(0, currentTotalLimit - baseDailyLimit);
    const remaining = Math.max(0, currentTotalLimit - usedToday);
    const percentUsed = Math.min(100, Math.round((usedToday / Math.max(1, currentTotalLimit)) * 100));

    const d = window._zLangDict || {};
    const titleStr = d.usageTitle || "AI Usage & Daily Quota";
    const activePlanLbl = d.activePlanLbl || "ACTIVE MEMBERSHIP";
    const planName = userTier === 2
        ? (d.proPlanName || "Zoreno Pro • 90 Chats / Day")
        : userTier === 1
            ? (d.plusPlanName || "Zoreno Plus • 50 Chats / Day")
            : (d.freePlanName || "Standard Tier • 10 Free Chats / Day");
    const resetNote = d.resetNote || "Quota resets automatically every midnight (12:00 AM)";
    const usedLbl = d.usedLbl || "Used Today";
    const remLbl = d.remLbl || "Available";
    const baseLbl = d.baseLbl || "Daily Base Quota";
    const bonusLbl = d.bonusLbl || "Rewarded Ad Bonus";
    const autoAdNote = d.autoAdNote || "When your daily quota reaches 0, a short ad prompt will appear automatically in chat to unlock +3 bonus messages.";
    const upgBtnTxt = d.upgBtnTxt || "Upgrade to Plus / Pro";

    modal.innerHTML = `
        <div class="custom-modal-box zoreno-frosted-modal-card" style="max-width:365px; text-align:left; padding:22px;">
            <div class="policy-modal-header" style="margin-bottom:14px;">
                <h3 style="display:flex; align-items:center; gap:9px; font-size:17.5px; font-weight:800; margin:0;">
                    <i class="fa-solid fa-chart-pie" style="color:#7c3aed;"></i>
                    <span>${escapeHtml(titleStr)}</span>
                </h3>
                <button type="button" class="modal-close-btn" onclick="document.getElementById('zorenoUsageLimitModal').style.display='none'">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            <div style="background:rgba(124,58,237,0.09); border:1px solid rgba(124,58,237,0.22); border-radius:18px; padding:14px; margin-bottom:16px;">
                <div style="font-size:10.5px; font-weight:800; color:#7c3aed; letter-spacing:0.5px;">${escapeHtml(activePlanLbl)}</div>
                <div style="font-size:15.5px; font-weight:800; margin-top:3px;">${escapeHtml(planName)}</div>
                <div style="font-size:11.5px; color:#64748b; margin-top:4px; font-weight:500;">${escapeHtml(resetNote)}</div>
            </div>

            <div style="margin-bottom:14px;">
                <div style="display:flex; justify-content:space-between; font-size:13.5px; font-weight:700; margin-bottom:7px;">
                    <span>${escapeHtml(usedLbl)}: ${usedToday} / ${currentTotalLimit}</span>
                    <span style="color:#10b981;">${remaining} ${escapeHtml(remLbl)}</span>
                </div>
                <div style="width:100%; height:9px; background:rgba(148,163,184,0.22); border-radius:8px; overflow:hidden;">
                    <div style="width:${percentUsed}%; height:100%; background:linear-gradient(90deg,#2563eb,#7c3aed); border-radius:8px; transition:width 0.3s ease;"></div>
                </div>
                <div style="display:flex; justify-content:space-between; font-size:11.5px; color:#64748b; margin-top:8px; font-weight:600;">
                    <span>${escapeHtml(baseLbl)}: ${baseDailyLimit}</span>
                    <span>${escapeHtml(bonusLbl)}: +${bonusUnlocked}</span>
                </div>
            </div>

            <div style="font-size:11.5px; color:#64748b; background:rgba(148,163,184,0.1); padding:10px 12px; border-radius:13px; line-height:1.45; margin-bottom:${userTier < 2 ? '14px' : '0'};">
                <i class="fa-solid fa-circle-info" style="color:#3b82f6; margin-right:4px;"></i> ${escapeHtml(autoAdNote)}
            </div>

            ${userTier < 2 ? `
            <button type="button" class="modal-submit-btn" style="background:linear-gradient(135deg,#2563eb,#7c3aed); font-weight:700;" onclick="document.getElementById('zorenoUsageLimitModal').style.display='none'; openSubscription();">
                <i class="fa-solid fa-crown" style="margin-right:6px;"></i> ${escapeHtml(upgBtnTxt)}
            </button>` : ""}
        </div>
    `;
    modal.style.display = "flex";
};

// 5. Translate Policy Modals (Terms, Privacy Policy, Refund) into Selected Language (32743 Fix)
const _v18OrigOpenPolicy = openPolicyModal;
openPolicyModal = async function (type) {
    _v18OrigOpenPolicy(type);
    const modalBox = document.querySelector("#policyModal .custom-modal-box");
    if (modalBox) modalBox.classList.add("zoreno-frosted-modal-card");

    const langCode = localStorage.getItem("zorenoAppLangCode") || "en-IN";
    const baseLang = langCode.split("-")[0];
    if (baseLang === "en") return;

    const titleEl = document.getElementById("policyModalTitle");
    const contentEl = document.getElementById("policyModalContent");
    const acceptBtn = document.querySelector("#policyModal .modal-submit-btn");
    if (!contentEl) return;

    const cacheKey = `zorenoPolicy_${type}_${baseLang}`;
    const cachedHtml = localStorage.getItem(cacheKey);
    if (cachedHtml) {
        try {
            const parsed = JSON.parse(cachedHtml);
            if (titleEl && parsed.title) titleEl.textContent = parsed.title;
            if (contentEl && parsed.body) contentEl.innerHTML = parsed.body;
            if (acceptBtn && parsed.btn) acceptBtn.textContent = parsed.btn;
            return;
        } catch (e) {}
    }

    try {
        const rawTitle = titleEl ? titleEl.textContent : "";
        const rawBtn = acceptBtn ? acceptBtn.textContent : "I Understand & Accept";
        const nodes = Array.from(contentEl.querySelectorAll("h3, p"));
        const linesToTranslate = [rawTitle, rawBtn, ...nodes.map(n => n.innerText.trim())];

        const translatedArr = await translateStringArrayViaGtx(linesToTranslate, baseLang);
        if (translatedArr && translatedArr.length === linesToTranslate.length) {
            if (titleEl) titleEl.textContent = translatedArr[0];
            if (acceptBtn) acceptBtn.textContent = translatedArr[1];
            nodes.forEach((n, idx) => {
                n.textContent = translatedArr[idx + 2];
            });
            localStorage.setItem(cacheKey, JSON.stringify({
                title: translatedArr[0],
                btn: translatedArr[1],
                body: contentEl.innerHTML
            }));
        }
    } catch (e) {}
};

// 6. Bulletproof Line-by-Line Translator for ALL 120+ Languages (Fixes Urdu, Tamil, French, Arabic, etc.)
async function translateStringArrayViaGtx(strArray, targetLang) {
    const queryText = strArray.map(s => s.replace(/\n/g, " ")).join("\n");
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=${encodeURIComponent(targetLang)}&dt=t&q=${encodeURIComponent(queryText)}`;
    const res = await fetch(url);
    const data = await res.json();
    const fullTranslated = (data?.[0] || []).map(seg => seg[0]).join("");
    return fullTranslated.split("\n").map(s => s.trim());
}

const MASTER_EN_DICTIONARY = {
    searchPh: "Search chats, @username or people...",
    sprintTitle: "Focus Sprint ⏱️",
    sprintSub: "Stay focused, keep the sprint alive!",
    tabAll: "All",
    tabUnread: "Unread",
    tabFriends: "Friends",
    tabGroups: "Groups",
    navChats: "Chats",
    navPro: "Premium",
    navTools: "Tools",
    navSettings: "Settings",
    setHeader: "Settings",
    setSub: "Customize your Zoreno experience",
    secApp: "APPEARANCE",
    darkTitle: "Dark Mode",
    darkSub: "Switch theme",
    eyeTitle: "Ultra Eye Protection",
    eyeSub: "Warm zero-strain reading colors",
    secReg: "REGION & CURRENCY",
    countryTitle: "Country / Currency",
    countrySub: "Select your region for pricing",
    langTitle: "Language",
    secLeg: "LEGAL & POLICIES",
    termsTitle: "Terms & Conditions",
    termsSub: "Usage rules & service terms",
    privTitle: "Privacy Policy",
    privSub: "How we protect your data",
    refTitle: "Refund & Cancellation",
    refSub: "Subscription refund rules",
    secData: "DATA & STORAGE",
    usageRowTitle: "Usage Limit & Quota",
    usageRowSub: "Check daily free chats & ad bonus",
    clearTitle: "Clear AI Chat",
    clearSub: "Delete saved AI conversation",
    logoutTitle: "Log Out",
    logoutSub: "Sign out from your account",
    delTitle: "Delete Account",
    delSub: "Permanently delete account & data",
    typePh: "Type a message...",
    editProf: "Edit Profile",
    saveBtn: "Save",
    usageTitle: "AI Usage & Daily Quota",
    activePlanLbl: "ACTIVE MEMBERSHIP",
    freePlanName: "Standard Tier • 10 Free Chats / Day",
    plusPlanName: "Zoreno Plus • 50 Chats / Day",
    proPlanName: "Zoreno Pro • 90 Chats / Day",
    resetNote: "Quota resets automatically every midnight (12:00 AM)",
    usedLbl: "Used Today",
    remLbl: "Available",
    baseLbl: "Daily Base Quota",
    bonusLbl: "Rewarded Ad Bonus",
    autoAdNote: "When your daily quota reaches 0, a short ad prompt will appear automatically in chat to unlock +3 bonus messages.",
    upgBtnTxt: "Upgrade to Plus / Pro",
    replyBtn: "Reply",
    copyBtn: "Copy",
    forwardBtn: "Forward",
    deleteBtn: "Delete"
};

window.applyZorenoWorldLanguage = async function (langCode, isSilentBoot = false) {
    const langObj = ZORENO_120_LANGUAGES.find(l => l.code === langCode) || ZORENO_120_LANGUAGES[0];
    localStorage.setItem("zorenoAppLangCode", langObj.code);
    localStorage.setItem("appLang", langObj.name);
    currentAppLang = langObj.name;

    const baseKey = langObj.code.split("-")[0];
    let d = { ...MASTER_EN_DICTIONARY };

    if (baseKey !== "en") {
        const cacheKey = "zorenoFullDictV18_" + langObj.code;
        const cached = localStorage.getItem(cacheKey);
        if (cached) {
            try { d = JSON.parse(cached); } catch (e) {}
        } else {
            try {
                const keys = Object.keys(MASTER_EN_DICTIONARY);
                const values = keys.map(k => MASTER_EN_DICTIONARY[k]);
                const translatedVals = await translateStringArrayViaGtx(values, langObj.code);
                if (translatedVals && translatedVals.length === keys.length) {
                    keys.forEach((k, idx) => {
                        if (translatedVals[idx]) d[k] = translatedVals[idx];
                    });
                    localStorage.setItem(cacheKey, JSON.stringify(d));
                }
            } catch (err) {
                console.warn("Translation fetch error:", err);
            }
        }
    }

    window._zLangDict = d;

    const setTxt = (sel, val) => { const el = document.querySelector(sel); if (el && val) el.textContent = val; };
    const setPh = (sel, val) => { const el = document.querySelector(sel); if (el && val) el.placeholder = val; };

    setPh("#homeChatSearchInput", d.searchPh);
    setTxt(".sprint-title", d.sprintTitle);
    setTxt(".sprint-subtitle", d.sprintSub);

    const hTabs = document.querySelectorAll(".chat-tabs .tab-btn");
    if (hTabs[0]) hTabs[0].textContent = d.tabAll;
    if (hTabs[1]) hTabs[1].textContent = d.tabUnread;
    if (hTabs[2]) hTabs[2].textContent = d.tabFriends;
    if (hTabs[3]) hTabs[3].textContent = d.tabGroups;

    const navSpans = document.querySelectorAll("#bottomNav .nav-item span");
    if (navSpans[0]) navSpans[0].textContent = d.navChats;
    if (navSpans[1]) navSpans[1].textContent = d.navPro;
    if (navSpans[2]) navSpans[2].textContent = d.navTools;
    if (navSpans[3]) navSpans[3].textContent = d.navSettings;

    setTxt("#settingsHeaderTitle", d.setHeader);
    setTxt("#settingsHeaderDesc", d.setSub);
    setTxt("#appearanceTitle", d.secApp);
    setTxt("#darkModeTitle", d.darkTitle);
    setTxt("#darkModeDesc", d.darkSub);

    const eyeH4 = document.querySelector('#settingsScreen .setting-item[onclick*="toggleEyeProtectionMode"] h4');
    const eyeP = document.querySelector('#settingsScreen .setting-item[onclick*="toggleEyeProtectionMode"] p');
    if (eyeH4) eyeH4.textContent = d.eyeTitle;
    if (eyeP) eyeP.textContent = d.eyeSub;

    setTxt("#regionTitle", d.secReg);
    setTxt("#countryTitle", d.countryTitle);
    setTxt("#countryDesc", d.countrySub);
    setTxt("#appLangSettingTitle", d.langTitle);
    setTxt("#appLangSettingSub", `${langObj.flag} ${langObj.name}`);

    setTxt("#legalTitle", d.secLeg);
    setTxt("#termsTitle", d.termsTitle);
    setTxt("#termsDesc", d.termsSub);
    setTxt("#privacyTitle", d.privTitle);
    setTxt("#privacyDesc", d.privSub);
    setTxt("#refundTitle", d.refTitle);
    setTxt("#refundDesc", d.refSub);

    const dataSecTitle = document.querySelectorAll("#settingsScreen .settings-section-title")[3];
    if (dataSecTitle) dataSecTitle.textContent = d.secData;

    setTxt("#zorenoUsageLimitSettingRow h4", d.usageRowTitle);
    setTxt("#zorenoUsageLimitSettingRow p", d.usageRowSub);
    setTxt("#clearHistoryTitle", d.clearTitle);
    setTxt("#clearHistoryDesc", d.clearSub);

    const logoutItem = document.querySelector('#settingsScreen .setting-item[onclick*="handleUserLogout"]');
    if (logoutItem) {
        const h4 = logoutItem.querySelector("h4");
        const p = logoutItem.querySelector("p");
        if (h4) h4.textContent = d.logoutTitle;
        if (p) p.textContent = d.logoutSub;
    }

    const delItem = document.querySelector('#settingsScreen .setting-item[onclick*="openDeleteAccountModal"]');
    if (delItem) {
        const h4 = delItem.querySelector("h4");
        const p = delItem.querySelector("p");
        if (h4) h4.textContent = d.delTitle;
        if (p) p.textContent = d.delSub;
    }

    setPh("#userInput", d.typePh);
    setPh("#activeChatInput", d.typePh);
    setTxt("#profileScreen .profile-header h2", d.editProf);
    setTxt("#profileSaveBtn", d.saveBtn);

    const modal = document.getElementById("zorenoWorldLangModal");
    if (modal) modal.style.display = "none";

    if (!isSilentBoot) {
        showCompactGlassToast(langObj.flag, langObj.name);
    }
};

window.addEventListener("DOMContentLoaded", () => {
    setTimeout(() => {
        cleanAiWelcomeBubbleHeader();
        bindCleanOneSecondHoldMenu();
        const savedLang = localStorage.getItem("zorenoAppLangCode");
        if (savedLang) {
            window.applyZorenoWorldLanguage(savedLang, true);
        }
    }, 550);
});

// =========================================================
// ZORENO V19 FINAL MASTER JS:
// 1. REAL WHATSAPP/TELEGRAM QUOTED REPLY BOX (NO "> " ARROW IN INPUT!)
// 2. FIX POLICY BUTTON LANGUAGE STICKING IN HINDI (32748/32749 FIX)
// 3. BLOCK STARTUP LANGUAGE POPUP FOREVER
// 4. ADD "RATE US ON GOOGLE PLAY ⭐" BUTTON IN SETTINGS
// =========================================================

let activePendingReplyObj = null;
let userManuallyClickedLanguage = false;

// 1. Block Any Automatic Language Toast on App Startup (Only Show When User Clicks in Modal!)
const _v19OrigToast = showCompactGlassToast;
showCompactGlassToast = function (iconHtml, titleText, subText = "") {
    const tStr = String(titleText || "");
    if (!userManuallyClickedLanguage && (tStr.startsWith("Language") || ZORENO_120_LANGUAGES.some(l => l.name === tStr))) {
        return; // Never show language popup on app startup!
    }
    _v19OrigToast(iconHtml, titleText, subText);
};

// 2. Real Quoted Reply System (Shows Reply Preview Bar Above Input & Renders Box Inside Bubble - 32744 & 32752 Fix)
function ensureReplyPreviewStripInInputs() {
    const configs = [
        { pillSel: "#inputAreaContainer .chat-input-pill", id: "aiReplyPreviewStrip" },
        { pillSel: "#activeChatScreen .chat-input-pill", id: "dmReplyPreviewStrip" }
    ];
    configs.forEach(cfg => {
        const pill = document.querySelector(cfg.pillSel);
        if (!pill || document.getElementById(cfg.id)) return;
        const strip = document.createElement("div");
        strip.id = cfg.id;
        strip.className = "zoreno-reply-preview-strip";
        strip.innerHTML = `
            <div class="zoreno-reply-preview-text">
                <strong class="r-sender">Replying to message</strong>
                <span class="r-text"></span>
            </div>
            <button type="button" class="zoreno-reply-cancel-btn" onclick="clearActiveReplyPreview()">
                <i class="fa-solid fa-xmark"></i>
            </button>
        `;
        pill.insertBefore(strip, pill.firstChild);
    });
}

window.clearActiveReplyPreview = function () {
    activePendingReplyObj = null;
    ["aiReplyPreviewStrip", "dmReplyPreviewStrip"].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.classList.remove("active");
    });
};

window.replyToHoldMenuMessage = function () {
    const meta = window._currentHoldMenuMeta;
    closeZorenoHoldMenu();
    if (!meta?.text) return;

    ensureReplyPreviewStripInInputs();
    const cleanQuote = meta.text
        .replace(/^>.*$/gm, "")
        .replace(/\s+/g, " ")
        .trim()
        .slice(0, 90);

    const senderTitle = meta.isAi ? "Zoreno AI" : (currentChatUserMeta?.name || "Message");
    activePendingReplyObj = {
        isAi: !!meta.isAi,
        sender: senderTitle,
        quote: cleanQuote
    };

    const stripId = meta.isAi ? "aiReplyPreviewStrip" : "dmReplyPreviewStrip";
    const strip = document.getElementById(stripId);
    if (strip) {
        strip.querySelector(".r-sender").textContent = senderTitle;
        strip.querySelector(".r-text").textContent = cleanQuote;
        strip.classList.add("active");
    }

    const targetInp = document.getElementById(meta.isAi ? "userInput" : "activeChatInput");
    if (targetInp) targetInp.focus();
};

// Format Any Message Containing Reply Metadata or Legacy '> "..."' into a Real Quoted Box!
function formatBubbleQuotedReplyBoxes(rootContainer) {
    if (!rootContainer) return;
    rootContainer.querySelectorAll(".clean-right-bubble, .clean-left-bubble").forEach(bubble => {
        if (bubble.dataset.replyFormatted === "true") return;
        bubble.dataset.replyFormatted = "true";

        const textDiv = Array.from(bubble.children).find(
            el => el.tagName === "DIV" && !el.classList.contains("sent-media-grid") && !el.classList.contains("bubble-meta-time") && !el.classList.contains("ai-bubble-bottom-bar")
        );
        if (!textDiv) return;

        const rawTxt = textDiv.textContent || "";
        // Match either [[REPLY:Sender|Quote]] or legacy > "Quote..." Body
        let match = rawTxt.match(/^\[\[REPLY:([^|]+)\|([^\]]+)\]\]\s*([\s\S]*)$/);
        let sender = "Reply";
        let quote = "";
        let mainBody = "";

        if (match) {
            sender = match[1].trim();
            quote = match[2].trim();
            mainBody = match[3].trim();
        } else {
            const legacyMatch = rawTxt.match(/^>\s*"([^"]+)"\s*([\s\S]*)$/);
            if (legacyMatch) {
                quote = legacyMatch[1].replace(/\.\.\.$/, "").trim();
                mainBody = legacyMatch[2].trim();
            }
        }

        if (quote) {
            textDiv.innerHTML = `
                <div class="zoreno-quoted-msg-box">
                    <span class="zoreno-quoted-sender">${escapeHtml(sender)}</span>
                    <span class="zoreno-quoted-snippet">${escapeHtml(quote)}</span>
                </div>
                <div style="font-size:14.2px; font-weight:600; line-height:1.4;">${escapeHtml(mainBody)}</div>
            `;
        }
    });
}

// Wrap Send Functions to Attach Quoted Reply Cleanly Without Showing Ugly Text in Input Box
const _v19OrigSendDm = sendRealtimeMessage;
sendRealtimeMessage = async function () {
    const inp = document.getElementById("activeChatInput");
    if (inp && activePendingReplyObj && !activePendingReplyObj.isAi && inp.value.trim()) {
        inp.value = `[[REPLY:${activePendingReplyObj.sender}|${activePendingReplyObj.quote}]] ${inp.value.trim()}`;
        clearActiveReplyPreview();
    }
    await _v19OrigSendDm();
};

const _v19OrigSendAi = sendMessage;
sendMessage = async function () {
    const inp = document.getElementById("userInput");
    if (inp && activePendingReplyObj && activePendingReplyObj.isAi && inp.value.trim()) {
        inp.value = `[[REPLY:${activePendingReplyObj.sender}|${activePendingReplyObj.quote}]] ${inp.value.trim()}`;
        clearActiveReplyPreview();
    }
    await _v19OrigSendAi();
};

const _v19OrigRenderDm = renderDmMessagesListToDOM;
renderDmMessagesListToDOM = function (chatId, messagesArray, myUid) {
    _v19OrigRenderDm(chatId, messagesArray, myUid);
    formatBubbleQuotedReplyBoxes(document.getElementById("activeChatMessages"));
};

const _v19OrigRenderAi = renderAiChatStream;
renderAiChatStream = function () {
    _v19OrigRenderAi();
    formatBubbleQuotedReplyBoxes(document.getElementById("chatMessages"));
};

// 3. Fix Policy Modal Button Staying in Hindi When Language Changes (32748 & 32749 Fix)
openPolicyModal = async function (type) {
    const modal = document.getElementById("policyModal");
    if (!modal) return;
    const modalBox = modal.querySelector(".custom-modal-box");
    if (modalBox) modalBox.classList.add("zoreno-frosted-modal-card");

    const titleEl = document.getElementById("policyModalTitle");
    const contentEl = document.getElementById("policyModalContent");
    const acceptBtn = modal.querySelector(".modal-submit-btn");

    // Always Reset to Fresh English Master First so Previous Language Never Sticks!
    const masterPolicies = {
        terms: {
            title: "Terms & Conditions",
            body: `<h3>1. Acceptance of Terms</h3><p>By accessing and using Zoreno (operated by Toko Platforms), you agree to comply with these Terms & Conditions and applicable app store policies.</p><h3>2. AI-Generated Content Disclaimer</h3><p>Zoreno uses advanced AI models to assist with study and general queries. Users can report any inappropriate AI response using the Feedback option in the chat menu.</p><h3>3. User-Generated Content (UGC) & Safety</h3><p>In direct messaging, abusive, spam, or illegal content is strictly prohibited. Users can Block and Report any user from the 3-dot chat menu.</p><h3>4. 30-Day Subscription Validity</h3><p>Zoreno Plus (50 chats/day) and Zoreno Pro (90 chats/day) remain active for 30 days from purchase via Google Play Billing or Razorpay.</p>`
        },
        privacy: {
            title: "Privacy Policy & Data Safety",
            body: `<h3>1. Information We Collect</h3><p>We collect basic account details (Name, Email, Username, optional Profile Photo) and chat messages via Google Firebase to provide real-time sync.</p><h3>2. Data Storage & Security</h3><p>All data is transmitted over encrypted HTTPS/TLS connections and stored on Google Firebase servers.</p><h3>3. Account & Data Deletion</h3><p>You can permanently delete your account and all associated data anytime directly from Settings -> Delete Account.</p>`
        },
        refund: {
            title: "Refund & Cancellation Policy",
            body: `<h3>1. Subscription Validity & Cancellation</h3><p>Purchased plans are active for 30 days. You may manage or cancel renewals anytime through Google Play Subscriptions or support.</p><h3>2. Payment Issues</h3><p>If payment is deducted without plan activation, contact support with your transaction ID for immediate resolution.</p>`
        }
    };

    const basePolicy = masterPolicies[type];
    if (!basePolicy) return;

    if (titleEl) titleEl.textContent = basePolicy.title;
    if (contentEl) contentEl.innerHTML = basePolicy.body;
    if (acceptBtn) acceptBtn.textContent = "I Understand & Accept";
    modal.style.display = "flex";

    const langCode = localStorage.getItem("zorenoAppLangCode") || "en-IN";
    const baseLang = langCode.split("-")[0];
    if (baseLang === "en") return;

    try {
        const nodes = Array.from(contentEl.querySelectorAll("h3, p"));
        const linesToTranslate = [basePolicy.title, "I Understand & Accept", ...nodes.map(n => n.innerText.trim())];
        const translatedArr = await translateStringArrayViaGtx(linesToTranslate, langCode);
        if (translatedArr && translatedArr.length === linesToTranslate.length) {
            if (titleEl) titleEl.textContent = translatedArr[0];
            if (acceptBtn) acceptBtn.textContent = translatedArr[1];
            nodes.forEach((n, idx) => { n.textContent = translatedArr[idx + 2]; });
        }
    } catch (e) {}
};

// 4. Add "Rate & Review on Google Play ⭐" Button in Settings & Track Manual Language Click
function injectPlayStoreRatingButtonInSettings() {
    const legalCard = document.querySelector("#settingsScreen .legal-card");
    if (legalCard && !document.getElementById("zorenoRateAppRow")) {
        const rateRow = document.createElement("div");
        rateRow.className = "setting-item";
        rateRow.id = "zorenoRateAppRow";
        rateRow.onclick = () => {
            window.open("https://play.google.com/store/apps/details?id=com.zoreno.app", "_blank");
        };
        rateRow.innerHTML = `
            <div class="setting-item-left">
                <div class="setting-icon" style="background:#f59e0b; color:#ffffff;">
                    <i class="fa-solid fa-star"></i>
                </div>
                <div class="setting-text">
                    <h4 id="rateAppSettingTitle">Rate Us on Google Play</h4>
                    <p id="rateAppSettingDesc">Love Zoreno? Leave a 5-star review ⭐</p>
                </div>
            </div>
            <div class="setting-item-right"><i class="fa-solid fa-up-right-from-square" style="font-size:14px;"></i></div>
        `;
        legalCard.appendChild(rateRow);
    }
}

document.addEventListener("click", (e) => {
    if (e.target.closest("#zorenoWorldLangModal .world-country-option")) {
        userManuallyClickedLanguage = true;
        setTimeout(() => { userManuallyClickedLanguage = false; }, 2000);
    }
}, true);

window.addEventListener("DOMContentLoaded", () => {
    setTimeout(() => {
        ensureReplyPreviewStripInInputs();
        injectPlayStoreRatingButtonInSettings();
        formatBubbleQuotedReplyBoxes(document.getElementById("chatMessages"));
        formatBubbleQuotedReplyBoxes(document.getElementById("activeChatMessages"));
    }, 600);
});


// =========================================================
// ZORENO V20 FINAL MASTER JS:
// 1. INSTANT ONE-TAP CLEAR CHAT WITH SMALL BOTTOM PILL (32754 FIX)
// 2. SHORT "COMING SOON" CALL PILL THAT NEVER CUTS OFF (32758 FIX)
// 3. CANCEL FRIEND INVITATION & UNFRIEND SYSTEM (PROFILE + 3-DOT MENU - 32753/32755)
// 4. EXECUTIVE MINIMALIST SHARE CARD & CORPORATE WHATSAPP CAPTION (32757 FIX)
// =========================================================

// 1. Short Crisp Call Coming Soon Pill (Never Overflows - 32758 Fix)
showCallComingSoon = function () {
    showCompactGlassToast("📞", "Coming Soon");
};
triggerZorenoAudioCall = function () { showCallComingSoon(); };
triggerZorenoVideoCall = function () { showCallComingSoon(); };

// 2. Instant Clear Chat (Clears Immediately on Click + Shows Small Bottom Pill - 32754 Fix)
clearAllChatHistory = async function () {
    closeAllDropdownMenus();
    aiChatMessagesList = [];
    localStorage.removeItem("zorenoAiChatStream");
    renderAiChatStream();

    const homePreview = document.getElementById("zorenoHomeLastPreview");
    if (homePreview) homePreview.textContent = "Tap to start chatting with your AI partner";

    if (db && auth?.currentUser) {
        try {
            const snap = await db.collection("users").doc(auth.currentUser.uid).collection("chats").get();
            const batch = db.batch();
            snap.forEach(d => batch.delete(d.ref));
            await batch.commit();
        } catch (e) {}
    }
    showCompactGlassToast("✓", "Chat cleared");
};

clearCurrentAiChat = function () {
    clearAllChatHistory();
};

clearCurrentDmChat = async function () {
    closeAllDropdownMenus();
    if (!currentChatUserId) return;
    const myUid = auth?.currentUser?.uid || "local";
    const chatId = currentChatIsGroup
        ? currentChatUserId
        : (myUid < currentChatUserId ? `${myUid}_${currentChatUserId}` : `${currentChatUserId}_${myUid}`);

    chatClearedAtMap[chatId] = Date.now();
    try { localStorage.setItem("zorenoChatClearedAtMap", JSON.stringify(chatClearedAtMap)); } catch (e) {}

    let cachedMsgs = [];
    try { cachedMsgs = JSON.parse(localStorage.getItem(`zorenoDmCache_${chatId}`) || "[]"); } catch (e) {}
    renderDmMessagesListToDOM(chatId, cachedMsgs, myUid);
    showCompactGlassToast("✓", "Chat cleared");
};

// 3. Full Friend Lifecycle: Add Friend -> Cancel Request -> Unfriend (Profile & 3-Dot Menu - 32753 & 32755 Fix)
async function checkPendingOutgoingRequestForCurrentChat() {
    if (!db || !auth?.currentUser || !currentChatUserId || currentChatIsGroup) return;
    try {
        const snap = await db.collection("friendRequests")
            .where("fromUid", "==", auth.currentUser.uid)
            .where("toUid", "==", currentChatUserId)
            .where("status", "==", "pending")
            .get();
        if (!snap.empty) {
            outgoingFriendReqsMap[currentChatUserId] = snap.docs[0].id;
        } else {
            delete outgoingFriendReqsMap[currentChatUserId];
        }
        syncMakeFriendButtonUI();
    } catch (e) {}
}

syncMakeFriendButtonUI = function () {
    const fpBtn = document.getElementById("fpMakeFriendBtn");
    const menuBtn = document.getElementById("dmFriendActionMenuBtn");
    if (!currentChatUserId || currentChatIsGroup) return;

    const uid = currentChatUserId;
    if (myFriendsMap && myFriendsMap[uid]) {
        if (fpBtn) {
            fpBtn.innerHTML = `<i class="fa-solid fa-user-minus" style="color:#ef4444;"></i><span style="color:#ef4444;">Unfriend</span>`;
        }
        if (menuBtn) {
            menuBtn.innerHTML = `<i class="fa-solid fa-user-minus" style="color:#ef4444;"></i> Unfriend`;
        }
    } else if (outgoingFriendReqsMap && outgoingFriendReqsMap[uid]) {
        if (fpBtn) {
            fpBtn.innerHTML = `<i class="fa-solid fa-xmark" style="color:#f59e0b;"></i><span style="color:#f59e0b;">Cancel Req</span>`;
        }
        if (menuBtn) {
            menuBtn.innerHTML = `<i class="fa-solid fa-xmark" style="color:#f59e0b;"></i> Cancel Invitation`;
        }
    } else {
        if (fpBtn) {
            fpBtn.innerHTML = `<i class="fa-solid fa-user-plus" style="color:#10b981;"></i><span style="color:#10b981;">Add Friend</span>`;
        }
        if (menuBtn) {
            menuBtn.innerHTML = `<i class="fa-solid fa-user-plus" style="color:#10b981;"></i> Add as Friend`;
        }
    }
};

handleMakeAsFriendClick = async function () {
    closeAllDropdownMenus();
    if (!currentChatUserId || currentChatIsGroup || !db || !auth?.currentUser) return;
    const myUid = auth.currentUser.uid;
    const targetUid = currentChatUserId;
    const targetName = currentChatUserMeta?.name || "User";

    // CASE A: Already Friends -> Unfriend
    if (myFriendsMap && myFriendsMap[targetUid]) {
        delete myFriendsMap[targetUid];
        localStorage.setItem("zorenoFriendsMap", JSON.stringify(myFriendsMap));
        syncMakeFriendButtonUI();
        scheduleRenderSavedDmChats();
        try {
            await db.collection("users").doc(myUid).set({
                friendsMap: { [targetUid]: firebase.firestore.FieldValue.delete() }
            }, { merge: true });
            await db.collection("users").doc(targetUid).set({
                friendsMap: { [myUid]: firebase.firestore.FieldValue.delete() }
            }, { merge: true });
        } catch (e) {}
        showCompactGlassToast("✓", `Unfriended ${targetName}`);
        return;
    }

    // CASE B: Invitation Already Pending -> Cancel Request
    if (outgoingFriendReqsMap && outgoingFriendReqsMap[targetUid]) {
        const reqDocId = outgoingFriendReqsMap[targetUid];
        delete outgoingFriendReqsMap[targetUid];
        syncMakeFriendButtonUI();
        try {
            if (typeof reqDocId === "string" && reqDocId.length > 3) {
                await db.collection("friendRequests").doc(reqDocId).delete();
            } else {
                const snap = await db.collection("friendRequests")
                    .where("fromUid", "==", myUid)
                    .where("toUid", "==", targetUid)
                    .get();
                snap.forEach(d => d.ref.delete());
            }
        } catch (e) {}
        showCompactGlassToast("✕", "Friend request cancelled");
        return;
    }

    // CASE C: Send New Friend Request
    try {
        outgoingFriendReqsMap[targetUid] = true;
        syncMakeFriendButtonUI();
        const docRef = await db.collection("friendRequests").add({
            fromUid: myUid,
            fromName: userName || "Student",
            fromUsername: currentUsername || "@student",
            fromAvatar: getSafeAvatar(userAvatarUrl),
            toUid: targetUid,
            status: "pending",
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        outgoingFriendReqsMap[targetUid] = docRef.id;
        syncMakeFriendButtonUI();
        showCompactGlassToast("✓", `Request sent to ${targetName}`);
    } catch (e) {}
};

// Update DM 3-Dot Menu with Dynamic Friend / Cancel / Unfriend Button ID
const _v20OrigOpenChat = openChatWithUser;
openChatWithUser = function (userId, targetName, targetAvatar, targetUsername) {
    _v20OrigOpenChat(userId, targetName, targetAvatar, targetUsername);
    const dmMenu = document.getElementById("dmHeaderDropdownMenu");
    if (dmMenu) {
        const addBtn = dmMenu.querySelector('button[onclick*="handleMakeAsFriendClick"]');
        if (addBtn) addBtn.id = "dmFriendActionMenuBtn";
    }
    syncMakeFriendButtonUI();
    checkPendingOutgoingRequestForCurrentChat();
};

// 4. Executive Minimalist Share Card & Clean Corporate WhatsApp Caption (No Rockets or Flashy Boxes - 32757 Fix)
createZorenoAnswerImageCard = async function (questionText, answerText) {
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    const width = 960;
    const cleanAns = answerText.replace(/\*\*/g, "").trim();

    ctx.font = "500 26px -apple-system, BlinkMacSystemFont, 'Plus Jakarta Sans', sans-serif";
    const maxLineWidth = width - 160;
    const rawLines = cleanAns.split("\n");
    const wrappedLines = [];

    rawLines.forEach(para => {
        const trimmed = para.trim();
        if (!trimmed) return;
        const words = trimmed.split(/\s+/);
        let currentLine = "";
        words.forEach(w => {
            const testLine = currentLine ? currentLine + " " + w : w;
            if (ctx.measureText(testLine).width > maxLineWidth) {
                if (currentLine) wrappedLines.push(currentLine);
                currentLine = w;
            } else {
                currentLine = testLine;
            }
        });
        if (currentLine) wrappedLines.push(currentLine);
    });

    const displayLines = wrappedLines.slice(0, 15);
    if (wrappedLines.length > 15) displayLines.push("...");

    const cardHeight = Math.max(500, 250 + displayLines.length * 42 + 110);
    canvas.width = width;
    canvas.height = cardHeight;

    // 1. Deep Matte Slate Background
    ctx.fillStyle = "#090d16";
    ctx.fillRect(0, 0, width, cardHeight);

    // 2. Elevated Inner Dark-Glass Card with Subtle Border
    ctx.fillStyle = "#111827";
    ctx.strokeStyle = "rgba(255, 255, 255, 0.12)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(44, 44, width - 88, cardHeight - 88, 28);
    ctx.fill();
    ctx.stroke();

    // 3. Minimalist Brand Header
    ctx.fillStyle = "#f8fafc";
    ctx.font = "800 30px -apple-system, sans-serif";
    ctx.fillText("Zoreno AI", 84, 108);

    ctx.fillStyle = "#64748b";
    ctx.font = "600 19px -apple-system, sans-serif";
    ctx.fillText("Toko Platforms", width - 225, 106);

    if (questionText) {
        ctx.fillStyle = "#94a3b8";
        ctx.font = "600 21px -apple-system, sans-serif";
        const qShort = questionText.replace(/^\[.*?\]\s*/, "").slice(0, 62);
        ctx.fillText(qShort + (questionText.length > 62 ? "..." : ""), 84, 146);
    }

    // Subtle Divider Line
    ctx.strokeStyle = "rgba(255, 255, 255, 0.08)";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(84, 170);
    ctx.lineTo(width - 84, 170);
    ctx.stroke();

    // 4. Clean Crisp Answer Body
    ctx.fillStyle = "#f1f5f9";
    ctx.font = "500 25px -apple-system, sans-serif";
    let y = 218;
    displayLines.forEach(line => {
        ctx.fillText(line, 84, y);
        y += 40;
    });

    // 5. Minimalist Corporate Footer
    const footerY = cardHeight - 86;
    ctx.strokeStyle = "rgba(255, 255, 255, 0.08)";
    ctx.beginPath();
    ctx.moveTo(84, footerY - 26);
    ctx.lineTo(width - 84, footerY - 26);
    ctx.stroke();

    ctx.fillStyle = "#94a3b8";
    ctx.font = "600 19px -apple-system, sans-serif";
    ctx.fillText("zoreno.app  •  Available on Google Play", 84, footerY + 6);

    return canvas.toDataURL("image/png");
};

shareAiResponseText = async function (idx) {
    const pair = aiChatMessagesList[idx];
    const rawBot = cleanLatexToNotebookMath(pair?.bot || "");
    if (!rawBot) return;
    const cleanAnswer = rawBot.replace(/\*\*/g, "").trim();
    const playUrl = "https://play.google.com/store/apps/details?id=com.zoreno.app";

    // Clean, Minimalist Corporate Caption (No Rocket Emojis!)
    const shareCaption = `${cleanAnswer}\n\n— Shared via Zoreno AI\n${playUrl}`;

    try {
        const dataUrl = await createZorenoAnswerImageCard(pair?.user || "", cleanAnswer);

        if (window.AndroidShare && typeof window.AndroidShare.shareImageAndText === "function") {
            window.AndroidShare.shareImageAndText(dataUrl, shareCaption);
            return;
        }

        if (navigator.canShare && navigator.share) {
            const res = await fetch(dataUrl);
            const blob = await res.blob();
            const imageFile = new File([blob], "Zoreno_AI.png", { type: "image/png" });
            if (navigator.canShare({ files: [imageFile] })) {
                await navigator.share({
                    title: "Zoreno AI",
                    text: shareCaption,
                    files: [imageFile]
                });
                return;
            }
        }
    } catch (err) {}

    if (window.AndroidShare && typeof window.AndroidShare.shareText === "function") {
        window.AndroidShare.shareText(shareCaption);
        return;
    }
    if (navigator.share) {
        try { await navigator.share({ title: "Zoreno AI", text: shareCaption, url: playUrl }); return; } catch (e) {}
    }
};
