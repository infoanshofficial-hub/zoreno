// =========================================================
// ZORENO APP.JS — PART 1 OF 3 (ZERO ERRORS VERSION)
// CONFIG, GUARDRAILS, COUNTRIES, FIREBASE, SUBS, AUTH & PROFILE
// =========================================================

const firebaseConfig = {
    apiKey: "AIzaSyCJDkWOq9LXX_zG5uPE60P_NiZ4r9wTUJM",
    authDomain: "zeraai-ans.firebaseapp.com",
    projectId: "zeraai-ans",
    storageBucket: "zeraai-ans.firebasestorage.app",
    messagingSenderId: "315803761947",
    appId: "1:315803761947:web:e9098ce69e48c56b78a7be",
    measurementId: "G-PS4DP24WBT"
};

const GOOGLE_CLIENT_ID = "205788450312-ljp89u7m3q7ptpsad8r2vaga3t3bidj6.apps.googleusercontent.com";
const RAZORPAY_KEY_ID = "rzp_live_TYfeuDd2b9eh85";
const GEMINI_API_KEY = "AQ.Ab8RN6JD9hPTj4ql1TKnZiiYYtgv48XVsjnBdGSKXcga0gs5wA";

const ZORENO_AI_MODEL = "gemini-3.5-flash-lite";
const ZORENO_FALLBACK_MODELS = ["gemini-3.5-flash-lite"];

const DEFAULT_AVATAR_URL = "default_avatar.png";

const PLAY_BILLING_SKUS = {
    1: "zoreno_plus_monthly",
    2: "zoreno_pro_monthly"
};

const ADS_CONFIG = {
    admobAppId: "ca-app-pub-5825754850490611~6362976717",
    admobRewardedUnitId: "ca-app-pub-5825754850490611/4904670790",
    adsenseClientId: "ca-pub-5825754850490611"
};

const SUBSCRIPTION_VALIDITY_MS = 30 * 24 * 60 * 60 * 1000;

// ================= SYSTEM GUARDRAIL =================
const SYSTEM_INSTRUCTION = `You are Zoreno, a smart, friendly AI study partner and daily assistant.
CREATOR & IDENTITY: You were created and developed by Achyut Tiwari under the parent company Toko Platforms Private Limited. Mention this only when the user asks who created you, who your founder/developer is, or about your company.
STRICT LANGUAGE, MEMORY & FORMATTING RULES:
1. NO REPEATED GREETINGS: NEVER start every reply with "Hello!", "Hello again!", "Hi!", or "Hey dost!". Start directly with the topic or answer in sentence 1.
2. STRICT LANGUAGE MIRRORING: Always reply in the EXACT language and script the user writes in (English, Hindi, or Hinglish).
3. STRUCTURED POINT-WISE FORMAT:
   - Write a direct 1-2 line opening about the topic.
   - Present key steps or points as numbered items like:
     1. Heading Title: Clear explanation underneath.
     2. Heading Title: Clear explanation underneath.
   - NEVER cut off a sentence in the middle. Always complete all points and end with a complete concluding sentence. If a chapter/topic is very long, explain the core points completely first and ask if the student wants to continue to the next part.
4. EDUCATIONAL BIOLOGY, HEALTH & LIFESTYLE ALLOWED: Answer questions about Biology (including tissues, reproduction, anatomy), personal health, mental health, and lifestyle helpfully.
5. CODING RULE: Only if the user explicitly asks to write programming code (HTML/JS/Python/C++/Java), politely decline.
6. STRICT SAFETY POLICY: Refuse queries about making bombs, weapons, murder, suicide, self-harm encouragement, hacking, or illegal crimes.
7. CONTINUOUS CONVERSATION MEMORY: Always remember the ongoing study chapter or topic from previous messages and continue seamlessly.`;


function checkQueryGuardrails(rawText) {
    const q = (rawText || "").toLowerCase();
    const unsafeRegex = /\b(make a bomb|how to make bomb|rdx|ied explosive|terrorist attack|how to murder|kill someone|commit suicide|how to die|make poison|hack bank|child abuse)\b|बम कैसे बनाएं|मर्डर कैसे/i;
    if (unsafeRegex.test(q)) {
        return {
            blocked: true,
            reply: "⚠️ **Safety Alert:** I cannot assist with dangerous, violent, or illegal activities. Please ask about studies, health, or safe daily topics."
        };
    }
    const codingRegex = /\b(write a code|write code|html code|javascript code|python code|java code|c\+\+ code|source code|program banao|code likho)\b/i;
    if (codingRegex.test(q)) {
        return {
            blocked: true,
            reply: "🚫 **Coding Disabled:** Programming code generation is currently turned off in Zoreno. Feel free to ask about any study subject, presentation, health, or general knowledge!"
        };
    }
    return { blocked: false };
}

function isHealthOrMedicalQuery(rawText) {
    const q = (rawText || "").toLowerCase();
    return /\b(health|doctor|medicine|tablet|symptom|fever|stomach|pain|ache|headache|panic attack|anxiety|depression|vomiting|diarrhea|disease|infection|blood pressure|diabetes|pregnancy|period|reproduction|sex|sexual|hiv|std|allergy|bukhar|pet kharab|dard|tabiyat|dawa|bimari|ilaj)\b/i.test(q);
}

function getSafeAvatar(url) {
    if (!url || typeof url !== "string") return DEFAULT_AVATAR_URL;
    if (url.includes("i.pravatar.cc")) return DEFAULT_AVATAR_URL;
    return url;
}

// ================= GLOBAL STATE VARIABLES =================
let db = null, auth = null, firebaseReadyPromise = null;
let incomingChatsUnsub = null;
let presenceHeartbeatTimer = null;
let currentAppLang = localStorage.getItem("appLang") || "English";
let currentCountry = localStorage.getItem("manualCountry") || "IN";
let isLoggedIn = localStorage.getItem("isLoggedIn") === "true";
let userTier = parseInt(localStorage.getItem("userTier")) || 0;
let subExpiresAtMs = parseInt(localStorage.getItem("subExpiresAtMs")) || 0;
let selectedTierLevel = userTier === 1 ? 2 : 1;
let selectedAmount = 249;

let userName = localStorage.getItem("userName") || "Student";
let userEmail = localStorage.getItem("userEmail") || "";
let userAvatarUrl = getSafeAvatar(localStorage.getItem("userAvatarUrl"));
let currentUsername = localStorage.getItem("username") || "";
let currentBio = localStorage.getItem("userBio") || "Learning. Creating. Improving. A better version, every day.";

let aiChatMessagesList = [];
try { aiChatMessagesList = JSON.parse(localStorage.getItem("zorenoAiChatStream") || "[]"); } catch (e) { aiChatMessagesList = []; }

let pendingAiAttachments = [];
let pendingDmAttachment = null;

let currentChatUserId = null;
let currentChatUserMeta = null;
let activeMessagesUnsubscribe = null;
let activeFriendProfileUnsub = null;
let activeChatMetaUnsub = null;
let isFriendCurrentlyTyping = false;
let typingTimeoutTimer = null;
let currentActiveChatTab = "all";
let msgToDeleteId = null;
let msgToDeleteChatId = null;
let aiMsgIndexToDelete = null;

let lastReadAtMap = {};
try { lastReadAtMap = JSON.parse(localStorage.getItem("zorenoLastReadAtMap") || "{}"); } catch (e) { lastReadAtMap = {}; }

let deletedMsgsMap = {};
try { deletedMsgsMap = JSON.parse(localStorage.getItem("zorenoDeletedMsgsMap") || "{}"); } catch (e) { deletedMsgsMap = {}; }

let chatClearedAtMap = {};
try { chatClearedAtMap = JSON.parse(localStorage.getItem("zorenoChatClearedAtMap") || "{}"); } catch (e) { chatClearedAtMap = {}; }

let recentDmUsers = [];
try {
    recentDmUsers = JSON.parse(localStorage.getItem("zorenoRecentDms") || "[]").filter(u => {
        if (!u || !u.uid || u.uid === "arjun_user_id") return false;
        const un = (u.username || "").toLowerCase();
        const nm = (u.name || "").toLowerCase();
        if (un === "@friend" || un === "@user" || nm === "friend" || nm === "user") return false;
        u.avatar = getSafeAvatar(u.avatar);
        return true;
    });
    localStorage.setItem("zorenoRecentDms", JSON.stringify(recentDmUsers));
} catch (e) { recentDmUsers = []; }

let blockedUsersMap = {};
try { blockedUsersMap = JSON.parse(localStorage.getItem("zorenoBlockedUsers") || "{}"); } catch (e) { blockedUsersMap = {}; }

let currentSearchQuery = "";
let currentSearchOffset = 0;
let hasMoreSearchResults = true;
let isSearchLoading = false;

// ================= 195+ WORLD COUNTRIES FULL LIST =================
const RAW_WORLD_COUNTRIES = [
    "IN|🇮🇳|India|INR (₹)", "US|🇺🇸|United States|USD ($)", "GB|🇬🇧|United Kingdom|USD ($)", "CA|🇨🇦|Canada|USD ($)", "AU|🇦🇺|Australia|USD ($)",
    "AE|🇦🇪|United Arab Emirates|USD ($)", "AF|🇦🇫|Afghanistan|USD ($)", "AL|🇦🇱|Albania|USD ($)", "DZ|🇩🇿|Algeria|USD ($)", "AD|🇦🇩|Andorra|USD ($)",
    "AO|🇦🇴|Angola|USD ($)", "AG|🇦🇬|Antigua & Barbuda|USD ($)", "AR|🇦🇷|Argentina|USD ($)", "AM|🇦🇲|Armenia|USD ($)", "AT|🇦🇹|Austria|USD ($)",
    "AZ|🇦🇿|Azerbaijan|USD ($)", "BS|🇧🇸|Bahamas|USD ($)", "BH|🇧🇭|Bahrain|USD ($)", "BD|🇧🇩|Bangladesh|USD ($)", "BB|🇧🇧|Barbados|USD ($)",
    "BY|🇧🇾|Belarus|USD ($)", "BE|🇧🇪|Belgium|USD ($)", "BZ|🇧🇿|Belize|USD ($)", "BJ|🇧🇯|Benin|USD ($)", "BT|🇧🇹|Bhutan|USD ($)",
    "BO|🇧🇴|Bolivia|USD ($)", "BA|🇧🇦|Bosnia & Herzegovina|USD ($)", "BW|🇧🇼|Botswana|USD ($)", "BR|🇧🇷|Brazil|USD ($)", "BN|🇧🇳|Brunei|USD ($)",
    "BG|🇧🇬|Bulgaria|USD ($)", "BF|🇧🇫|Burkina Faso|USD ($)", "BI|🇧🇮|Burundi|USD ($)", "KH|🇰🇭|Cambodia|USD ($)", "CM|🇨🇲|Cameroon|USD ($)",
    "CV|🇨🇻|Cape Verde|USD ($)", "CF|🇨🇫|Central African Republic|USD ($)", "TD|🇹🇩|Chad|USD ($)", "CL|🇨🇱|Chile|USD ($)", "CN|🇨🇳|China|USD ($)",
    "CO|🇨🇴|Colombia|USD ($)", "KM|🇰🇲|Comoros|USD ($)", "CG|🇨🇬|Congo|USD ($)", "CR|🇨🇷|Costa Rica|USD ($)", "HR|🇭🇷|Croatia|USD ($)",
    "CU|🇨🇺|Cuba|USD ($)", "CY|🇨🇾|Cyprus|USD ($)", "CZ|🇨🇿|Czech Republic|USD ($)", "DK|🇩🇰|Denmark|USD ($)", "DJ|🇩🇯|Djibouti|USD ($)",
    "DM|🇩🇲|Dominica|USD ($)", "DO|🇩🇴|Dominican Republic|USD ($)", "EC|🇪🇨|Ecuador|USD ($)", "EG|🇪🇬|Egypt|USD ($)", "SV|🇸🇻|El Salvador|USD ($)",
    "GQ|🇬🇶|Equatorial Guinea|USD ($)", "ER|🇪🇷|Eritrea|USD ($)", "EE|🇪🇪|Estonia|USD ($)", "SZ|🇸🇿|Eswatini|USD ($)", "ET|🇪🇹|Ethiopia|USD ($)",
    "FJ|🇫🇯|Fiji|USD ($)", "FI|🇫🇮|Finland|USD ($)", "FR|🇫🇷|France|USD ($)", "GA|🇬🇦|Gabon|USD ($)", "GM|🇬🇲|Gambia|USD ($)",
    "GE|🇬🇪|Georgia|USD ($)", "DE|🇩🇪|Germany|USD ($)", "GH|🇬🇭|Ghana|USD ($)", "GR|🇬🇷|Greece|USD ($)", "GD|🇬🇩|Grenada|USD ($)",
    "GT|🇬🇹|Guatemala|USD ($)", "GN|🇬🇳|Guinea|USD ($)", "GY|🇬🇾|Guyana|USD ($)", "HT|🇭🇹|Haiti|USD ($)", "HN|🇭🇳|Honduras|USD ($)",
    "HU|🇭🇺|Hungary|USD ($)", "IS|🇮🇸|Iceland|USD ($)", "ID|🇮🇩|Indonesia|USD ($)", "IR|🇮🇷|Iran|USD ($)", "IQ|🇮🇶|Iraq|USD ($)",
    "IE|🇮🇪|Ireland|USD ($)", "IL|🇮🇱|Israel|USD ($)", "IT|🇮🇹|Italy|USD ($)", "JM|🇯🇲|Jamaica|USD ($)", "JP|🇯🇵|Japan|USD ($)",
    "JO|🇯🇴|Jordan|USD ($)", "KZ|🇰🇿|Kazakhstan|USD ($)", "KE|🇰🇪|Kenya|USD ($)", "KW|🇰🇼|Kuwait|USD ($)", "KG|🇰🇬|Kyrgyzstan|USD ($)",
    "LA|🇱🇦|Laos|USD ($)", "LV|🇱🇻|Latvia|USD ($)", "LB|🇱🇧|Lebanon|USD ($)", "LS|🇱🇸|Lesotho|USD ($)", "LR|🇱🇷|Liberia|USD ($)",
    "LY|🇱🇾|Libya|USD ($)", "LI|🇱🇮|Liechtenstein|USD ($)", "LT|🇱🇹|Lithuania|USD ($)", "LU|🇱🇺|Luxembourg|USD ($)", "MG|🇲🇬|Madagascar|USD ($)",
    "MW|🇲🇼|Malawi|USD ($)", "MY|🇲🇾|Malaysia|USD ($)", "MV|🇲🇻|Maldives|USD ($)", "ML|🇲🇱|Mali|USD ($)", "MT|🇲🇹|Malta|USD ($)",
    "MR|🇲🇷|Mauritania|USD ($)", "MU|🇲🇺|Mauritius|USD ($)", "MX|🇲🇽|Mexico|USD ($)", "MD|🇲🇩|Moldova|USD ($)", "MC|🇲🇨|Monaco|USD ($)",
    "MN|🇲🇳|Mongolia|USD ($)", "ME|🇲🇪|Montenegro|USD ($)", "MA|🇲🇦|Morocco|USD ($)", "MZ|🇲🇿|Mozambique|USD ($)", "MM|🇲🇲|Myanmar|USD ($)",
    "NA|🇳🇦|Namibia|USD ($)", "NP|🇳🇵|Nepal|USD ($)", "NL|🇳🇱|Netherlands|USD ($)", "NZ|🇳🇿|New Zealand|USD ($)", "NI|🇳🇮|Nicaragua|USD ($)",
    "NE|🇳🇪|Niger|USD ($)", "NG|🇳🇬|Nigeria|USD ($)", "KP|🇰🇵|North Korea|USD ($)", "MK|🇲🇰|North Macedonia|USD ($)", "NO|🇳🇴|Norway|USD ($)",
    "OM|🇴🇲|Oman|USD ($)", "PK|🇵🇰|Pakistan|USD ($)", "PA|🇵🇦|Panama|USD ($)", "PG|🇵🇬|Papua New Guinea|USD ($)", "PY|🇵🇾|Paraguay|USD ($)",
    "PE|🇵🇪|Peru|USD ($)", "PH|🇵🇭|Philippines|USD ($)", "PL|🇵🇱|Poland|USD ($)", "PT|🇵🇹|Portugal|USD ($)", "QA|🇶🇦|Qatar|USD ($)",
    "RO|🇷🇴|Romania|USD ($)", "RU|🇷🇺|Russia|USD ($)", "RW|🇷🇼|Rwanda|USD ($)", "SA|🇸🇦|Saudi Arabia|USD ($)", "SN|🇸🇳|Senegal|USD ($)",
    "RS|🇷🇸|Serbia|USD ($)", "SG|🇸🇬|Singapore|USD ($)", "SK|🇸🇰|Slovakia|USD ($)", "SI|🇸🇮|Slovenia|USD ($)", "ZA|🇿🇦|South Africa|USD ($)",
    "KR|🇰🇷|South Korea|USD ($)", "ES|🇪🇸|Spain|USD ($)", "LK|🇱🇰|Sri Lanka|USD ($)", "SD|🇸🇩|Sudan|USD ($)", "SE|🇸🇪|Sweden|USD ($)",
    "CH|🇨🇭|Switzerland|USD ($)", "SY|🇸🇾|Syria|USD ($)", "TW|🇹🇼|Taiwan|USD ($)", "TJ|🇹🇯|Tajikistan|USD ($)", "TZ|🇹🇿|Tanzania|USD ($)",
    "TH|🇹🇭|Thailand|USD ($)", "TR|🇹🇷|Turkey|USD ($)", "TM|🇹🇲|Turkmenistan|USD ($)", "UG|🇺🇬|Uganda|USD ($)", "UA|🇺🇦|Ukraine|USD ($)",
    "UY|🇺🇾|Uruguay|USD ($)", "UZ|🇺🇿|Uzbekistan|USD ($)", "VE|🇻🇪|Venezuela|USD ($)", "VN|🇻🇳|Vietnam|USD ($)", "YE|🇾🇪|Yemen|USD ($)",
    "ZM|🇿🇲|Zambia|USD ($)", "ZW|🇿🇼|Zimbabwe|USD ($)"
].map(item => {
    const [code, flag, name, curr] = item.split("|");
    return { code, flag, name, curr };
});

function loadExternalScript(src, id) {
    return new Promise((resolve, reject) => {
        let old = document.getElementById(id);
        if (old) {
            if (old.dataset.loaded === "true") return resolve();
            old.addEventListener("load", resolve, { once: true });
            return;
        }
        let s = document.createElement("script");
        s.id = id;
        s.src = src;
        s.onload = () => { s.dataset.loaded = "true"; resolve(); };
        s.onerror = () => reject(Error("Failed to load " + src));
        document.head.appendChild(s);
    });
}

function escapeHtml(s) {
    return String(s || "").replace(/[&<>"']/g, function(c) {
        return {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        }[c];
    });
}

function formatSmartTimeLabel(ms) {
    if (!ms || typeof ms !== "number") return "";
    const d = new Date(ms);
    const now = new Date();
    const isToday = d.toDateString() === now.toDateString();
    const yesterday = new Date(now);
    yesterday.setDate(now.getDate() - 1);
    const isYesterday = d.toDateString() === yesterday.toDateString();
    const timeStr = d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    if (isToday) return timeStr;
    if (isYesterday) return "Yesterday";
    return d.toLocaleDateString([], { day: "2-digit", month: "short" });
}

function formatPresenceStatusText(isOnlineFlag, lastActiveAtMs, fallbackLabel) {
    const now = Date.now();
    const isRecentlyActive = lastActiveAtMs && (now - lastActiveAtMs < 120000);
    if (isOnlineFlag && (isRecentlyActive || !lastActiveAtMs)) {
        return { online: true, text: "Online" };
    }
    if (lastActiveAtMs) {
        const d = new Date(lastActiveAtMs);
        const nowDate = new Date();
        const timePart = d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
        if (d.toDateString() === nowDate.toDateString()) {
            return { online: false, text: `Last seen today at ${timePart}` };
        }
        const yest = new Date(nowDate);
        yest.setDate(nowDate.getDate() - 1);
        if (d.toDateString() === yest.toDateString()) {
            return { online: false, text: `Last seen yesterday at ${timePart}` };
        }
        const datePart = d.toLocaleDateString([], { day: "2-digit", month: "short" });
        return { online: false, text: `Last seen ${datePart}, ${timePart}` };
    }
    return { online: false, text: `Last seen ${fallbackLabel || "recently"}` };
}

// ================= FIREBASE INIT & 30-DAY SUBSCRIPTION CHECK =================
async function initFirebase() {
    if (firebaseReadyPromise) return firebaseReadyPromise;
    firebaseReadyPromise = (async () => {
        try {
            if (!window.firebase?.initializeApp)
                await loadExternalScript("https://www.gstatic.com/firebasejs/10.8.0/firebase-app-compat.js", "zfb-app");
            if (!window.firebase?.auth)
                await loadExternalScript("https://www.gstatic.com/firebasejs/10.8.0/firebase-auth-compat.js", "zfb-auth");
            if (!window.firebase?.firestore)
                await loadExternalScript("https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore-compat.js", "zfb-firestore");

            if (!firebase.apps.length) firebase.initializeApp(firebaseConfig);
            db = firebase.firestore();
            auth = firebase.auth();

            auth.onAuthStateChanged(async u => {
                const authScreen = document.getElementById("authScreen");
                const splashScreen = document.getElementById("splashScreen");
                const bottomNav = document.getElementById("bottomNav");

                if (u) {
                    isLoggedIn = true;
                    userName = u.displayName || userName || "Student";
                    userEmail = u.email || "";
                    if (u.photoURL && !userAvatarUrl.startsWith("data:image")) {
                        userAvatarUrl = getSafeAvatar(u.photoURL);
                    }

                    localStorage.setItem("isLoggedIn", "true");
                    localStorage.setItem("userName", userName);
                    localStorage.setItem("userEmail", userEmail);

                    await loadUserProfile(u);
                    await ensureUniqueUsernameForUser(u);
                    updateProfileUI();
                    updatePricingUI(currentCountry);
                    updateMyPresenceStatus(true);
                    startPresenceHeartbeat();
                    requestNotificationPermissionSafely();
                    await loadUserChatsFromFirebase();

                    if (splashScreen) splashScreen.style.setProperty("display", "none", "important");
                    if (authScreen) authScreen.style.setProperty("display", "none", "important");
                    if (bottomNav) bottomNav.style.setProperty("display", "flex", "important");

                    showChatsHome();
                } else {
                    isLoggedIn = false;
                    stopPresenceHeartbeat();
                    if (incomingChatsUnsub) { incomingChatsUnsub(); incomingChatsUnsub = null; }
                    hideAllScreens();
                    if (bottomNav) bottomNav.style.setProperty("display", "none", "important");
                    if (authScreen) authScreen.style.setProperty("display", "flex", "important");
                    if (splashScreen) splashScreen.style.setProperty("display", "none", "important");
                }
            });

            return true;
        } catch (e) {
            console.error("Firebase init:", e);
            return false;
        }
    })();
    return firebaseReadyPromise;
}

async function loadUserProfile(user) {
    if (!user) return;
    try {
        if (!db) await initFirebase();
        const userDocRef = db.collection("users").doc(user.uid);
        const userDoc = await userDocRef.get();

        if (userDoc.exists) {
            const data = userDoc.data();
            userName = data.name || user.displayName || "Student";
            currentUsername = data.username || "";
            currentBio = data.bio || currentBio;
            userAvatarUrl = getSafeAvatar(data.photoURL || data.avatarUrl || user.photoURL);

            let savedTier = typeof data.userTier === "number" ? data.userTier : 0;
            let expiresMs = data.subscriptionExpiresAtMs || 0;

            if (savedTier > 0 && expiresMs > 0 && Date.now() > expiresMs) {
                savedTier = 0;
                expiresMs = 0;
                await userDocRef.set({ userTier: 0, subscriptionExpiresAtMs: 0 }, { merge: true });
            }

            userTier = savedTier;
            subExpiresAtMs = expiresMs;
            localStorage.setItem("userTier", String(userTier));
            localStorage.setItem("subExpiresAtMs", String(subExpiresAtMs));
            localStorage.setItem("username", currentUsername);
            localStorage.setItem("userName", userName);
            localStorage.setItem("userBio", currentBio);
            localStorage.setItem("userAvatarUrl", userAvatarUrl);

            syncEditProfileInputs();
            updateProfileUI();
            updatePricingUI(currentCountry);
        } else {
            const cleanName = (user.displayName || "student").toLowerCase().replace(/[^a-z0-9]/g, "") || "student";
            const defaultUsername = `@${cleanName}_${Math.floor(1000 + Math.random() * 9000)}`;

            const initialData = {
                uid: user.uid,
                name: user.displayName || "Student",
                nameLower: (user.displayName || "Student").toLowerCase(),
                email: user.email || "",
                username: defaultUsername,
                usernameLower: defaultUsername.toLowerCase(),
                photoURL: getSafeAvatar(userAvatarUrl),
                bio: currentBio,
                userTier: 0,
                subscriptionExpiresAtMs: 0,
                isOnline: true,
                lastActiveAtMs: Date.now(),
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            };

            await userDocRef.set(initialData, { merge: true });
            userName = initialData.name;
            currentUsername = initialData.username;
            userAvatarUrl = initialData.photoURL;

            localStorage.setItem("username", currentUsername);
            localStorage.setItem("userName", userName);
            localStorage.setItem("userAvatarUrl", userAvatarUrl);
            syncEditProfileInputs();
        }
    } catch (err) {
        console.error("Error loading user profile:", err);
    }
}

// ================= NAVIGATION & SCREENS =================
function closeAllDropdownMenus() {
    const ids = ["aiHeaderDropdownMenu", "dmHeaderDropdownMenu", "fpHeaderDropdownMenu"];
    ids.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = "none";
    });
}

function hideAllScreens() {
    closeAllDropdownMenus();
    const screens = [
        "chatListScreen", "subScreen", "toolsScreen", "settingsScreen",
        "chatScreen", "webSearchScreen", "activeChatScreen", "profileScreen", "historyScreen", "friendProfileScreen"
    ];
    screens.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.setProperty("display", "none", "important");
    });
    const prevBar = document.getElementById("aiAttachmentPreviewBar");
    if (prevBar) prevBar.style.display = "none";
}

function switchTab(tabId, element) {
    hideAllScreens();

    const inputArea = document.getElementById("inputAreaContainer");
    if (inputArea) inputArea.style.setProperty("display", "none", "important");

    const bottomNav = document.getElementById("bottomNav");
    if (bottomNav) bottomNav.style.setProperty("display", "flex", "important");

    if (tabId === "chat") {
        document.getElementById("chatListScreen")?.style.setProperty("display", "block", "important");
    } else if (tabId === "pro") {
        document.getElementById("subScreen")?.style.setProperty("display", "block", "important");
        if (userTier === 1) selectedTierLevel = 2;
        updatePricingUI(currentCountry);
    } else if (tabId === "tools") {
        document.getElementById("toolsScreen")?.style.setProperty("display", "flex", "important");
    } else if (tabId === "settings") {
        document.getElementById("settingsScreen")?.style.setProperty("display", "block", "important");
    }

    document.querySelectorAll(".nav-item").forEach(btn => btn.classList.remove("active"));
    if (element) element.classList.add("active");

    window.scrollTo(0, 0);
}

function showChatsHome() {
    hideAllScreens();

    const chatList = document.getElementById("chatListScreen");
    if (chatList) chatList.style.setProperty("display", "block", "important");

    const inputArea = document.getElementById("inputAreaContainer");
    if (inputArea) inputArea.style.setProperty("display", "none", "important");

    const bottomNav = document.getElementById("bottomNav");
    if (bottomNav) bottomNav.style.setProperty("display", "flex", "important");

    document.querySelectorAll(".nav-item").forEach(btn => btn.classList.remove("active"));
    const firstTab = document.querySelector(".floating-nav .nav-item");
    if (firstTab) firstTab.classList.add("active");
}

function goHome() {
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    showChatsHome();
}

function openSettings() {
    pushScreenState("settings");
    hideAllScreens();
    document.getElementById("settingsScreen")?.style.setProperty("display", "block", "important");
    document.getElementById("inputAreaContainer")?.style.setProperty("display", "none", "important");
}

function openSubscription() {
    pushScreenState("sub");
    hideAllScreens();
    document.getElementById("subScreen")?.style.setProperty("display", "block", "important");
    document.getElementById("inputAreaContainer")?.style.setProperty("display", "none", "important");
    selectedTierLevel = userTier >= 1 ? 2 : 1;
    updatePricingUI(currentCountry);
}

function openProfile() {
    hideAllScreens();
    const profile = document.getElementById("profileScreen");
    if (profile) profile.style.setProperty("display", "block", "important");
    document.getElementById("inputAreaContainer")?.style.setProperty("display", "none", "important");
    syncEditProfileInputs();
    updateProfileUI();
}

function pushScreenState(screenName) {
    try { history.pushState({ screen: screenName }, ""); } catch (e) {}
}

function syncDarkModeUI(enabled) {
    const toggle = document.getElementById("darkModeToggle");
    if (toggle) {
        if (enabled) toggle.classList.remove("off");
        else toggle.classList.add("off");
    }
    const lightDot = document.getElementById("authThemeLight");
    const darkDot = document.getElementById("authThemeDark");
    if (lightDot && darkDot) {
        lightDot.classList.toggle("active", !enabled);
        darkDot.classList.toggle("active", enabled);
    }
}

function toggleDarkMode() {
    document.body.classList.toggle("dark-mode");
    const enabled = document.body.classList.contains("dark-mode");
    localStorage.setItem("darkMode", enabled ? "true" : "false");
    syncDarkModeUI(enabled);
}

// ================= MODALS & ALERTS =================
function showCustomAlert(title, message, isSuccess = false) {
    const modal = document.getElementById("alertModal");
    if (!modal) {
        alert(`${title}\n\n${message}`);
        return;
    }

    const titleEl = document.getElementById("alertModalTitle");
    const msgEl = document.getElementById("alertModalMsg");
    const iconEl = document.getElementById("alertModalIcon");

    if (titleEl) titleEl.textContent = title || "Notice";
    if (msgEl) msgEl.textContent = message || "";
    if (iconEl) {
        iconEl.className = isSuccess ? "modal-icon" : "modal-icon error-icon";
        iconEl.innerHTML = isSuccess
            ? '<i class="fa-solid fa-circle-check" style="color:#16a34a;"></i>'
            : '<i class="fa-solid fa-circle-info"></i>';
    }

    modal.style.display = "flex";
}

function closeCustomAlert() {
    const modal = document.getElementById("alertModal");
    if (modal) modal.style.display = "none";
}

function openPolicyModal(type) {
    const modal = document.getElementById("policyModal");
    if (!modal) return;

    const title = document.getElementById("policyModalTitle");
    const content = document.getElementById("policyModalContent");

    const policies = {
        terms: {
            title: "Terms & Conditions",
            content: `
                <h3>1. Acceptance of Terms</h3>
                <p>By accessing and using Zoreno, you agree to comply with these Terms & Conditions and Google Play Policies.</p>
                <h3>2. AI-Generated Content Disclaimer</h3>
                <p>Zoreno uses advanced AI models to assist with study and general queries. Users can report any inappropriate AI response using the Feedback option in the chat menu.</p>
                <h3>3. User-Generated Content (UGC) & Safety</h3>
                <p>In direct messaging, abusive or illegal content is strictly prohibited. Users can <strong>Block</strong> and <strong>Report</strong> any user from the 3-dot chat menu.</p>
                <h3>4. 30-Day Subscription Validity</h3>
                <p>Zoreno Plus (50 chats/day) and Zoreno Pro (90 chats/day) remain active for 30 days from purchase via Google Play Billing or Razorpay.</p>
            `
        },
        privacy: {
            title: "Privacy Policy & Data Safety",
            content: `
                <h3>1. Information We Collect</h3>
                <p>We collect basic account details (Name, Email, Username, optional Profile Photo) and chat messages via Google Firebase to provide real-time sync.</p>
                <h3>2. Data Security</h3>
                <p>All data is encrypted in transit (HTTPS/TLS) and stored securely on Google Firebase servers. We never sell your personal data.</p>
                <h3>3. Account & Data Deletion</h3>
                <p>You can permanently delete your account and all associated data anytime directly from <strong>Settings &rarr; Delete Account</strong>.</p>
            `
        },
        refund: {
            title: "Refund & Cancellation Policy",
            content: `
                <h3>1. Subscription Validity & Cancellation</h3>
                <p>Purchased plans are active for 30 days. You may manage or cancel renewals anytime through Google Play Subscriptions or support.</p>
                <h3>2. Payment Issues</h3>
                <p>If payment is deducted without plan activation, contact support with your transaction ID for immediate resolution.</p>
            `
        }
    };

    const policy = policies[type];
    if (!policy) return;

    if (title) title.textContent = policy.title;
    if (content) content.innerHTML = policy.content;
    modal.style.display = "flex";
}

function closePolicyModal() {
    const modal = document.getElementById("policyModal");
    if (modal) modal.style.display = "none";
}

// ================= COUNTRY MODAL & PRICING =================
function openWorldCountryModal() {
    const modal = document.getElementById("worldCountryModal");
    const searchInput = document.getElementById("countrySearchInput");
    if (searchInput) searchInput.value = "";
    renderWorldCountries(RAW_WORLD_COUNTRIES);
    if (modal) modal.style.display = "flex";
}

function closeWorldCountryModal() {
    const modal = document.getElementById("worldCountryModal");
    if (modal) modal.style.display = "none";
}

function filterWorldCountries(query) {
    const q = (query || "").toLowerCase().trim();
    const filtered = RAW_WORLD_COUNTRIES.filter(c =>
        c.name.toLowerCase().includes(q) || c.code.toLowerCase().includes(q)
    );
    renderWorldCountries(filtered);
}

function renderWorldCountries(list) {
    const container = document.getElementById("worldCountryList");
    if (!container) return;

    container.innerHTML = list.map(c => {
        const isSelected = c.code === currentCountry;
        return `
            <div class="world-country-option ${isSelected ? 'active' : ''}" onclick="selectWorldCountry('${c.code}')">
                <div class="wc-left">
                    <span class="wc-flag">${c.flag}</span>
                    <div class="wc-text">
                        <h5>${c.name}</h5>
                        <span>${c.curr}</span>
                    </div>
                </div>
                <div class="wc-radio">
                    ${isSelected ? '<i class="fa-solid fa-circle-check"></i>' : '<i class="fa-regular fa-circle"></i>'}
                </div>
            </div>
        `;
    }).join("");
}

function selectWorldCountry(code) {
    currentCountry = code || "IN";
    localStorage.setItem("manualCountry", currentCountry);
    updatePricingUI(currentCountry);
    closeWorldCountryModal();
}

function detectAndSetCountry() {
    const saved = localStorage.getItem("manualCountry");
    if (saved) {
        currentCountry = saved;
        updatePricingUI(saved);
        return;
    }
    fetch("https://ipapi.co/json/")
        .then(r => r.json())
        .then(data => {
            const code = data?.country_code || "IN";
            currentCountry = code;
            localStorage.setItem("manualCountry", code);
            updatePricingUI(code);
        })
        .catch(() => {
            currentCountry = "IN";
            updatePricingUI("IN");
        });
}

function getRemainingSubDays() {
    if (!subExpiresAtMs || subExpiresAtMs <= Date.now()) return 30;
    return Math.max(1, Math.ceil((subExpiresAtMs - Date.now()) / (24 * 60 * 60 * 1000)));
}

function selectPlan(tierLevel) {
    if (userTier >= 2) {
        showCustomAlert("Subscription Already Active 👑", `You already have Zoreno Pro active for the next ${getRemainingSubDays()} days!`, true);
        return;
    }
    if (userTier === 1 && tierLevel <= 1) {
        showCustomAlert("Plus Plan Already Active ✨", `Your Zoreno Plus plan is active (${getRemainingSubDays()} days left). You can only upgrade to Zoreno Pro!`);
        selectedTierLevel = 2;
        updatePricingUI(currentCountry);
        return;
    }

    selectedTierLevel = tierLevel;
    updatePricingUI(currentCountry);
}

function updatePricingUI(countryCode) {
    currentCountry = countryCode || localStorage.getItem("manualCountry") || "IN";
    localStorage.setItem("manualCountry", currentCountry);

    const isIndia = currentCountry === "IN";
    const symbol = isIndia ? "₹" : "$";
    const plusPrice = isIndia ? 249 : 3.99;
    const proPrice = isIndia ? 349 : 6.99;

    if (userTier === 1 && selectedTierLevel < 2) {
        selectedTierLevel = 2;
    }

    const found = RAW_WORLD_COUNTRIES.find(c => c.code === currentCountry) || RAW_WORLD_COUNTRIES[0];
    const displayEl = document.getElementById("selectedCountryDisplay");
    if (displayEl) displayEl.innerText = `${found.flag} ${found.name} (${symbol})`;

    const plusCard = document.getElementById("plusPlanCard");
    const proCard = document.getElementById("proPlanCard");
    const plan1Title = document.getElementById("plan1Title");
    const plan2Title = document.getElementById("plan2Title");
    const plan1Desc = document.getElementById("plan1Description");
    const plan2Desc = document.getElementById("plan2Description");
    const payBtn = document.getElementById("payButtonText");
    const payBtnText = document.querySelector("#payButtonText .btn-text");

    if (plan1Title) plan1Title.innerText = `${symbol}${plusPrice} / Month (Plus)`;
    if (plan2Title) plan2Title.innerText = `${symbol}${proPrice} / Month (Pro)`;

    const daysLeft = getRemainingSubDays();

    if (userTier === 0) {
        if (plan1Desc) plan1Desc.innerText = "50 Messages/Day • 30 Days Validity";
        if (plan2Desc) plan2Desc.innerText = "90 Messages/Day • 30 Days • Vision";
        if (plusCard) {
            plusCard.style.opacity = "1";
            plusCard.classList.toggle("active", selectedTierLevel === 1);
        }
        if (proCard) {
            proCard.style.opacity = "1";
            proCard.classList.toggle("active", selectedTierLevel === 2);
        }
        selectedAmount = selectedTierLevel === 2 ? proPrice : plusPrice;
        if (payBtn) {
            payBtn.disabled = false;
            payBtn.style.opacity = "1";
        }
        if (payBtnText) payBtnText.innerText = `Upgrade to ${selectedTierLevel === 2 ? "Pro" : "Plus"} (${symbol}${selectedAmount})`;
    } else if (userTier === 1) {
        if (plan1Desc) plan1Desc.innerHTML = `<strong style="color:#10b981;">✓ Active (${daysLeft} Days Left)</strong> • Cannot Rebuy`;
        if (plan2Desc) plan2Desc.innerText = "Upgrade for 90 Messages/Day • 30 Days";
        if (plusCard) {
            plusCard.classList.remove("active");
            plusCard.style.opacity = "0.55";
        }
        if (proCard) {
            proCard.classList.add("active");
            proCard.style.opacity = "1";
        }
        selectedTierLevel = 2;
        selectedAmount = proPrice;
        if (payBtn) {
            payBtn.disabled = false;
            payBtn.style.opacity = "1";
        }
        if (payBtnText) payBtnText.innerText = `Upgrade to Pro (${symbol}${proPrice})`;
    } else if (userTier >= 2) {
        if (plan1Desc) plan1Desc.innerText = "Included in your active Pro Plan";
        if (plan2Desc) plan2Desc.innerHTML = `<strong style="color:#10b981;">✓ Active (${daysLeft} Days Left)</strong> • 90 Msgs/Day`;
        if (plusCard) {
            plusCard.classList.remove("active");
            plusCard.style.opacity = "0.45";
        }
        if (proCard) {
            proCard.classList.add("active");
            proCard.style.opacity = "1";
        }
        if (payBtn) {
            payBtn.disabled = true;
            payBtn.style.opacity = "0.75";
        }
        if (payBtnText) payBtnText.innerText = `Subscription Already Active (${daysLeft}d) 👑`;
    }
}

function isRunningInAndroidApp() {
    const ua = navigator.userAgent || "";
    return Boolean(window.AndroidBilling || window.ZorenoGoogleAuth || /wv|Android.*Version\/[0-9.]+/i.test(ua));
}

async function activateUserSubscriptionInFirestore(newTier, paymentReferenceId, providerName) {
    userTier = newTier;
    subExpiresAtMs = Date.now() + SUBSCRIPTION_VALIDITY_MS;

    localStorage.setItem("userTier", String(userTier));
    localStorage.setItem("subExpiresAtMs", String(subExpiresAtMs));

    if (db && auth?.currentUser) {
        await db.collection("users").doc(auth.currentUser.uid).set({
            userTier: userTier,
            subscriptionExpiresAtMs: subExpiresAtMs,
            paymentId: paymentReferenceId || "",
            paymentProvider: providerName || "unknown",
            subscriptionUpdatedAt: firebase.firestore.FieldValue.serverTimestamp()
        }, { merge: true });
    }

    updatePricingUI(currentCountry);
    updateProfileUI();

    showCustomAlert(
        "Subscription Activated (30 Days)! 🎉",
        `Welcome to Zoreno ${userTier === 2 ? "Pro" : "Plus"}! Your plan is now active for the next 30 days.`,
        true
    );
}

window.onPlayBillingSuccess = function (tierLevel, purchaseToken) {
    activateUserSubscriptionInFirestore(parseInt(tierLevel) || selectedTierLevel, purchaseToken || "play_billing", "google_play");
};

async function triggerRazorpay() {
    if (userTier >= 2) {
        showCustomAlert("Subscription Already Active 👑", `You already have Zoreno Pro active (${getRemainingSubDays()} days remaining).`, true);
        return;
    }
    if (userTier === 1 && selectedTierLevel <= 1) {
        selectedTierLevel = 2;
        updatePricingUI(currentCountry);
    }

    const targetTier = selectedTierLevel;
    const skuId = PLAY_BILLING_SKUS[targetTier];

    if (window.AndroidBilling && typeof window.AndroidBilling.purchaseSubscription === "function") {
        window.AndroidBilling.purchaseSubscription(skuId, targetTier);
        return;
    }

    if ("getDigitalGoodsService" in window) {
        try {
            const service = await window.getDigitalGoodsService("https://play.google.com/billing");
            if (service) {
                const paymentMethods = [{
                    supportedMethods: "https://play.google.com/billing",
                    data: { sku: skuId }
                }];
                const paymentDetails = {
                    total: {
                        label: targetTier === 2 ? "Zoreno Pro (30 Days)" : "Zoreno Plus (30 Days)",
                        amount: { currency: currentCountry === "IN" ? "INR" : "USD", value: String(selectedAmount) }
                    }
                };
                const request = new PaymentRequest(paymentMethods, paymentDetails);
                const paymentResponse = await request.show();
                const { purchaseToken } = paymentResponse.details;
                await paymentResponse.complete("success");
                await activateUserSubscriptionInFirestore(targetTier, purchaseToken, "google_play_twa");
                return;
            }
        } catch (playErr) {
            if (playErr.name === "AbortError") return;
            showCustomAlert("Google Play Billing", "Unable to connect to Google Play Billing. Please ensure you are signed into the Play Store.");
            return;
        }
    }

    if (!window.Razorpay) {
        try {
            await loadExternalScript("https://checkout.razorpay.com/v1/checkout.js", "rzp-checkout-js");
        } catch (e) {
            showCustomAlert("Loading Payment", "Payment system could not be loaded. Please check your internet connection.");
            return;
        }
    }

    const options = {
        key: RAZORPAY_KEY_ID,
        amount: Math.round(selectedAmount * 100),
        currency: currentCountry === "IN" ? "INR" : "USD",
        name: "Zoreno",
        description: targetTier === 2 ? "Zoreno Pro (30 Days)" : "Zoreno Plus (30 Days)",
        handler: async function (response) {
            try {
                await activateUserSubscriptionInFirestore(
                    targetTier,
                    response?.razorpay_payment_id || "rzp_web",
                    "razorpay"
                );
            } catch (e) {
                console.error("Subscription update error:", e);
            }
        },
        prefill: { name: userName || "", email: userEmail || "" },
        theme: { color: "#7c3aed" }
    };

    const rzp = new Razorpay(options);
    rzp.open();
}

// ================= AUTHENTICATION & ACCOUNT DELETION =================
function showSignUpForm() {
    document.getElementById("loginViewSection").style.display = "none";
    document.getElementById("signUpViewSection").style.display = "block";
    document.getElementById("authBackBtn").style.display = "inline-flex";
}

function showLoginForm() {
    document.getElementById("signUpViewSection").style.display = "none";
    document.getElementById("loginViewSection").style.display = "block";
    document.getElementById("authBackBtn").style.display = "none";
}

function toggleInputPassword(fieldId, btn) {
    const input = document.getElementById(fieldId);
    if (!input) return;
    const isPass = input.type === "password";
    input.type = isPass ? "text" : "password";
    btn.innerHTML = isPass ? '<i class="fa-regular fa-eye"></i>' : '<i class="fa-regular fa-eye-slash"></i>';
}

async function handleEmailLogin(e) {
    e.preventDefault();
    const email = document.getElementById("loginEmail").value.trim();
    const pass = document.getElementById("loginPassword").value;
    const btn = document.getElementById("loginSubmitBtn");
    if (!email || !pass) return;

    try {
        if (btn) btn.disabled = true;
        await initFirebase();
        const userCred = await auth.signInWithEmailAndPassword(email, pass);
        if (userCred.user) {
            document.getElementById("authScreen")?.style.setProperty("display", "none", "important");
            showChatsHome();
        }
    } catch (err) {
        let customMsg = err.message;
        if (err.code === "auth/invalid-credential" || err.code === "auth/user-not-found" || err.code === "auth/wrong-password") {
            customMsg = "Account not found or wrong password. Please check your details or Sign Up.";
        }
        showCustomAlert("Login Failed", customMsg);
    } finally {
        if (btn) btn.disabled = false;
    }
}

async function handleEmailSignUp(e) {
    e.preventDefault();
    const name = document.getElementById("regName").value.trim();
    const email = document.getElementById("regEmail").value.trim();
    const pass = document.getElementById("regPassword").value;
    const btn = document.getElementById("signUpSubmitBtn");

    try {
        if (btn) btn.disabled = true;
        await initFirebase();
        const res = await auth.createUserWithEmailAndPassword(email, pass);

        if (res.user) {
            const cleanName = name.toLowerCase().replace(/[^a-z0-9]/g, "") || "student";
            const randomCode = Math.floor(1000 + Math.random() * 9000);
            const autoUsername = `@${cleanName}_${randomCode}`;

            await res.user.updateProfile({ displayName: name });
            userName = name;
            currentUsername = autoUsername;
            userAvatarUrl = DEFAULT_AVATAR_URL;
            localStorage.setItem("username", autoUsername);
            localStorage.setItem("userName", name);
            localStorage.setItem("userAvatarUrl", DEFAULT_AVATAR_URL);

            if (db) {
                await db.collection("users").doc(res.user.uid).set({
                    uid: res.user.uid,
                    name: name,
                    nameLower: name.toLowerCase(),
                    email: email,
                    username: autoUsername,
                    usernameLower: autoUsername.toLowerCase(),
                    photoURL: DEFAULT_AVATAR_URL,
                    bio: currentBio,
                    userTier: 0,
                    subscriptionExpiresAtMs: 0,
                    isOnline: true,
                    lastActiveAtMs: Date.now(),
                    createdAt: firebase.firestore.FieldValue.serverTimestamp()
                }, { merge: true });
            }

            await loadUserProfile(res.user);
            showChatsHome();
        }
    } catch (err) {
        showCustomAlert("Sign Up Failed", err.message);
    } finally {
        if (btn) btn.disabled = false;
    }
}

async function handleForgotPassword() {
    const email = document.getElementById("loginEmail").value.trim();
    if (!email) {
        showCustomAlert("Email Required", "Please enter your email in the email address box first.");
        return;
    }
    try {
        await initFirebase();
        await auth.sendPasswordResetEmail(email);
        showCustomAlert("Reset Email Sent", "Password reset instructions sent to your email.", true);
    } catch (err) {
        showCustomAlert("Reset Failed", err.message);
    }
}

async function handleUserLogout() {
    try {
        await updateMyPresenceStatus(false);
        stopPresenceHeartbeat();
        if (incomingChatsUnsub) { incomingChatsUnsub(); incomingChatsUnsub = null; }
        if (auth) await auth.signOut();
        localStorage.clear();
        sessionStorage.clear();
        window.location.reload();
    } catch (err) {
        showCustomAlert("Logout Failed", err.message);
    }
}

function openDeleteAccountModal() {
    const emailInp = document.getElementById("delAccEmail");
    const passInp = document.getElementById("delAccPass");
    if (emailInp) emailInp.value = userEmail || auth?.currentUser?.email || "";
    if (passInp) passInp.value = "";
    const modal = document.getElementById("deleteAccountModal");
    if (modal) modal.style.display = "flex";
}

async function confirmDeleteAccount() {
    const email = document.getElementById("delAccEmail")?.value.trim();
    const pass = document.getElementById("delAccPass")?.value;
    if (!email || !pass) {
        showCustomAlert("Details Required", "Please enter both your email and password to confirm deletion.");
        return;
    }
    if (!auth?.currentUser) return;

    try {
        const uid = auth.currentUser.uid;
        const cred = firebase.auth.EmailAuthProvider.credential(email, pass);
        await auth.currentUser.reauthenticateWithCredential(cred);

        if (db) {
            const chatSnap = await db.collection("users").doc(uid).collection("chats").get();
            const batch = db.batch();
            chatSnap.forEach(d => batch.delete(d.ref));
            batch.delete(db.collection("users").doc(uid));
            await batch.commit();
        }

        await auth.currentUser.delete();
        localStorage.clear();
        sessionStorage.clear();
        document.getElementById("deleteAccountModal").style.display = "none";
        window.location.reload();
    } catch (err) {
        showCustomAlert("Deletion Failed", "Incorrect password or authentication error: " + err.message);
    }
}

// ================= PROFILE EDIT & PHOTO SAVE =================
function updateProfileUI() {
    const tierLabel = userTier === 2
        ? `Pro Member (${getRemainingSubDays()}d left) 👑`
        : userTier === 1
            ? `Plus Member (${getRemainingSubDays()}d left) ✨`
            : "Free Member";
    const cardTierEl = document.getElementById("profileCardTierTitle");
    if (cardTierEl) cardTierEl.textContent = tierLabel;

    const avImg = document.getElementById("profileEditAvatarImg");
    if (avImg) avImg.src = getSafeAvatar(userAvatarUrl);

    const badge = document.getElementById("profileUsernameBadge");
    if (badge) badge.innerText = currentUsername || "@student";
}

function syncEditProfileInputs() {
    const uInp = document.getElementById("profileEditUsername");
    const nInp = document.getElementById("profileEditName");
    const bInp = document.getElementById("profileEditBio");
    const badge = document.getElementById("profileUsernameBadge");
    const avImg = document.getElementById("profileEditAvatarImg");

    if (uInp) uInp.value = (currentUsername || "").replace(/^@/, "");
    if (nInp) nInp.value = userName || "Student";
    if (bInp) bInp.value = currentBio;
    if (badge) badge.innerText = currentUsername || "@student";
    if (avImg) avImg.src = getSafeAvatar(userAvatarUrl);
}

function previewAndUploadProfilePic(event) {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function (e) {
        const img = new Image();
        img.onload = async function () {
            const canvas = document.createElement("canvas");
            const MAX_SIZE = 200;
            let w = img.width;
            let h = img.height;

            if (w > h) {
                if (w > MAX_SIZE) { h = Math.round((h * MAX_SIZE) / w); w = MAX_SIZE; }
            } else {
                if (h > MAX_SIZE) { w = Math.round((w * MAX_SIZE) / h); h = MAX_SIZE; }
            }

            canvas.width = w;
            canvas.height = h;
            const ctx = canvas.getContext("2d");
            ctx.drawImage(img, 0, 0, w, h);

            const compressedBase64 = canvas.toDataURL("image/jpeg", 0.72);
            userAvatarUrl = compressedBase64;
            localStorage.setItem("userAvatarUrl", compressedBase64);
            updateProfileUI();

            if (db && auth?.currentUser) {
                const myUid = auth.currentUser.uid;
                try {
                    await db.collection("users").doc(myUid).set({
                        photoURL: compressedBase64,
                        avatarUrl: compressedBase64,
                        updatedAt: firebase.firestore.FieldValue.serverTimestamp()
                    }, { merge: true });
                } catch (err) {
                    console.error("Avatar sync error:", err);
                }
            }
        };
        img.src = e.target.result;
    };
    reader.readAsDataURL(file);
}

async function ensureUniqueUsernameForUser(u) {
    if (!db || !u) return;
    try {
        const userRef = db.collection("users").doc(u.uid);
        const snap = await userRef.get();
        let data = snap.exists ? snap.data() : {};

        if (data.username && data.username !== "@user" && data.username !== "@friend") {
            currentUsername = data.username;
        } else {
            const base = (u.displayName || userName || "student")
                .toLowerCase()
                .replace(/[^a-z0-9]/g, "")
                .slice(0, 10) || "student";
            const rand = Math.floor(1000 + Math.random() * 9000);
            currentUsername = `@${base}_${rand}`;

            await userRef.set({
                uid: u.uid,
                name: u.displayName || userName || "Student",
                nameLower: (u.displayName || userName || "Student").toLowerCase(),
                username: currentUsername,
                usernameLower: currentUsername.toLowerCase(),
                bio: currentBio,
                photoURL: getSafeAvatar(userAvatarUrl)
            }, { merge: true });
        }

        if (data.bio) currentBio = data.bio;
        if (data.photoURL) userAvatarUrl = getSafeAvatar(data.photoURL);
        localStorage.setItem("username", currentUsername);
        localStorage.setItem("userBio", currentBio);
        localStorage.setItem("userAvatarUrl", userAvatarUrl);

        syncEditProfileInputs();
        listenIncomingRealtimeChats(u.uid);
    } catch (e) {
        console.error("Username init error:", e);
    }
}

async function saveUserProfileChanges() {
    const uInp = document.getElementById("profileEditUsername");
    const nInp = document.getElementById("profileEditName");
    const bInp = document.getElementById("profileEditBio");
    const hint = document.getElementById("usernameStatusHint");
    const saveBtn = document.getElementById("profileSaveBtn");

    let rawU = (uInp?.value || "").trim().toLowerCase().replace(/^@/, "").replace(/[^a-z0-9_.]/g, "");
    let newName = (nInp?.value || "").trim() || userName;
    let newBio = (bInp?.value || "").trim() || currentBio;

    if (rawU.length < 3 || rawU === "user" || rawU === "friend") {
        if (hint) {
            hint.style.color = "#ef4444";
            hint.innerText = "Please choose a valid unique username (min 3 chars).";
        }
        return;
    }

    const formattedUsername = `@${rawU}`;

    try {
        if (saveBtn) {
            saveBtn.disabled = true;
            saveBtn.innerText = "Saving...";
        }

        if (db && auth?.currentUser) {
            const q = await db.collection("users")
                .where("usernameLower", "==", formattedUsername.toLowerCase())
                .get();

            let isTaken = false;
            q.forEach(doc => {
                if (doc.id !== auth.currentUser.uid) isTaken = true;
            });

            if (isTaken) {
                if (hint) {
                    hint.style.color = "#ef4444";
                    hint.innerText = `❌ ${formattedUsername} is already taken!`;
                }
                return;
            }

            await db.collection("users").doc(auth.currentUser.uid).set({
                name: newName,
                nameLower: newName.toLowerCase(),
                username: formattedUsername,
                usernameLower: formattedUsername.toLowerCase(),
                bio: newBio,
                photoURL: getSafeAvatar(userAvatarUrl)
            }, { merge: true });
        }

        currentUsername = formattedUsername;
        userName = newName;
        currentBio = newBio;

        localStorage.setItem("username", currentUsername);
        localStorage.setItem("userName", userName);
        localStorage.setItem("userBio", currentBio);

        if (hint) hint.innerText = "";
        syncEditProfileInputs();
        updateProfileUI();
        showChatsHome();
    } catch (err) {
        console.error("Save profile error:", err);
    } finally {
        if (saveBtn) {
            saveBtn.disabled = false;
            saveBtn.innerText = "Save";
        }
    }
}

// =========================================================
// ZORENO APP.JS — PART 2 OF 3 (ZERO ERRORS VERSION)
// PRESENCE, NOTIFICATIONS, HOME SEARCH, FRIEND DM & IMAGE UPLOAD
// =========================================================

// ================= ACCURATE ONLINE / LAST SEEN PRESENCE =================
async function updateMyPresenceStatus(isOnlineNow) {
    if (!db || !auth?.currentUser) return;
    const nowMs = Date.now();
    const nowTime = new Date(nowMs).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    try {
        await db.collection("users").doc(auth.currentUser.uid).set({
            isOnline: isOnlineNow,
            lastSeenLabel: nowTime,
            lastActiveAtMs: nowMs,
            lastActiveAt: firebase.firestore.FieldValue.serverTimestamp()
        }, { merge: true });
    } catch (e) {}
}

function startPresenceHeartbeat() {
    stopPresenceHeartbeat();
    presenceHeartbeatTimer = setInterval(() => {
        if (!document.hidden && auth?.currentUser) {
            updateMyPresenceStatus(true);
        }
    }, 45000);
}

function stopPresenceHeartbeat() {
    if (presenceHeartbeatTimer) {
        clearInterval(presenceHeartbeatTimer);
        presenceHeartbeatTimer = null;
    }
}

window.addEventListener("beforeunload", () => updateMyPresenceStatus(false));
window.addEventListener("pagehide", () => updateMyPresenceStatus(false));
document.addEventListener("visibilitychange", () => {
    updateMyPresenceStatus(!document.hidden);
});

// ================= WHATSAPP-STYLE IN-APP & SYSTEM NOTIFICATIONS (30860.PNG) =================
function requestNotificationPermissionSafely() {
    if ("Notification" in window && Notification.permission === "default") {
        Notification.requestPermission().catch(() => {});
    }
}

let inAppNotifTimeout = null;
function showZorenoIncomingNotification(friendUid, senderName, senderAvatar, senderUsername, messageText) {
    if (blockedUsersMap[friendUid]) return;

    const banner = document.getElementById("zorenoInAppNotifBanner");
    const nameEl = document.getElementById("znotifSenderName");
    const msgEl = document.getElementById("znotifMsgPreview");
    const avatarEl = document.getElementById("znotifSenderAvatar");

    if (banner && nameEl && msgEl && avatarEl) {
        nameEl.textContent = senderName || "Friend";
        msgEl.textContent = messageText || "Sent you a message";
        avatarEl.src = getSafeAvatar(senderAvatar);

        banner.onclick = () => {
            banner.classList.remove("show");
            openChatWithUser(friendUid, senderName, getSafeAvatar(senderAvatar), senderUsername);
        };

        banner.classList.add("show");
        clearTimeout(inAppNotifTimeout);
        inAppNotifTimeout = setTimeout(() => {
            banner.classList.remove("show");
        }, 4500);
    }

    // 1. Native Android Status-Bar Notification Bridge (Works in APK/AAB)
    if (window.AndroidNotif && typeof window.AndroidNotif.showNotification === "function") {
        try {
            window.AndroidNotif.showNotification(senderName || "Zoreno Message", messageText || "New message received");
        } catch (e) {}
    }

    // 2. Web Browser Notification Fallback
    if ("Notification" in window && Notification.permission === "granted" && document.hidden) {
        try {
            const n = new Notification(senderName || "Zoreno Message", {
                body: messageText || "New message received",
                icon: "icon.png",
                badge: "icon.png",
                tag: `zoreno_dm_${friendUid}`
            });
            n.onclick = () => {
                window.focus();
                openChatWithUser(friendUid, senderName, getSafeAvatar(senderAvatar), senderUsername);
                n.close();
            };
        } catch (e) {}
    }
}


// ================= HOME SEARCH & TABS =================
function setupHomeSearchAndTabs() {
    const searchInp = document.getElementById("homeChatSearchInput");
    if (searchInp) {
        searchInp.addEventListener("input", e => handleHomeUserSearch(e.target.value));
        searchInp.addEventListener("search", e => handleHomeUserSearch(e.target.value));
        searchInp.addEventListener("keyup", e => {
            if (!e.target.value.trim()) handleHomeUserSearch("");
        });
    }

    const tabBtns = document.querySelectorAll(".chat-tabs .tab-btn");
    const tabKeys = ["all", "unread", "friends", "groups"];
    tabBtns.forEach((btn, idx) => {
        btn.onclick = () => {
            tabBtns.forEach(b => b.classList.remove("active"));
            btn.classList.add("active");
            currentActiveChatTab = tabKeys[idx] || "all";
            filterHomeChatListByTab(currentActiveChatTab);
        };
    });

    renderSavedDmChatsOnHome();
}

function filterHomeChatListByTab(tabKey) {
    const items = document.querySelectorAll(".chats-container .chat-list-item");
    items.forEach(item => {
        if (item.classList.contains("pinned")) {
            item.style.display = tabKey === "all" ? "flex" : "none";
            return;
        }
        const isGroup = item.querySelector(".group-avatar") !== null;
        const hasUnread = item.querySelector(".unread-count") !== null;

        if (tabKey === "all") item.style.display = "flex";
        else if (tabKey === "unread") item.style.display = hasUnread ? "flex" : "none";
        else if (tabKey === "friends") item.style.display = !isGroup ? "flex" : "none";
        else if (tabKey === "groups") item.style.display = isGroup ? "flex" : "none";
    });
}

const userProfileCache = {};
let searchDebounceTimer = null;

async function handleHomeUserSearch(rawQuery) {
    const q = (rawQuery || "").trim().toLowerCase();
    let resultsBox = document.getElementById("liveUserSearchDropdown");

    if (!resultsBox) {
        resultsBox = document.createElement("div");
        resultsBox.id = "liveUserSearchDropdown";
        resultsBox.className = "live-user-search-dropdown";
        const header = document.querySelector(".chat-list-header-modern");
        header?.insertAdjacentElement("afterend", resultsBox);
    }

    clearTimeout(searchDebounceTimer);
    if (!q) {
        resultsBox.innerHTML = "";
        resultsBox.style.display = "none";
        filterHomeChatListByTab(currentActiveChatTab);
        return;
    }

    document.querySelectorAll(".chats-container .chat-list-item").forEach(item => {
        const text = item.innerText.toLowerCase();
        item.style.display = text.includes(q) ? "flex" : "none";
    });

    if (!db) return;
    searchDebounceTimer = setTimeout(async () => {
        const currentVal = (document.getElementById("homeChatSearchInput")?.value || "").trim();
        if (!currentVal) {
            resultsBox.innerHTML = "";
            resultsBox.style.display = "none";
            return;
        }

        try {
            const cleanQ = q.replace(/^@/, "");
            const matchesMap = new Map();

            try {
                const uSnap = await db.collection("users")
                    .where("usernameLower", ">=", `@${cleanQ}`)
                    .where("usernameLower", "<=", `@${cleanQ}\uf8ff`)
                    .limit(12)
                    .get();
                uSnap.forEach(doc => matchesMap.set(doc.id, { id: doc.id, ...doc.data() }));
            } catch (e) {}

            try {
                const nSnap = await db.collection("users")
                    .where("nameLower", ">=", cleanQ)
                    .where("nameLower", "<=", `${cleanQ}\uf8ff`)
                    .limit(12)
                    .get();
                nSnap.forEach(doc => matchesMap.set(doc.id, { id: doc.id, ...doc.data() }));
            } catch (e) {}

            const matches = Array.from(matchesMap.values()).filter(u => {
                if (auth?.currentUser && u.id === auth.currentUser.uid) return false;
                if (u.id === "arjun_user_id") return false;
                const un = (u.username || "").toLowerCase();
                const nm = (u.name || "").toLowerCase();
                if (!un || un === "@user" || un === "@friend") return false;
                if (!nm || nm === "user" || nm === "friend") return false;
                return true;
            });

            if (matches.length === 0) {
                resultsBox.innerHTML = `<div class="user-search-empty">No user found with "${escapeHtml(rawQuery)}"</div>`;
            } else {
                resultsBox.innerHTML = "";
                matches.forEach(u => {
                    const row = document.createElement("div");
                    row.className = "user-search-item";
                    const safeDp = getSafeAvatar(u.photoURL || u.avatarUrl);
                    row.innerHTML = `
                        <img src="${escapeHtml(safeDp)}" onerror="this.src='logo.png'" alt="User">
                        <div class="us-info">
                            <h5>${escapeHtml(u.name)}</h5>
                            <span>${escapeHtml(u.username)}</span>
                        </div>
                        <button type="button" class="us-msg-btn">Message</button>
                    `;
                    row.addEventListener("click", () => {
                        startChatFromSearch(u.id, u.name, u.username, safeDp);
                    });
                    resultsBox.appendChild(row);
                });
            }
            resultsBox.style.display = "flex";
        } catch (err) {
            console.error("User search error:", err);
        }
    }, 180);
}

function startChatFromSearch(uid, name, username, avatar) {
    clearTimeout(searchDebounceTimer);
    const resultsBox = document.getElementById("liveUserSearchDropdown");
    const searchInp = document.getElementById("homeChatSearchInput");
    if (resultsBox) {
        resultsBox.innerHTML = "";
        resultsBox.style.display = "none";
    }
    if (searchInp) searchInp.value = "";
    filterHomeChatListByTab("all");

    openChatWithUser(uid, name, avatar, username);
}

// ================= FRIEND DM CHAT & PROFILE (ZERO DELAY + NO JUMPING ORDER) =================
function markDmChatAsRead(userId) {
    if (!userId) return;
    lastReadAtMap[userId] = Date.now();
    try { localStorage.setItem("zorenoLastReadAtMap", JSON.stringify(lastReadAtMap)); } catch (e) {}

    const idx = recentDmUsers.findIndex(x => x.uid === userId);
    if (idx >= 0 && recentDmUsers[idx].unread > 0) {
        recentDmUsers[idx].unread = 0;
        try { localStorage.setItem("zorenoRecentDms", JSON.stringify(recentDmUsers)); } catch (e) {}
        scheduleRenderSavedDmChats();
    }
}

function openChatWithUser(userId, targetName, targetAvatar, targetUsername = "@student") {
    closeAllDropdownMenus();
    currentChatUserId = userId;
    isFriendCurrentlyTyping = false;
    const existingEntry = recentDmUsers.find(x => x.uid === userId);

    currentChatUserMeta = {
        uid: userId,
        name: targetName || existingEntry?.name || "Student",
        avatar: getSafeAvatar(targetAvatar || existingEntry?.avatar),
        username: targetUsername || existingEntry?.username || "@student",
        bio: "Student | Exploring new things | Keep learning.",
        isOnline: false,
        lastActiveAtMs: 0,
        lastSeenLabel: "recently"
    };

    markDmChatAsRead(userId);

    const chatWin = document.getElementById("activeChatScreen");
    const nameEl = document.getElementById("activeChatName");
    const avatarEl = document.getElementById("activeChatAvatar");
    const bottomNav = document.getElementById("bottomNav");

    if (nameEl) nameEl.textContent = currentChatUserMeta.name;
    if (avatarEl) avatarEl.src = currentChatUserMeta.avatar;
    renderDmHeaderStatus();
    updateBlockMenuButtonUI();

    if (bottomNav) bottomNav.style.setProperty("display", "none", "important");
    if (chatWin) {
        chatWin.style.setProperty("display", "flex", "important");
        chatWin.style.setProperty("visibility", "visible", "important");
        chatWin.style.setProperty("pointer-events", "auto", "important");
    }

    if (activeFriendProfileUnsub) activeFriendProfileUnsub();
    if (db && userId) {
        activeFriendProfileUnsub = db.collection("users").doc(userId).onSnapshot(doc => {
            if (!doc.exists) return;
            const d = doc.data();
            currentChatUserMeta.name = d.name || currentChatUserMeta.name;
            currentChatUserMeta.username = d.username || currentChatUserMeta.username;
            currentChatUserMeta.avatar = getSafeAvatar(d.photoURL || d.avatarUrl || currentChatUserMeta.avatar);
            currentChatUserMeta.bio = d.bio || currentChatUserMeta.bio;
            currentChatUserMeta.isOnline = d.isOnline === true;
            currentChatUserMeta.lastActiveAtMs = d.lastActiveAtMs || 0;
            currentChatUserMeta.lastSeenLabel = d.lastSeenLabel || "recently";

            if (nameEl) nameEl.textContent = currentChatUserMeta.name;
            if (avatarEl) avatarEl.src = currentChatUserMeta.avatar;
            renderDmHeaderStatus();
            syncFriendProfileViewDOM();

            document.querySelectorAll(".dm-friend-side-dp").forEach(img => {
                img.src = currentChatUserMeta.avatar;
            });

            updateRecentDmMetaOnly(
                userId,
                currentChatUserMeta.name,
                currentChatUserMeta.avatar,
                currentChatUserMeta.username
            );
        });
    }

    if (activeChatMetaUnsub) activeChatMetaUnsub();
    if (db && auth?.currentUser && userId) {
        const myUid = auth.currentUser.uid;
        const chatId = myUid < userId ? `${myUid}_${userId}` : `${userId}_${myUid}`;
        activeChatMetaUnsub = db.collection("chats").doc(chatId).onSnapshot(doc => {
            if (!doc.exists) return;
            const data = doc.data() || {};
            isFriendCurrentlyTyping = !!data[`typing_${userId}`];
            renderDmHeaderStatus();
        });
    }

    loadMessagesFromFirestore(userId);
}

function openFriendProfileScreen() {
    closeAllDropdownMenus();
    if (!currentChatUserMeta) return;
    syncFriendProfileViewDOM();
    const fpScreen = document.getElementById("friendProfileScreen");
    if (fpScreen) fpScreen.style.setProperty("display", "block", "important");
}

function closeFriendProfileScreen() {
    closeAllDropdownMenus();
    const fpScreen = document.getElementById("friendProfileScreen");
    if (fpScreen) fpScreen.style.setProperty("display", "none", "important");
}

function toggleFpHeaderMenu(forceState) {
    const menu = document.getElementById("fpHeaderDropdownMenu");
    if (!menu) return;
    const nextState = typeof forceState === "boolean" ? forceState : menu.style.display !== "block";
    closeAllDropdownMenus();
    menu.style.display = nextState ? "block" : "none";
}

function syncFriendProfileViewDOM() {
    if (!currentChatUserMeta) return;
    const cleanHandle = (currentChatUserMeta.username || "@student").replace(/^@/, "");
    const fullHandle = `@${cleanHandle}`;
    const bioStr = currentChatUserMeta.bio || "Student | Exploring new things | Keep learning.";
    const pres = formatPresenceStatusText(
        currentChatUserMeta.isOnline,
        currentChatUserMeta.lastActiveAtMs,
        currentChatUserMeta.lastSeenLabel
    );
    const dotColor = pres.online ? "#10b981" : "#94a3b8";

    const avImg = document.getElementById("fpAvatarImg");
    const avDot = document.getElementById("fpAvatarDot");
    const fName = document.getElementById("fpFullName");
    const uSub = document.getElementById("fpUsernameSub");
    const pillDot = document.getElementById("fpPillDot");
    const pillTxt = document.getElementById("fpPillText");
    const pillBox = document.getElementById("fpOnlinePill");

    if (avImg) avImg.src = getSafeAvatar(currentChatUserMeta.avatar);
    if (avDot) avDot.style.background = dotColor;
    if (fName) fName.textContent = currentChatUserMeta.name || "Student";
    if (uSub) uSub.textContent = fullHandle;
    if (pillDot) pillDot.style.background = dotColor;
    if (pillTxt) pillTxt.textContent = pres.text;
    if (pillBox) {
        pillBox.style.background = pres.online ? "rgba(16, 185, 129, 0.14)" : "rgba(148, 163, 184, 0.18)";
        pillBox.style.color = pres.online ? "#059669" : "#64748b";
    }

    const cUser = document.getElementById("fpCardUsername");
    const cName = document.getElementById("fpCardName");
    const cBio = document.getElementById("fpCardBio");
    const cBioCount = document.getElementById("fpBioCount");
    const bDot = document.getElementById("fpBottomStatusDot");
    const bTxt = document.getElementById("fpBottomStatusText");

    if (cUser) cUser.textContent = cleanHandle;
    if (cName) cName.textContent = currentChatUserMeta.name || "Student";
    if (cBio) cBio.textContent = bioStr;
    if (cBioCount) cBioCount.textContent = `${bioStr.length}/150`;
    if (bDot) bDot.style.background = dotColor;
    if (bTxt) bTxt.textContent = pres.text;
}

async function copyFriendUsername() {
    if (!currentChatUserMeta) return;
    const handle = (currentChatUserMeta.username || "").replace(/^@/, "");
    try {
        await navigator.clipboard.writeText(handle);
        showCustomAlert("Copied! ✓", `@${handle} copied to clipboard.`, true);
    } catch (e) {}
}

function viewDmUserProfileInfo() {
    openFriendProfileScreen();
}

function renderDmHeaderStatus() {
    const statusEl = document.getElementById("activeChatStatus");
    const dotEl = document.getElementById("activeChatOnlineDot");
    if (!statusEl || !currentChatUserMeta) return;

    const uHandle = escapeHtml(currentChatUserMeta.username || "@student");
    if (isFriendCurrentlyTyping) {
        statusEl.innerHTML = `${uHandle} • <span style="color:#10b981; font-weight:800;">typing...</span>`;
        if (dotEl) dotEl.style.background = "#10b981";
        return;
    }

    const pres = formatPresenceStatusText(
        currentChatUserMeta.isOnline,
        currentChatUserMeta.lastActiveAtMs,
        currentChatUserMeta.lastSeenLabel
    );
    if (pres.online) {
        statusEl.innerHTML = `${uHandle} • <span style="color:#10b981; font-weight:700;">Online</span>`;
        if (dotEl) dotEl.style.background = "#10b981";
    } else {
        statusEl.innerHTML = `${uHandle} • <span style="color:#94a3b8;">${escapeHtml(pres.text)}</span>`;
        if (dotEl) dotEl.style.background = "#94a3b8";
    }
}

function handleLiveTypingInput() {
    if (!db || !auth?.currentUser || !currentChatUserId) return;
    const myUid = auth.currentUser.uid;
    const chatId = myUid < currentChatUserId ? `${myUid}_${currentChatUserId}` : `${currentChatUserId}_${myUid}`;

    db.collection("chats").doc(chatId).set({
        [`typing_${myUid}`]: true
    }, { merge: true }).catch(() => {});

    clearTimeout(typingTimeoutTimer);
    typingTimeoutTimer = setTimeout(() => {
        db.collection("chats").doc(chatId).set({
            [`typing_${myUid}`]: false
        }, { merge: true }).catch(() => {});
    }, 1500);
}

function renderDmMessagesListToDOM(chatId, messagesArray, myUid) {
    const msgContainer = document.getElementById("activeChatMessages");
    if (!msgContainer) return;

    const clearedAt = chatClearedAtMap[chatId] || 0;
    const visibleMsgs = messagesArray.filter(m => {
        if (deletedMsgsMap[m.id]) return false;
        if (clearedAt && (m.timestampMs || 0) <= clearedAt) return false;
        return true;
    });

    const firstName = escapeHtml((currentChatUserMeta?.name || "Friend").split(" ")[0]);
    if (visibleMsgs.length === 0) {
        msgContainer.innerHTML = `
            <div class="dm-empty-state-wrap">
                <div class="dm-3d-bubbles-box">
                    <div class="dm-bubble-big"><span></span><span></span><span></span></div>
                    <div class="dm-bubble-small"><span></span><span></span><span></span></div>
                </div>
                <h3>No messages yet</h3>
                <p>Start a conversation with ${firstName}</p>
            </div>
        `;
        return;
    }

    const friendDp = escapeHtml(getSafeAvatar(currentChatUserMeta?.avatar));
    const fragment = document.createDocumentFragment();

    visibleMsgs.forEach(d => {
        const isMe = d.senderId === myUid;
        let tickIcon = '<i class="fa-solid fa-check" style="color:rgba(255,255,255,0.8); font-size:10px;"></i>';
        if (d.seen) {
            tickIcon = '<i class="fa-solid fa-check-double" style="color:#38bdf8; font-size:11px;"></i>';
        } else if (d.delivered) {
            tickIcon = '<i class="fa-solid fa-check-double" style="color:rgba(255,255,255,0.85); font-size:10px;"></i>';
        }

        const mediaHtml = d.imageData
            ? `<div class="sent-media-grid"><img src="${d.imageData}" class="sent-small-thumb" onclick="event.stopPropagation(); openFullImageModal('${d.imageData}')" alt="Image"></div>`
            : "";

        const row = document.createElement("div");
        row.className = `msg-row-with-avatar ${isMe ? "right-user" : "left-friend"}`;

        if (isMe) {
            row.innerHTML = `
                <div class="clean-right-bubble" onclick="promptDeleteMessage('${d.id}', '${chatId}')" style="cursor:pointer;" title="Tap to delete for me">
                    ${mediaHtml}
                    ${d.text ? `<div>${escapeHtml(d.text)}</div>` : ""}
                    <div class="bubble-meta-time">
                        <span>${escapeHtml(d.timeLabel || "Now")}</span>
                        ${tickIcon}
                    </div>
                </div>
            `;
        } else {
            row.innerHTML = `
                <img src="${friendDp}" onerror="this.src='logo.png'" class="msg-side-avatar dm-friend-side-dp" alt="DP" onclick="openFriendProfileScreen()" style="cursor:pointer;">
                <div class="clean-left-bubble" onclick="promptDeleteMessage('${d.id}', '${chatId}')" style="cursor:pointer;" title="Tap to delete for me">
                    ${mediaHtml}
                    <div style="display:flex; justify-content:space-between; align-items:baseline; gap:12px;">
                        <span>${escapeHtml(d.text || "")}</span>
                        <span style="font-size:10px; color:#94a3b8; font-weight:500; white-space:nowrap;">${escapeHtml(d.timeLabel || "Now")}</span>
                    </div>
                </div>
            `;
        }
        fragment.appendChild(row);
    });

    msgContainer.innerHTML = "";
    msgContainer.appendChild(fragment);
    msgContainer.scrollTop = msgContainer.scrollHeight;
}

function loadMessagesFromFirestore(recipientId) {
    const msgContainer = document.getElementById("activeChatMessages");
    if (!msgContainer) return;

    if (activeMessagesUnsubscribe) {
        activeMessagesUnsubscribe();
        activeMessagesUnsubscribe = null;
    }

    const myUid = auth?.currentUser?.uid || "local";
    const chatId = myUid < recipientId ? `${myUid}_${recipientId}` : `${recipientId}_${myUid}`;
    const cacheKey = `zorenoDmCache_${chatId}`;

    let cachedMsgs = [];
    try { cachedMsgs = JSON.parse(localStorage.getItem(cacheKey) || "[]"); } catch (e) { cachedMsgs = []; }
    if (cachedMsgs.length > 0) {
        renderDmMessagesListToDOM(chatId, cachedMsgs, myUid);
    } else {
        renderDmMessagesListToDOM(chatId, [], myUid);
    }

    if (!db || !auth?.currentUser) return;

    activeMessagesUnsubscribe = db.collection("chats").doc(chatId).collection("messages")
        .onSnapshot(snapshot => {
            const docs = snapshot.docs.slice().sort((a, b) => {
                const da = a.data();
                const dbData = b.data();
                const ta = da.timestampMs || da.createdAt?.toMillis?.() || 0;
                const tb = dbData.timestampMs || dbData.createdAt?.toMillis?.() || 0;
                return ta - tb;
            });

            const unseenRefs = [];
            const freshList = docs.map(doc => {
                const d = doc.data();
                if (d.senderId !== myUid && !d.seen) {
                    unseenRefs.push(doc.ref);
                }
                return {
                    id: doc.id,
                    senderId: d.senderId,
                    text: d.text || "",
                    imageData: d.imageData || "",
                    timeLabel: d.timeLabel || "Now",
                    timestampMs: d.timestampMs || d.createdAt?.toMillis?.() || 0,
                    delivered: true,
                    seen: d.senderId !== myUid ? true : !!d.seen
                };
            });

            try { localStorage.setItem(cacheKey, JSON.stringify(freshList.slice(-60))); } catch (e) {}
            renderDmMessagesListToDOM(chatId, freshList, myUid);
            markDmChatAsRead(recipientId);

            if (unseenRefs.length > 0) {
                const batch = db.batch();
                unseenRefs.forEach(ref => batch.update(ref, { seen: true, delivered: true }));
                batch.commit().catch(() => {});
            }
        });
}

// ================= DM IMAGE UPLOAD WITH CIRCULAR LOADING SPINNER =================
function openDmImagePicker() {
    document.getElementById("dmImageInput")?.click();
}

function handleDmImageSelect(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    event.target.value = "";

    const strip = document.getElementById("dmAttachmentPreviewBar");
    if (!strip) return;

    pendingDmAttachment = { loading: true, dataUrl: "" };
    strip.style.display = "flex";
    strip.innerHTML = `
        <div class="preview-item-chip">
            <div class="chip-spinner-overlay"><i class="fa-solid fa-circle-notch fa-spin"></i></div>
        </div>
        <span style="font-size:12px; font-weight:700; color:#7c3aed;">Processing photo...</span>
    `;

    const reader = new FileReader();
    reader.onload = function (e) {
        const img = new Image();
        img.onload = function () {
            const canvas = document.createElement("canvas");
            const MAX_DIM = 720;
            let w = img.width, h = img.height;
            if (w > h && w > MAX_DIM) { h = Math.round((h * MAX_DIM) / w); w = MAX_DIM; }
            else if (h >= w && h > MAX_DIM) { w = Math.round((w * MAX_DIM) / h); h = MAX_DIM; }
            canvas.width = w;
            canvas.height = h;
            canvas.getContext("2d").drawImage(img, 0, 0, w, h);
            const compressed = canvas.toDataURL("image/jpeg", 0.68);

            setTimeout(() => {
                pendingDmAttachment = { loading: false, dataUrl: compressed };
                strip.innerHTML = `
                    <div class="preview-item-chip">
                        <img src="${compressed}" alt="Preview">
                        <button type="button" class="preview-remove-x" onclick="clearDmAttachment()">×</button>
                    </div>
                    <span style="font-size:12px; font-weight:700; color:#10b981;">✓ Ready to send</span>
                `;
            }, 320);
        };
        img.src = e.target.result;
    };
    reader.readAsDataURL(file);
}

function clearDmAttachment() {
    pendingDmAttachment = null;
    const strip = document.getElementById("dmAttachmentPreviewBar");
    if (strip) {
        strip.innerHTML = "";
        strip.style.display = "none";
    }
}

async function sendRealtimeMessage() {
    const input = document.getElementById("activeChatInput");
    const text = (input?.value || "").trim();
    if (pendingDmAttachment?.loading) {
        showCustomAlert("Please Wait", "Photo is still loading...");
        return;
    }
    const imgData = pendingDmAttachment?.dataUrl || "";
    if ((!text && !imgData) || !currentChatUserId) return;

    if (blockedUsersMap[currentChatUserId]) {
        showCustomAlert("Blocked 🚫", "You have blocked this user. Unblock from the 3-dot menu to send messages.");
        return;
    }

    const nowMs = Date.now();
    const nowTime = new Date(nowMs).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    if (input) input.value = "";
    clearDmAttachment();

    const previewLabel = text ? `You: ${text}` : "You: 📷 Photo";

    if (currentChatUserMeta) {
        upsertRecentDmOnHome(
            currentChatUserMeta.uid,
            currentChatUserMeta.name,
            currentChatUserMeta.avatar,
            currentChatUserMeta.username,
            previewLabel,
            nowTime,
            0,
            nowMs
        );
    }

    if (!db || !auth?.currentUser) return;
    const myUid = auth.currentUser.uid;
    const chatId = myUid < currentChatUserId ? `${myUid}_${currentChatUserId}` : `${currentChatUserId}_${myUid}`;

    try {
        await db.collection("chats").doc(chatId).collection("messages").add({
            senderId: myUid,
            text: text,
            imageData: imgData,
            timeLabel: nowTime,
            timestampMs: nowMs,
            delivered: true,
            seen: false,
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });

        await db.collection("chats").doc(chatId).set({
            participants: [myUid, currentChatUserId],
            lastMessage: text || "📷 Photo",
            lastSenderId: myUid,
            lastSenderName: userName,
            lastSenderAvatar: getSafeAvatar(userAvatarUrl),
            lastSenderUsername: currentUsername || "@student",
            [`typing_${myUid}`]: false,
            lastMessageAtMs: nowMs,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
            timeLabel: nowTime
        }, { merge: true });
    } catch (e) {
        console.error("Send DM error:", e);
    }
}

function updateRecentDmMetaOnly(uid, name, avatar, username) {
    const idx = recentDmUsers.findIndex(x => x.uid === uid);
    if (idx < 0) return;
    recentDmUsers[idx].name = name || recentDmUsers[idx].name;
    recentDmUsers[idx].avatar = getSafeAvatar(avatar || recentDmUsers[idx].avatar);
    recentDmUsers[idx].username = username || recentDmUsers[idx].username;
    try { localStorage.setItem("zorenoRecentDms", JSON.stringify(recentDmUsers)); } catch (e) {}
    scheduleRenderSavedDmChats();
}

function upsertRecentDmOnHome(uid, name, avatar, username, lastMsg, timeStr, unreadCount = 0, msgTimestampMs = 0) {
    if (!uid || uid === "arjun_user_id") return;
    const cleanUn = (username || "").toLowerCase();
    const cleanNm = (name || "").toLowerCase();
    if (cleanUn === "@friend" || cleanUn === "@user" || cleanNm === "friend" || cleanNm === "user") return;

    const idx = recentDmUsers.findIndex(x => x.uid === uid);
    const prev = idx >= 0 ? recentDmUsers[idx] : {};
    const effectiveMs = msgTimestampMs || prev.lastMessageAtMs || Date.now();

    const entry = {
        uid,
        name: name || prev.name || "Student",
        avatar: getSafeAvatar(avatar || prev.avatar),
        username: username || prev.username || "@student",
        lastMsg: lastMsg || prev.lastMsg || "Tap to chat",
        timeStr: formatSmartTimeLabel(effectiveMs) || timeStr || prev.timeStr || "",
        lastMessageAtMs: effectiveMs,
        unread: typeof unreadCount === "number" ? unreadCount : (prev.unread || 0)
    };

    if (idx >= 0) recentDmUsers.splice(idx, 1);
    recentDmUsers.push(entry);

    recentDmUsers.sort((a, b) => (b.lastMessageAtMs || 0) - (a.lastMessageAtMs || 0));

    localStorage.setItem("zorenoRecentDms", JSON.stringify(recentDmUsers.slice(0, 25)));
    scheduleRenderSavedDmChats();
}

let renderHomeDmTimer = null;
function scheduleRenderSavedDmChats() {
    clearTimeout(renderHomeDmTimer);
    renderHomeDmTimer = setTimeout(renderSavedDmChatsOnHome, 80);
}

function renderSavedDmChatsOnHome() {
    const container = document.querySelector(".chats-container");
    if (!container) return;

    container.querySelectorAll(".dynamic-dm-item").forEach(el => el.remove());
    const pinnedItem = container.querySelector(".chat-list-item.pinned");

    const sortedList = recentDmUsers.slice().sort((a, b) => (b.lastMessageAtMs || 0) - (a.lastMessageAtMs || 0));

    sortedList.slice().reverse().forEach(item => {
        const cleanUn = (item.username || "").toLowerCase();
        if (cleanUn === "@friend" || cleanUn === "@user") return;

        const div = document.createElement("div");
        div.className = "chat-list-item dynamic-dm-item";
        div.style.cursor = "pointer";
        div.onclick = () => openChatWithUser(item.uid, item.name, item.avatar, item.username);
        const displayTime = formatSmartTimeLabel(item.lastMessageAtMs) || item.timeStr || "";
        div.innerHTML = `
            <div class="chat-avatar">
                <img src="${escapeHtml(getSafeAvatar(item.avatar))}" onerror="this.src='logo.png'" alt="${escapeHtml(item.name)}">
                <div class="online-dot"></div>
            </div>
            <div class="chat-info">
                <div class="chat-name-row">
                    <h4>${escapeHtml(item.name)}</h4>
                    <span class="chat-time">${escapeHtml(displayTime)}</span>
                </div>
                <div class="chat-msg-row">
                    <p>${escapeHtml(item.lastMsg)}</p>
                    ${item.unread > 0 ? `<span class="unread-count">${item.unread}</span>` : ""}
                </div>
            </div>
        `;
        if (pinnedItem) {
            pinnedItem.insertAdjacentElement("afterend", div);
        } else {
            container.prepend(div);
        }
    });
}

function listenIncomingRealtimeChats(myUid) {
    if (!db || !myUid) return;
    if (incomingChatsUnsub) {
        incomingChatsUnsub();
        incomingChatsUnsub = null;
    }

    let isInitialLoad = true;
    setTimeout(() => { isInitialLoad = false; }, 2500);

    incomingChatsUnsub = db.collection("chats")
        .where("participants", "array-contains", myUid)
        .onSnapshot(snap => {
            snap.docChanges().forEach(async change => {
                if (change.type !== "added" && change.type !== "modified") return;
                const d = change.doc.data();
                const otherUid = (d.participants || []).find(id => id !== myUid);
                if (!otherUid || !d.lastMessage) return;

                let cached = userProfileCache[otherUid];
                if (!cached) {
                    try {
                        const uDoc = await db.collection("users").doc(otherUid).get();
                        if (!uDoc.exists) return;
                        cached = uDoc.data();
                        userProfileCache[otherUid] = cached;
                    } catch (e) { return; }
                }

                const friendName = cached.name || d.lastSenderName || "Friend";
                const friendAvatar = getSafeAvatar(cached.photoURL || cached.avatarUrl || d.lastSenderAvatar);
                const friendUsername = cached.username || d.lastSenderUsername;

                if (!friendUsername || friendUsername === "@friend" || friendUsername === "@user") return;

                const prevEntry = recentDmUsers.find(x => x.uid === otherUid);
                const msgTimeMs = d.lastMessageAtMs || d.updatedAt?.toMillis?.() || prevEntry?.lastMessageAtMs || 0;
                const displayTimeStr = msgTimeMs ? formatSmartTimeLabel(msgTimeMs) : (d.timeLabel || prevEntry?.timeStr || "");
                const lastReadMs = lastReadAtMap[otherUid] || 0;
                const isChatOpen = document.getElementById("activeChatScreen")?.style.display === "flex" && currentChatUserId === otherUid;

                if (isChatOpen && msgTimeMs) {
                    lastReadAtMap[otherUid] = Date.now();
                    try { localStorage.setItem("zorenoLastReadAtMap", JSON.stringify(lastReadAtMap)); } catch (e) {}
                }

                const isUnreadForMe = d.lastSenderId !== myUid && !isChatOpen && msgTimeMs > 0 && msgTimeMs > lastReadMs;
                const msgPreview = d.lastSenderId === myUid ? `You: ${d.lastMessage}` : d.lastMessage;

                upsertRecentDmOnHome(
                    otherUid,
                    friendName,
                    friendAvatar,
                    friendUsername,
                    msgPreview,
                    displayTimeStr,
                    isUnreadForMe ? 1 : 0,
                    msgTimeMs || 1
                );

                if (!isInitialLoad && change.type === "modified" && isUnreadForMe) {
                    showZorenoIncomingNotification(otherUid, friendName, friendAvatar, friendUsername, d.lastMessage);
                }
            });
        });
}


function closeActiveDmChat() {
    closeAllDropdownMenus();
    closeFriendProfileScreen();
    if (activeFriendProfileUnsub) { activeFriendProfileUnsub(); activeFriendProfileUnsub = null; }
    if (activeChatMetaUnsub) { activeChatMetaUnsub(); activeChatMetaUnsub = null; }
    if (activeMessagesUnsubscribe) { activeMessagesUnsubscribe(); activeMessagesUnsubscribe = null; }
    const chatWin = document.getElementById("activeChatScreen");
    if (chatWin) chatWin.style.setProperty("display", "none", "important");
    showChatsHome();
}

function toggleDmHeaderMenu(forceState) {
    const menu = document.getElementById("dmHeaderDropdownMenu");
    if (!menu) return;
    const nextState = typeof forceState === "boolean" ? forceState : menu.style.display !== "block";
    closeAllDropdownMenus();
    menu.style.display = nextState ? "block" : "none";
}

function toggleBlockChatUser() {
    closeAllDropdownMenus();
    if (!currentChatUserId) return;
    const isBlocked = !!blockedUsersMap[currentChatUserId];
    if (isBlocked) {
        delete blockedUsersMap[currentChatUserId];
        showCustomAlert("User Unblocked", "You can now send messages to this user.", true);
    } else {
        blockedUsersMap[currentChatUserId] = true;
        showCustomAlert("User Blocked 🚫", "You will no longer receive or send messages in this chat.");
    }
    localStorage.setItem("zorenoBlockedUsers", JSON.stringify(blockedUsersMap));
    updateBlockMenuButtonUI();
}

function updateBlockMenuButtonUI() {
    const isBlocked = currentChatUserId && !!blockedUsersMap[currentChatUserId];
    const html = isBlocked
        ? '<i class="fa-solid fa-rotate-left"></i> Unblock User'
        : '<i class="fa-solid fa-ban"></i> Block User';
    const btn1 = document.getElementById("dmBlockMenuBtn");
    const btn2 = document.getElementById("fpBlockMenuBtn");
    if (btn1) btn1.innerHTML = html;
    if (btn2) btn2.innerHTML = html;
}

async function clearCurrentDmChat() {
    closeAllDropdownMenus();
    if (!currentChatUserId) return;
    const myUid = auth?.currentUser?.uid || "local";
    const chatId = myUid < currentChatUserId ? `${myUid}_${currentChatUserId}` : `${currentChatUserId}_${myUid}`;

    chatClearedAtMap[chatId] = Date.now();
    try { localStorage.setItem("zorenoChatClearedAtMap", JSON.stringify(chatClearedAtMap)); } catch (e) {}

    let cachedMsgs = [];
    try { cachedMsgs = JSON.parse(localStorage.getItem(`zorenoDmCache_${chatId}`) || "[]"); } catch (e) {}
    renderDmMessagesListToDOM(chatId, cachedMsgs, myUid);
    showCustomAlert("Chat Cleared 🗑️", "Messages have been cleared from your view.", true);
}

function openReportModal() {
    closeAllDropdownMenus();
    document.getElementById("userReportModal").style.display = "flex";
}

async function submitUserReport() {
    const reason = document.getElementById("userReportReason").value.trim();
    if (!reason || !currentChatUserId) return;
    try {
        if (db && auth?.currentUser) {
            await db.collection("reports").add({
                reporterUid: auth.currentUser.uid,
                reportedUserId: currentChatUserId,
                reason: reason,
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            });
        }
        document.getElementById("userReportReason").value = "";
        document.getElementById("userReportModal").style.display = "none";
        showCustomAlert("Report Submitted", "Our moderation team will review this user within 24 hours.", true);
    } catch (e) {
        showCustomAlert("Error", e.message);
    }
}

// ================= DELETE FOR ME (30958.PNG FIXED) =================
function promptDeleteMessage(msgId, chatId) {
    aiMsgIndexToDelete = null;
    msgToDeleteId = msgId;
    msgToDeleteChatId = chatId;
    document.getElementById("deleteMsgModal").style.display = "flex";
}

function promptDeleteSingleAiMessage(idx) {
    msgToDeleteId = null;
    msgToDeleteChatId = null;
    aiMsgIndexToDelete = idx;
    document.getElementById("deleteMsgModal").style.display = "flex";
}

async function confirmDeleteMessage() {
    if (aiMsgIndexToDelete !== null && aiChatMessagesList[aiMsgIndexToDelete]) {
        const removed = aiChatMessagesList.splice(aiMsgIndexToDelete, 1)[0];
        try { localStorage.setItem("zorenoAiChatStream", JSON.stringify(aiChatMessagesList)); } catch (e) {}
        renderAiChatStream();

        if (db && auth?.currentUser && removed?.timestampMs) {
            try {
                const snap = await db.collection("users").doc(auth.currentUser.uid)
                    .collection("chats").where("timestampMs", "==", removed.timestampMs).get();
                snap.forEach(d => d.ref.delete());
            } catch (e) {}
        }
        document.getElementById("deleteMsgModal").style.display = "none";
        aiMsgIndexToDelete = null;
        return;
    }

    if (!msgToDeleteId || !msgToDeleteChatId) return;
    deletedMsgsMap[msgToDeleteId] = true;
    try { localStorage.setItem("zorenoDeletedMsgsMap", JSON.stringify(deletedMsgsMap)); } catch (e) {}

    const myUid = auth?.currentUser?.uid || "local";
    let cachedMsgs = [];
    try { cachedMsgs = JSON.parse(localStorage.getItem(`zorenoDmCache_${msgToDeleteChatId}`) || "[]"); } catch (e) {}
    renderDmMessagesListToDOM(msgToDeleteChatId, cachedMsgs, myUid);

    document.getElementById("deleteMsgModal").style.display = "none";
    msgToDeleteId = null;
    msgToDeleteChatId = null;
}

function showCallComingSoon() {
    showCustomAlert("Coming Soon 🚀", "Voice & Video Calling will be available in the next update!", true);
}

function triggerZorenoAudioCall() {
    showCallComingSoon();
}

function triggerZorenoVideoCall() {
    showCallComingSoon();
}

function showAttachmentComingSoon() {
    openDmImagePicker();
}

// ================= AI CHAT IMAGE SELECTION WITH CIRCULAR SPINNER =================
function openImagePicker() {
    document.getElementById("imageInput")?.click();
}

function openFileOrPdfPicker() {
    document.getElementById("imageInput")?.click();
}

function handleMultipleImages(event) {
    const allSelected = Array.from(event.target.files || []);
    event.target.value = "";
    if (!allSelected.length) return;

    const remainingSlots = 2 - pendingAiAttachments.length;
    if (remainingSlots <= 0) {
        showCustomAlert("Maximum 2 Images", "You can select up to 2 images at a time.");
        return;
    }

    const files = allSelected.slice(0, remainingSlots);
    const strip = document.getElementById("aiAttachmentPreviewBar");
    if (strip) strip.style.setProperty("display", "flex", "important");

    files.forEach(file => {
        const tempId = "att_" + Date.now() + "_" + Math.random().toString(36).slice(2, 6);
        pendingAiAttachments.push({ id: tempId, loading: true, dataUrl: "", mimeType: "image/jpeg" });
        renderAiAttachmentPreviewStrip();

        const reader = new FileReader();
        reader.onload = function (e) {
            const img = new Image();
            img.onload = function () {
                const canvas = document.createElement("canvas");
                const MAX_DIM = 560; // Compact size & low quality so it sends super fast
                let w = img.width, h = img.height;
                if (w > h && w > MAX_DIM) { h = Math.round((h * MAX_DIM) / w); w = MAX_DIM; }
                else if (h >= w && h > MAX_DIM) { w = Math.round((w * MAX_DIM) / h); h = MAX_DIM; }
                canvas.width = w;
                canvas.height = h;
                canvas.getContext("2d").drawImage(img, 0, 0, w, h);
                const compressed = canvas.toDataURL("image/jpeg", 0.58);

                setTimeout(() => {
                    const item = pendingAiAttachments.find(x => x.id === tempId);
                    if (item) {
                        item.loading = false;
                        item.dataUrl = compressed;
                        renderAiAttachmentPreviewStrip();
                    }
                }, 300);
            };
            img.onerror = function () {
                pendingAiAttachments = pendingAiAttachments.filter(x => x.id !== tempId);
                renderAiAttachmentPreviewStrip();
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(file);
    });
}

function renderAiAttachmentPreviewStrip() {
    const strip = document.getElementById("aiAttachmentPreviewBar");
    if (!strip) return;
    if (pendingAiAttachments.length === 0) {
        strip.innerHTML = "";
        strip.style.setProperty("display", "none", "important");
        return;
    }
    const isAnyLoading = pendingAiAttachments.some(a => a.loading);
    strip.style.setProperty("display", "flex", "important");
    strip.innerHTML = pendingAiAttachments.map(att => {
        if (att.loading) {
            return `
                <div class="preview-item-chip">
                    <div class="chip-spinner-overlay"><i class="fa-solid fa-circle-notch fa-spin"></i></div>
                </div>
            `;
        }
        return `
            <div class="preview-item-chip">
                <img src="${att.dataUrl}" onclick="openFullImageModal('${att.dataUrl}')" alt="Preview">
                <button type="button" class="preview-remove-x" onclick="removeAiAttachment('${att.id}')">×</button>
            </div>
        `;
    }).join("") + `<span style="font-size:12px; font-weight:700; color:${isAnyLoading ? '#7c3aed' : '#10b981'}; margin-left:6px;">
        ${isAnyLoading ? 'Loading photo...' : `✓ ${pendingAiAttachments.length}/2 Ready`}
    </span>`;
}


function removeAiAttachment(id) {
    pendingAiAttachments = pendingAiAttachments.filter(x => x.id !== id);
    renderAiAttachmentPreviewStrip();
}

function openFullImageModal(dataUrl) {
    const modal = document.getElementById("fullImagePreviewModal");
    const img = document.getElementById("fullImagePreviewTarget");
    if (modal && img) {
        img.src = dataUrl;
        modal.style.display = "flex";
    }
}

function insertQuickEmoji() {
    const inp = document.getElementById("activeChatInput");
    if (inp) { inp.value += "😊"; inp.focus(); }
}

function insertAiQuickEmoji() {
    const inp = document.getElementById("userInput");
    if (inp) { inp.value += "😊"; inp.focus(); }
}

// =========================================================
// ZORENO APP.JS — PART 3 OF 3 (FINAL - ZERO ERRORS VERSION)
// ZORENO AI CHAT, COLORFUL STEPS, COPY/LISTEN, ADS, SEARCH & TOOLS
// =========================================================

// ================= ZORENO AI CHAT (COLORFUL POINTS + COPY & LISTEN BUTTONS) =================
function getLocalDailyAiLimit() {
    const today = new Date().toISOString().slice(0, 10);
    if (localStorage.getItem("zorenoAiLimitDate") !== today) {
        localStorage.setItem("zorenoAiLimitDate", today);
        localStorage.setItem("zorenoAiDailyLimit", "10");
    }
    return parseInt(localStorage.getItem("zorenoAiDailyLimit") || "10");
}

function getLocalDailyAiCount() {
    const today = new Date().toISOString().slice(0, 10);
    if (localStorage.getItem("zorenoAiDate") !== today) {
        localStorage.setItem("zorenoAiDate", today);
        localStorage.setItem("zorenoAiCount", "0");
    }
    return parseInt(localStorage.getItem("zorenoAiCount") || "0");
}

function incrementLocalDailyAiCount() {
    const c = getLocalDailyAiCount() + 1;
    localStorage.setItem("zorenoAiCount", String(c));
    return c;
}

function addBonusAiChats(extraChats = 3) {
    const currentLimit = getLocalDailyAiLimit();
    const newLimit = currentLimit + extraChats;
    localStorage.setItem("zorenoAiDailyLimit", String(newLimit));
    return newLimit;
}

const STEP_ICON_PALETTE = [
    { icon: "fa-brain", bg: "rgba(139, 92, 246, 0.14)", color: "#8b5cf6" },
    { icon: "fa-Seedling", fallback: "fa-leaf", bg: "rgba(16, 185, 129, 0.14)", color: "#10b981" },
    { icon: "fa-bolt", bg: "rgba(245, 158, 11, 0.15)", color: "#f59e0b" },
    { icon: "fa-book-open", bg: "rgba(14, 165, 233, 0.14)", color: "#0ea5e9" },
    { icon: "fa-star", bg: "rgba(236, 72, 153, 0.14)", color: "#ec4899" },
    { icon: "fa-compass", bg: "rgba(99, 102, 241, 0.14)", color: "#6366f1" },
    { icon: "fa-microscope", bg: "rgba(20, 184, 166, 0.14)", color: "#14b8a6" },
    { icon: "fa-fire-flame-curved", bg: "rgba(244, 63, 94, 0.14)", color: "#f43f5e" },
    { icon: "fa-lightbulb", bg: "rgba(234, 179, 8, 0.15)", color: "#ca8a04" },
    { icon: "fa-check-double", bg: "rgba(34, 197, 94, 0.14)", color: "#16a34a" },
    { icon: "fa-atom", bg: "rgba(59, 130, 246, 0.14)", color: "#3b82f6" },
    { icon: "fa-rocket", bg: "rgba(168, 85, 247, 0.14)", color: "#a855f7" }
];

function formatMarkdown(t, seedOffset = 0) {
    if (!t) return "";
    let lines = String(t).replace(/\r\n/g, "\n").split("\n");
    let htmlParts = [];
    let inList = false;

    // Seed offset based on text length so every answer gets different colorful icons!
    let hashSeed = seedOffset || (t.length + t.charCodeAt(0));
    let stepIndex = Math.abs(hashSeed) % STEP_ICON_PALETTE.length;

    for (let i = 0; i < lines.length; i++) {
        let line = lines[i].trim();
        if (!line) continue;

        let safeLine = escapeHtml(line).replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");

        let numMatch = safeLine.match(/^(\d+)\.\s+(?:<strong>)?([^:<]+?)(?:<\/strong>)?(?::\s*(.*))?$/);
        if (numMatch) {
            if (inList) {
                htmlParts.push("</ul>");
                inList = false;
            }
            const num = numMatch[1];
            const title = numMatch[2].trim();
            let desc = (numMatch[3] || "").trim();

            if (!desc && i + 1 < lines.length) {
                const nextLine = lines[i + 1].trim();
                if (nextLine && !/^\d+\.\s+/.test(nextLine) && !/^[\*\-•]\s+/.test(nextLine)) {
                    desc = escapeHtml(nextLine).replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
                    i++;
                }
            }

            const styleObj = STEP_ICON_PALETTE[stepIndex % STEP_ICON_PALETTE.length];
            const iconClass = styleObj.fallback || styleObj.icon;
            stepIndex += 2; // Jump by 2 for maximum variety

            htmlParts.push(`
                <div class="ai-step-card">
                    <div class="ai-step-icon-circle" style="background:${styleObj.bg}; color:${styleObj.color};">
                        <i class="fa-solid ${iconClass}"></i>
                    </div>
                    <div class="ai-step-text">
                        <h5>${num}. ${title}</h5>
                        ${desc ? `<p>${desc}</p>` : ""}
                    </div>
                </div>
            `);
            continue;
        }

        if (/^[\*\-•]\s+(.*)/.test(safeLine)) {
            let itemText = safeLine.replace(/^[\*\-•]\s+/, "");
            if (!inList) {
                htmlParts.push('<ul class="ai-compact-list">');
                inList = true;
            }
            htmlParts.push(`<li>${itemText}</li>`);
        } else {
            if (inList) {
                htmlParts.push("</ul>");
                inList = false;
            }
            safeLine = safeLine.replace(/^#{1,3}\s+/, "");
            htmlParts.push(`<p>${safeLine}</p>`);
        }
    }
    if (inList) htmlParts.push("</ul>");
    return htmlParts.join("");
}

function getHealthDisclaimerHTML(userQuery) {
    if (typeof isHealthOrMedicalQuery === "function" && isHealthOrMedicalQuery(userQuery)) {
        return `
            <div class="ai-health-disclaimer">
                <i class="fa-solid fa-circle-info"></i>
                <span>Information only • Not medical advice. Consult a doctor or contact local emergency services if needed.</span>
            </div>
        `;
    }
    return "";
}

function getSmartAffiliateCard(userQuery) {
    const q = (userQuery || "").toLowerCase();
    if (/pen|pencil|stationary|stationery|schneider|luxor|write/i.test(q)) {
        return `
            <div class="ai-affiliate-card" onclick="event.stopPropagation(); window.open('https://www.amazon.in/s?k=Luxor+Schneider+LX+Max+Pen&tag=zoreno-21', '_blank')">
                <span class="aff-badge">✦ Recommended Study Gear</span>
                <div class="aff-body">
                    <div>
                        <h5>Luxor Schneider LX Max Pen</h5>
                        <p>Best for fast exam writing & smooth notes</p>
                    </div>
                    <button type="button">Buy ↗</button>
                </div>
            </div>
        `;
    }
    return "";
}

async function copyAiResponseText(idx, btnEl) {
    const text = aiChatMessagesList[idx]?.bot || "";
    if (!text) return;
    const cleanText = text.replace(/\*\*/g, "");
    try {
        await navigator.clipboard.writeText(cleanText);
        if (btnEl) {
            const oldHtml = btnEl.innerHTML;
            btnEl.innerHTML = '<i class="fa-solid fa-check" style="color:#10b981;"></i>';
            setTimeout(() => { btnEl.innerHTML = oldHtml; }, 1400);
        }
    } catch (e) {}
}

let activeSpeakingIdx = null;
function speakAiResponseText(idx, btnEl) {
    if (!("speechSynthesis" in window)) {
        showCustomAlert("Not Supported", "Text-to-speech is not supported on this device.");
        return;
    }
    const text = (aiChatMessagesList[idx]?.bot || "").replace(/[*#_]/g, "");
    if (!text) return;

    if (window.speechSynthesis.speaking && activeSpeakingIdx === idx) {
        window.speechSynthesis.cancel();
        activeSpeakingIdx = null;
        document.querySelectorAll(".ai-listen-btn").forEach(b => b.classList.remove("speaking"));
        return;
    }

    window.speechSynthesis.cancel();
    document.querySelectorAll(".ai-listen-btn").forEach(b => b.classList.remove("speaking"));

    const utter = new SpeechSynthesisUtterance(text);
    utter.lang = /[\u0900-\u097F]/.test(text) ? "hi-IN" : "en-IN";
    utter.rate = 1.0;

    activeSpeakingIdx = idx;
    if (btnEl) btnEl.classList.add("speaking");

    utter.onend = () => {
        activeSpeakingIdx = null;
        if (btnEl) btnEl.classList.remove("speaking");
    };
    utter.onerror = () => {
        activeSpeakingIdx = null;
        if (btnEl) btnEl.classList.remove("speaking");
    };

    window.speechSynthesis.speak(utter);
}

function renderAiChatStream() {
    const chatMessages = document.getElementById("chatMessages");
    if (!chatMessages) return;

    const nowTime = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    let html = `
        <div class="msg-row-with-avatar">
            <img src="logo.png" class="ai-logo-avatar" onerror="this.src='default_avatar.png'" alt="Zoreno">
            <div class="clean-left-bubble">
                <div style="display:flex; justify-content:space-between; align-items:center; gap:14px; margin-bottom:2px;">
                    <strong>Zoreno AI</strong>
                    <span style="font-size:10px; color:#94a3b8; font-weight:500;">${nowTime}</span>
                </div>
                <p style="margin:0;">How can I help with your studies today?</p>
            </div>
        </div>
    `;

    aiChatMessagesList.forEach((pair, idx) => {
        const tLabel = escapeHtml(pair.timeLabel || nowTime);
        if (pair.user || (pair.images && pair.images.length)) {
            const imgsHtml = (pair.images || []).map(src =>
                `<img src="${src}" class="sent-small-thumb" onclick="event.stopPropagation(); openFullImageModal('${src}')" alt="Uploaded">`
            ).join("");
            html += `
                <div class="msg-row-with-avatar right-user">
                    <div class="clean-right-bubble" onclick="promptDeleteSingleAiMessage(${idx})" style="cursor:pointer;" title="Tap to delete for me">
                        ${imgsHtml ? `<div class="sent-media-grid">${imgsHtml}</div>` : ""}
                        ${pair.user ? `<div>${escapeHtml(pair.user)}</div>` : ""}
                        <div class="bubble-meta-time">
                            <span>${tLabel}</span>
                            <i class="fa-solid fa-check-double"></i>
                        </div>
                    </div>
                </div>
            `;
        }
        if (pair.bot) {
            html += `
                <div class="msg-row-with-avatar">
                    <img src="logo.png" class="ai-logo-avatar" onerror="this.src='default_avatar.png'" alt="Zoreno">
                    <div class="clean-left-bubble" onclick="promptDeleteSingleAiMessage(${idx})" style="cursor:pointer;" title="Tap to delete for me">
                        ${getHealthDisclaimerHTML(pair.user || "")}
                        <div class="ai-formatted-body">${formatMarkdown(pair.bot, idx * 3 + 1)}</div>
                        ${getSmartAffiliateCard(pair.user || "")}
                        <div class="ai-bubble-bottom-bar">
                            <span class="ai-time-txt">${tLabel}</span>
                            <div class="ai-action-btns-wrap" onclick="event.stopPropagation();">
                                <button type="button" class="ai-mini-circle-btn" onclick="copyAiResponseText(${idx}, this)" title="Copy">
                                    <i class="fa-regular fa-copy"></i>
                                </button>
                                <button type="button" class="ai-mini-circle-btn ai-listen-btn" onclick="speakAiResponseText(${idx}, this)" title="Listen">
                                    <i class="fa-solid fa-volume-high"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }
    });

    chatMessages.innerHTML = html;

    const lastPair = aiChatMessagesList[aiChatMessagesList.length - 1];
    const homePreview = document.getElementById("zorenoHomeLastPreview");
    if (homePreview && lastPair?.bot) {
        homePreview.textContent = lastPair.bot.replace(/[*#_]/g, "").slice(0, 48) + "...";
    }
    scrollToBottom();
}

function openZorenoAIChat() {
    hideAllScreens();
    const chatScreen = document.getElementById("chatScreen");
    const inputArea = document.getElementById("inputAreaContainer");
    const bottomNav = document.getElementById("bottomNav");

    if (bottomNav) bottomNav.style.setProperty("display", "none", "important");
    if (chatScreen) chatScreen.style.setProperty("display", "flex", "important");
    if (inputArea) inputArea.style.setProperty("display", "flex", "important");

    renderAiChatStream();
}

// Strict gemini-3.5-flash-lite caller with 3x auto-retry on High Demand spikes
async function callGeminiWithFallback(payloadBody, abortSignal) {
    let lastError = null;
    for (let attempt = 1; attempt <= 3; attempt++) {
        try {
            const response = await fetch(
                `https://generativelanguage.googleapis.com/v1beta/models/${ZORENO_AI_MODEL}:generateContent?key=${GEMINI_API_KEY}`,
                {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(payloadBody),
                    signal: abortSignal
                }
            );
            const data = await response.json();
            if (data.error) {
                const msg = data.error.message || "API Error";
                lastError = new Error(msg);
                if (/high demand|overloaded|unavailable|503|429/i.test(msg) && attempt < 3) {
                    await new Promise(r => setTimeout(r, 1400 * attempt));
                    continue;
                }
                throw lastError;
            }
            const parts = data?.candidates?.[0]?.content?.parts || [];
            const fullText = parts.map(p => p.text || "").join("").trim();
            if (fullText) return fullText;
        } catch (err) {
            if (err.name === "AbortError") throw err;
            lastError = err;
            if (attempt < 3) {
                await new Promise(r => setTimeout(r, 1200));
            }
        }
    }
    throw lastError || new Error("Please try again in a moment.");
}

let isAiGenerating = false;
let currentAiAbortController = null;

function setSendBtnStopMode(isGenerating) {
    const sendBtn = document.getElementById("sendBtn");
    if (!sendBtn) return;
    sendBtn.disabled = false;
    if (isGenerating) {
        sendBtn.innerHTML = '<i class="fa-solid fa-stop"></i>';
        sendBtn.style.background = "linear-gradient(135deg, #ef4444, #dc2626)";
        sendBtn.title = "Stop generating";
    } else {
        sendBtn.innerHTML = '<i class="fa-solid fa-paper-plane"></i>';
        sendBtn.style.background = "";
        sendBtn.title = "Send";
    }
}

async function sendMessage() {
    // Agar AI soch raha hai aur user button dabaye -> Turant jawab rok do!
    if (isAiGenerating && currentAiAbortController) {
        currentAiAbortController.abort();
        return;
    }

    const input = document.getElementById("userInput");
    const chatMessages = document.getElementById("chatMessages");
    if (!input || !chatMessages) return;

    if (pendingAiAttachments.some(a => a.loading)) {
        showCustomAlert("Please Wait", "Photo is still loading, please wait a second...");
        return;
    }

    let text = input.value.trim();
    const attachedImages = pendingAiAttachments.map(a => a.dataUrl).filter(Boolean).slice(0, 2);
    if (!text && attachedImages.length === 0) return;

    const usedToday = getLocalDailyAiCount();
    const todayLimit = userTier === 2 ? 90 : userTier === 1 ? 50 : getLocalDailyAiLimit();

    if (usedToday >= todayLimit) {
        if (userTier === 0) {
            openRewardedAdModal();
        } else {
            showCustomAlert("Daily Fair-Use Limit Reached", `You have used your ${todayLimit} messages for today.`);
        }
        return;
    }

    if (userTier === 0 && text.length > 600) text = text.slice(0, 600);

    const nowTime = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    const msgIdx = aiChatMessagesList.length;
    input.value = "";
    pendingAiAttachments = [];
    renderAiAttachmentPreviewStrip();

    const imgsPreviewHtml = attachedImages.map(src =>
        `<img src="${src}" class="sent-small-thumb" onclick="event.stopPropagation(); openFullImageModal('${src}')" alt="Uploaded">`
    ).join("");

    chatMessages.insertAdjacentHTML("beforeend", `
        <div class="msg-row-with-avatar right-user">
            <div class="clean-right-bubble" onclick="promptDeleteSingleAiMessage(${msgIdx})" style="cursor:pointer;">
                ${imgsPreviewHtml ? `<div class="sent-media-grid">${imgsPreviewHtml}</div>` : ""}
                ${text ? `<div>${escapeHtml(text)}</div>` : ""}
                <div class="bubble-meta-time">
                    <span>${nowTime}</span>
                    <i class="fa-solid fa-check-double"></i>
                </div>
            </div>
        </div>
    `);

    const guardrailCheck = checkQueryGuardrails(text);
    if (guardrailCheck.blocked) {
        await saveChatToFirebase(text, guardrailCheck.reply, nowTime, attachedImages);
        renderAiChatStream();
        scrollToBottom();
        return;
    }

    const thinkingId = "zorenoThinking_" + Date.now();
    chatMessages.insertAdjacentHTML("beforeend", `
        <div class="msg-row-with-avatar" id="${thinkingId}">
            <img src="logo.png" class="ai-logo-avatar" onerror="this.src='default_avatar.png'" alt="Zoreno">
            <div class="clean-left-bubble" style="padding:10px 16px!important; border-radius:22px!important;">
                <div style="display:flex; align-items:center; gap:10px; color:#7c3aed; font-weight:600; font-size:13.5px;">
                    <span>Zoreno is thinking</span>
                    <div class="thinking-dots"><span></span><span></span><span></span></div>
                </div>
            </div>
        </div>
    `);
    scrollToBottom();

    isAiGenerating = true;
    currentAiAbortController = new AbortController();
    setSendBtnStopMode(true);

    try {
        // High token limit so student answers NEVER cut off mid-sentence
        const maxTokens = userTier === 0 ? 1800 : 3000;

        // 20-message deep context memory for continuous study sessions
        const recentHistory = [];
        aiChatMessagesList.slice(-20).forEach(pair => {
            if (pair.user) recentHistory.push({ role: "user", parts: [{ text: pair.user }] });
            if (pair.bot) recentHistory.push({ role: "model", parts: [{ text: pair.bot }] });
        });

        const currentParts = [];
        attachedImages.forEach(dataUrl => {
            const base64Data = dataUrl.split(",")[1];
            if (base64Data) {
                currentParts.push({
                    inlineData: { mimeType: "image/jpeg", data: base64Data }
                });
            }
        });
        currentParts.push({ text: text || "Please explain this image clearly step-by-step." });

        const payloadBody = {
            systemInstruction: {
                parts: [{ text: SYSTEM_INSTRUCTION }]
            },
            contents: [
                ...recentHistory,
                { role: "user", parts: currentParts }
            ],
            generationConfig: {
                maxOutputTokens: maxTokens,
                temperature: 0.6
            },
            safetySettings: [
                { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_ONLY_HIGH" },
                { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_ONLY_HIGH" },
                { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_ONLY_HIGH" },
                { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_ONLY_HIGH" }
            ]
        };

        const replyText = await callGeminiWithFallback(payloadBody, currentAiAbortController.signal);
        incrementLocalDailyAiCount();

        await saveChatToFirebase(text, replyText, nowTime, attachedImages);
        renderAiChatStream();
    } catch (err) {
        const thinkingRow = document.getElementById(thinkingId);
        if (err.name === "AbortError") {
            await saveChatToFirebase(text, "⏹️ Response stopped by user.", nowTime, attachedImages);
            renderAiChatStream();
        } else if (thinkingRow) {
            thinkingRow.innerHTML = `
                <img src="logo.png" class="ai-logo-avatar" onerror="this.src='default_avatar.png'" alt="Zoreno">
                <div class="clean-left-bubble">
                    <span style="color:#ef4444; font-weight:600;">⚠️ ${escapeHtml(err.message)}</span>
                </div>
            `;
        }
    } finally {
        isAiGenerating = false;
        currentAiAbortController = null;
        setSendBtnStopMode(false);
        scrollToBottom();
    }
}




async function saveChatToFirebase(userText, botText, timeLabel, imagesList = []) {
    const tLabel = timeLabel || new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    const item = {
        user: userText || "",
        bot: botText || "",
        images: (imagesList || []).slice(0, 2),
        timeLabel: tLabel,
        timestampMs: Date.now()
    };

    aiChatMessagesList.push(item);
    if (aiChatMessagesList.length > 40) aiChatMessagesList = aiChatMessagesList.slice(-40);
    try { localStorage.setItem("zorenoAiChatStream", JSON.stringify(aiChatMessagesList)); } catch (e) {}

    const homePreview = document.getElementById("zorenoHomeLastPreview");
    if (homePreview && botText) {
        homePreview.textContent = botText.replace(/[*#_]/g, "").slice(0, 48) + "...";
    }

    if (!db || !auth?.currentUser) return;
    try {
        await db.collection("users").doc(auth.currentUser.uid).collection("chats").add({
            user: userText || "",
            bot: botText || "",
            timeLabel: tLabel,
            timestampMs: item.timestampMs,
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    } catch (e) {}
}

async function loadUserChatsFromFirebase() {
    if (!db || !auth?.currentUser) return;
    try {
        const snap = await db.collection("users").doc(auth.currentUser.uid)
            .collection("chats").orderBy("timestampMs", "asc").limitToLast(40).get();
        if (!snap.empty) {
            aiChatMessagesList = [];
            snap.forEach(doc => {
                const d = doc.data();
                aiChatMessagesList.push({
                    user: d.user || "",
                    bot: d.bot || "",
                    timeLabel: d.timeLabel || "",
                    timestampMs: d.timestampMs || 0
                });
            });
            try { localStorage.setItem("zorenoAiChatStream", JSON.stringify(aiChatMessagesList)); } catch (e) {}
            const lastPair = aiChatMessagesList[aiChatMessagesList.length - 1];
            const homePreview = document.getElementById("zorenoHomeLastPreview");
            if (homePreview && lastPair?.bot) {
                homePreview.textContent = lastPair.bot.replace(/[*#_]/g, "").slice(0, 48) + "...";
            }
        }
    } catch (e) {}
}

async function clearAllChatHistory() {
    closeAllDropdownMenus();
    aiChatMessagesList = [];
    localStorage.removeItem("zorenoAiChatStream");
    renderAiChatStream();

    const homePreview = document.getElementById("zorenoHomeLastPreview");
    if (homePreview) homePreview.textContent = "Tap to start chatting with your AI partner";

    if (db && auth?.currentUser) {
        try {
            const snap = await db.collection("users").doc(auth.currentUser.uid).collection("chats").get();
            const batch = db.batch();
            snap.forEach(d => batch.delete(d.ref));
            await batch.commit();
        } catch (e) {}
    }
    showCustomAlert("Chat Cleared 🗑️", "Your AI conversation has been cleared.", true);
}

function clearCurrentAiChat() {
    clearAllChatHistory();
}

function toggleAiHeaderMenu(forceState) {
    const menu = document.getElementById("aiHeaderDropdownMenu");
    if (!menu) return;
    const nextState = typeof forceState === "boolean" ? forceState : menu.style.display !== "block";
    closeAllDropdownMenus();
    menu.style.display = nextState ? "block" : "none";
}

function openAiFeedbackModal() {
    closeAllDropdownMenus();
    document.getElementById("aiFeedbackModal").style.display = "flex";
}

async function submitAiFeedback() {
    const text = document.getElementById("aiFeedbackText").value.trim();
    if (!text) return;
    try {
        if (db && auth?.currentUser) {
            await db.collection("feedbacks").add({
                uid: auth.currentUser.uid,
                email: auth.currentUser.email || "Anonymous",
                feedback: text,
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            });
        }
        document.getElementById("aiFeedbackText").value = "";
        document.getElementById("aiFeedbackModal").style.display = "none";
        showCustomAlert("Thank You! 🎉", "Your feedback has been sent successfully.", true);
    } catch (e) {
        showCustomAlert("Error", e.message);
    }
}

function scrollToBottom() {
    const container = document.getElementById("chatMessages");
    if (container) container.scrollTo({ top: container.scrollHeight, behavior: "smooth" });
}

// ================= ADMOB (APP) & ADSENSE (WEB) REWARDED AD (+3 CHATS) =================
function openRewardedAdModal() {
    const modal = document.getElementById("rewardedAdModal");
    if (modal) modal.style.display = "flex";
}

function closeRewardedAdModal() {
    const modal = document.getElementById("rewardedAdModal");
    if (modal) modal.style.display = "none";
}

function triggerRewardedAdForChats() {
    const btn = document.getElementById("watchRewardedAdBtn");
    const btnText = document.getElementById("watchAdBtnText");

    if (window.AndroidAdMob && typeof window.AndroidAdMob.showRewardedAd === "function") {
        if (btn) btn.disabled = true;
        if (btnText) btnText.innerText = "Loading Ad...";

        window.AndroidAdMob.showRewardedAd(ADS_CONFIG.admobRewardedUnitId);

        setTimeout(() => {
            if (btn) btn.disabled = false;
            if (btnText) btnText.innerText = "Watch Ad";
        }, 8000);
        return;
    }

    if (btn) btn.disabled = true;
    let sec = 5;
    if (btnText) btnText.innerText = `Loading Ad (${sec}s)...`;

    try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch (e) {}

    const adTimer = setInterval(() => {
        sec--;
        if (sec > 0) {
            if (btnText) btnText.innerText = `Watching Ad (${sec}s)...`;
        } else {
            clearInterval(adTimer);
            if (btn) btn.disabled = false;
            if (btnText) btnText.innerText = "Watch Ad";
            onAdMobRewardGranted();
        }
    }, 1000);
}

window.onAdMobRewardGranted = function () {
    const btn = document.getElementById("watchRewardedAdBtn");
    const btnText = document.getElementById("watchAdBtnText");
    if (btn) btn.disabled = false;
    if (btnText) btnText.innerText = "Watch Ad";

    const newLimit = addBonusAiChats(3);
    const used = getLocalDailyAiCount();
    const left = Math.max(0, newLimit - used);

    closeRewardedAdModal();
    showCustomAlert("3 Chats Unlocked! 🎉", `You now have ${left} free chats available to continue learning.`, true);
};

// ================= LIVE WEB SEARCH, FOCUS SPRINT & FOCUS MUSIC =================
function openLiveGoogleSearch(initialQuery = "") {
    hideAllScreens();
    const searchScreen = document.getElementById("webSearchScreen");
    if (searchScreen) searchScreen.style.setProperty("display", "flex", "important");
    const inp = document.getElementById("liveGoogleInput");
    if (inp) {
        inp.value = initialQuery || "";
        if (initialQuery) runLiveGoogleSearch();
        else inp.focus();
    }
}

function closeLiveGoogleSearch() { goHome(); }
function clearLiveSearch() {
    const inp = document.getElementById("liveGoogleInput");
    if (inp) { inp.value = ""; inp.focus(); }
}
function handleLiveGoogleEnter(e) {
    if (e.key === "Enter") { e.preventDefault(); runLiveGoogleSearch(); }
}

async function runLiveGoogleSearch() {
    let query = document.getElementById("liveGoogleInput")?.value.trim();
    const resultsArea = document.getElementById("liveSearchResultsArea");
    if (!query || !resultsArea) return;

    currentSearchQuery = query;
    currentSearchOffset = 0;
    hasMoreSearchResults = true;
    resultsArea.innerHTML = `<div style="text-align:center;padding:30px;color:#7c3aed;"><i class="fa-solid fa-spinner fa-spin" style="font-size:24px;"></i><p style="margin-top:10px;font-weight:700;font-size:13px;">Searching live web for "${escapeHtml(query)}"...</p></div>`;
    resultsArea.innerHTML = "";
    await fetchMoreSearchResults();
}

async function fetchMoreSearchResults() {
    if (isSearchLoading || !hasMoreSearchResults) return;
    isSearchLoading = true;
    const resultsArea = document.getElementById("liveSearchResultsArea");

    try {
        const apiUrl = `https://en.wikipedia.org/w/api.php?action=query&format=json&origin=*&generator=search&gsrsearch=${encodeURIComponent(currentSearchQuery)}&gsrlimit=8&gsroffset=${currentSearchOffset}&prop=extracts|pageimages&exintro=1&explaintext=1&exsentences=2&piprop=thumbnail&pithumbsize=300`;
        const res = await fetch(apiUrl);
        const data = await res.json();
        const pages = data?.query?.pages ? Object.values(data.query.pages) : [];

        if (pages.length === 0) {
            hasMoreSearchResults = false;
            isSearchLoading = false;
            return;
        }
        currentSearchOffset += 8;

        pages.forEach(p => {
            const card = document.createElement("div");
            card.className = "web-result-item";
            const itemImg = p.thumbnail ? p.thumbnail.source : null;
            const wikiLink = "https://en.wikipedia.org/wiki/" + encodeURIComponent(p.title);
            card.innerHTML = `
                <div class="res-source-row">
                    <img src="https://www.google.com/s2/favicons?domain=wikipedia.org" class="res-favicon" alt="icon">
                    <span>Wikipedia • en.wikipedia.org</span>
                </div>
                <div style="display:flex;justify-content:space-between;gap:10px;">
                    <div style="flex:1;">
                        <a href="${wikiLink}" target="_blank" class="res-title">${escapeHtml(p.title)}</a>
                        <p class="res-snippet">${escapeHtml(p.extract || "Verified details and facts.")}</p>
                    </div>
                    ${itemImg ? `<img src="${itemImg}" style="width:70px;height:50px;border-radius:10px;object-fit:cover;margin-top:2px;">` : ""}
                </div>
            `;
            resultsArea.appendChild(card);
        });
    } catch (e) {} finally {
        isSearchLoading = false;
    }
}

let sprintDurationMinutes = parseInt(localStorage.getItem("sprintSelectedDuration") || "20");
let sprintInterval = null;
let memSprintTargetMs = 0;
let memSprintTotalMs = 0;

function selectSprintPreset(mins, btnEl) {
    sprintDurationMinutes = mins;
    localStorage.setItem("sprintSelectedDuration", String(mins));
    document.querySelectorAll(".preset-pill-btn").forEach(b => b.classList.remove("active"));
    if (btnEl) btnEl.classList.add("active");
    resetSprintState();
}

function toggleSprintTimer() {
    if (localStorage.getItem("sprintIsActive") === "true") pauseSprintState();
    else startSprintState();
}

function startSprintState() {
    const now = Date.now();
    let remainingMs = parseInt(localStorage.getItem("sprintRemainingMs") || "0");
    if (!remainingMs || remainingMs <= 0) {
        remainingMs = sprintDurationMinutes * 60 * 1000;
        localStorage.setItem("sprintTotalDurationMs", String(remainingMs));
    }
    memSprintTotalMs = parseInt(localStorage.getItem("sprintTotalDurationMs") || String(remainingMs));
    memSprintTargetMs = now + remainingMs;

    localStorage.setItem("sprintTargetTimestamp", String(memSprintTargetMs));
    localStorage.setItem("sprintIsActive", "true");
    localStorage.removeItem("sprintRemainingMs");

    setSprintUIRunning(true);
    if (sprintInterval) clearInterval(sprintInterval);
    sprintInterval = setInterval(tickSprint, 1000);
}

function pauseSprintState() {
    localStorage.setItem("sprintRemainingMs", String(Math.max(0, memSprintTargetMs - Date.now())));
    localStorage.setItem("sprintIsActive", "false");
    localStorage.removeItem("sprintTargetTimestamp");
    clearInterval(sprintInterval);
    sprintInterval = null;
    setSprintUIRunning(false);
}

function resetSprintState() {
    if (sprintInterval) clearInterval(sprintInterval);
    sprintInterval = null;
    memSprintTargetMs = 0;
    memSprintTotalMs = 0;
    localStorage.removeItem("sprintTargetTimestamp");
    localStorage.removeItem("sprintRemainingMs");
    localStorage.removeItem("sprintTotalDurationMs");
    localStorage.setItem("sprintIsActive", "false");
    setSprintUIRunning(false);

    const timerText = document.getElementById("sprintTimerText");
    if (timerText) timerText.innerText = `${String(sprintDurationMinutes).padStart(2, "0")}:00`;
    const progressFill = document.getElementById("sprintProgressFill");
    const rabbit = document.getElementById("sprintRabbit");
    if (progressFill) progressFill.style.width = "0%";
    if (rabbit) { rabbit.style.left = "0%"; rabbit.classList.remove("hopping"); }
}

function tickSprint() {
    const remainingMs = memSprintTargetMs - Date.now();

    if (remainingMs <= 0) {
        resetSprintState();
        showCustomAlert("Sprint Completed! 🏆", "Great job staying focused!", true);
        return;
    }

    const remainingSecs = Math.ceil(remainingMs / 1000);
    const timerText = document.getElementById("sprintTimerText");
    if (timerText) timerText.innerText = `${String(Math.floor(remainingSecs / 60)).padStart(2, "0")}:${String(remainingSecs % 60).padStart(2, "0")}`;

    const totalMs = memSprintTotalMs || (sprintDurationMinutes * 60 * 1000);
    const progressPercent = Math.min(100, Math.max(0, ((totalMs - remainingMs) / totalMs) * 100));
    const progressFill = document.getElementById("sprintProgressFill");
    const rabbit = document.getElementById("sprintRabbit");
    if (progressFill) progressFill.style.width = `${progressPercent}%`;
    if (rabbit) rabbit.style.left = `${Math.min(94, progressPercent)}%`;
}

function setSprintUIRunning(isRunning) {
    const pill = document.getElementById("sprintControlPill");
    const btnLabel = document.getElementById("sprintBtnLabel");
    const btnIcon = document.getElementById("sprintPlayIcon");
    const rabbit = document.getElementById("sprintRabbit");

    if (isRunning) {
        pill?.classList.add("running");
        if (btnLabel) btnLabel.innerText = "Pause";
        if (btnIcon) btnIcon.className = "fa-solid fa-pause";
        rabbit?.classList.add("hopping");
    } else {
        pill?.classList.remove("running");
        if (btnLabel) btnLabel.innerText = "Go";
        if (btnIcon) btnIcon.className = "fa-solid fa-play";
        rabbit?.classList.remove("hopping");
    }
}

const FOCUS_TRACKS = [
    { title: "Rain Storm", icon: "fa-cloud-showers-heavy", file: "sounds/rain.mp3", cover: "https://images.unsplash.com/photo-1519692933481-e162a57d6721?w=300" },
    { title: "Deep Lo-Fi", icon: "fa-music", file: "sounds/lofi.mp3", cover: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=300" },
    { title: "Forest Birds", icon: "fa-dove", file: "sounds/birds.mp3", cover: "https://images.unsplash.com/photo-1448375240586-882707db888b?w=300" },
    { title: "Ocean Waves", icon: "fa-water", file: "sounds/ocean.mp3", cover: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=300" },
    { title: "Cafe Ambient", icon: "fa-mug-saucer", file: "sounds/cafe.mp3", cover: "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=300" },
    { title: "Night Campfire", icon: "fa-fire", file: "sounds/campfire.mp3", cover: "https://images.unsplash.com/photo-1510312305653-8ed496efae75?w=300" },
    { title: "White Noise", icon: "fa-wind", file: "sounds/whitenoise.mp3", cover: "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=300" },
    { title: "Clock Ticking", icon: "fa-clock", file: "sounds/clock.mp3", cover: "https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=300" },
    { title: "Nature Forest", icon: "fa-leaf", file: "sounds/forest.mp3", cover: "https://images.unsplash.com/photo-1473448912268-2022ce9509d8?w=300" },
    { title: "Binaural Beats", icon: "fa-tower-broadcast", file: "sounds/binaural.mp3", cover: "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=300" }
];

let currentTrackIndex = 0;
let focusAudio = new Audio();
focusAudio.loop = true;
let isMusicPlaying = false;

function selectMusicTrack(index) {
    currentTrackIndex = index;
    const track = FOCUS_TRACKS[index];
    const titleEl = document.getElementById("currentTrackTitle");
    const coverEl = document.getElementById("currentTrackCover");
    if (titleEl) titleEl.innerText = track.title;
    if (coverEl) coverEl.src = track.cover;

    document.querySelectorAll(".sound-card-pill").forEach((pill, i) => {
        const actionBox = pill.querySelector(".sound-card-action-box");
        if (i === index) {
            pill.classList.add("active");
            if (actionBox) actionBox.innerHTML = `<div class="mini-playing-waves"><span></span><span></span><span></span></div>`;
        } else {
            pill.classList.remove("active");
            if (actionBox) actionBox.innerHTML = `<i class="fa-solid fa-play"></i>`;
        }
    });

    focusAudio.src = track.file;
    focusAudio.currentTime = 0;
    playFocusMusic();
}

function playFocusMusic() {
    focusAudio.play().then(() => { isMusicPlaying = true; updatePlayerUIState(true); })
              .catch(() => { isMusicPlaying = true; updatePlayerUIState(true); });
}

function pauseFocusMusic() {
    focusAudio.pause();
    isMusicPlaying = false;
    updatePlayerUIState(false);
}

function toggleFocusMusicPlay() {
    if (isMusicPlaying) pauseFocusMusic();
    else {
        if (!focusAudio.src) selectMusicTrack(currentTrackIndex);
        else playFocusMusic();
    }
}

function playNextTrack() {
    currentTrackIndex = (currentTrackIndex + 1) % FOCUS_TRACKS.length;
    selectMusicTrack(currentTrackIndex);
}

function playPreviousTrack() {
    currentTrackIndex = (currentTrackIndex - 1 + FOCUS_TRACKS.length) % FOCUS_TRACKS.length;
    selectMusicTrack(currentTrackIndex);
}

function updatePlayerUIState(playing) {
    const playIcon = document.getElementById("musicPlayIcon");
    const visualizer = document.getElementById("musicWaveVisualizer");
    if (playing) {
        if (playIcon) playIcon.className = "fa-solid fa-pause";
        visualizer?.classList.add("playing");
    } else {
        if (playIcon) playIcon.className = "fa-solid fa-play";
        visualizer?.classList.remove("playing");
    }
}

focusAudio.ontimeupdate = () => {
    const current = focusAudio.currentTime || 0;
    const duration = focusAudio.duration || 30;
    const elapsedEl = document.getElementById("musicTimeElapsed");
    const durEl = document.getElementById("musicTimeDuration");
    if (elapsedEl) elapsedEl.innerText = `${String(Math.floor(current / 60)).padStart(2, "0")}:${String(Math.floor(current % 60)).padStart(2, "0")}`;
    if (durEl) durEl.innerText = `${String(Math.floor(duration / 60)).padStart(2, "0")}:${String(Math.floor(duration % 60)).padStart(2, "0")}`;

    const percent = (current / duration) * 100;
    const fill = document.getElementById("musicProgressFill");
    const knob = document.getElementById("musicProgressKnob");
    if (fill) fill.style.width = `${percent}%`;
    if (knob) knob.style.left = `${percent}%`;
};

function handleMusicSeek(e) {
    const rail = document.querySelector(".music-progress-rail");
    if (!rail) return;
    const rect = rail.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const offsetX = Math.max(0, Math.min(rect.width, clientX - rect.left));
    focusAudio.currentTime = (offsetX / rect.width) * (focusAudio.duration || 30);
}

function seekMusicByClick(e) { handleMusicSeek(e); }

function toggleMusicLike(btn) {
    btn.classList.toggle("liked");
    const icon = btn.querySelector("i");
    if (icon) icon.className = btn.classList.contains("liked") ? "fa-solid fa-heart" : "fa-regular fa-heart";
}

function updateOnlineStatus() {
    const banner = document.getElementById("offlineBanner");
    if (!banner) return;
    if (!navigator.onLine) banner.classList.add("show");
    else banner.classList.remove("show");
}

window.addEventListener("online", updateOnlineStatus);
window.addEventListener("offline", updateOnlineStatus);

document.addEventListener("click", e => {
    const isMenuClick = e.target.closest(".custom-dropdown-menu");
    const isTriggerClick = e.target.closest('[onclick*="toggleAiHeaderMenu"], [onclick*="toggleDmHeaderMenu"], [onclick*="toggleFpHeaderMenu"]');
    if (!isMenuClick && !isTriggerClick) {
        closeAllDropdownMenus();
    }
});

window.addEventListener("popstate", () => {
    closeAllDropdownMenus();
    const fullImgModal = document.getElementById("fullImagePreviewModal");
    if (fullImgModal && fullImgModal.style.display === "flex") { fullImgModal.style.display = "none"; return; }
    const fpScreen = document.getElementById("friendProfileScreen");
    if (fpScreen && fpScreen.style.display === "block") { closeFriendProfileScreen(); return; }
    const policyModal = document.getElementById("policyModal");
    const alertModal = document.getElementById("alertModal");
    if (policyModal && policyModal.style.display === "flex") { closePolicyModal(); return; }
    if (alertModal && alertModal.style.display === "flex") { closeCustomAlert(); return; }

    const chatList = document.getElementById("chatListScreen");
    if (chatList && chatList.style.display === "none") {
        closeActiveDmChat();
        goHome();
    }
});

window.addEventListener("keydown", e => {
    if (e.key === "Enter" && !e.shiftKey && e.target?.id === "userInput") {
        e.preventDefault();
        sendMessage();
    }
});

window.addEventListener("DOMContentLoaded", () => {
    const isDark = localStorage.getItem("darkMode") === "true";
    if (isDark) document.body.classList.add("dark-mode");
    syncDarkModeUI(isDark);

    detectAndSetCountry();
    setupHomeSearchAndTabs();
    syncEditProfileInputs();

    const dmInput = document.getElementById("activeChatInput");
    if (dmInput) {
        dmInput.addEventListener("keydown", e => {
            if (e.key === "Enter") {
                e.preventDefault();
                sendRealtimeMessage();
            }
        });
    }

    const rail = document.querySelector(".music-progress-rail");
    if (rail) {
        rail.addEventListener("click", handleMusicSeek);
        rail.addEventListener("touchstart", handleMusicSeek, { passive: true });
        rail.addEventListener("touchmove", handleMusicSeek, { passive: true });
    }

    const splashScreen = document.getElementById("splashScreen");
    const authScreen = document.getElementById("authScreen");
    const alreadyLoggedIn = localStorage.getItem("isLoggedIn") === "true";

    if (alreadyLoggedIn) {
        if (authScreen) authScreen.style.setProperty("display", "none", "important");
        if (splashScreen) {
            splashScreen.classList.add("hide");
            setTimeout(() => { splashScreen.style.display = "none"; }, 350);
        }
        showChatsHome();
    } else {
        setTimeout(() => {
            if (splashScreen && splashScreen.style.display !== "none") {
                splashScreen.style.display = "none";
                if (authScreen) authScreen.style.display = "flex";
            }
        }, 1800);
    }

    initFirebase();
});

      function toggleEyeProtectionMode() {
    document.body.classList.toggle("eye-care-mode");
    const enabled = document.body.classList.contains("eye-care-mode");
    localStorage.setItem("eyeCareMode", enabled ? "true" : "false");
    const toggle = document.getElementById("eyeCareToggle");
    if (toggle) toggle.classList.toggle("off", !enabled);
}

window.addEventListener("DOMContentLoaded", () => {
    if (localStorage.getItem("eyeCareMode") === "true") {
        document.body.classList.add("eye-care-mode");
        document.getElementById("eyeCareToggle")?.classList.remove("off");
    }
});
