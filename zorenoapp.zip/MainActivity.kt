package com.zoreno.app

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.lifecycle.lifecycleScope
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.UpdateAvailability
import com.zoreno.app.billing.BillingManager

class MainActivity : ComponentActivity() {

    private lateinit var billingManager: BillingManager

    override fun onCreate(savedInstanceState: Bundle?) {
        // Edge-to-Edge: content behind status bar, handled by safeDrawingPadding
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        billingManager = BillingManager(this, lifecycleScope)
        checkForAppUpdates()

        setContent {
            var isSecureMode by remember { mutableStateOf(false) }

            // Dynamic FLAG_SECURE: blocked on friend chats and profiles
            LaunchedEffect(isSecureMode) {
                if (isSecureMode) {
                    window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }
            }

            MainScreen(
                billingManager = billingManager,
                onSecureChange = { secure -> isSecureMode = secure }
            )
        }
    }

    override fun onResume() {
        super.onResume()
        billingManager.queryActivePurchases()
    }

    private fun checkForAppUpdates() {
        val appUpdateManager = AppUpdateManagerFactory.create(this)
        appUpdateManager.appUpdateInfo.addOnSuccessListener { info ->
            if (info.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE) {
                if (info.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)) {
                    appUpdateManager.startUpdateFlowForResult(info, AppUpdateType.IMMEDIATE, this, 1001)
                } else if (info.isUpdateTypeAllowed(AppUpdateType.FLEXIBLE)) {
                    appUpdateManager.startUpdateFlowForResult(info, AppUpdateType.FLEXIBLE, this, 1001)
                }
            }
        }
    }
}
