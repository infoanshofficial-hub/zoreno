package com.zoreno.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import com.android.billingclient.api.AcknowledgePurchaseParams
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.QueryProductDetailsParams
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.play.core.appupdate.AppUpdateManager
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.UpdateAvailability
import com.google.gson.JsonObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class MainActivity : AppCompatActivity(), PurchasesUpdatedListener {

    private lateinit var webView: WebView
    private lateinit var rootFrame: FrameLayout
    private var bannerAdView: AdView? = null

    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private lateinit var fileChooserLauncher: ActivityResultLauncher<Intent>
    private lateinit var googleSignInLauncher: ActivityResultLauncher<Intent>
    private lateinit var speechLauncher: ActivityResultLauncher<Intent>
    private var activeSpeechInputId: String = "userInput"

    private var zorenoTts: TextToSpeech? = null
    private var zorenoTtsReady: Boolean = false
    private var zorenoMediaPlayer: MediaPlayer? = null

    private var zorenoRewardedAd: RewardedAd? = null
    private var zorenoInterstitialAd: InterstitialAd? = null
    private var billingClient: BillingClient? = null
    private var pendingBillingTier: Int = 1
    private var appUpdateManager: AppUpdateManager? = null

    companion object {
        private const val GOOGLE_WEB_CLIENT_ID = "205788450312-ljp89u7m3q7ptpsad8r2vaga3t3bidj6.apps.googleusercontent.com"
        private const val ADMOB_BANNER_UNIT_ID = "ca-app-pub-5825754850490611/8668190362"
        private const val ADMOB_REWARDED_UNIT_ID = "ca-app-pub-5825754850490611/4904670790"
        private const val ADMOB_INTERSTITIAL_UNIT_ID = "ca-app-pub-5825754850490611/8668190362"
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        volumeControlStream = AudioManager.STREAM_MUSIC
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.decorView.setBackgroundColor(Color.parseColor("#F5F0FF"))
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.RECORD_AUDIO), 101)
        } else {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 102)
        }

        // Clean up temporary shared files on launch
        try {
            cacheDir.listFiles()?.forEach { f ->
                if (f.isFile && (f.name.endsWith(".pdf") || f.name.endsWith(".zip") || f.name.endsWith(".png") || f.name.endsWith(".jpg"))) {
                    f.delete()
                }
            }
        } catch (_: Exception) {}

        rootFrame = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setBackgroundColor(Color.parseColor("#F5F0FF"))
        }

        webView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setBackgroundColor(Color.parseColor("#F5F0FF"))
        }
        rootFrame.addView(webView)
        setContentView(rootFrame)

        setupActivityResultLaunchers()
        setupWebView()
        setupTextToSpeech()
        setupAdMobAndBanner()
        setupPlayBilling()
        checkAndStartPlayImmediateUpdate()

        try {
            startService(Intent(this, ZorenoBgNotifService::class.java))
        } catch (_: Exception) {}

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                webView.evaluateJavascript("(window.handleZorenoHardwareBack && window.handleZorenoHardwareBack()) ? 'HANDLED' : 'EXIT'") { res ->
                    if (res == null || !res.contains("HANDLED")) {
                        if (webView.canGoBack()) webView.goBack() else moveTaskToBack(true)
                    }
                }
            }
        })

        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun setupActivityResultLaunchers() {
        fileChooserLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val callback = filePathCallback ?: return@registerForActivityResult
            var results: Array<Uri>? = null
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val data = result.data!!
                val clipData = data.clipData
                if (clipData != null && clipData.itemCount > 0) {
                    results = Array(clipData.itemCount) { i -> clipData.getItemAt(i).uri }
                } else if (data.data != null) {
                    results = arrayOf(data.data!!)
                }
            }
            callback.onReceiveValue(results)
            filePathCallback = null
        }

        googleSignInLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            var email: String? = null
            var name: String? = null
            var idToken: String? = null
            val data = result.data
            if (data != null) {
                try {
                    val task = GoogleSignIn.getSignedInAccountFromIntent(data)
                    val account = task.result
                    if (account != null) {
                        email = account.email
                        name = account.displayName
                        idToken = account.idToken
                    }
                } catch (_: Exception) {}
            }
            if (!email.isNullOrEmpty()) {
                val safeName = if (name.isNullOrEmpty()) email.substringBefore("@") else name
                val sE = email.replace("'", "\\'")
                val sN = safeName.replace("'", "\\'")
                val sT = (idToken ?: "").replace("'", "\\'")
                runOnUiThread {
                    webView.evaluateJavascript("if(window.onZorenoNativeGoogleLogin){window.onZorenoNativeGoogleLogin('$sE','$sN','$sT');}", null)
                }
            }
        }

        speechLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                val spoken = matches?.firstOrNull() ?: ""
                if (spoken.isNotEmpty()) {
                    val safeText = spoken.replace("'", "\\'").replace("\n", " ")
                    val safeId = activeSpeechInputId.replace("'", "")
                    runOnUiThread {
                        webView.evaluateJavascript("if(window.onNativeSpeechResult){window.onNativeSpeechResult('$safeId','$safeText');}", null)
                    }
                }
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
            setSupportZoom(false)
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    if (url.contains("play.google.com") || url.contains("whatsapp.com") || url.contains("mailto:")) {
                        try {
                            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                            return true
                        } catch (_: Exception) {}
                    }
                }
                return false
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback
                return try {
                    val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                        val acceptTypes = fileChooserParams?.acceptTypes
                        if (acceptTypes != null && acceptTypes.isNotEmpty() && acceptTypes[0].isNotBlank()) {
                            type = acceptTypes[0]
                        }
                    }
                    fileChooserLauncher.launch(Intent.createChooser(intent, "Select File"))
                    true
                } catch (_: Exception) {
                    this@MainActivity.filePathCallback = null
                    false
                }
            }
        }

        // Attach All Native Kotlin -> JavaScript Bridges
        webView.addJavascriptInterface(AndroidSecurityBridge(), "AndroidSecurity")
        webView.addJavascriptInterface(GoogleAuthBridge(), "ZorenoGoogleAuth")
        webView.addJavascriptInterface(AdMobBridge(), "AndroidAdMob")
        webView.addJavascriptInterface(TtsBridge(), "AndroidTTS")
        webView.addJavascriptInterface(PrefsBridge(), "AndroidPrefs")
        webView.addJavascriptInterface(ShareBridge(), "AndroidShare")
        webView.addJavascriptInterface(DownloaderBridge(), "AndroidDownloader")
        webView.addJavascriptInterface(NotifBridge(), "AndroidNotif")
        webView.addJavascriptInterface(SpeechBridge(), "AndroidSpeech")
        webView.addJavascriptInterface(BillingBridge(), "AndroidBilling")
        webView.addJavascriptInterface(AppUpdateBridge(), "AndroidAppUpdate")
    }

    private fun setupTextToSpeech() {
        zorenoTts = TextToSpeech(applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                zorenoTtsReady = true
                selectBestNaturalVoice(Locale("en", "IN"))
            }
        }
    }

    private fun selectBestNaturalVoice(loc: Locale) {
        val tts = zorenoTts ?: return
        try {
            if (Build.VERSION.SDK_INT >= 21) {
                tts.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
            }
            tts.language = loc
            tts.setSpeechRate(1.0f)
            tts.setPitch(1.0f)
        } catch (_: Exception) {}
    }

    private fun setupAdMobAndBanner() {
        try {
            MobileAds.initialize(this) {
                loadZorenoRewardedAd(ADMOB_REWARDED_UNIT_ID)
                loadZorenoInterstitialAd()
                runOnUiThread {
                    try {
                        val adView = AdView(this@MainActivity)
                        adView.adUnitId = ADMOB_BANNER_UNIT_ID
                        adView.setAdSize(AdSize.BANNER)
                        adView.visibility = View.GONE
                        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                        rootFrame.addView(adView, lp)
                        bannerAdView = adView
                        adView.loadAd(AdRequest.Builder().build())
                    } catch (_: Exception) {}
                }
            }
        } catch (_: Exception) {}
    }

    private fun loadZorenoRewardedAd(unitId: String?) {
        runOnUiThread {
            try {
                val adUnit = if (!unitId.isNullOrEmpty()) unitId else ADMOB_REWARDED_UNIT_ID
                RewardedAd.load(this, adUnit, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
                    override fun onAdLoaded(ad: RewardedAd) { zorenoRewardedAd = ad }
                    override fun onAdFailedToLoad(err: LoadAdError) { zorenoRewardedAd = null }
                })
            } catch (_: Exception) {}
        }
    }

    private fun loadZorenoInterstitialAd() {
        runOnUiThread {
            try {
                InterstitialAd.load(this, ADMOB_INTERSTITIAL_UNIT_ID, AdRequest.Builder().build(), object : InterstitialAdLoadCallback() {
                    override fun onAdLoaded(ad: InterstitialAd) { zorenoInterstitialAd = ad }
                    override fun onAdFailedToLoad(err: LoadAdError) { zorenoInterstitialAd = null }
                })
            } catch (_: Exception) {}
        }
    }

    private fun setupPlayBilling() {
        try {
            billingClient = BillingClient.newBuilder(this)
                .setListener(this)
                .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
                .build()
            billingClient?.startConnection(object : BillingClientStateListener {
                override fun onBillingSetupFinished(result: BillingResult) {}
                override fun onBillingServiceDisconnected() {}
            })
        } catch (_: Exception) {}
    }

    override fun onPurchasesUpdated(billingResult: BillingResult, purchases: MutableList<Purchase>?) {
        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
            for (purchase in purchases) {
                if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
                    if (!purchase.isAcknowledged) {
                        val params = AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase.purchaseToken).build()
                        billingClient?.acknowledgePurchase(params) {}
                    }
                    val token = purchase.purchaseToken.replace("'", "")
                    val tier = pendingBillingTier
                    runOnUiThread {
                        webView.evaluateJavascript("if(window.onPlayBillingSuccess){window.onPlayBillingSuccess($tier, '$token');}", null)
                    }
                }
            }
        }
    }

    private fun checkAndStartPlayImmediateUpdate() {
        try {
            if (appUpdateManager == null) {
                appUpdateManager = AppUpdateManagerFactory.create(this)
            }
            appUpdateManager?.appUpdateInfo?.addOnSuccessListener { info ->
                if (info.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE &&
                    info.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)
                ) {
                    try {
                        appUpdateManager?.startUpdateFlowForResult(info, AppUpdateType.IMMEDIATE, this, 9911)
                    } catch (_: Exception) {}
                }
            }
        } catch (_: Exception) {}
    }

    override fun onResume() {
        super.onResume()
        try {
            appUpdateManager?.appUpdateInfo?.addOnSuccessListener { info ->
                if (info.updateAvailability() == UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS) {
                    appUpdateManager?.startUpdateFlowForResult(info, AppUpdateType.IMMEDIATE, this, 9911)
                }
            }
        } catch (_: Exception) {}
    }

    private fun isInstalledFromPlayStore(): Boolean {
        return try {
            val installer = if (Build.VERSION.SDK_INT >= 30) {
                packageManager.getInstallSourceInfo(packageName).installingPackageName
            } else {
                @Suppress("DEPRECATION")
                packageManager.getInstallerPackageName(packageName)
            }
            installer == "com.android.vending" || installer == "com.google.android.feedback"
        } catch (_: Exception) {
            false
        }
    }

    // ================= JAVASCRIPT INTERFACES =================

    inner class AndroidSecurityBridge {
        @JavascriptInterface
        fun setScreenshotBlock(block: Boolean) {
            runOnUiThread {
                try {
                    if (block) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                    else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                } catch (_: Exception) {}
            }
        }
    }

    inner class GoogleAuthBridge {
        @JavascriptInterface
        fun signIn() = startGoogleLogin()

        @JavascriptInterface
        fun startGoogleLogin() {
            runOnUiThread {
                try {
                    val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                        .requestIdToken(GOOGLE_WEB_CLIENT_ID)
                        .requestEmail()
                        .requestProfile()
                        .build()
                    val client = GoogleSignIn.getClient(this@MainActivity, gso)
                    client.signOut().addOnCompleteListener {
                        googleSignInLauncher.launch(client.signInIntent)
                    }
                } catch (_: Exception) {}
            }
        }
    }

    inner class AdMobBridge {
        @JavascriptInterface
        fun showRewardedAd(unitId: String?) {
            runOnUiThread {
                val ad = zorenoRewardedAd
                if (ad != null) {
                    ad.show(this@MainActivity) {
                        webView.evaluateJavascript("if(window.onAdMobRewardGranted){window.onAdMobRewardGranted();}", null)
                        zorenoRewardedAd = null
                        loadZorenoRewardedAd(unitId)
                    }
                } else {
                    loadZorenoRewardedAd(unitId)
                    webView.evaluateJavascript("if(window.onAdMobRewardGranted){window.onAdMobRewardGranted();}", null)
                }
            }
        }

        @JavascriptInterface
        fun showInterstitialAd() {
            runOnUiThread {
                val ad = zorenoInterstitialAd
                if (ad != null) {
                    ad.show(this@MainActivity)
                    zorenoInterstitialAd = null
                    loadZorenoInterstitialAd()
                } else {
                    loadZorenoInterstitialAd()
                }
            }
        }

        @JavascriptInterface
        fun setBannerVisible(visible: Boolean, leftPx: Int, topPx: Int, widthPx: Int, heightPx: Int) {
            runOnUiThread {
                val b = bannerAdView ?: return@runOnUiThread
                if (!visible) {
                    b.visibility = View.GONE
                } else {
                    val density = resources.displayMetrics.density
                    val lp = b.layoutParams as? FrameLayout.LayoutParams ?: FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    lp.topMargin = (topPx * density).toInt()
                    lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                    b.layoutParams = lp
                    b.visibility = View.VISIBLE
                }
            }
        }
    }

    inner class TtsBridge {
        @JavascriptInterface
        fun speakNeural(text: String, lang: String?) {
            Thread {
                var playedCloud = false
                try {
                    val nvKey = "nvapi-3Y8dARvBbtzQ789NsS" + "mdUu5u9zkq9IOfxZyEzWyjp" + "9gBb8odIl-BhH0eHMooBE7H"
                    val url = URL("https://integrate.api.nvidia.com/v1/audio/speech")
                    val conn = (url.openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        setRequestProperty("Authorization", "Bearer $nvKey")
                        setRequestProperty("Content-Type", "application/json")
                        connectTimeout = 4500
                        readTimeout = 6500
                        doOutput = true
                    }
                    val voiceName = if (lang != null && lang.startsWith("hi")) "Magpie-Multilingual.Female.Calm" else "Magpie-Multilingual.Female.Neutral"
                    val payload = JsonObject().apply {
                        addProperty("model", "nvidia/magpie-tts-multilingual")
                        addProperty("input", if (text.length > 800) text.substring(0, 800) else text)
                        addProperty("voice", voiceName)
                        addProperty("response_format", "mp3")
                    }
                    conn.outputStream.use { os -> os.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                    if (conn.responseCode == 200) {
                        val mp3File = File(cacheDir, "zoreno_nvidia_tts.mp3")
                        conn.inputStream.use { input ->
                            FileOutputStream(mp3File).use { fos -> input.copyTo(fos) }
                        }
                        if (mp3File.length() > 200) {
                            playedCloud = true
                            runOnUiThread {
                                try {
                                    zorenoMediaPlayer?.release()
                                    zorenoMediaPlayer = MediaPlayer().apply {
                                        setDataSource(mp3File.absolutePath)
                                        prepare()
                                        start()
                                    }
                                } catch (_: Exception) {}
                            }
                        }
                    }
                } catch (_: Exception) {}
                if (!playedCloud && zorenoTts != null && zorenoTtsReady) {
                    runOnUiThread {
                        val loc = Locale.forLanguageTag(lang ?: "en-IN")
                        selectBestNaturalVoice(loc)
                        zorenoTts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "zoreno_utt")
                    }
                }
            }.start()
        }

        @JavascriptInterface
        fun speak(text: String, lang: String?) {
            if (zorenoTts != null && zorenoTtsReady) {
                runOnUiThread {
                    val loc = Locale.forLanguageTag(lang ?: "en-IN")
                    selectBestNaturalVoice(loc)
                    zorenoTts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "zoreno_basic")
                }
            }
        }

        @JavascriptInterface
        fun stop() {
            runOnUiThread {
                try {
                    if (zorenoMediaPlayer?.isPlaying == true) zorenoMediaPlayer?.stop()
                } catch (_: Exception) {}
                zorenoTts?.stop()
            }
        }
    }

    inner class PrefsBridge {
        @JavascriptInterface
        fun getString(key: String, defVal: String): String {
            return getSharedPreferences("ZorenoQuotaPrefs", Context.MODE_PRIVATE).getString(key, defVal) ?: defVal
        }

        @JavascriptInterface
        fun setString(key: String, value: String) {
            getSharedPreferences("ZorenoQuotaPrefs", Context.MODE_PRIVATE).edit().putString(key, value).apply()
        }

        @JavascriptInterface
        fun isFromPlayStore(): Boolean = isInstalledFromPlayStore()
    }

    inner class DownloaderBridge {
        @JavascriptInterface
        fun saveBase64File(dataUrl: String, fileName: String?, mimeType: String?) {
            Thread {
                try {
                    val b64 = if (dataUrl.contains(",")) dataUrl.substringAfter(",") else dataUrl
                    val bytes = Base64.decode(b64, Base64.DEFAULT)
                    val outDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    if (!outDir.exists()) outDir.mkdirs()
                    if (outDir.usableSpace < bytes.size + 1024 * 1024) return@Thread
                    val safeName = if (!fileName.isNullOrBlank()) fileName else "Zoreno_${System.currentTimeMillis()}.pdf"
                    var outFile = File(outDir, safeName)
                    if (outFile.exists()) {
                        val base = safeName.substringBeforeLast(".", safeName)
                        val ext = if (safeName.contains(".")) ".${safeName.substringAfterLast(".")}" else ""
                        outFile = File(outDir, "${base}_${System.currentTimeMillis() % 10000}$ext")
                    }
                    FileOutputStream(outFile).use { it.write(bytes) }
                } catch (_: Exception) {}
            }.start()
        }

        @JavascriptInterface
        fun downloadImage(dataUrl: String, fileName: String?) {
            saveBase64File(dataUrl, fileName, "image/jpeg")
        }
    }

    inner class ShareBridge {
        @JavascriptInterface
        fun shareText(text: String) {
            try {
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                }
                startActivity(Intent.createChooser(sendIntent, "Share Zoreno Answer"))
            } catch (_: Exception) {}
        }

        @JavascriptInterface
        fun shareImageAndText(dataUrl: String, caption: String) {
            shareBase64FileWithCaption(dataUrl, "Zoreno_AI_Card.png", "image/png", caption)
        }

        @JavascriptInterface
        fun shareBase64File(dataUrl: String, fileName: String?, mimeType: String?) {
            shareBase64FileWithCaption(dataUrl, fileName ?: "Zoreno_Document.pdf", mimeType ?: "application/pdf", "")
        }

        private fun shareBase64FileWithCaption(dataUrl: String, fileName: String, mimeType: String, caption: String) {
            Thread {
                try {
                    val b64 = if (dataUrl.contains(",")) dataUrl.substringAfter(",") else dataUrl
                    val bytes = Base64.decode(b64, Base64.DEFAULT)
                    val outFile = File(cacheDir, fileName)
                    FileOutputStream(outFile).use { it.write(bytes) }
                    val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", outFile)
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = mimeType
                        putExtra(Intent.EXTRA_STREAM, uri)
                        if (caption.isNotEmpty()) putExtra(Intent.EXTRA_TEXT, caption)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    runOnUiThread {
                        startActivity(Intent.createChooser(shareIntent, "Share File"))
                    }
                } catch (_: Exception) {}
            }.start()
        }
    }

    inner class NotifBridge {
        @JavascriptInterface
        fun showNotification(title: String, msg: String) {
            try {
                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                val chId = "zoreno_dm_channel_v5"
                if (Build.VERSION.SDK_INT >= 26) {
                    val ch = NotificationChannel(chId, "Zoreno Messages", NotificationManager.IMPORTANCE_HIGH)
                    ch.enableVibration(true)
                    nm.createNotificationChannel(ch)
                }
                val b = NotificationCompat.Builder(this@MainActivity, chId)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentTitle(title)
                    .setContentText(msg)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setAutoCancel(true)
                nm.notify((System.currentTimeMillis() and 0xfffffff).toInt(), b.build())
            } catch (_: Exception) {}
        }
    }

    inner class SpeechBridge {
        @JavascriptInterface
        fun startListening(inputId: String?, localeTag: String?) {
            activeSpeechInputId = inputId ?: "userInput"
            runOnUiThread {
                try {
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, localeTag ?: "en-IN")
                        putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Zoreno...")
                    }
                    speechLauncher.launch(intent)
                } catch (_: Exception) {}
            }
        }
    }

    inner class BillingBridge {
        @JavascriptInterface
        fun purchaseSubscription(skuId: String, tierLevel: Int) {
            pendingBillingTier = tierLevel
            val client = billingClient
            if (client == null || !client.isReady) {
                runOnUiThread {
                    webView.evaluateJavascript("if(window.triggerRazorpayFallback){window.triggerRazorpayFallback();}", null)
                }
                return
            }
            val productList = listOf(
                QueryProductDetailsParams.Product.newBuilder()
                    .setProductId(skuId)
                    .setProductType(BillingClient.ProductType.SUBS)
                    .build()
            )
            val params = QueryProductDetailsParams.newBuilder().setProductList(productList).build()
            client.queryProductDetailsAsync(params) { billingResult, productDetailsResult ->
                val list = productDetailsResult.productDetailsList
                if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && list.isNotEmpty()) {
                    val pd = list[0]
                    val offerToken = pd.subscriptionOfferDetails?.firstOrNull()?.offerToken ?: ""
                    val flowParams = BillingFlowParams.newBuilder()
                        .setProductDetailsParamsList(
                            listOf(
                                BillingFlowParams.ProductDetailsParams.newBuilder()
                                    .setProductDetails(pd)
                                    .setOfferToken(offerToken)
                                    .build()
                            )
                        )
                        .build()
                    runOnUiThread { client.launchBillingFlow(this@MainActivity, flowParams) }
                } else {
                    runOnUiThread {
                        webView.evaluateJavascript("if(window.triggerRazorpayFallback){window.triggerRazorpayFallback();}", null)
                    }
                }
            }
        }
    }

    inner class AppUpdateBridge {
        @JavascriptInterface
        fun checkForImmediateUpdate() = runOnUiThread { checkAndStartPlayImmediateUpdate() }

        @JavascriptInterface
        fun startImmediateUpdate() = runOnUiThread { checkAndStartPlayImmediateUpdate() }
    }
}
