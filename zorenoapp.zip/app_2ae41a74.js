// =========================================================
// ZORENO APP.JS — PART 1 OF 3
// CONFIG, GUARDRAILS, 195+ COUNTRIES, FIREBASE & 30-DAY SUB CHECK
// =========================================================

const firebaseConfig = {
    apiKey: "AIzaSyCJDkWOq9LXX_zG5uPE60P_NiZ4r9wTUJM",
    authDomain: "zeraai-ans.firebaseapp.com",
    projectId: "zeraai-ans",
    storageBucket: "zeraai-ans.firebasestorage.app",
    messagingSenderId: "315803761947",
    appId: "1:315803761947:web:e9098ce69e48c56b78a7be",
    measurementId: "G-PS4DP24WBT"
};

const GOOGLE_CLIENT_ID = "205788450312-ljp89u7m3q7ptpsad8r2vaga3t3bidj6.apps.googleusercontent.com";
const RAZORPAY_KEY_ID = "rzp_live_TYfeuDd2b9eh85";
const GEMINI_API_KEY = "AQ.Ab8RN6KJzHxIJ3tEtesJDMMG7p2Dcnb-J8qoNfht_pCqGa8M9g";

// Har jagah Gemini 3.5 Flash-Lite model hi rahega
const ZORENO_AI_MODEL = "gemini-3.5-flash-lite";

// ================= PLAY BILLING, ADMOB & ADSENSE CONFIG =================
const PLAY_BILLING_SKUS = {
    1: "zoreno_plus_monthly", // Play Console Subscription ID for Plus (₹249 / $3.99)
    2: "zoreno_pro_monthly"   // Play Console Subscription ID for Pro (₹349 / $6.99)
};

const ADS_CONFIG = {
    admobAppId: "ca-app-pub-5825754850490611~6362976717",           // Aapki AdMob App ID
    admobRewardedUnitId: "ca-app-pub-5825754850490611/4904670790",  // Aapki AdMob Rewarded Ad Unit ID
    adsenseClientId: "ca-pub-5825754850490611"                      // Aapki Website AdSense Publisher ID
};

const SUBSCRIPTION_VALIDITY_MS = 30 * 24 * 60 * 60 * 1000; // 30 Days in milliseconds

// ================= SYSTEM GUARDRAIL (ALL LANGUAGES + HEALTH/BIOLOGY ALLOWED + NO CODING) =================
const SYSTEM_INSTRUCTION = `You are Zoreno, a smart, friendly AI study partner and daily assistant.
STRICT LANGUAGE, MEMORY & FORMATTING RULES:
1. STRICT LANGUAGE MIRRORING (ALL LANGUAGES): Always reply in the EXACT language and script the user writes in or asks for.
   - If the user writes in English or says "English", reply 100% in pure English (do NOT use Hinglish).
   - If the user writes in Hindi (Devanagari), reply in Hindi.
   - If the user writes in Hinglish, reply in Hinglish.
   - If the user writes in or requests any other language, reply 100% in that language.
2. COMPACT FORMAT: Never put blank lines between bullet points. Write a short 1-2 line intro, tight bullet points (using * or -), and a 1-line conclusion. Use **bold** only for key terms.
3. EDUCATIONAL BIOLOGY, HEALTH & LIFESTYLE ALLOWED: Answer questions about Biology (including human reproduction, anatomy, sex education), personal health, mental health, stomach ache/illness, fashion, and lifestyle helpfully and respectfully.
4. NO CODING ALLOWED: Do NOT write programming code, HTML/CSS/JS/Python scripts, or software code. If asked for coding, reply politely in the user's language that coding is currently disabled in Zoreno.
5. STRICT SAFETY POLICY: Strictly refuse queries about making bombs, weapons, murder, suicide, self-harm encouragement, hacking, or illegal crimes.
6. CONTINUOUS CONVERSATION & FOLLOW-UP MEMORY: Always remember the ongoing topic from previous messages. If the user asks "Teach me Class 9 Maths" and then follows up with "Tell me the chapters", "Explain chapter 1", "Aur batao", or "Give an example", continue directly from that exact topic without repeating your greeting or introduction.`;


function checkQueryGuardrails(rawText) {
    const q = (rawText || "").toLowerCase();
    const unsafeRegex = /\b(make a bomb|how to make bomb|rdx|ied explosive|terrorist attack|how to murder|kill someone|commit suicide|how to die|make poison|hack bank|child abuse)\b|बम कैसे बनाएं|मर्डर कैसे/i;
    if (unsafeRegex.test(q)) {
        return {
            blocked: true,
            reply: "⚠️ **Safety Alert:** I cannot assist with dangerous, violent, or illegal activities. Please ask about studies, health, or safe daily topics."
        };
    }
    const codingRegex = /\b(write a code|write code|html code|javascript code|python code|java code|c\+\+ code|source code|program banao|code likho|coding kar)\b/i;
    if (codingRegex.test(q)) {
        return {
            blocked: true,
            reply: "🚫 **Coding Disabled:** Coding and programming features are currently turned off in Zoreno. Feel free to ask about any study subject, health, lifestyle, or general knowledge!"
        };
    }
    return { blocked: false };
}

// Health / Medical Query Detector (For Automated ⓘ Consult a Professional Banner)
function isHealthOrMedicalQuery(rawText) {
    const q = (rawText || "").toLowerCase();
    return /\b(health|doctor|medicine|tablet|symptom|fever|stomach|pain|ache|headache|panic attack|anxiety|depression| vomiting|diarrhea|disease|infection|blood pressure|diabetes|pregnancy|period|reproduction|sex|sexual|hiv|std|allergy|bukhar|pet kharab|dard|tabiyat|dawa|bimari|ilaj)\b/i.test(q);
}


// ================= GLOBAL STATE VARIABLES =================
let db = null, auth = null, firebaseReadyPromise = null;
let currentAppLang = localStorage.getItem("appLang") || "English";
let currentCountry = localStorage.getItem("manualCountry") || "IN";
let isLoggedIn = localStorage.getItem("isLoggedIn") === "true";
let userTier = parseInt(localStorage.getItem("userTier")) || 0;
let subExpiresAtMs = parseInt(localStorage.getItem("subExpiresAtMs")) || 0;
let selectedTierLevel = userTier === 1 ? 2 : 1;
let selectedAmount = 249;

let userName = localStorage.getItem("userName") || "Student";
let userEmail = localStorage.getItem("userEmail") || "";
let userAvatarUrl = localStorage.getItem("userAvatarUrl") || "https://i.pravatar.cc/150?img=11";
let currentUsername = localStorage.getItem("username") || "";
let currentBio = localStorage.getItem("userBio") || "Learning. Creating. Improving. A better version, every day.";

let activeConversationHistory = [];
let aiChatMessagesList = [];
try { aiChatMessagesList = JSON.parse(localStorage.getItem("zorenoAiChatStream") || "[]"); } catch (e) { aiChatMessagesList = []; }

let currentChatUserId = null;
let currentChatUserMeta = null;
let activeMessagesUnsubscribe = null;
let activeFriendProfileUnsub = null;
let activeChatMetaUnsub = null;
let isFriendCurrentlyTyping = false;
let typingTimeoutTimer = null;
let currentActiveChatTab = "all";
let msgToDeleteId = null;
let msgToDeleteChatId = null;

// Clean out any old @friend or @user dummy entries immediately
let recentDmUsers = [];
try {
    recentDmUsers = JSON.parse(localStorage.getItem("zorenoRecentDms") || "[]").filter(u => {
        if (!u || !u.uid || u.uid === "arjun_user_id") return false;
        const un = (u.username || "").toLowerCase();
        const nm = (u.name || "").toLowerCase();
        if (un === "@friend" || un === "@user" || nm === "friend" || nm === "user") return false;
        return true;
    });
    localStorage.setItem("zorenoRecentDms", JSON.stringify(recentDmUsers));
} catch (e) { recentDmUsers = []; }

let blockedUsersMap = {};
try { blockedUsersMap = JSON.parse(localStorage.getItem("zorenoBlockedUsers") || "{}"); } catch (e) { blockedUsersMap = {}; }

let searchHistoryList = [];
try { searchHistoryList = JSON.parse(localStorage.getItem("zorenoSearchHistory") || "[]"); } catch (e) { searchHistoryList = []; }
let currentSearchQuery = "";
let currentSearchOffset = 0;
let hasMoreSearchResults = true;
let isSearchLoading = false;

// ================= 195+ WORLD COUNTRIES FULL LIST =================
const RAW_WORLD_COUNTRIES = [
    "IN|🇮🇳|India|INR (₹)", "US|🇺🇸|United States|USD ($)", "GB|🇬🇧|United Kingdom|USD ($)", "CA|🇨🇦|Canada|USD ($)", "AU|🇦🇺|Australia|USD ($)",
    "AE|🇦🇪|United Arab Emirates|USD ($)", "AF|🇦🇫|Afghanistan|USD ($)", "AL|🇦🇱|Albania|USD ($)", "DZ|🇩🇿|Algeria|USD ($)", "AD|🇦🇩|Andorra|USD ($)",
    "AO|🇦🇴|Angola|USD ($)", "AG|🇦🇬|Antigua & Barbuda|USD ($)", "AR|🇦🇷|Argentina|USD ($)", "AM|🇦🇲|Armenia|USD ($)", "AT|🇦🇹|Austria|USD ($)",
    "AZ|🇦🇿|Azerbaijan|USD ($)", "BS|🇧🇸|Bahamas|USD ($)", "BH|🇧🇭|Bahrain|USD ($)", "BD|🇧🇩|Bangladesh|USD ($)", "BB|🇧🇧|Barbados|USD ($)",
    "BY|🇧🇾|Belarus|USD ($)", "BE|🇧🇪|Belgium|USD ($)", "BZ|🇧🇿|Belize|USD ($)", "BJ|🇧🇯|Benin|USD ($)", "BT|🇧🇹|Bhutan|USD ($)",
    "BO|🇧🇴|Bolivia|USD ($)", "BA|🇧🇦|Bosnia & Herzegovina|USD ($)", "BW|🇧🇼|Botswana|USD ($)", "BR|🇧🇷|Brazil|USD ($)", "BN|🇧🇳|Brunei|USD ($)",
    "BG|🇧🇬|Bulgaria|USD ($)", "BF|🇧🇫|Burkina Faso|USD ($)", "BI|🇧🇮|Burundi|USD ($)", "KH|🇰🇭|Cambodia|USD ($)", "CM|🇨🇲|Cameroon|USD ($)",
    "CV|🇨🇻|Cape Verde|USD ($)", "CF|🇨🇫|Central African Republic|USD ($)", "TD|🇹🇩|Chad|USD ($)", "CL|🇨🇱|Chile|USD ($)", "CN|🇨🇳|China|USD ($)",
    "CO|🇨🇴|Colombia|USD ($)", "KM|🇰🇲|Comoros|USD ($)", "CG|🇨🇬|Congo|USD ($)", "CR|🇨🇷|Costa Rica|USD ($)", "HR|🇭🇷|Croatia|USD ($)",
    "CU|🇨🇺|Cuba|USD ($)", "CY|🇨🇾|Cyprus|USD ($)", "CZ|🇨🇿|Czech Republic|USD ($)", "DK|🇩🇰|Denmark|USD ($)", "DJ|🇩🇯|Djibouti|USD ($)",
    "DM|🇩🇲|Dominica|USD ($)", "DO|🇩🇴|Dominican Republic|USD ($)", "EC|🇪🇨|Ecuador|USD ($)", "EG|🇪🇬|Egypt|USD ($)", "SV|🇸🇻|El Salvador|USD ($)",
    "GQ|🇬🇶|Equatorial Guinea|USD ($)", "ER|🇪🇷|Eritrea|USD ($)", "EE|🇪🇪|Estonia|USD ($)", "SZ|🇸🇿|Eswatini|USD ($)", "ET|🇪🇹|Ethiopia|USD ($)",
    "FJ|🇫🇯|Fiji|USD ($)", "FI|🇫🇮|Finland|USD ($)", "FR|🇫🇷|France|USD ($)", "GA|🇬🇦|Gabon|USD ($)", "GM|🇬🇲|Gambia|USD ($)",
    "GE|🇬🇪|Georgia|USD ($)", "DE|🇩🇪|Germany|USD ($)", "GH|🇬🇭|Ghana|USD ($)", "GR|🇬🇷|Greece|USD ($)", "GD|🇬🇩|Grenada|USD ($)",
    "GT|🇬🇹|Guatemala|USD ($)", "GN|🇬🇳|Guinea|USD ($)", "GY|🇬🇾|Guyana|USD ($)", "HT|🇭🇹|Haiti|USD ($)", "HN|🇭🇳|Honduras|USD ($)",
    "HU|🇭🇺|Hungary|USD ($)", "IS|🇮🇸|Iceland|USD ($)", "ID|🇮🇩|Indonesia|USD ($)", "IR|🇮🇷|Iran|USD ($)", "IQ|🇮🇶|Iraq|USD ($)",
    "IE|🇮🇪|Ireland|USD ($)", "IL|🇮🇱|Israel|USD ($)", "IT|🇮🇹|Italy|USD ($)", "JM|🇯🇲|Jamaica|USD ($)", "JP|🇯🇵|Japan|USD ($)",
    "JO|🇯🇴|Jordan|USD ($)", "KZ|🇰🇿|Kazakhstan|USD ($)", "KE|🇰🇪|Kenya|USD ($)", "KW|🇰🇼|Kuwait|USD ($)", "KG|🇰🇬|Kyrgyzstan|USD ($)",
    "LA|🇱🇦|Laos|USD ($)", "LV|🇱🇻|Latvia|USD ($)", "LB|🇱🇧|Lebanon|USD ($)", "LS|🇱🇸|Lesotho|USD ($)", "LR|🇱🇷|Liberia|USD ($)",
    "LY|🇱🇾|Libya|USD ($)", "LI|🇱🇮|Liechtenstein|USD ($)", "LT|🇱🇹|Lithuania|USD ($)", "LU|🇱🇺|Luxembourg|USD ($)", "MG|🇲🇬|Madagascar|USD ($)",
    "MW|🇲🇼|Malawi|USD ($)", "MY|🇲🇾|Malaysia|USD ($)", "MV|🇲🇻|Maldives|USD ($)", "ML|🇲🇱|Mali|USD ($)", "MT|🇲🇹|Malta|USD ($)",
    "MR|🇲🇷|Mauritania|USD ($)", "MU|🇲🇺|Mauritius|USD ($)", "MX|🇲🇽|Mexico|USD ($)", "MD|🇲🇩|Moldova|USD ($)", "MC|🇲🇨|Monaco|USD ($)",
    "MN|🇲🇳|Mongolia|USD ($)", "ME|🇲🇪|Montenegro|USD ($)", "MA|🇲🇦|Morocco|USD ($)", "MZ|🇲🇿|Mozambique|USD ($)", "MM|🇲🇲|Myanmar|USD ($)",
    "NA|🇳🇦|Namibia|USD ($)", "NP|🇳🇵|Nepal|USD ($)", "NL|🇳🇱|Netherlands|USD ($)", "NZ|🇳🇿|New Zealand|USD ($)", "NI|🇳🇮|Nicaragua|USD ($)",
    "NE|🇳🇪|Niger|USD ($)", "NG|🇳🇬|Nigeria|USD ($)", "KP|🇰🇵|North Korea|USD ($)", "MK|🇲🇰|North Macedonia|USD ($)", "NO|🇳🇴|Norway|USD ($)",
    "OM|🇴🇲|Oman|USD ($)", "PK|🇵🇰|Pakistan|USD ($)", "PA|🇵🇦|Panama|USD ($)", "PG|🇵🇬|Papua New Guinea|USD ($)", "PY|🇵🇾|Paraguay|USD ($)",
    "PE|🇵🇪|Peru|USD ($)", "PH|🇵🇭|Philippines|USD ($)", "PL|🇵🇱|Poland|USD ($)", "PT|🇵🇹|Portugal|USD ($)", "QA|🇶🇦|Qatar|USD ($)",
    "RO|🇷🇴|Romania|USD ($)", "RU|🇷🇺|Russia|USD ($)", "RW|🇷🇼|Rwanda|USD ($)", "SA|🇸🇦|Saudi Arabia|USD ($)", "SN|🇸🇳|Senegal|USD ($)",
    "RS|🇷🇸|Serbia|USD ($)", "SG|🇸🇬|Singapore|USD ($)", "SK|🇸🇰|Slovakia|USD ($)", "SI|🇸🇮|Slovenia|USD ($)", "ZA|🇿🇦|South Africa|USD ($)",
    "KR|🇰🇷|South Korea|USD ($)", "ES|🇪🇸|Spain|USD ($)", "LK|🇱🇰|Sri Lanka|USD ($)", "SD|🇸🇩|Sudan|USD ($)", "SE|🇸🇪|Sweden|USD ($)",
    "CH|🇨🇭|Switzerland|USD ($)", "SY|🇸🇾|Syria|USD ($)", "TW|🇹🇼|Taiwan|USD ($)", "TJ|🇹🇯|Tajikistan|USD ($)", "TZ|🇹🇿|Tanzania|USD ($)",
    "TH|🇹🇭|Thailand|USD ($)", "TR|🇹🇷|Turkey|USD ($)", "TM|🇹🇲|Turkmenistan|USD ($)", "UG|🇺🇬|Uganda|USD ($)", "UA|🇺🇦|Ukraine|USD ($)",
    "UY|🇺🇾|Uruguay|USD ($)", "UZ|🇺🇿|Uzbekistan|USD ($)", "VE|🇻🇪|Venezuela|USD ($)", "VN|🇻🇳|Vietnam|USD ($)", "YE|🇾🇪|Yemen|USD ($)",
    "ZM|🇿🇲|Zambia|USD ($)", "ZW|🇿🇼|Zimbabwe|USD ($)"
].map(item => {
    const [code, flag, name, curr] = item.split("|");
    return { code, flag, name, curr };
});

function loadExternalScript(src, id) {
    return new Promise((resolve, reject) => {
        let old = document.getElementById(id);
        if (old) {
            if (old.dataset.loaded === "true") return resolve();
            old.addEventListener("load", resolve, { once: true });
            return;
        }
        let s = document.createElement("script");
        s.id = id;
        s.src = src;
        s.onload = () => { s.dataset.loaded = "true"; resolve(); };
        s.onerror = () => reject(Error("Failed to load " + src));
        document.head.appendChild(s);
    });
}

function escapeHtml(s) {
    return String(s || "").replace(/[&<>"']/g, c => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
    }[c]));
}

// ================= FIREBASE INIT & 30-DAY SUBSCRIPTION CHECK =================
async function initFirebase() {
    if (firebaseReadyPromise) return firebaseReadyPromise;
    firebaseReadyPromise = (async () => {
        try {
            if (!window.firebase?.initializeApp)
                await loadExternalScript("https://www.gstatic.com/firebasejs/10.8.0/firebase-app-compat.js", "zfb-app");
            if (!window.firebase?.auth)
                await loadExternalScript("https://www.gstatic.com/firebasejs/10.8.0/firebase-auth-compat.js", "zfb-auth");
            if (!window.firebase?.firestore)
                await loadExternalScript("https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore-compat.js", "zfb-firestore");

            if (!firebase.apps.length) firebase.initializeApp(firebaseConfig);
            db = firebase.firestore();
            auth = firebase.auth();

            auth.onAuthStateChanged(async u => {
                const authScreen = document.getElementById("authScreen");
                const splashScreen = document.getElementById("splashScreen");
                const bottomNav = document.getElementById("bottomNav");

                if (u) {
                    isLoggedIn = true;
                    userName = u.displayName || userName || "Student";
                    userEmail = u.email || "";
                    if (u.photoURL && !userAvatarUrl.startsWith("data:image")) {
                        userAvatarUrl = u.photoURL;
                    }

                    localStorage.setItem("isLoggedIn", "true");
                    localStorage.setItem("userName", userName);
                    localStorage.setItem("userEmail", userEmail);

                    await loadUserProfile(u);
                    await ensureUniqueUsernameForUser(u);
                    updateProfileUI();
                    updatePricingUI(currentCountry);
                    updateMyPresenceStatus(true);
                    await loadUserChatsFromFirebase();

                    if (splashScreen) splashScreen.style.setProperty("display", "none", "important");
                    if (authScreen) authScreen.style.setProperty("display", "none", "important");
                    if (bottomNav) bottomNav.style.setProperty("display", "flex", "important");

                    showChatsHome();
                } else {
                    isLoggedIn = false;
                    hideAllScreens();
                    if (bottomNav) bottomNav.style.setProperty("display", "none", "important");
                    if (authScreen) authScreen.style.setProperty("display", "flex", "important");
                    if (splashScreen) splashScreen.style.setProperty("display", "none", "important");
                }
            });

            return true;
        } catch (e) {
            console.error("Firebase init:", e);
            return false;
        }
    })();
    return firebaseReadyPromise;
}

async function loadUserProfile(user) {
    if (!user) return;
    try {
        if (!db) await initFirebase();
        const userDocRef = db.collection("users").doc(user.uid);
        const userDoc = await userDocRef.get();

        if (userDoc.exists) {
            const data = userDoc.data();
            userName = data.name || user.displayName || "Student";
            currentUsername = data.username || "";
            currentBio = data.bio || currentBio;
            userAvatarUrl = data.photoURL || data.avatarUrl || user.photoURL || "https://i.pravatar.cc/150?img=11";

            // 30-Day Subscription Validity Check
            let savedTier = typeof data.userTier === "number" ? data.userTier : 0;
            let expiresMs = data.subscriptionExpiresAtMs || 0;

            if (savedTier > 0 && expiresMs > 0 && Date.now() > expiresMs) {
                // 30 Din pure hone par wapas Free Tier (0) kar do
                savedTier = 0;
                expiresMs = 0;
                await userDocRef.set({ userTier: 0, subscriptionExpiresAtMs: 0 }, { merge: true });
            }

            userTier = savedTier;
            subExpiresAtMs = expiresMs;
            localStorage.setItem("userTier", String(userTier));
            localStorage.setItem("subExpiresAtMs", String(subExpiresAtMs));
            localStorage.setItem("username", currentUsername);
            localStorage.setItem("userName", userName);
            localStorage.setItem("userBio", currentBio);
            localStorage.setItem("userAvatarUrl", userAvatarUrl);

            syncEditProfileInputs();
            updateProfileUI();
            updatePricingUI(currentCountry);
        } else {
            const cleanName = (user.displayName || "student").toLowerCase().replace(/[^a-z0-9]/g, "") || "student";
            const defaultUsername = `@${cleanName}_${Math.floor(1000 + Math.random() * 9000)}`;

            const initialData = {
                uid: user.uid,
                name: user.displayName || "Student",
                nameLower: (user.displayName || "Student").toLowerCase(),
                email: user.email || "",
                username: defaultUsername,
                usernameLower: defaultUsername.toLowerCase(),
                photoURL: userAvatarUrl || "https://i.pravatar.cc/150?img=11",
                bio: currentBio,
                userTier: 0,
                subscriptionExpiresAtMs: 0,
                isOnline: true,
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            };

            await userDocRef.set(initialData, { merge: true });
            userName = initialData.name;
            currentUsername = initialData.username;
            userAvatarUrl = initialData.photoURL;

            localStorage.setItem("username", currentUsername);
            localStorage.setItem("userName", userName);
            localStorage.setItem("userAvatarUrl", userAvatarUrl);
            syncEditProfileInputs();
        }
    } catch (err) {
        console.error("Error loading user profile:", err);
    }
}

// ================= NAVIGATION & SCREENS =================
function hideAllScreens() {
    const screens = [
        "chatListScreen", "subScreen", "toolsScreen", "settingsScreen",
        "chatScreen", "webSearchScreen", "activeChatScreen", "profileScreen", "historyScreen"
    ];
    screens.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.setProperty("display", "none", "important");
    });
}

function switchTab(tabId, element) {
    hideAllScreens();

    const inputArea = document.getElementById("inputAreaContainer");
    if (inputArea) inputArea.style.setProperty("display", "none", "important");

    const bottomNav = document.getElementById("bottomNav");
    if (bottomNav) bottomNav.style.setProperty("display", "flex", "important");

    if (tabId === "chat") {
        document.getElementById("chatListScreen")?.style.setProperty("display", "block", "important");
    } else if (tabId === "pro") {
        document.getElementById("subScreen")?.style.setProperty("display", "block", "important");
        if (userTier === 1) selectedTierLevel = 2;
        updatePricingUI(currentCountry);
    } else if (tabId === "tools") {
        document.getElementById("toolsScreen")?.style.setProperty("display", "flex", "important");
    } else if (tabId === "settings") {
        document.getElementById("settingsScreen")?.style.setProperty("display", "block", "important");
    }

    document.querySelectorAll(".nav-item").forEach(btn => btn.classList.remove("active"));
    if (element) element.classList.add("active");

    window.scrollTo(0, 0);
}

function showChatsHome() {
    hideAllScreens();

    const chatList = document.getElementById("chatListScreen");
    if (chatList) chatList.style.setProperty("display", "block", "important");

    const inputArea = document.getElementById("inputAreaContainer");
    if (inputArea) inputArea.style.setProperty("display", "none", "important");

    const bottomNav = document.getElementById("bottomNav");
    if (bottomNav) bottomNav.style.setProperty("display", "flex", "important");

    document.querySelectorAll(".nav-item").forEach(btn => btn.classList.remove("active"));
    const firstTab = document.querySelector(".floating-nav .nav-item");
    if (firstTab) firstTab.classList.add("active");
}

function goHome() {
    showChatsHome();
}

function openSettings() {
    pushScreenState("settings");
    hideAllScreens();
    document.getElementById("settingsScreen")?.style.setProperty("display", "block", "important");
    document.getElementById("inputAreaContainer")?.style.setProperty("display", "none", "important");
}

function openSubscription() {
    pushScreenState("sub");
    hideAllScreens();
    document.getElementById("subScreen")?.style.setProperty("display", "block", "important");
    document.getElementById("inputAreaContainer")?.style.setProperty("display", "none", "important");
    selectedTierLevel = userTier >= 1 ? 2 : 1;
    updatePricingUI(currentCountry);
}

function openProfile() {
    hideAllScreens();
    const profile = document.getElementById("profileScreen");
    if (profile) profile.style.setProperty("display", "block", "important");
    document.getElementById("inputAreaContainer")?.style.setProperty("display", "none", "important");
    syncEditProfileInputs();
    updateProfileUI();
}

function pushScreenState(screenName) {
    try { history.pushState({ screen: screenName }, ""); } catch (e) {}
}

function syncDarkModeUI(enabled) {
    const toggle = document.getElementById("darkModeToggle");
    if (toggle) {
        if (enabled) toggle.classList.remove("off");
        else toggle.classList.add("off");
    }
    const lightDot = document.getElementById("authThemeLight");
    const darkDot = document.getElementById("authThemeDark");
    if (lightDot && darkDot) {
        lightDot.classList.toggle("active", !enabled);
        darkDot.classList.toggle("active", enabled);
    }
}

function toggleDarkMode() {
    document.body.classList.toggle("dark-mode");
    const enabled = document.body.classList.contains("dark-mode");
    localStorage.setItem("darkMode", enabled ? "true" : "false");
    syncDarkModeUI(enabled);
}

// =========================================================
// ZORENO APP.JS — PART 2 OF 3
// 30-DAY SUBSCRIPTION LOCK (₹ & $), PLAY BILLING, AUTH & PROFILE
// =========================================================

function showCustomAlert(title, message, isSuccess = false) {
    const modal = document.getElementById("alertModal");
    if (!modal) {
        alert(`${title}\n\n${message}`);
        return;
    }

    const titleEl = document.getElementById("alertModalTitle");
    const msgEl = document.getElementById("alertModalMsg");
    const iconEl = document.getElementById("alertModalIcon");

    if (titleEl) titleEl.textContent = title || "Notice";
    if (msgEl) msgEl.textContent = message || "";
    if (iconEl) {
        iconEl.className = isSuccess ? "modal-icon" : "modal-icon error-icon";
        iconEl.innerHTML = isSuccess
            ? '<i class="fa-solid fa-circle-check" style="color:#16a34a;"></i>'
            : '<i class="fa-solid fa-circle-info"></i>';
    }

    modal.style.display = "flex";
}

function closeCustomAlert() {
    const modal = document.getElementById("alertModal");
    if (modal) modal.style.display = "none";
}

function openPolicyModal(type) {
    const modal = document.getElementById("policyModal");
    if (!modal) return;

    const title = document.getElementById("policyModalTitle");
    const content = document.getElementById("policyModalContent");

    const policies = {
        terms: {
            title: "Terms & Conditions",
            content: `
                <h3>1. Acceptance of Terms</h3>
                <p>By accessing and using Zoreno, you agree to comply with these Terms & Conditions and Google Play Policies.</p>
                <h3>2. AI-Generated Content Disclaimer</h3>
                <p>Zoreno uses advanced AI models to assist with study and general queries. Users can report any inappropriate AI response using the Feedback option in the chat menu.</p>
                <h3>3. User-Generated Content (UGC) & Safety</h3>
                <p>In direct messaging, abusive or illegal content is strictly prohibited. Users can <strong>Block</strong> and <strong>Report</strong> any user from the 3-dot chat menu.</p>
                <h3>4. 30-Day Subscription Validity</h3>
                <p>Zoreno Plus (50 chats/day) and Zoreno Pro (90 chats/day) remain active for 30 days from purchase via Google Play Billing or Razorpay.</p>
            `
        },
        privacy: {
            title: "Privacy Policy & Data Safety",
            content: `
                <h3>1. Information We Collect</h3>
                <p>We collect basic account details (Name, Email, Username, optional Profile Photo) and chat messages via Google Firebase to provide real-time sync.</p>
                <h3>2. Data Security</h3>
                <p>All data is encrypted in transit (HTTPS/TLS) and stored securely on Google Firebase servers. We never sell your personal data.</p>
                <h3>3. Account & Data Deletion</h3>
                <p>You can permanently delete your account and all associated data anytime directly from <strong>Settings &rarr; Delete Account</strong>.</p>
            `
        },
        refund: {
            title: "Refund & Cancellation Policy",
            content: `
                <h3>1. Subscription Validity & Cancellation</h3>
                <p>Purchased plans are active for 30 days. You may manage or cancel renewals anytime through Google Play Subscriptions or support.</p>
                <h3>2. Payment Issues</h3>
                <p>If payment is deducted without plan activation, contact support with your transaction ID for immediate resolution.</p>
            `
        }
    };

    const policy = policies[type];
    if (!policy) return;

    if (title) title.textContent = policy.title;
    if (content) content.innerHTML = policy.content;
    modal.style.display = "flex";
}

function closePolicyModal() {
    const modal = document.getElementById("policyModal");
    if (modal) modal.style.display = "none";
}

// ================= COUNTRY MODAL & 30-DAY PRICING LOCK (INR ₹ & USD $) =================
function openWorldCountryModal() {
    const modal = document.getElementById("worldCountryModal");
    const searchInput = document.getElementById("countrySearchInput");
    if (searchInput) searchInput.value = "";
    renderWorldCountries(RAW_WORLD_COUNTRIES);
    if (modal) modal.style.display = "flex";
}

function closeWorldCountryModal() {
    const modal = document.getElementById("worldCountryModal");
    if (modal) modal.style.display = "none";
}

function filterWorldCountries(query) {
    const q = (query || "").toLowerCase().trim();
    const filtered = RAW_WORLD_COUNTRIES.filter(c =>
        c.name.toLowerCase().includes(q) || c.code.toLowerCase().includes(q)
    );
    renderWorldCountries(filtered);
}

function renderWorldCountries(list) {
    const container = document.getElementById("worldCountryList");
    if (!container) return;

    container.innerHTML = list.map(c => {
        const isSelected = c.code === currentCountry;
        return `
            <div class="world-country-option ${isSelected ? 'active' : ''}" onclick="selectWorldCountry('${c.code}')">
                <div class="wc-left">
                    <span class="wc-flag">${c.flag}</span>
                    <div class="wc-text">
                        <h5>${c.name}</h5>
                        <span>${c.curr}</span>
                    </div>
                </div>
                <div class="wc-radio">
                    ${isSelected ? '<i class="fa-solid fa-circle-check"></i>' : '<i class="fa-regular fa-circle"></i>'}
                </div>
            </div>
        `;
    }).join("");
}

function selectWorldCountry(code) {
    currentCountry = code || "IN";
    localStorage.setItem("manualCountry", currentCountry);
    updatePricingUI(currentCountry);
    closeWorldCountryModal();
}

function detectAndSetCountry() {
    const saved = localStorage.getItem("manualCountry");
    if (saved) {
        currentCountry = saved;
        updatePricingUI(saved);
        return;
    }
    fetch("https://ipapi.co/json/")
        .then(r => r.json())
        .then(data => {
            const code = data?.country_code || "IN";
            currentCountry = code;
            localStorage.setItem("manualCountry", code);
            updatePricingUI(code);
        })
        .catch(() => {
            currentCountry = "IN";
            updatePricingUI("IN");
        });
}

function getRemainingSubDays() {
    if (!subExpiresAtMs || subExpiresAtMs <= Date.now()) return 30;
    return Math.max(1, Math.ceil((subExpiresAtMs - Date.now()) / (24 * 60 * 60 * 1000)));
}

function selectPlan(tierLevel, element) {
    if (userTier >= 2) {
        showCustomAlert("Subscription Already Active 👑", `You already have Zoreno Pro active for the next ${getRemainingSubDays()} days!`, true);
        return;
    }
    if (userTier === 1 && tierLevel <= 1) {
        showCustomAlert("Plus Plan Already Active ✨", `Your Zoreno Plus plan is active (${getRemainingSubDays()} days left). You can only upgrade to Zoreno Pro!`);
        selectedTierLevel = 2;
        updatePricingUI(currentCountry);
        return;
    }

    selectedTierLevel = tierLevel;
    updatePricingUI(currentCountry);
}

function updatePricingUI(countryCode) {
    currentCountry = countryCode || localStorage.getItem("manualCountry") || "IN";
    localStorage.setItem("manualCountry", currentCountry);

    const isIndia = currentCountry === "IN";
    const symbol = isIndia ? "₹" : "$";
    const plusPrice = isIndia ? 249 : 3.99;
    const proPrice = isIndia ? 349 : 6.99;

    if (userTier === 1 && selectedTierLevel < 2) {
        selectedTierLevel = 2;
    }

    const found = RAW_WORLD_COUNTRIES.find(c => c.code === currentCountry) || RAW_WORLD_COUNTRIES[0];
    const displayEl = document.getElementById("selectedCountryDisplay");
    if (displayEl) displayEl.innerText = `${found.flag} ${found.name} (${symbol})`;

    const plusCard = document.getElementById("plusPlanCard");
    const proCard = document.getElementById("proPlanCard");
    const plan1Title = document.getElementById("plan1Title");
    const plan2Title = document.getElementById("plan2Title");
    const plan1Desc = document.getElementById("plan1Description");
    const plan2Desc = document.getElementById("plan2Description");
    const payBtn = document.getElementById("payButtonText");
    const payBtnText = document.querySelector("#payButtonText .btn-text");

    if (plan1Title) plan1Title.innerText = `${symbol}${plusPrice} / Month (Plus)`;
    if (plan2Title) plan2Title.innerText = `${symbol}${proPrice} / Month (Pro)`;

    const daysLeft = getRemainingSubDays();

    if (userTier === 0) {
        if (plan1Desc) plan1Desc.innerText = "50 Messages/Day • 30 Days Validity";
        if (plan2Desc) plan2Desc.innerText = "90 Messages/Day • 30 Days • Vision";
        if (plusCard) {
            plusCard.style.opacity = "1";
            plusCard.classList.toggle("active", selectedTierLevel === 1);
        }
        if (proCard) {
            proCard.style.opacity = "1";
            proCard.classList.toggle("active", selectedTierLevel === 2);
        }
        selectedAmount = selectedTierLevel === 2 ? proPrice : plusPrice;
        if (payBtn) {
            payBtn.disabled = false;
            payBtn.style.opacity = "1";
        }
        if (payBtnText) payBtnText.innerText = `Upgrade to ${selectedTierLevel === 2 ? "Pro" : "Plus"} (${symbol}${selectedAmount})`;
    } else if (userTier === 1) {
        // Plus (249 / $3.99) Active -> Lock Plus, Only Allow Pro (349 / $6.99)
        if (plan1Desc) plan1Desc.innerHTML = `<strong style="color:#10b981;">✓ Active (${daysLeft} Days Left)</strong> • Cannot Rebuy`;
        if (plan2Desc) plan2Desc.innerText = "Upgrade for 90 Messages/Day • 30 Days";
        if (plusCard) {
            plusCard.classList.remove("active");
            plusCard.style.opacity = "0.55";
        }
        if (proCard) {
            proCard.classList.add("active");
            proCard.style.opacity = "1";
        }
        selectedTierLevel = 2;
        selectedAmount = proPrice;
        if (payBtn) {
            payBtn.disabled = false;
            payBtn.style.opacity = "1";
        }
        if (payBtnText) payBtnText.innerText = `Upgrade to Pro (${symbol}${proPrice})`;
    } else if (userTier >= 2) {
        // Pro (349 / $6.99) Active -> Lock Both Plans
        if (plan1Desc) plan1Desc.innerText = "Included in your active Pro Plan";
        if (plan2Desc) plan2Desc.innerHTML = `<strong style="color:#10b981;">✓ Active (${daysLeft} Days Left)</strong> • 90 Msgs/Day`;
        if (plusCard) {
            plusCard.classList.remove("active");
            plusCard.style.opacity = "0.45";
        }
        if (proCard) {
            proCard.classList.add("active");
            proCard.style.opacity = "1";
        }
        if (payBtn) {
            payBtn.disabled = true;
            payBtn.style.opacity = "0.75";
        }
        if (payBtnText) payBtnText.innerText = `Subscription Already Active (${daysLeft}d) 👑`;
    }
}

// ================= HYBRID PAYMENT: PLAY BILLING (APP) + RAZORPAY (WEB) =================
async function activateUserSubscriptionInFirestore(newTier, paymentReferenceId, providerName) {
    userTier = newTier;
    subExpiresAtMs = Date.now() + SUBSCRIPTION_VALIDITY_MS; // Valid for 30 Days

    localStorage.setItem("userTier", String(userTier));
    localStorage.setItem("subExpiresAtMs", String(subExpiresAtMs));

    if (db && auth?.currentUser) {
        await db.collection("users").doc(auth.currentUser.uid).set({
            userTier: userTier,
            subscriptionExpiresAtMs: subExpiresAtMs,
            paymentId: paymentReferenceId || "",
            paymentProvider: providerName || "unknown",
            subscriptionUpdatedAt: firebase.firestore.FieldValue.serverTimestamp()
        }, { merge: true });
    }

    updatePricingUI(currentCountry);
    updateProfileUI();

    showCustomAlert(
        "Subscription Activated (30 Days)! 🎉",
        `Welcome to Zoreno ${userTier === 2 ? "Pro" : "Plus"}! Your plan is now active for the next 30 days.`,
        true
    );
}

window.onPlayBillingSuccess = function (tierLevel, purchaseToken) {
    activateUserSubscriptionInFirestore(parseInt(tierLevel) || selectedTierLevel, purchaseToken || "play_billing", "google_play");
};

async function triggerRazorpay() {
    if (userTier >= 2) {
        showCustomAlert("Subscription Already Active 👑", `You already have Zoreno Pro active (${getRemainingSubDays()} days remaining).`, true);
        return;
    }
    if (userTier === 1 && selectedTierLevel <= 1) {
        selectedTierLevel = 2;
        updatePricingUI(currentCountry);
    }

    const targetTier = selectedTierLevel;
    const skuId = PLAY_BILLING_SKUS[targetTier];

    // 1. Android Native Bridge (Capacitor / Custom WebView)
    if (window.AndroidBilling && typeof window.AndroidBilling.purchaseSubscription === "function") {
        window.AndroidBilling.purchaseSubscription(skuId, targetTier);
        return;
    }

    // 2. Google Play TWA Digital Goods API (Play Store AAB)
    if ("getDigitalGoodsService" in window) {
        try {
            const service = await window.getDigitalGoodsService("https://play.google.com/billing");
            if (service) {
                const paymentMethods = [{
                    supportedMethods: "https://play.google.com/billing",
                    data: { sku: skuId }
                }];
                const paymentDetails = {
                    total: {
                        label: targetTier === 2 ? "Zoreno Pro (30 Days)" : "Zoreno Plus (30 Days)",
                        amount: { currency: currentCountry === "IN" ? "INR" : "USD", value: String(selectedAmount) }
                    }
                };
                const request = new PaymentRequest(paymentMethods, paymentDetails);
                const paymentResponse = await request.show();
                const { purchaseToken } = paymentResponse.details;
                await paymentResponse.complete("success");
                await activateUserSubscriptionInFirestore(targetTier, purchaseToken, "google_play_twa");
                return;
            }
        } catch (playErr) {
            if (playErr.name === "AbortError") return;
            console.warn("Play Billing fallback:", playErr);
        }
    }

    // 3. Website Browser -> Razorpay Checkout (Supports both INR ₹ and USD $)
    if (!window.Razorpay) {
        showCustomAlert("Loading Payment", "Payment system is loading. Please check your internet connection.");
        return;
    }

    const options = {
        key: RAZORPAY_KEY_ID,
        amount: Math.round(selectedAmount * 100),
        currency: currentCountry === "IN" ? "INR" : "USD",
        name: "Zoreno",
        description: targetTier === 2 ? "Zoreno Pro (30 Days)" : "Zoreno Plus (30 Days)",
        handler: async function (response) {
            try {
                await activateUserSubscriptionInFirestore(
                    targetTier,
                    response?.razorpay_payment_id || "rzp_web",
                    "razorpay"
                );
            } catch (e) {
                console.error("Subscription update error:", e);
            }
        },
        prefill: { name: userName || "", email: userEmail || "" },
        theme: { color: "#7c3aed" }
    };

    const rzp = new Razorpay(options);
    rzp.open();
}

// ================= AUTHENTICATION & ACCOUNT DELETION =================
function showSignUpForm() {
    document.getElementById("loginViewSection").style.display = "none";
    document.getElementById("signUpViewSection").style.display = "block";
    document.getElementById("authBackBtn").style.display = "inline-flex";
}

function showLoginForm() {
    document.getElementById("signUpViewSection").style.display = "none";
    document.getElementById("loginViewSection").style.display = "block";
    document.getElementById("authBackBtn").style.display = "none";
}

function toggleInputPassword(fieldId, btn) {
    const input = document.getElementById(fieldId);
    if (!input) return;
    const isPass = input.type === "password";
    input.type = isPass ? "text" : "password";
    btn.innerHTML = isPass ? '<i class="fa-regular fa-eye"></i>' : '<i class="fa-regular fa-eye-slash"></i>';
}

async function handleEmailLogin(e) {
    e.preventDefault();
    const email = document.getElementById("loginEmail").value.trim();
    const pass = document.getElementById("loginPassword").value;
    const btn = document.getElementById("loginSubmitBtn");
    if (!email || !pass) return;

    try {
        if (btn) btn.disabled = true;
        await initFirebase();
        const userCred = await auth.signInWithEmailAndPassword(email, pass);
        if (userCred.user) {
            document.getElementById("authScreen")?.style.setProperty("display", "none", "important");
            showChatsHome();
        }
    } catch (err) {
        let customMsg = err.message;
        if (err.code === "auth/invalid-credential" || err.code === "auth/user-not-found" || err.code === "auth/wrong-password") {
            customMsg = "Account not found or wrong password. Please check your details or Sign Up.";
        }
        showCustomAlert("Login Failed", customMsg);
    } finally {
        if (btn) btn.disabled = false;
    }
}

async function handleEmailSignUp(e) {
    e.preventDefault();
    const name = document.getElementById("regName").value.trim();
    const email = document.getElementById("regEmail").value.trim();
    const pass = document.getElementById("regPassword").value;
    const btn = document.getElementById("signUpSubmitBtn");

    try {
        if (btn) btn.disabled = true;
        await initFirebase();
        const res = await auth.createUserWithEmailAndPassword(email, pass);

        if (res.user) {
            const cleanName = name.toLowerCase().replace(/[^a-z0-9]/g, "") || "student";
            const randomCode = Math.floor(1000 + Math.random() * 9000);
            const autoUsername = `@${cleanName}_${randomCode}`;

            await res.user.updateProfile({ displayName: name });
            userName = name;
            currentUsername = autoUsername;
            localStorage.setItem("username", autoUsername);
            localStorage.setItem("userName", name);

            if (db) {
                await db.collection("users").doc(res.user.uid).set({
                    uid: res.user.uid,
                    name: name,
                    nameLower: name.toLowerCase(),
                    email: email,
                    username: autoUsername,
                    usernameLower: autoUsername.toLowerCase(),
                    photoURL: "https://i.pravatar.cc/150?img=11",
                    bio: currentBio,
                    userTier: 0,
                    subscriptionExpiresAtMs: 0,
                    isOnline: true,
                    createdAt: firebase.firestore.FieldValue.serverTimestamp()
                }, { merge: true });
            }

            await loadUserProfile(res.user);
            showChatsHome();
        }
    } catch (err) {
        showCustomAlert("Sign Up Failed", err.message);
    } finally {
        if (btn) btn.disabled = false;
    }
}

async function handleForgotPassword() {
    const email = document.getElementById("loginEmail").value.trim();
    if (!email) {
        showCustomAlert("Email Required", "Please enter your email in the email address box first.");
        return;
    }
    try {
        await initFirebase();
        await auth.sendPasswordResetEmail(email);
        showCustomAlert("Reset Email Sent", "Password reset instructions sent to your email.", true);
    } catch (err) {
        showCustomAlert("Reset Failed", err.message);
    }
}

async function handleUserLogout() {
    try {
        updateMyPresenceStatus(false);
        if (auth) await auth.signOut();
        localStorage.clear();
        sessionStorage.clear();
        window.location.reload();
    } catch (err) {
        showCustomAlert("Logout Failed", err.message);
    }
}

function openDeleteAccountModal() {
    const emailInp = document.getElementById("delAccEmail");
    const passInp = document.getElementById("delAccPass");
    if (emailInp) emailInp.value = userEmail || auth?.currentUser?.email || "";
    if (passInp) passInp.value = "";
    const modal = document.getElementById("deleteAccountModal");
    if (modal) modal.style.display = "flex";
}

async function confirmDeleteAccount() {
    const email = document.getElementById("delAccEmail")?.value.trim();
    const pass = document.getElementById("delAccPass")?.value;
    if (!email || !pass) {
        showCustomAlert("Details Required", "Please enter both your email and password to confirm deletion.");
        return;
    }
    if (!auth?.currentUser) return;

    try {
        const uid = auth.currentUser.uid;
        const cred = firebase.auth.EmailAuthProvider.credential(email, pass);
        await auth.currentUser.reauthenticateWithCredential(cred);

        if (db) {
            const chatSnap = await db.collection("users").doc(uid).collection("chats").get();
            const batch = db.batch();
            chatSnap.forEach(d => batch.delete(d.ref));
            batch.delete(db.collection("users").doc(uid));
            await batch.commit();
        }

        await auth.currentUser.delete();
        localStorage.clear();
        sessionStorage.clear();
        document.getElementById("deleteAccountModal").style.display = "none";
        window.location.reload();
    } catch (err) {
        showCustomAlert("Deletion Failed", "Incorrect password or authentication error: " + err.message);
    }
}

// ================= PROFILE EDIT & PHOTO SAVE (FIXED BLANK WHITE SCREEN) =================
function updateProfileUI() {
    const tierLabel = userTier === 2
        ? `Pro Member (${getRemainingSubDays()}d left) 👑`
        : userTier === 1
            ? `Plus Member (${getRemainingSubDays()}d left) ✨`
            : "Free Member";
    const cardTierEl = document.getElementById("profileCardTierTitle");
    if (cardTierEl) cardTierEl.textContent = tierLabel;

    const avImg = document.getElementById("profileEditAvatarImg");
    if (avImg && userAvatarUrl) avImg.src = userAvatarUrl;

    const badge = document.getElementById("profileUsernameBadge");
    if (badge) badge.innerText = currentUsername || "@student";
}

function syncEditProfileInputs() {
    const uInp = document.getElementById("profileEditUsername");
    const nInp = document.getElementById("profileEditName");
    const bInp = document.getElementById("profileEditBio");
    const badge = document.getElementById("profileUsernameBadge");
    const avImg = document.getElementById("profileEditAvatarImg");

    if (uInp) uInp.value = (currentUsername || "").replace(/^@/, "");
    if (nInp) nInp.value = userName || "Student";
    if (bInp) bInp.value = currentBio;
    if (badge) badge.innerText = currentUsername || "@student";
    if (avImg && userAvatarUrl) avImg.src = userAvatarUrl;
}

function previewAndUploadProfilePic(event) {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function (e) {
        const img = new Image();
        img.onload = async function () {
            const canvas = document.createElement("canvas");
            const MAX_SIZE = 240;
            let w = img.width;
            let h = img.height;

            if (w > h) {
                if (w > MAX_SIZE) { h = Math.round((h * MAX_SIZE) / w); w = MAX_SIZE; }
            } else {
                if (h > MAX_SIZE) { w = Math.round((w * MAX_SIZE) / h); h = MAX_SIZE; }
            }

            canvas.width = w;
            canvas.height = h;
            const ctx = canvas.getContext("2d");
            ctx.drawImage(img, 0, 0, w, h);

            const compressedBase64 = canvas.toDataURL("image/jpeg", 0.78);
            userAvatarUrl = compressedBase64;
            localStorage.setItem("userAvatarUrl", compressedBase64);
            updateProfileUI();

            if (db && auth?.currentUser) {
                const myUid = auth.currentUser.uid;
                try {
                    await db.collection("users").doc(myUid).set({
                        photoURL: compressedBase64,
                        avatarUrl: compressedBase64,
                        updatedAt: firebase.firestore.FieldValue.serverTimestamp()
                    }, { merge: true });

                    const chatSnap = await db.collection("chats")
                        .where("participants", "array-contains", myUid)
                        .get();

                    const batch = db.batch();
                    chatSnap.forEach(doc => {
                        const d = doc.data();
                        if (d.lastSenderId === myUid) {
                            batch.update(doc.ref, { lastSenderAvatar: compressedBase64 });
                        }
                    });
                    await batch.commit();
                } catch (err) {
                    console.error("Avatar sync error:", err);
                }
            }
        };
        img.src = e.target.result;
    };
    reader.readAsDataURL(file);
}

async function ensureUniqueUsernameForUser(u) {
    if (!db || !u) return;
    try {
        const userRef = db.collection("users").doc(u.uid);
        const snap = await userRef.get();
        let data = snap.exists ? snap.data() : {};

        if (data.username && data.username !== "@user" && data.username !== "@friend") {
            currentUsername = data.username;
        } else {
            const base = (u.displayName || userName || "student")
                .toLowerCase()
                .replace(/[^a-z0-9]/g, "")
                .slice(0, 10) || "student";
            const rand = Math.floor(1000 + Math.random() * 9000);
            currentUsername = `@${base}_${rand}`;

            await userRef.set({
                uid: u.uid,
                name: u.displayName || userName || "Student",
                nameLower: (u.displayName || userName || "Student").toLowerCase(),
                username: currentUsername,
                usernameLower: currentUsername.toLowerCase(),
                bio: currentBio,
                photoURL: userAvatarUrl || "https://i.pravatar.cc/150?img=11"
            }, { merge: true });
        }

        if (data.bio) currentBio = data.bio;
        if (data.photoURL) userAvatarUrl = data.photoURL;
        localStorage.setItem("username", currentUsername);
        localStorage.setItem("userBio", currentBio);
        localStorage.setItem("userAvatarUrl", userAvatarUrl);

        syncEditProfileInputs();
        listenIncomingRealtimeChats(u.uid);
    } catch (e) {
        console.error("Username init error:", e);
    }
}

async function saveUserProfileChanges() {
    const uInp = document.getElementById("profileEditUsername");
    const nInp = document.getElementById("profileEditName");
    const bInp = document.getElementById("profileEditBio");
    const hint = document.getElementById("usernameStatusHint");
    const saveBtn = document.getElementById("profileSaveBtn");

    let rawU = (uInp?.value || "").trim().toLowerCase().replace(/^@/, "").replace(/[^a-z0-9_.]/g, "");
    let newName = (nInp?.value || "").trim() || userName;
    let newBio = (bInp?.value || "").trim() || currentBio;

    if (rawU.length < 3 || rawU === "user" || rawU === "friend") {
        if (hint) {
            hint.style.color = "#ef4444";
            hint.innerText = "Please choose a valid unique username (min 3 chars).";
        }
        return;
    }

    const formattedUsername = `@${rawU}`;

    try {
        if (saveBtn) {
            saveBtn.disabled = true;
            saveBtn.innerText = "Saving...";
        }

        if (db && auth?.currentUser) {
            const q = await db.collection("users")
                .where("usernameLower", "==", formattedUsername.toLowerCase())
                .get();

            let isTaken = false;
            q.forEach(doc => {
                if (doc.id !== auth.currentUser.uid) isTaken = true;
            });

            if (isTaken) {
                if (hint) {
                    hint.style.color = "#ef4444";
                    hint.innerText = `❌ ${formattedUsername} is already taken!`;
                }
                return;
            }

            await db.collection("users").doc(auth.currentUser.uid).set({
                name: newName,
                nameLower: newName.toLowerCase(),
                username: formattedUsername,
                usernameLower: formattedUsername.toLowerCase(),
                bio: newBio,
                photoURL: userAvatarUrl
            }, { merge: true });
        }

        currentUsername = formattedUsername;
        userName = newName;
        currentBio = newBio;

        localStorage.setItem("username", currentUsername);
        localStorage.setItem("userName", userName);
        localStorage.setItem("userBio", currentBio);

        if (hint) hint.innerText = "";
        syncEditProfileInputs();
        updateProfileUI();

        // White blank screen fix -> Seedha Home Screen par redirect karega!
        showChatsHome();
    } catch (err) {
        console.error("Save profile error:", err);
    } finally {
        if (saveBtn) {
            saveBtn.disabled = false;
            saveBtn.innerText = "Save";
        }
    }
}


// =========================================================
// ZORENO APP.JS — PART 3 OF 3 (FINAL)
// FULL NAME HOME LIST, FRIEND PROFILE VIEW (29552), WHATSAPP MESSAGE
// DELETE (AI + DM), IMAGE COMING SOON, & HEALTH DISCLAIMER BANNER
// =========================================================

let aiMsgIndexToDelete = null;

function updateMyPresenceStatus(isOnlineNow) {
    if (!db || !auth?.currentUser) return;
    const nowTime = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    db.collection("users").doc(auth.currentUser.uid).set({
        isOnline: isOnlineNow,
        lastSeenLabel: nowTime,
        lastActiveAt: firebase.firestore.FieldValue.serverTimestamp()
    }, { merge: true }).catch(() => {});
}

window.addEventListener("focus", () => updateMyPresenceStatus(true));
window.addEventListener("blur", () => updateMyPresenceStatus(false));
window.addEventListener("beforeunload", () => updateMyPresenceStatus(false));
window.addEventListener("pagehide", () => updateMyPresenceStatus(false));
document.addEventListener("visibilitychange", () => {
    updateMyPresenceStatus(!document.hidden);
});

// ================= HOME SEARCH (0ms INSTANT CLEAR) & TABS =================
function setupHomeSearchAndTabs() {
    const searchInp = document.getElementById("homeChatSearchInput");
    if (searchInp) {
        searchInp.addEventListener("input", e => handleHomeUserSearch(e.target.value));
        searchInp.addEventListener("search", e => handleHomeUserSearch(e.target.value));
        searchInp.addEventListener("keyup", e => {
            if (!e.target.value.trim()) handleHomeUserSearch("");
        });
    }

    const tabBtns = document.querySelectorAll(".chat-tabs .tab-btn");
    const tabKeys = ["all", "unread", "friends", "groups"];
    tabBtns.forEach((btn, idx) => {
        btn.onclick = () => {
            tabBtns.forEach(b => b.classList.remove("active"));
            btn.classList.add("active");
            currentActiveChatTab = tabKeys[idx] || "all";
            filterHomeChatListByTab(currentActiveChatTab);
        };
    });

    renderSavedDmChatsOnHome();
}

function filterHomeChatListByTab(tabKey) {
    const items = document.querySelectorAll(".chats-container .chat-list-item");
    items.forEach(item => {
        if (item.classList.contains("pinned")) {
            item.style.display = tabKey === "all" ? "flex" : "none";
            return;
        }
        const isGroup = item.querySelector(".group-avatar") !== null;
        const hasUnread = item.querySelector(".unread-count") !== null;

        if (tabKey === "all") item.style.display = "flex";
        else if (tabKey === "unread") item.style.display = hasUnread ? "flex" : "none";
        else if (tabKey === "friends") item.style.display = !isGroup ? "flex" : "none";
        else if (tabKey === "groups") item.style.display = isGroup ? "flex" : "none";
    });
}

let searchDebounceTimer = null;
async function handleHomeUserSearch(rawQuery) {
    const q = (rawQuery || "").trim().toLowerCase();
    let resultsBox = document.getElementById("liveUserSearchDropdown");

    if (!resultsBox) {
        resultsBox = document.createElement("div");
        resultsBox.id = "liveUserSearchDropdown";
        resultsBox.className = "live-user-search-dropdown";
        const header = document.querySelector(".chat-list-header-modern");
        header?.insertAdjacentElement("afterend", resultsBox);
    }

    clearTimeout(searchDebounceTimer);
    if (!q) {
        resultsBox.innerHTML = "";
        resultsBox.style.display = "none";
        filterHomeChatListByTab(currentActiveChatTab);
        return;
    }

    document.querySelectorAll(".chats-container .chat-list-item").forEach(item => {
        const text = item.innerText.toLowerCase();
        item.style.display = text.includes(q) ? "flex" : "none";
    });

    if (!db) return;
    searchDebounceTimer = setTimeout(async () => {
        const currentVal = (document.getElementById("homeChatSearchInput")?.value || "").trim();
        if (!currentVal) {
            resultsBox.innerHTML = "";
            resultsBox.style.display = "none";
            return;
        }

        try {
            const cleanQ = q.replace(/^@/, "");
            const matchesMap = new Map();

            try {
                const uSnap = await db.collection("users")
                    .where("usernameLower", ">=", `@${cleanQ}`)
                    .where("usernameLower", "<=", `@${cleanQ}\uf8ff`)
                    .limit(15)
                    .get();
                uSnap.forEach(doc => matchesMap.set(doc.id, { id: doc.id, ...doc.data() }));
            } catch (e) {}

            const allSnap = await db.collection("users").limit(80).get();
            allSnap.forEach(doc => {
                const d = doc.data();
                const uName = (d.username || "").toLowerCase();
                const fName = (d.name || "").toLowerCase();
                if (uName.includes(cleanQ) || fName.includes(cleanQ)) {
                    matchesMap.set(doc.id, { id: doc.id, ...d });
                }
            });

            const matches = Array.from(matchesMap.values()).filter(u => {
                if (auth?.currentUser && u.id === auth.currentUser.uid) return false;
                if (u.id === "arjun_user_id") return false;
                const un = (u.username || "").toLowerCase();
                const nm = (u.name || "").toLowerCase();
                if (!un || un === "@user" || un === "@friend") return false;
                if (!nm || nm === "user" || nm === "friend") return false;
                return true;
            });

            if (matches.length === 0) {
                resultsBox.innerHTML = `<div class="user-search-empty">No user found with "${escapeHtml(rawQuery)}"</div>`;
            } else {
                resultsBox.innerHTML = matches.map(u => `
                    <div class="user-search-item" onclick="startChatFromSearch('${u.id}', '${escapeHtml(u.name)}', '${escapeHtml(u.username)}', '${escapeHtml(u.photoURL || 'https://i.pravatar.cc/150?img=11')}')">
                        <img src="${escapeHtml(u.photoURL || 'https://i.pravatar.cc/150?img=11')}" alt="User">
                        <div class="us-info">
                            <h5>${escapeHtml(u.name)}</h5>
                            <span>${escapeHtml(u.username)}</span>
                        </div>
                        <button type="button" class="us-msg-btn">Message</button>
                    </div>
                `).join("");
            }
            resultsBox.style.display = "flex";
        } catch (err) {
            console.error("User search error:", err);
        }
    }, 180);
}

function startChatFromSearch(uid, name, username, avatar) {
    clearTimeout(searchDebounceTimer);
    const resultsBox = document.getElementById("liveUserSearchDropdown");
    const searchInp = document.getElementById("homeChatSearchInput");
    if (resultsBox) {
        resultsBox.innerHTML = "";
        resultsBox.style.display = "none";
    }
    if (searchInp) searchInp.value = "";
    filterHomeChatListByTab("all");

    openChatWithUser(uid, name, avatar, username);
}

// ================= FRIEND DM CHAT & DEDICATED FRIEND PROFILE SCREEN (29552.PNG) =================
function openChatWithUser(userId, targetName, targetAvatar, targetUsername = "@student") {
    currentChatUserId = userId;
    isFriendCurrentlyTyping = false;
    currentChatUserMeta = {
        uid: userId,
        name: targetName || "Student",
        avatar: targetAvatar || "https://i.pravatar.cc/150?img=11",
        username: targetUsername || "@student",
        bio: "Student | Exploring new things | Keep learning.",
        isOnline: false,
        lastSeenLabel: "recently"
    };

    const chatWin = document.getElementById("activeChatScreen");
    const nameEl = document.getElementById("activeChatName");
    const avatarEl = document.getElementById("activeChatAvatar");
    const bottomNav = document.getElementById("bottomNav");

    if (nameEl) nameEl.textContent = currentChatUserMeta.name;
    if (avatarEl) avatarEl.src = currentChatUserMeta.avatar;
    renderDmHeaderStatus();
    updateBlockMenuButtonUI();

    if (bottomNav) bottomNav.style.setProperty("display", "none", "important");
    if (chatWin) {
        chatWin.style.setProperty("display", "flex", "important");
        chatWin.style.setProperty("visibility", "visible", "important");
        chatWin.style.setProperty("pointer-events", "auto", "important");
    }

    if (activeFriendProfileUnsub) activeFriendProfileUnsub();
    if (db && userId) {
        activeFriendProfileUnsub = db.collection("users").doc(userId).onSnapshot(doc => {
            if (!doc.exists) return;
            const d = doc.data();
            currentChatUserMeta.name = d.name || currentChatUserMeta.name;
            currentChatUserMeta.username = d.username || currentChatUserMeta.username;
            currentChatUserMeta.avatar = d.photoURL || d.avatarUrl || currentChatUserMeta.avatar;
            currentChatUserMeta.bio = d.bio || currentChatUserMeta.bio;
            currentChatUserMeta.isOnline = d.isOnline === true;
            currentChatUserMeta.lastSeenLabel = d.lastSeenLabel || "recently";

            if (nameEl) nameEl.textContent = currentChatUserMeta.name;
            if (avatarEl) avatarEl.src = currentChatUserMeta.avatar;
            renderDmHeaderStatus();
            syncFriendProfileViewDOM();

            document.querySelectorAll(".dm-friend-side-dp").forEach(img => {
                img.src = currentChatUserMeta.avatar;
            });

            upsertRecentDmOnHome(
                userId,
                currentChatUserMeta.name,
                currentChatUserMeta.avatar,
                currentChatUserMeta.username,
                "",
                "",
                0
            );
        });
    }

    if (activeChatMetaUnsub) activeChatMetaUnsub();
    if (db && auth?.currentUser && userId) {
        const myUid = auth.currentUser.uid;
        const chatId = myUid < userId ? `${myUid}_${userId}` : `${userId}_${myUid}`;
        activeChatMetaUnsub = db.collection("chats").doc(chatId).onSnapshot(doc => {
            if (!doc.exists) return;
            const data = doc.data() || {};
            isFriendCurrentlyTyping = !!data[`typing_${userId}`];
            renderDmHeaderStatus();
        });
    }

    upsertRecentDmOnHome(userId, targetName, targetAvatar, targetUsername, "", "Just now", 0);
    loadMessagesFromFirestore(userId);
}

// Open Friend Profile View (29552.png Match)
function openFriendProfileScreen() {
    toggleDmHeaderMenu(false);
    if (!currentChatUserMeta) return;
    syncFriendProfileViewDOM();
    const fpScreen = document.getElementById("friendProfileScreen");
    if (fpScreen) fpScreen.style.setProperty("display", "block", "important");
}

function closeFriendProfileScreen() {
    toggleFpHeaderMenu(false);
    const fpScreen = document.getElementById("friendProfileScreen");
    if (fpScreen) fpScreen.style.setProperty("display", "none", "important");
}

function toggleFpHeaderMenu(forceState) {
    const menu = document.getElementById("fpHeaderDropdownMenu");
    if (!menu) return;
    if (typeof forceState === "boolean") {
        menu.style.display = forceState ? "block" : "none";
    } else {
        menu.style.display = menu.style.display === "block" ? "none" : "block";
    }
}

function syncFriendProfileViewDOM() {
    if (!currentChatUserMeta) return;
    const cleanHandle = (currentChatUserMeta.username || "@student").replace(/^@/, "");
    const fullHandle = `@${cleanHandle}`;
    const bioStr = currentChatUserMeta.bio || "Student | Exploring new things | Keep learning.";
    const isOnline = currentChatUserMeta.isOnline === true;
    const statusText = isOnline ? "Online" : `Last seen ${currentChatUserMeta.lastSeenLabel || "recently"}`;
    const dotColor = isOnline ? "#10b981" : "#94a3b8";

    const avImg = document.getElementById("fpAvatarImg");
    const avDot = document.getElementById("fpAvatarDot");
    const fName = document.getElementById("fpFullName");
    const uSub = document.getElementById("fpUsernameSub");
    const pillDot = document.getElementById("fpPillDot");
    const pillTxt = document.getElementById("fpPillText");
    const pillBox = document.getElementById("fpOnlinePill");

    if (avImg) avImg.src = currentChatUserMeta.avatar || "https://i.pravatar.cc/150?img=11";
    if (avDot) avDot.style.background = dotColor;
    if (fName) fName.textContent = currentChatUserMeta.name || "Student";
    if (uSub) uSub.textContent = fullHandle;
    if (pillDot) pillDot.style.background = dotColor;
    if (pillTxt) pillTxt.textContent = statusText;
    if (pillBox) {
        pillBox.style.background = isOnline ? "rgba(16, 185, 129, 0.14)" : "rgba(148, 163, 184, 0.18)";
        pillBox.style.color = isOnline ? "#059669" : "#64748b";
    }

    const cUser = document.getElementById("fpCardUsername");
    const cName = document.getElementById("fpCardName");
    const cBio = document.getElementById("fpCardBio");
    const cBioCount = document.getElementById("fpBioCount");
    const bDot = document.getElementById("fpBottomStatusDot");
    const bTxt = document.getElementById("fpBottomStatusText");

    if (cUser) cUser.textContent = cleanHandle;
    if (cName) cName.textContent = currentChatUserMeta.name || "Student";
    if (cBio) cBio.textContent = bioStr;
    if (cBioCount) cBioCount.textContent = `${bioStr.length}/150`;
    if (bDot) bDot.style.background = dotColor;
    if (bTxt) bTxt.textContent = statusText;
}

async function copyFriendUsername() {
    if (!currentChatUserMeta) return;
    const handle = (currentChatUserMeta.username || "").replace(/^@/, "");
    try {
        await navigator.clipboard.writeText(handle);
        showCustomAlert("Copied! ✓", `@${handle} copied to clipboard.`, true);
    } catch (e) {}
}

function viewDmUserProfileInfo() {
    openFriendProfileScreen();
}

function renderDmHeaderStatus() {
    const statusEl = document.getElementById("activeChatStatus");
    const dotEl = document.getElementById("activeChatOnlineDot");
    if (!statusEl || !currentChatUserMeta) return;

    const uHandle = escapeHtml(currentChatUserMeta.username || "@student");
    if (isFriendCurrentlyTyping) {
        statusEl.innerHTML = `${uHandle} • <span style="color:#10b981; font-weight:800;">typing...</span>`;
        if (dotEl) dotEl.style.background = "#10b981";
    } else if (currentChatUserMeta.isOnline) {
        statusEl.innerHTML = `${uHandle} • <span style="color:#10b981; font-weight:700;">Online</span>`;
        if (dotEl) dotEl.style.background = "#10b981";
    } else {
        const lastSeen = escapeHtml(currentChatUserMeta.lastSeenLabel || "recently");
        statusEl.innerHTML = `${uHandle} • <span style="color:#94a3b8;">Last seen ${lastSeen}</span>`;
        if (dotEl) dotEl.style.background = "#94a3b8";
    }
}

function handleLiveTypingInput() {
    if (!db || !auth?.currentUser || !currentChatUserId) return;
    const myUid = auth.currentUser.uid;
    const chatId = myUid < currentChatUserId ? `${myUid}_${currentChatUserId}` : `${currentChatUserId}_${myUid}`;

    db.collection("chats").doc(chatId).set({
        [`typing_${myUid}`]: true
    }, { merge: true }).catch(() => {});

    clearTimeout(typingTimeoutTimer);
    typingTimeoutTimer = setTimeout(() => {
        db.collection("chats").doc(chatId).set({
            [`typing_${myUid}`]: false
        }, { merge: true }).catch(() => {});
    }, 1500);
}

function loadMessagesFromFirestore(recipientId) {
    const msgContainer = document.getElementById("activeChatMessages");
    if (!msgContainer) return;

    if (activeMessagesUnsubscribe) {
        activeMessagesUnsubscribe();
        activeMessagesUnsubscribe = null;
    }

    const firstName = escapeHtml((currentChatUserMeta?.name || "Friend").split(" ")[0]);
    const emptyStateHTML = `
        <div class="dm-empty-state-wrap">
            <div class="dm-3d-bubbles-box">
                <div class="dm-bubble-big"><span></span><span></span><span></span></div>
                <div class="dm-bubble-small"><span></span><span></span><span></span></div>
            </div>
            <h3>No messages yet</h3>
            <p>Start a conversation with ${firstName}</p>
        </div>
    `;

    if (!db || !auth?.currentUser) {
        msgContainer.innerHTML = emptyStateHTML;
        return;
    }

    const myUid = auth.currentUser.uid;
    const chatId = myUid < recipientId ? `${myUid}_${recipientId}` : `${recipientId}_${myUid}`;

    activeMessagesUnsubscribe = db.collection("chats").doc(chatId).collection("messages")
        .onSnapshot({ includeMetadataChanges: true }, snapshot => {
            if (snapshot.empty) {
                msgContainer.innerHTML = emptyStateHTML;
                return;
            }

            const docs = snapshot.docs.slice().sort((a, b) => {
                const da = a.data();
                const dbData = b.data();
                const ta = da.timestampMs || da.createdAt?.toMillis?.() || 0;
                const tb = dbData.timestampMs || dbData.createdAt?.toMillis?.() || 0;
                return ta - tb;
            });

            msgContainer.innerHTML = "";
            const friendDp = escapeHtml(currentChatUserMeta?.avatar || "https://i.pravatar.cc/150?img=11");

            docs.forEach(doc => {
                const d = doc.data();
                const isMe = d.senderId === myUid;

                if (!isMe && !d.seen) {
                    doc.ref.update({ seen: true, delivered: true }).catch(() => {});
                }

                let tickIcon = '<i class="fa-solid fa-check" style="color:rgba(255,255,255,0.8); font-size:10px;"></i>';
                if (d.seen) {
                    tickIcon = '<i class="fa-solid fa-check-double" style="color:#ffffff; font-size:10.5px;"></i>';
                } else if (d.delivered || !doc.metadata.hasPendingWrites) {
                    tickIcon = '<i class="fa-solid fa-check-double" style="color:rgba(255,255,255,0.85); font-size:10px;"></i>';
                }

                const row = document.createElement("div");
                row.className = `msg-row-with-avatar ${isMe ? "right-user" : "left-friend"}`;

                if (isMe) {
                    row.innerHTML = `
                        <div class="clean-right-bubble" onclick="promptDeleteMessage('${doc.id}', '${chatId}')" style="cursor:pointer;" title="Tap to delete message">
                            <div>${escapeHtml(d.text || "")}</div>
                            <div class="bubble-meta-time">
                                <span>${escapeHtml(d.timeLabel || "Now")}</span>
                                ${tickIcon}
                            </div>
                        </div>
                    `;
                } else {
                    row.innerHTML = `
                        <img src="${friendDp}" class="msg-side-avatar dm-friend-side-dp" alt="DP" onclick="openFriendProfileScreen()" style="cursor:pointer;">
                        <div class="clean-left-bubble" onclick="promptDeleteMessage('${doc.id}', '${chatId}')" style="cursor:pointer;" title="Tap to delete message">
                            <div style="display:flex; justify-content:space-between; align-items:baseline; gap:12px;">
                                <span>${escapeHtml(d.text || "")}</span>
                                <span style="font-size:10px; color:#94a3b8; font-weight:500; white-space:nowrap;">${escapeHtml(d.timeLabel || "Now")}</span>
                            </div>
                        </div>
                    `;
                }
                msgContainer.appendChild(row);
            });
            msgContainer.scrollTop = msgContainer.scrollHeight;
        });
}

async function sendRealtimeMessage() {
    const input = document.getElementById("activeChatInput");
    const text = (input?.value || "").trim();
    if (!text || !currentChatUserId) return;

    if (blockedUsersMap[currentChatUserId]) {
        showCustomAlert("Blocked 🚫", "You have blocked this user. Unblock from the 3-dot menu to send messages.");
        return;
    }

    const nowMs = Date.now();
    const nowTime = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    input.value = "";

    if (currentChatUserMeta) {
        upsertRecentDmOnHome(
            currentChatUserMeta.uid,
            currentChatUserMeta.name,
            currentChatUserMeta.avatar,
            currentChatUserMeta.username,
            `You: ${text}`,
            nowTime,
            0
        );
    }

    if (!db || !auth?.currentUser) return;
    const myUid = auth.currentUser.uid;
    const chatId = myUid < currentChatUserId ? `${myUid}_${currentChatUserId}` : `${currentChatUserId}_${myUid}`;

    try {
        await db.collection("chats").doc(chatId).collection("messages").add({
            senderId: myUid,
            text: text,
            timeLabel: nowTime,
            timestampMs: nowMs,
            delivered: true,
            seen: false,
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });

        await db.collection("chats").doc(chatId).set({
            participants: [myUid, currentChatUserId],
            lastMessage: text,
            lastSenderId: myUid,
            lastSenderName: userName,
            lastSenderAvatar: userAvatarUrl || "https://i.pravatar.cc/150?img=11",
            lastSenderUsername: currentUsername || "@student",
            [`typing_${myUid}`]: false,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
            timeLabel: nowTime
        }, { merge: true });
    } catch (e) {
        console.error("Send DM error:", e);
    }
}

function upsertRecentDmOnHome(uid, name, avatar, username, lastMsg, timeStr, unreadCount = 0) {
    if (!uid || uid === "arjun_user_id") return;
    const cleanUn = (username || "").toLowerCase();
    const cleanNm = (name || "").toLowerCase();
    if (cleanUn === "@friend" || cleanUn === "@user" || cleanNm === "friend" || cleanNm === "user") return;

    const idx = recentDmUsers.findIndex(x => x.uid === uid);
    const prev = idx >= 0 ? recentDmUsers[idx] : {};
    const entry = {
        uid,
        name: name || prev.name || "Student",
        avatar: avatar || prev.avatar || "https://i.pravatar.cc/150?img=11",
        username: username || prev.username || "@student",
        lastMsg: lastMsg || prev.lastMsg || "Tap to chat",
        timeStr: timeStr || prev.timeStr || "Now",
        unread: typeof unreadCount === "number" ? unreadCount : (prev.unread || 0)
    };

    if (idx >= 0) recentDmUsers.splice(idx, 1);
    recentDmUsers.unshift(entry);
    localStorage.setItem("zorenoRecentDms", JSON.stringify(recentDmUsers.slice(0, 25)));
    renderSavedDmChatsOnHome();
}

// Home Screen par Sirf Full Name dikhega, @username nahi (29550.png Fix)
function renderSavedDmChatsOnHome() {
    const container = document.querySelector(".chats-container");
    if (!container) return;

    container.querySelectorAll(".dynamic-dm-item").forEach(el => el.remove());
    const pinnedItem = container.querySelector(".chat-list-item.pinned");

    recentDmUsers.slice().reverse().forEach(item => {
        const cleanUn = (item.username || "").toLowerCase();
        if (cleanUn === "@friend" || cleanUn === "@user") return;

        const div = document.createElement("div");
        div.className = "chat-list-item dynamic-dm-item";
        div.style.cursor = "pointer";
        div.onclick = () => openChatWithUser(item.uid, item.name, item.avatar, item.username);
        div.innerHTML = `
            <div class="chat-avatar">
                <img src="${escapeHtml(item.avatar)}" alt="${escapeHtml(item.name)}">
                <div class="online-dot"></div>
            </div>
            <div class="chat-info">
                <div class="chat-name-row">
                    <h4>${escapeHtml(item.name)}</h4>
                    <span class="chat-time">${escapeHtml(item.timeStr)}</span>
                </div>
                <div class="chat-msg-row">
                    <p>${escapeHtml(item.lastMsg)}</p>
                    ${item.unread > 0 ? `<span class="unread-count">${item.unread}</span>` : ""}
                </div>
            </div>
        `;
        if (pinnedItem) {
            pinnedItem.insertAdjacentElement("afterend", div);
        } else {
            container.prepend(div);
        }
    });
}

function listenIncomingRealtimeChats(myUid) {
    if (!db || !myUid) return;
    db.collection("chats")
        .where("participants", "array-contains", myUid)
        .onSnapshot(snap => {
            snap.forEach(async doc => {
                const d = doc.data();
                const otherUid = (d.participants || []).find(id => id !== myUid);
                if (!otherUid || !d.lastMessage) return;

                let friendName = d.lastSenderId !== myUid ? d.lastSenderName : null;
                let friendAvatar = d.lastSenderId !== myUid ? d.lastSenderAvatar : null;
                let friendUsername = d.lastSenderId !== myUid ? d.lastSenderUsername : null;

                try {
                    const uDoc = await db.collection("users").doc(otherUid).get();
                    if (!uDoc.exists) return;
                    const ud = uDoc.data();
                    friendName = ud.name || friendName;
                    friendAvatar = ud.photoURL || ud.avatarUrl || friendAvatar;
                    friendUsername = ud.username || friendUsername;
                } catch (e) {}

                if (!friendUsername || friendUsername === "@friend" || friendUsername === "@user") return;

                const isChatOpen = document.getElementById("activeChatScreen")?.style.display === "flex" && currentChatUserId === otherUid;
                const msgPreview = d.lastSenderId === myUid ? `You: ${d.lastMessage}` : d.lastMessage;
                upsertRecentDmOnHome(
                    otherUid,
                    friendName,
                    friendAvatar || "https://i.pravatar.cc/150?img=11",
                    friendUsername,
                    msgPreview,
                    d.timeLabel || "Now",
                    (d.lastSenderId !== myUid && !isChatOpen) ? 1 : 0
                );
            });
        });
}

function closeActiveDmChat() {
    closeFriendProfileScreen();
    if (activeFriendProfileUnsub) { activeFriendProfileUnsub(); activeFriendProfileUnsub = null; }
    if (activeChatMetaUnsub) { activeChatMetaUnsub(); activeChatMetaUnsub = null; }
    if (activeMessagesUnsubscribe) { activeMessagesUnsubscribe(); activeMessagesUnsubscribe = null; }
    const chatWin = document.getElementById("activeChatScreen");
    if (chatWin) chatWin.style.setProperty("display", "none", "important");
    showChatsHome();
}

function toggleDmHeaderMenu(forceState) {
    const menu = document.getElementById("dmHeaderDropdownMenu");
    if (!menu) return;
    if (typeof forceState === "boolean") {
        menu.style.display = forceState ? "block" : "none";
    } else {
        menu.style.display = menu.style.display === "block" ? "none" : "block";
    }
}

function toggleBlockChatUser() {
    toggleDmHeaderMenu(false);
    if (!currentChatUserId) return;
    const isBlocked = !!blockedUsersMap[currentChatUserId];
    if (isBlocked) {
        delete blockedUsersMap[currentChatUserId];
        showCustomAlert("User Unblocked", "You can now send messages to this user.", true);
    } else {
        blockedUsersMap[currentChatUserId] = true;
        showCustomAlert("User Blocked 🚫", "You will no longer receive or send messages in this chat.");
    }
    localStorage.setItem("zorenoBlockedUsers", JSON.stringify(blockedUsersMap));
    updateBlockMenuButtonUI();
}

function updateBlockMenuButtonUI() {
    const isBlocked = currentChatUserId && !!blockedUsersMap[currentChatUserId];
    const html = isBlocked
        ? '<i class="fa-solid fa-rotate-left"></i> Unblock User'
        : '<i class="fa-solid fa-ban"></i> Block User';
    const btn1 = document.getElementById("dmBlockMenuBtn");
    const btn2 = document.getElementById("fpBlockMenuBtn");
    if (btn1) btn1.innerHTML = html;
    if (btn2) btn2.innerHTML = html;
}

async function clearCurrentDmChat() {
    toggleDmHeaderMenu(false);
    if (!db || !auth?.currentUser || !currentChatUserId) return;
    const myUid = auth.currentUser.uid;
    const chatId = myUid < currentChatUserId ? `${myUid}_${currentChatUserId}` : `${currentChatUserId}_${myUid}`;
    try {
        const snap = await db.collection("chats").doc(chatId).collection("messages").get();
        const batch = db.batch();
        snap.forEach(doc => batch.delete(doc.ref));
        await batch.commit();
    } catch (e) {
        console.error("Clear DM error:", e);
    }
}

function openReportModal() {
    toggleDmHeaderMenu(false);
    document.getElementById("userReportModal").style.display = "flex";
}

async function submitUserReport() {
    const reason = document.getElementById("userReportReason").value.trim();
    if (!reason || !currentChatUserId) return;
    try {
        if (db && auth?.currentUser) {
            await db.collection("reports").add({
                reporterUid: auth.currentUser.uid,
                reportedUserId: currentChatUserId,
                reason: reason,
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            });
        }
        document.getElementById("userReportReason").value = "";
        document.getElementById("userReportModal").style.display = "none";
        showCustomAlert("Report Submitted", "Our moderation team will review this user within 24 hours.", true);
    } catch (e) {
        showCustomAlert("Error", e.message);
    }
}

// ================= WHATSAPP-STYLE SINGLE MESSAGE DELETE (BOTH DM & AI CHAT) =================
function promptDeleteMessage(msgId, chatId) {
    aiMsgIndexToDelete = null;
    msgToDeleteId = msgId;
    msgToDeleteChatId = chatId;
    document.getElementById("deleteMsgModal").style.display = "flex";
}

function promptDeleteSingleAiMessage(idx) {
    msgToDeleteId = null;
    msgToDeleteChatId = null;
    aiMsgIndexToDelete = idx;
    document.getElementById("deleteMsgModal").style.display = "flex";
}

async function confirmDeleteMessage() {
    // 1. If deleting a single AI Chat message
    if (aiMsgIndexToDelete !== null && aiChatMessagesList[aiMsgIndexToDelete]) {
        const removed = aiChatMessagesList.splice(aiMsgIndexToDelete, 1)[0];
        try { localStorage.setItem("zorenoAiChatStream", JSON.stringify(aiChatMessagesList)); } catch (e) {}
        renderAiChatStream();

        if (db && auth?.currentUser && removed?.timestampMs) {
            try {
                const snap = await db.collection("users").doc(auth.currentUser.uid)
                    .collection("chats").where("timestampMs", "==", removed.timestampMs).get();
                snap.forEach(d => d.ref.delete());
            } catch (e) {}
        }
        document.getElementById("deleteMsgModal").style.display = "none";
        aiMsgIndexToDelete = null;
        return;
    }

    // 2. If deleting a single Friend DM message
    if (!msgToDeleteId || !msgToDeleteChatId || !db) return;
    try {
        await db.collection("chats").doc(msgToDeleteChatId).collection("messages").doc(msgToDeleteId).delete();
        document.getElementById("deleteMsgModal").style.display = "none";
        msgToDeleteId = null;
        msgToDeleteChatId = null;
    } catch (e) {
        console.error("Delete msg error:", e);
    }
}

function showCallComingSoon() {
    showCustomAlert("Coming Soon 📞", "Voice & Video calling feature will be available in v1.1!", true);
}

function showAttachmentComingSoon() {
    showCustomAlert("Coming Soon ✨", "Image & PDF upload will be available in the next update!", true);
}

// Image / File Upload Disabled for Now (As Requested to Save Billing)
function openImagePicker() {
    showAttachmentComingSoon();
}

function openFileOrPdfPicker() {
    showAttachmentComingSoon();
}

function handleMultipleImages(event) {
    if (event?.target) event.target.value = "";
    showAttachmentComingSoon();
}

function insertQuickEmoji() {
    const inp = document.getElementById("activeChatInput");
    if (inp) { inp.value += "😊"; inp.focus(); }
}

function insertAiQuickEmoji() {
    const inp = document.getElementById("userInput");
    if (inp) { inp.value += "😊"; inp.focus(); }
}

// ================= ZORENO AI CHAT (ALL LANGUAGES + HEALTH BANNER + SINGLE DELETE) =================
function getLocalDailyAiLimit() {
    const today = new Date().toISOString().slice(0, 10);
    if (localStorage.getItem("zorenoAiLimitDate") !== today) {
        localStorage.setItem("zorenoAiLimitDate", today);
        localStorage.setItem("zorenoAiDailyLimit", "10");
    }
    return parseInt(localStorage.getItem("zorenoAiDailyLimit") || "10");
}

function getLocalDailyAiCount() {
    const today = new Date().toISOString().slice(0, 10);
    if (localStorage.getItem("zorenoAiDate") !== today) {
        localStorage.setItem("zorenoAiDate", today);
        localStorage.setItem("zorenoAiCount", "0");
    }
    return parseInt(localStorage.getItem("zorenoAiCount") || "0");
}

function incrementLocalDailyAiCount() {
    const c = getLocalDailyAiCount() + 1;
    localStorage.setItem("zorenoAiCount", String(c));
    return c;
}

function addBonusAiChats(extraChats = 3) {
    const currentLimit = getLocalDailyAiLimit();
    const newLimit = currentLimit + extraChats;
    localStorage.setItem("zorenoAiDailyLimit", String(newLimit));
    return newLimit;
}

function formatMarkdown(t) {
    if (!t) return "";
    let lines = String(t).replace(/\r\n/g, "\n").split("\n");
    let htmlParts = [];
    let inList = false;

    for (let rawLine of lines) {
        let line = rawLine.trim();
        if (!line) continue;

        line = escapeHtml(line).replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

        if (/^[\*\-•]\s+(.*)/.test(line)) {
            let itemText = line.replace(/^[\*\-•]\s+/, "");
            if (!inList) {
                htmlParts.push('<ul class="ai-compact-list">');
                inList = true;
            }
            htmlParts.push(`<li>${itemText}</li>`);
        } else {
            if (inList) {
                htmlParts.push("</ul>");
                inList = false;
            }
            line = line.replace(/^#{1,3}\s+/, "");
            htmlParts.push(`<p>${line}</p>`);
        }
    }
    if (inList) htmlParts.push("</ul>");
    return htmlParts.join("");
}

function getHealthDisclaimerHTML(userQuery) {
    if (typeof isHealthOrMedicalQuery === "function" && isHealthOrMedicalQuery(userQuery)) {
        return `
            <div class="ai-health-disclaimer">
                <i class="fa-solid fa-circle-info"></i>
                <span>Information only • Consult a medical professional for health advice.</span>
            </div>
        `;
    }
    return "";
}

function getSmartAffiliateCard(userQuery) {
    const q = (userQuery || "").toLowerCase();
    if (/pen|pencil|stationary|stationery|schneider|luxor|write/i.test(q)) {
        return `
            <div class="ai-affiliate-card" onclick="event.stopPropagation(); window.open('https://link.amazon/B0ji6uiuO', '_blank')">
                <span class="aff-badge">✦ Recommended Study Gear</span>
                <div class="aff-body">
                    <div>
                        <h5>Luxor Schneider LX Max Pen</h5>
                        <p>Best for fast exam writing & smooth notes</p>
                    </div>
                    <button type="button">Buy ↗</button>
                </div>
            </div>
        `;
    }
    return "";
}

function renderAiChatStream() {
    const chatMessages = document.getElementById("chatMessages");
    if (!chatMessages) return;

    const nowTime = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    let html = `
        <div class="msg-row-with-avatar">
            <img src="logo.png" class="ai-logo-avatar" onerror="this.src='https://i.pravatar.cc/150?img=12'" alt="Zoreno">
            <div class="clean-left-bubble">
                <div style="display:flex; justify-content:space-between; align-items:center; gap:14px; margin-bottom:2px;">
                    <strong>Hello!</strong>
                    <span style="font-size:10px; color:#94a3b8; font-weight:500;">${nowTime}</span>
                </div>
                <p style="margin:0;">How can I help you today?</p>
            </div>
        </div>
    `;

    aiChatMessagesList.forEach((pair, idx) => {
        const tLabel = escapeHtml(pair.timeLabel || nowTime);
        if (pair.user) {
            html += `
                <div class="msg-row-with-avatar right-user">
                    <div class="clean-right-bubble" onclick="promptDeleteSingleAiMessage(${idx})" style="cursor:pointer;" title="Tap to delete">
                        <div>${escapeHtml(pair.user)}</div>
                        <div class="bubble-meta-time">
                            <span>${tLabel}</span>
                            <i class="fa-solid fa-check-double"></i>
                        </div>
                    </div>
                </div>
            `;
        }
        if (pair.bot) {
            html += `
                <div class="msg-row-with-avatar">
                    <img src="logo.png" class="ai-logo-avatar" onerror="this.src='https://i.pravatar.cc/150?img=12'" alt="Zoreno">
                    <div class="clean-left-bubble" onclick="promptDeleteSingleAiMessage(${idx})" style="cursor:pointer;" title="Tap to delete">
                        ${getHealthDisclaimerHTML(pair.user || "")}
                        <div class="ai-formatted-body">${formatMarkdown(pair.bot)}</div>
                        ${getSmartAffiliateCard(pair.user || "")}
                        <div class="bubble-meta-time"><span>${tLabel}</span></div>
                    </div>
                </div>
            `;
        }
    });

    chatMessages.innerHTML = html;

    const lastPair = aiChatMessagesList[aiChatMessagesList.length - 1];
    const homePreview = document.getElementById("zorenoHomeLastPreview");
    if (homePreview && lastPair?.bot) {
        homePreview.textContent = lastPair.bot.replace(/[*#_]/g, "").slice(0, 48) + "...";
    }
    scrollToBottom();
}

function openZorenoAIChat() {
    hideAllScreens();
    const chatScreen = document.getElementById("chatScreen");
    const inputArea = document.getElementById("inputAreaContainer");
    const bottomNav = document.getElementById("bottomNav");

    if (bottomNav) bottomNav.style.setProperty("display", "none", "important");
    if (chatScreen) chatScreen.style.setProperty("display", "flex", "important");
    if (inputArea) inputArea.style.setProperty("display", "flex", "important");

    renderAiChatStream();
}

async function sendMessage() {
    const input = document.getElementById("userInput");
    const chatMessages = document.getElementById("chatMessages");
    const sendBtn = document.getElementById("sendBtn");
    if (!input || !chatMessages) return;

    let text = input.value.trim();
    if (!text) return;

    const usedToday = getLocalDailyAiCount();
    const todayLimit = userTier === 2 ? 90 : userTier === 1 ? 50 : getLocalDailyAiLimit();

    if (usedToday >= todayLimit) {
        if (userTier === 0) {
            openRewardedAdModal();
        } else {
            showCustomAlert("Daily Fair-Use Limit Reached", `You have used your ${todayLimit} messages for today.`);
        }
        return;
    }

    if (userTier === 0 && text.length > 350) text = text.slice(0, 350);

    const nowTime = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    const msgIdx = aiChatMessagesList.length;
    input.value = "";
    if (sendBtn) sendBtn.disabled = true;

    chatMessages.insertAdjacentHTML("beforeend", `
        <div class="msg-row-with-avatar right-user">
            <div class="clean-right-bubble" onclick="promptDeleteSingleAiMessage(${msgIdx})" style="cursor:pointer;">
                <div>${escapeHtml(text)}</div>
                <div class="bubble-meta-time">
                    <span>${nowTime}</span>
                    <i class="fa-solid fa-check-double"></i>
                </div>
            </div>
        </div>
    `);

    const guardrailCheck = checkQueryGuardrails(text);
    if (guardrailCheck.blocked) {
        chatMessages.insertAdjacentHTML("beforeend", `
            <div class="msg-row-with-avatar">
                <img src="logo.png" class="ai-logo-avatar" onerror="this.src='https://i.pravatar.cc/150?img=12'" alt="Zoreno">
                <div class="clean-left-bubble" onclick="promptDeleteSingleAiMessage(${msgIdx})" style="cursor:pointer;">
                    <div class="ai-formatted-body">${formatMarkdown(guardrailCheck.reply)}</div>
                    <div class="bubble-meta-time"><span>${nowTime}</span></div>
                </div>
            </div>
        `);
        saveChatToFirebase(text, guardrailCheck.reply, nowTime);
        if (sendBtn) sendBtn.disabled = false;
        scrollToBottom();
        return;
    }

    const thinkingId = "zorenoThinking_" + Date.now();
    chatMessages.insertAdjacentHTML("beforeend", `
        <div class="msg-row-with-avatar" id="${thinkingId}">
            <img src="logo.png" class="ai-logo-avatar" onerror="this.src='https://i.pravatar.cc/150?img=12'" alt="Zoreno">
            <div class="clean-left-bubble" style="padding:10px 16px!important; border-radius:22px!important;">
                <div style="display:flex; align-items:center; gap:10px; color:#7c3aed; font-weight:600; font-size:13.5px;">
                    <span>Zoreno is thinking</span>
                    <div class="thinking-dots"><span></span><span></span><span></span></div>
                </div>
            </div>
        </div>
    `);
    scrollToBottom();

    try {
        const isFreeUser = userTier === 0;
        const maxTokens = isFreeUser ? 240 : 600;

        // पिछली 10 बातचीत को सीधे स्क्रीन की चैट लिस्ट से उठाएं ताकि एआई टॉपिक कभी न भूले
        const recentHistory = [];
        aiChatMessagesList.slice(-10).forEach(pair => {
            if (pair.user) recentHistory.push({ role: "user", parts: [{ text: pair.user }] });
            if (pair.bot) recentHistory.push({ role: "model", parts: [{ text: pair.bot }] });
        });

        const payloadContents = [
            ...recentHistory,
            {
                role: "user",
                parts: [{
                    text: `${SYSTEM_INSTRUCTION}\n\n[Continue the conversation naturally from the previous messages above. Reply in the exact language of the user's current message.]\nUser: ${text}`
                }]
            }
        ];

        const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${ZORENO_AI_MODEL}:generateContent?key=${GEMINI_API_KEY}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                contents: payloadContents,
                generationConfig: { maxOutputTokens: maxTokens, temperature: 0.55 },
                safetySettings: [
                    { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_ONLY_HIGH" },
                    { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_ONLY_HIGH" },
                    { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_ONLY_HIGH" },
                    { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_ONLY_HIGH" }
                ]
            })
        });

        const data = await response.json();
        if (data.error) throw new Error(data.error.message);

        const replyText = data?.candidates?.[0]?.content?.parts?.[0]?.text || "⚠️ I cannot answer this request due to safety policies.";
        incrementLocalDailyAiCount();

        const thinkingRow = document.getElementById(thinkingId);
        if (thinkingRow) {
            thinkingRow.className = "msg-row-with-avatar";
            thinkingRow.innerHTML = `
                <img src="logo.png" class="ai-logo-avatar" onerror="this.src='https://i.pravatar.cc/150?img=12'" alt="Zoreno">
                <div class="clean-left-bubble" onclick="promptDeleteSingleAiMessage(${msgIdx})" style="cursor:pointer;" title="Tap to delete">
                    ${getHealthDisclaimerHTML(text)}
                    <div class="ai-formatted-body">${formatMarkdown(replyText)}</div>
                    ${getSmartAffiliateCard(text)}
                    <div class="bubble-meta-time"><span>${nowTime}</span></div>
                </div>
            `;
        }
        await saveChatToFirebase(text, replyText, nowTime);
    } catch (err) {
        const thinkingRow = document.getElementById(thinkingId);
        if (thinkingRow) {
            thinkingRow.innerHTML = `
                <img src="logo.png" class="ai-logo-avatar" onerror="this.src='https://i.pravatar.cc/150?img=12'" alt="Zoreno">
                <div class="clean-left-bubble">
                    <span style="color:#ef4444; font-weight:600;">⚠️ Error: ${escapeHtml(err.message)}</span>
                </div>
            `;
        }
    } finally {
        if (sendBtn) sendBtn.disabled = false;
        scrollToBottom();
    }
}


async function saveChatToFirebase(userText, botText, timeLabel) {
    const tLabel = timeLabel || new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    const item = { user: userText || "", bot: botText || "", timeLabel: tLabel, timestampMs: Date.now() };

    aiChatMessagesList.push(item);
    if (aiChatMessagesList.length > 40) aiChatMessagesList = aiChatMessagesList.slice(-40);
    try { localStorage.setItem("zorenoAiChatStream", JSON.stringify(aiChatMessagesList)); } catch (e) {}

    const homePreview = document.getElementById("zorenoHomeLastPreview");
    if (homePreview && botText) {
        homePreview.textContent = botText.replace(/[*#_]/g, "").slice(0, 48) + "...";
    }

    if (!db || !auth?.currentUser) return;
    try {
        await db.collection("users").doc(auth.currentUser.uid).collection("chats").add({
            user: userText || "",
            bot: botText || "",
            timeLabel: tLabel,
            timestampMs: item.timestampMs,
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    } catch (e) {}
}

async function loadUserChatsFromFirebase() {
    if (!db || !auth?.currentUser) return;
    try {
        const snap = await db.collection("users").doc(auth.currentUser.uid)
            .collection("chats").orderBy("createdAt", "asc").limitToLast(40).get();
        if (!snap.empty) {
            aiChatMessagesList = [];
            snap.forEach(doc => {
                const d = doc.data();
                aiChatMessagesList.push({
                    user: d.user || "",
                    bot: d.bot || "",
                    timeLabel: d.timeLabel || "",
                    timestampMs: d.timestampMs || 0
                });
            });
            try { localStorage.setItem("zorenoAiChatStream", JSON.stringify(aiChatMessagesList)); } catch (e) {}
            activeConversationHistory = [];
            aiChatMessagesList.slice(-4).forEach(p => {
                if (p.user) activeConversationHistory.push({ role: "user", parts: [{ text: p.user }] });
                if (p.bot) activeConversationHistory.push({ role: "model", parts: [{ text: p.bot }] });
            });
            const lastPair = aiChatMessagesList[aiChatMessagesList.length - 1];
            const homePreview = document.getElementById("zorenoHomeLastPreview");
            if (homePreview && lastPair?.bot) {
                homePreview.textContent = lastPair.bot.replace(/[*#_]/g, "").slice(0, 48) + "...";
            }
        }
    } catch (e) {}
}

async function clearAllChatHistory() {
    toggleAiHeaderMenu(false);
    aiChatMessagesList = [];
    activeConversationHistory = [];
    localStorage.removeItem("zorenoAiChatStream");
    renderAiChatStream();

    const homePreview = document.getElementById("zorenoHomeLastPreview");
    if (homePreview) homePreview.textContent = "Tap to start chatting with your AI partner";

    if (db && auth?.currentUser) {
        try {
            const snap = await db.collection("users").doc(auth.currentUser.uid).collection("chats").get();
            const batch = db.batch();
            snap.forEach(d => batch.delete(d.ref));
            await batch.commit();
        } catch (e) {}
    }
    showCustomAlert("Chat Cleared 🗑️", "Your AI conversation has been cleared.", true);
}

function clearCurrentAiChat() {
    clearAllChatHistory();
}

function toggleAiHeaderMenu(forceState) {
    const menu = document.getElementById("aiHeaderDropdownMenu");
    if (!menu) return;
    if (typeof forceState === "boolean") {
        menu.style.display = forceState ? "block" : "none";
    } else {
        menu.style.display = menu.style.display === "block" ? "none" : "block";
    }
}

function openAiFeedbackModal() {
    toggleAiHeaderMenu(false);
    document.getElementById("aiFeedbackModal").style.display = "flex";
}

async function submitAiFeedback() {
    const text = document.getElementById("aiFeedbackText").value.trim();
    if (!text) return;
    try {
        if (db && auth?.currentUser) {
            await db.collection("feedbacks").add({
                uid: auth.currentUser.uid,
                email: auth.currentUser.email || "Anonymous",
                feedback: text,
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            });
        }
        document.getElementById("aiFeedbackText").value = "";
        document.getElementById("aiFeedbackModal").style.display = "none";
        showCustomAlert("Thank You! 🎉", "Your feedback has been sent successfully.", true);
    } catch (e) {
        showCustomAlert("Error", e.message);
    }
}

function scrollToBottom() {
    const container = document.getElementById("chatMessages");
    if (container) container.scrollTo({ top: container.scrollHeight, behavior: "smooth" });
}

// ================= ADMOB (APP) & ADSENSE (WEB) REWARDED AD (+3 CHATS) =================
function openRewardedAdModal() {
    const modal = document.getElementById("rewardedAdModal");
    if (modal) modal.style.display = "flex";
}

function closeRewardedAdModal() {
    const modal = document.getElementById("rewardedAdModal");
    if (modal) modal.style.display = "none";
}

// ================= STRICT ADMOB REWARDED AD TRIGGER (ONLY ON CLICK) =================
function triggerRewardedAdForChats() {
    const btn = document.getElementById("watchRewardedAdBtn");
    const btnText = document.getElementById("watchAdBtnText");

    // 1. Agar Android App (.aab / .apk) ke andar hai -> Sirf Asli AdMob Ad chalao
    if (window.AndroidAdMob && typeof window.AndroidAdMob.showRewardedAd === "function") {
        if (btn) btn.disabled = true;
        if (btnText) btnText.innerText = "Loading Ad...";

        window.AndroidAdMob.showRewardedAd(ADS_CONFIG.admobRewardedUnitId);

        // Agar 8 second tak network ki wajah se ad load na ho toh button wapas chalu kar do
        setTimeout(() => {
            if (btn) btn.disabled = false;
            if (btnText) btnText.innerText = "Watch Ad";
        }, 8000);
        return;
    }

    // 2. Agar Website (Browser) par hai -> AdSense / 5s Timer Fallback
    if (btn) btn.disabled = true;
    let sec = 5;
    if (btnText) btnText.innerText = `Loading Ad (${sec}s)...`;

    try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch (e) {}

    const adTimer = setInterval(() => {
        sec--;
        if (sec > 0) {
            if (btnText) btnText.innerText = `Watching Ad (${sec}s)...`;
        } else {
            clearInterval(adTimer);
            if (btn) btn.disabled = false;
            if (btnText) btnText.innerText = "Watch Ad";
            onAdMobRewardGranted();
        }
    }, 1000);
}

window.onAdMobRewardGranted = function () {
    const btn = document.getElementById("watchRewardedAdBtn");
    const btnText = document.getElementById("watchAdBtnText");
    if (btn) btn.disabled = false;
    if (btnText) btnText.innerText = "Watch Ad";

    const newLimit = addBonusAiChats(3);
    const used = getLocalDailyAiCount();
    const left = Math.max(0, newLimit - used);

    closeRewardedAdModal();
    showCustomAlert("3 Chats Unlocked! 🎉", `You now have ${left} free chats available to continue learning.`, true);
};


// ================= LIVE WEB SEARCH, FOCUS SPRINT & FOCUS MUSIC =================
function openLiveGoogleSearch(initialQuery = "") {
    hideAllScreens();
    const searchScreen = document.getElementById("webSearchScreen");
    if (searchScreen) searchScreen.style.setProperty("display", "flex", "important");
    const inp = document.getElementById("liveGoogleInput");
    if (inp) {
        inp.value = initialQuery || "";
        if (initialQuery) runLiveGoogleSearch();
        else inp.focus();
    }
}

function closeLiveGoogleSearch() { goHome(); }
function clearLiveSearch() {
    const inp = document.getElementById("liveGoogleInput");
    if (inp) { inp.value = ""; inp.focus(); }
}
function handleLiveGoogleEnter(e) {
    if (e.key === "Enter") { e.preventDefault(); runLiveGoogleSearch(); }
}

async function runLiveGoogleSearch() {
    let query = document.getElementById("liveGoogleInput")?.value.trim();
    const resultsArea = document.getElementById("liveSearchResultsArea");
    if (!query || !resultsArea) return;

    currentSearchQuery = query;
    currentSearchOffset = 0;
    hasMoreSearchResults = true;
    resultsArea.innerHTML = `<div style="text-align:center;padding:30px;color:#7c3aed;"><i class="fa-solid fa-spinner fa-spin" style="font-size:24px;"></i><p style="margin-top:10px;font-weight:700;font-size:13px;">Searching live web for "${escapeHtml(query)}"...</p></div>`;
    resultsArea.innerHTML = "";
    await fetchMoreSearchResults();
}

async function fetchMoreSearchResults() {
    if (isSearchLoading || !hasMoreSearchResults) return;
    isSearchLoading = true;
    const resultsArea = document.getElementById("liveSearchResultsArea");

    try {
        const apiUrl = `https://en.wikipedia.org/w/api.php?action=query&format=json&origin=*&generator=search&gsrsearch=${encodeURIComponent(currentSearchQuery)}&gsrlimit=8&gsroffset=${currentSearchOffset}&prop=extracts|pageimages&exintro=1&explaintext=1&exsentences=2&piprop=thumbnail&pithumbsize=300`;
        const res = await fetch(apiUrl);
        const data = await res.json();
        const pages = data?.query?.pages ? Object.values(data.query.pages) : [];

        if (pages.length === 0) {
            hasMoreSearchResults = false;
            isSearchLoading = false;
            return;
        }
        currentSearchOffset += 8;

        pages.forEach(p => {
            const card = document.createElement("div");
            card.className = "web-result-item";
            const itemImg = p.thumbnail ? p.thumbnail.source : null;
            const wikiLink = "https://en.wikipedia.org/wiki/" + encodeURIComponent(p.title);
            card.innerHTML = `
                <div class="res-source-row">
                    <img src="https://www.google.com/s2/favicons?domain=wikipedia.org" class="res-favicon" alt="icon">
                    <span>Wikipedia • en.wikipedia.org</span>
                </div>
                <div style="display:flex;justify-content:space-between;gap:10px;">
                    <div style="flex:1;">
                        <a href="${wikiLink}" target="_blank" class="res-title">${escapeHtml(p.title)}</a>
                        <p class="res-snippet">${escapeHtml(p.extract || "Verified details and facts.")}</p>
                    </div>
                    ${itemImg ? `<img src="${itemImg}" style="width:70px;height:50px;border-radius:10px;object-fit:cover;margin-top:2px;">` : ""}
                </div>
            `;
            resultsArea.appendChild(card);
        });
    } catch (e) {} finally {
        isSearchLoading = false;
    }
}

let sprintDurationMinutes = parseInt(localStorage.getItem("sprintSelectedDuration") || "20");
let sprintInterval = null;

function selectSprintPreset(mins, btnEl) {
    sprintDurationMinutes = mins;
    localStorage.setItem("sprintSelectedDuration", String(mins));
    document.querySelectorAll(".preset-pill-btn").forEach(b => b.classList.remove("active"));
    if (btnEl) btnEl.classList.add("active");
    resetSprintState();
}

function toggleSprintTimer() {
    if (localStorage.getItem("sprintIsActive") === "true") pauseSprintState();
    else startSprintState();
}

function startSprintState() {
    const now = Date.now();
    let remainingMs = parseInt(localStorage.getItem("sprintRemainingMs") || "0");
    if (!remainingMs || remainingMs <= 0) {
        remainingMs = sprintDurationMinutes * 60 * 1000;
        localStorage.setItem("sprintTotalDurationMs", String(remainingMs));
    }
    localStorage.setItem("sprintTargetTimestamp", String(now + remainingMs));
    localStorage.setItem("sprintIsActive", "true");
    localStorage.removeItem("sprintRemainingMs");

    setSprintUIRunning(true);
    if (sprintInterval) clearInterval(sprintInterval);
    sprintInterval = setInterval(tickSprint, 500);
}

function pauseSprintState() {
    const targetTime = parseInt(localStorage.getItem("sprintTargetTimestamp") || "0");
    localStorage.setItem("sprintRemainingMs", String(Math.max(0, targetTime - Date.now())));
    localStorage.setItem("sprintIsActive", "false");
    localStorage.removeItem("sprintTargetTimestamp");
    clearInterval(sprintInterval);
    sprintInterval = null;
    setSprintUIRunning(false);
}

function resetSprintState() {
    if (sprintInterval) clearInterval(sprintInterval);
    sprintInterval = null;
    localStorage.removeItem("sprintTargetTimestamp");
    localStorage.removeItem("sprintRemainingMs");
    localStorage.removeItem("sprintTotalDurationMs");
    localStorage.setItem("sprintIsActive", "false");
    setSprintUIRunning(false);

    const timerText = document.getElementById("sprintTimerText");
    if (timerText) timerText.innerText = `${String(sprintDurationMinutes).padStart(2, "0")}:00`;
    const progressFill = document.getElementById("sprintProgressFill");
    const rabbit = document.getElementById("sprintRabbit");
    if (progressFill) progressFill.style.width = "0%";
    if (rabbit) { rabbit.style.left = "0%"; rabbit.classList.remove("hopping"); }
}

function tickSprint() {
    const targetTime = parseInt(localStorage.getItem("sprintTargetTimestamp") || "0");
    const totalMs = parseInt(localStorage.getItem("sprintTotalDurationMs") || String(sprintDurationMinutes * 60 * 1000));
    const remainingMs = targetTime - Date.now();

    if (remainingMs <= 0) {
        resetSprintState();
        showCustomAlert("Sprint Completed! 🏆", "Great job staying focused!", true);
        return;
    }

    const remainingSecs = Math.ceil(remainingMs / 1000);
    const timerText = document.getElementById("sprintTimerText");
    if (timerText) timerText.innerText = `${String(Math.floor(remainingSecs / 60)).padStart(2, "0")}:${String(remainingSecs % 60).padStart(2, "0")}`;

    const progressPercent = Math.min(100, Math.max(0, ((totalMs - remainingMs) / totalMs) * 100));
    const progressFill = document.getElementById("sprintProgressFill");
    const rabbit = document.getElementById("sprintRabbit");
    if (progressFill) progressFill.style.width = `${progressPercent}%`;
    if (rabbit) rabbit.style.left = `${Math.min(94, progressPercent)}%`;
}

function setSprintUIRunning(isRunning) {
    const pill = document.getElementById("sprintControlPill");
    const btnLabel = document.getElementById("sprintBtnLabel");
    const btnIcon = document.getElementById("sprintPlayIcon");
    const rabbit = document.getElementById("sprintRabbit");

    if (isRunning) {
        pill?.classList.add("running");
        if (btnLabel) btnLabel.innerText = "Pause";
        if (btnIcon) btnIcon.className = "fa-solid fa-pause";
        rabbit?.classList.add("hopping");
    } else {
        pill?.classList.remove("running");
        if (btnLabel) btnLabel.innerText = "Go";
        if (btnIcon) btnIcon.className = "fa-solid fa-play";
        rabbit?.classList.remove("hopping");
    }
}

const FOCUS_TRACKS = [
    { title: "Rain Storm", icon: "fa-cloud-showers-heavy", file: "sounds/rain.mp3", cover: "https://images.unsplash.com/photo-1519692933481-e162a57d6721?w=300" },
    { title: "Deep Lo-Fi", icon: "fa-music", file: "sounds/lofi.mp3", cover: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=300" },
    { title: "Forest Birds", icon: "fa-dove", file: "sounds/birds.mp3", cover: "https://images.unsplash.com/photo-1448375240586-882707db888b?w=300" },
    { title: "Ocean Waves", icon: "fa-water", file: "sounds/ocean.mp3", cover: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=300" },
    { title: "Cafe Ambient", icon: "fa-mug-saucer", file: "sounds/cafe.mp3", cover: "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=300" },
    { title: "Night Campfire", icon: "fa-fire", file: "sounds/campfire.mp3", cover: "https://images.unsplash.com/photo-1510312305653-8ed496efae75?w=300" },
    { title: "White Noise", icon: "fa-wind", file: "sounds/whitenoise.mp3", cover: "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=300" },
    { title: "Clock Ticking", icon: "fa-clock", file: "sounds/clock.mp3", cover: "https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=300" },
    { title: "Nature Forest", icon: "fa-leaf", file: "sounds/forest.mp3", cover: "https://images.unsplash.com/photo-1473448912268-2022ce9509d8?w=300" },
    { title: "Binaural Beats", icon: "fa-tower-broadcast", file: "sounds/binaural.mp3", cover: "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=300" }
];

let currentTrackIndex = 0;
let focusAudio = new Audio();
focusAudio.loop = true;
let isMusicPlaying = false;

function selectMusicTrack(index) {
    currentTrackIndex = index;
    const track = FOCUS_TRACKS[index];
    const titleEl = document.getElementById("currentTrackTitle");
    const coverEl = document.getElementById("currentTrackCover");
    if (titleEl) titleEl.innerText = track.title;
    if (coverEl) coverEl.src = track.cover;

    document.querySelectorAll(".sound-card-pill").forEach((pill, i) => {
        const actionBox = pill.querySelector(".sound-card-action-box");
        if (i === index) {
            pill.classList.add("active");
            if (actionBox) actionBox.innerHTML = `<div class="mini-playing-waves"><span></span><span></span><span></span></div>`;
        } else {
            pill.classList.remove("active");
            if (actionBox) actionBox.innerHTML = `<i class="fa-solid fa-play"></i>`;
        }
    });

    focusAudio.src = track.file;
    focusAudio.currentTime = 0;
    playFocusMusic();
}

function playFocusMusic() {
    focusAudio.play().then(() => { isMusicPlaying = true; updatePlayerUIState(true); })
              .catch(() => { isMusicPlaying = true; updatePlayerUIState(true); });
}

function pauseFocusMusic() {
    focusAudio.pause();
    isMusicPlaying = false;
    updatePlayerUIState(false);
}

function toggleFocusMusicPlay() {
    if (isMusicPlaying) pauseFocusMusic();
    else {
        if (!focusAudio.src) selectMusicTrack(currentTrackIndex);
        else playFocusMusic();
    }
}

function playNextTrack() {
    currentTrackIndex = (currentTrackIndex + 1) % FOCUS_TRACKS.length;
    selectMusicTrack(currentTrackIndex);
}

function playPreviousTrack() {
    currentTrackIndex = (currentTrackIndex - 1 + FOCUS_TRACKS.length) % FOCUS_TRACKS.length;
    selectMusicTrack(currentTrackIndex);
}

function updatePlayerUIState(playing) {
    const playIcon = document.getElementById("musicPlayIcon");
    const visualizer = document.getElementById("musicWaveVisualizer");
    if (playing) {
        if (playIcon) playIcon.className = "fa-solid fa-pause";
        visualizer?.classList.add("playing");
    } else {
        if (playIcon) playIcon.className = "fa-solid fa-play";
        visualizer?.classList.remove("playing");
    }
}

focusAudio.ontimeupdate = () => {
    const current = focusAudio.currentTime || 0;
    const duration = focusAudio.duration || 30;
    const elapsedEl = document.getElementById("musicTimeElapsed");
    const durEl = document.getElementById("musicTimeDuration");
    if (elapsedEl) elapsedEl.innerText = `${String(Math.floor(current / 60)).padStart(2, "0")}:${String(Math.floor(current % 60)).padStart(2, "0")}`;
    if (durEl) durEl.innerText = `${String(Math.floor(duration / 60)).padStart(2, "0")}:${String(Math.floor(duration % 60)).padStart(2, "0")}`;

    const percent = (current / duration) * 100;
    const fill = document.getElementById("musicProgressFill");
    const knob = document.getElementById("musicProgressKnob");
    if (fill) fill.style.width = `${percent}%`;
    if (knob) knob.style.left = `${percent}%`;
};

function handleMusicSeek(e) {
    const rail = document.querySelector(".music-progress-rail");
    if (!rail) return;
    const rect = rail.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const offsetX = Math.max(0, Math.min(rect.width, clientX - rect.left));
    focusAudio.currentTime = (offsetX / rect.width) * (focusAudio.duration || 30);
}

function seekMusicByClick(e) { handleMusicSeek(e); }

function toggleMusicLike(btn) {
    btn.classList.toggle("liked");
    const icon = btn.querySelector("i");
    if (icon) icon.className = btn.classList.contains("liked") ? "fa-solid fa-heart" : "fa-regular fa-heart";
}

function updateOnlineStatus() {
    const banner = document.getElementById("offlineBanner");
    if (!banner) return;
    if (!navigator.onLine) banner.classList.add("show");
    else banner.classList.remove("show");
}

window.addEventListener("online", updateOnlineStatus);
window.addEventListener("offline", updateOnlineStatus);

window.addEventListener("popstate", () => {
    const fpScreen = document.getElementById("friendProfileScreen");
    if (fpScreen && fpScreen.style.display === "block") { closeFriendProfileScreen(); return; }
    const policyModal = document.getElementById("policyModal");
    const alertModal = document.getElementById("alertModal");
    if (policyModal && policyModal.style.display === "flex") { closePolicyModal(); return; }
    if (alertModal && alertModal.style.display === "flex") { closeCustomAlert(); return; }

    const chatList = document.getElementById("chatListScreen");
    if (chatList && chatList.style.display === "none") {
        closeActiveDmChat();
        goHome();
    }
});

window.addEventListener("keydown", e => {
    if (e.key === "Enter" && !e.shiftKey && e.target?.id === "userInput") {
        e.preventDefault();
        sendMessage();
    }
});

window.addEventListener("DOMContentLoaded", () => {
    const isDark = localStorage.getItem("darkMode") === "true";
    if (isDark) document.body.classList.add("dark-mode");
    syncDarkModeUI(isDark);

    detectAndSetCountry();
    setupHomeSearchAndTabs();
    syncEditProfileInputs();

    const dmInput = document.getElementById("activeChatInput");
    if (dmInput) {
        dmInput.addEventListener("keydown", e => {
            if (e.key === "Enter") {
                e.preventDefault();
                sendRealtimeMessage();
            }
        });
    }

    const rail = document.querySelector(".music-progress-rail");
    if (rail) {
        rail.addEventListener("click", handleMusicSeek);
        rail.addEventListener("touchstart", handleMusicSeek, { passive: true });
        rail.addEventListener("touchmove", handleMusicSeek, { passive: true });
    }

    const splashScreen = document.getElementById("splashScreen");
    const authScreen = document.getElementById("authScreen");
    const alreadyLoggedIn = localStorage.getItem("isLoggedIn") === "true";

    if (alreadyLoggedIn) {
        if (authScreen) authScreen.style.setProperty("display", "none", "important");
        if (splashScreen) {
            splashScreen.classList.add("hide");
            setTimeout(() => { splashScreen.style.display = "none"; }, 350);
        }
        showChatsHome();
    } else {
        setTimeout(() => {
            if (splashScreen && splashScreen.style.display !== "none") {
                splashScreen.style.display = "none";
                if (authScreen) authScreen.style.display = "flex";
            }
        }, 1800);
    }

    initFirebase();
});
