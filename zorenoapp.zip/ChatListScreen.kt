package com.zoreno.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ChatListScreen(
    onOpenAiChat: () -> Unit,
    onOpenDm: (String, String, String) -> Unit,
    onOpenProfile: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf("All") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF080C14))
            .padding(16.dp)
    ) {
        // Top search bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search chats, @username...", color = Color.Gray, fontSize = 13.sp) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFF151E32),
                    unfocusedContainerColor = Color(0xFF151E32),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.weight(1f).height(50.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = onOpenProfile,
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF7C3AED))
            ) {
                Icon(Icons.Default.Person, contentDescription = "Profile", tint = Color.White)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Focus Sprint Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF151E32))
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Focus Sprint ⏱️", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Stay focused, keep the sprint alive!", color = Color.Gray, fontSize = 11.sp)
                }
                Text("20:00", color = Color(0xFF38BDF8), fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Filter Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(Color(0xFF151E32))
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            listOf("All", "Unread", "Friends", "Groups").forEach { tab ->
                val isSelected = tab == selectedTab
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (isSelected) Color(0xFF7C3AED) else Color.Transparent)
                        .clickable { selectedTab = tab }
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Text(tab, color = if (isSelected) Color.White else Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f)
        ) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color(0x337C3AED))
                        .clickable { onOpenAiChat() }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF7C3AED)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Z", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Zoreno AI", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text("Tap to start chatting with your AI partner", color = Color.LightGray, fontSize = 12.sp)
                    }
                    Icon(Icons.Default.PushPin, contentDescription = "Pinned", tint = Color(0xFFA855F7), modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}
