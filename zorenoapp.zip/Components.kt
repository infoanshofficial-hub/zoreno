package com.zoreno.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zoreno.app.AppScreen

@Composable
fun BoxScope.FloatingBottomNav(
    currentScreen: AppScreen,
    onTabSelect: (AppScreen) -> Unit
) {
    Box(
        modifier = Modifier
            .align(Alignment.BottomCenter)
            .padding(bottom = 16.dp, start = 16.dp, end = 16.dp)
            .fillMaxWidth()
            .height(64.dp)
            .clip(RoundedCornerShape(32.dp))
            .background(Color(0xE61C1C1E))
            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(32.dp))
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavItem(
                title = "Chats",
                icon = Icons.Default.ChatBubble,
                isSelected = currentScreen is AppScreen.ChatList,
                onClick = { onTabSelect(AppScreen.ChatList) }
            )
            NavItem(
                title = "Premium",
                icon = Icons.Default.WorkspacePremium,
                isSelected = currentScreen is AppScreen.Subscription,
                onClick = { onTabSelect(AppScreen.Subscription) }
            )
            NavItem(
                title = "Tools",
                icon = Icons.Default.Layers,
                isSelected = currentScreen is AppScreen.FocusMusic,
                onClick = { onTabSelect(AppScreen.FocusMusic) }
            )
            NavItem(
                title = "Settings",
                icon = Icons.Default.Settings,
                isSelected = currentScreen is AppScreen.Settings,
                onClick = { onTabSelect(AppScreen.Settings) }
            )
        }
    }
}

@Composable
fun NavItem(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterVertically,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = if (isSelected) Color(0xFF38BDF8) else Color(0xFF8E8E93),
            modifier = Modifier.size(24.dp)
        )
        Text(
            text = title,
            fontSize = 11.sp,
            color = if (isSelected) Color(0xFF38BDF8) else Color(0xFF8E8E93)
        )
    }
}
