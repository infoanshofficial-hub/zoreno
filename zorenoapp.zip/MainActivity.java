package com.example;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity implements PurchasesUpdatedListener {

    private static final String TAG = "ZorenoMainActivity";
    private static final String DEFAULT_REWARDED_AD_UNIT = "ca-app-pub-5825754850490611/4904670790";

    private WebView webView;
    private BillingClient billingClient;
    private RewardedAd rewardedAd;
    private boolean isAdLoading = false;
    private int currentTargetTier = 1;

    private ValueCallback<Uri[]> filePathCallback;
    private ActivityResultLauncher<Intent> fileChooserLauncher;

    @SuppressLint({"SetJavaScriptEnabled"})
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Setup File Chooser Activity Result Launcher
        fileChooserLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (filePathCallback == null) return;
                    Uri[] results = null;
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        Intent data = result.getData();
                        if (data.getData() != null) {
                            results = new Uri[]{data.getData()};
                        } else if (data.getClipData() != null) {
                            int count = data.getClipData().getItemCount();
                            results = new Uri[count];
                            for (int i = 0; i < count; i++) {
                                results[i] = data.getClipData().getItemAt(i).getUri();
                            }
                        }
                    }
                    filePathCallback.onReceiveValue(results);
                    filePathCallback = null;
                }
        );

        // Initialize Layout & WebView
        FrameLayout rootLayout = new FrameLayout(this);
        webView = new WebView(this);
        rootLayout.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));
        setContentView(rootLayout);

        configureWebView();
        initializeBillingClient();
        initializeMobileAds();

        // Load local bundled web application assets
        webView.loadUrl("file:///android_asset/index.html");

        // Handle Back button
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView != null && webView.canGoBack()) {
                    webView.goBack();
                } else {
                    finish();
                }
            }
        });
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        // Register Native JavaScript Bridges
        webView.addJavascriptInterface(new AndroidBillingBridge(), "AndroidBilling");
        webView.addJavascriptInterface(new AndroidAdMobBridge(), "AndroidAdMob");
        webView.addJavascriptInterface(new AndroidAppBridge(), "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                // Expose Android runtime check in DOM
                injectAndroidRuntimeFlag();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                injectAndroidRuntimeFlag();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    // Internal web navigation stays inside WebView
                    if (uri.getHost() != null && uri.getHost().contains("wikipedia.org")) {
                        try {
                            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                            startActivity(intent);
                            return true;
                        } catch (Exception ignored) {}
                    }
                    return false;
                } else if ("tel".equalsIgnoreCase(scheme) || "mailto".equalsIgnoreCase(scheme)) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                        startActivity(intent);
                        return true;
                    } catch (Exception e) {
                        return true;
                    }
                }
                return false;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                Log.e(TAG, "WebView Error: " + error.getDescription());
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;

                Intent intent = fileChooserParams.createIntent();
                try {
                    fileChooserLauncher.launch(intent);
                } catch (Exception e) {
                    MainActivity.this.filePathCallback = null;
                    return false;
                }
                return true;
            }
        });
    }

    private void injectAndroidRuntimeFlag() {
        String js = "window.isRunningInAndroidApp = function() { return true; };"
                + "window.isAndroidAppEnvironment = true;";
        webView.evaluateJavascript(js, null);
    }

    // =====================================================================
    // GOOGLE PLAY BILLING SDK IMPLEMENTATION
    // =====================================================================
    private void initializeBillingClient() {
        PendingPurchasesParams pendingPurchasesParams = PendingPurchasesParams.newBuilder()
                .enableOneTimeProducts()
                .build();

        billingClient = BillingClient.newBuilder(this)
                .setListener(this)
                .enablePendingPurchases(pendingPurchasesParams)
                .build();

        connectToBillingService();
    }

    private void connectToBillingService() {
        billingClient.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(@NonNull BillingResult billingResult) {
                if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    Log.i(TAG, "Google Play Billing client setup succeeded.");
                } else {
                    Log.w(TAG, "Billing setup failed with response code: " + billingResult.getResponseCode());
                }
            }

            @Override
            public void onBillingServiceDisconnected() {
                Log.w(TAG, "Billing service disconnected. Will retry connection on next purchase request.");
            }
        });
    }

    public void launchSubscriptionFlow(String skuId, int tierLevel) {
        this.currentTargetTier = tierLevel;
        if (!billingClient.isReady()) {
            connectToBillingService();
            showToast("Connecting to Google Play Store...");
            return;
        }

        List<QueryProductDetailsParams.Product> productList = new ArrayList<>();
        productList.add(
                QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(skuId)
                        .setProductType(BillingClient.ProductType.SUBS)
                        .build()
        );

        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder()
                .setProductList(productList)
                .build();

        billingClient.queryProductDetailsAsync(params, (billingResult, productDetailsList) -> {
            if (billingResult.getResponseCode() != BillingClient.BillingResponseCode.OK || productDetailsList.isEmpty()) {
                Log.e(TAG, "Error querying product details: " + billingResult.getDebugMessage());
                showToast("Subscription product not found on Play Console: " + skuId);
                return;
            }

            ProductDetails productDetails = productDetailsList.get(0);
            List<ProductDetails.SubscriptionOfferDetails> offerDetails = productDetails.getSubscriptionOfferDetails();

            if (offerDetails == null || offerDetails.isEmpty()) {
                showToast("No active subscription offer available.");
                return;
            }

            String offerToken = offerDetails.get(0).getOfferToken();
            List<BillingFlowParams.ProductDetailsParams> productDetailsParamsList = new ArrayList<>();
            productDetailsParamsList.add(
                    BillingFlowParams.ProductDetailsParams.newBuilder()
                            .setProductDetails(productDetails)
                            .setOfferToken(offerToken)
                            .build()
            );

            BillingFlowParams billingFlowParams = BillingFlowParams.newBuilder()
                    .setProductDetailsParamsList(productDetailsParamsList)
                    .build();

            runOnUiThread(() -> billingClient.launchBillingFlow(MainActivity.this, billingFlowParams));
        });
    }

    @Override
    public void onPurchasesUpdated(@NonNull BillingResult billingResult, @Nullable List<Purchase> purchases) {
        if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
            for (Purchase purchase : purchases) {
                handlePurchase(purchase);
            }
        } else if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.USER_CANCELED) {
            Log.i(TAG, "User canceled subscription flow.");
        } else {
            Log.e(TAG, "Purchase failed: " + billingResult.getDebugMessage());
            showToast("Purchase error: " + billingResult.getDebugMessage());
        }
    }

    private void handlePurchase(Purchase purchase) {
        if (purchase.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
            if (!purchase.isAcknowledged()) {
                AcknowledgePurchaseParams acknowledgePurchaseParams = AcknowledgePurchaseParams.newBuilder()
                        .setPurchaseToken(purchase.getPurchaseToken())
                        .build();

                billingClient.acknowledgePurchase(acknowledgePurchaseParams, billingResult -> {
                    if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                        notifyWebSubscriptionSuccess(purchase.getPurchaseToken());
                    } else {
                        Log.e(TAG, "Failed to acknowledge purchase: " + billingResult.getDebugMessage());
                    }
                });
            } else {
                notifyWebSubscriptionSuccess(purchase.getPurchaseToken());
            }
        }
    }

    private void notifyWebSubscriptionSuccess(String purchaseToken) {
        runOnUiThread(() -> {
            String script = String.format(
                    "if (window.onPlayBillingSuccess) { window.onPlayBillingSuccess(%d, '%s'); }",
                    currentTargetTier, purchaseToken
            );
            webView.evaluateJavascript(script, null);
        });
    }

    // =====================================================================
    // GOOGLE ADMOB REWARDED ADS IMPLEMENTATION
    // =====================================================================
    private void initializeMobileAds() {
        MobileAds.initialize(this, initializationStatus -> {
            Log.i(TAG, "Google Mobile Ads initialized.");
            loadRewardedAd(DEFAULT_REWARDED_AD_UNIT);
        });
    }

    public void loadRewardedAd(String adUnitId) {
        if (isAdLoading || (rewardedAd != null)) return;
        isAdLoading = true;

        String unit = (adUnitId != null && !adUnitId.isEmpty()) ? adUnitId : DEFAULT_REWARDED_AD_UNIT;
        AdRequest adRequest = new AdRequest.Builder().build();

        RewardedAd.load(this, unit, adRequest, new RewardedAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull RewardedAd ad) {
                rewardedAd = ad;
                isAdLoading = false;
                Log.i(TAG, "Rewarded ad loaded successfully.");

                rewardedAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdDismissedFullScreenContent() {
                        rewardedAd = null;
                        loadRewardedAd(unit);
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(@NonNull com.google.android.gms.ads.AdError adError) {
                        rewardedAd = null;
                        loadRewardedAd(unit);
                    }
                });
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                rewardedAd = null;
                isAdLoading = false;
                Log.w(TAG, "Rewarded ad failed to load: " + loadAdError.getMessage());
            }
        });
    }

    public void showRewardedAd(String adUnitId) {
        runOnUiThread(() -> {
            if (rewardedAd != null) {
                rewardedAd.show(MainActivity.this, rewardItem -> {
                    Log.i(TAG, "User earned reward: " + rewardItem.getAmount() + " " + rewardItem.getType());
                    runOnUiThread(() -> {
                        String js = "if (window.onAdMobRewardGranted) { window.onAdMobRewardGranted(); }";
                        webView.evaluateJavascript(js, null);
                    });
                });
            } else {
                showToast("Ad is still loading. Please try again in a few moments.");
                loadRewardedAd(adUnitId);
            }
        });
    }

    private void showToast(String message) {
        new Handler(Looper.getMainLooper()).post(() ->
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show()
        );
    }

    // =====================================================================
    // JAVASCRIPT BRIDGES (Called directly from app.js)
    // =====================================================================
    public class AndroidBillingBridge {
        @JavascriptInterface
        public void purchaseSubscription(String skuId, int targetTier) {
            Log.i(TAG, "AndroidBillingBridge purchase requested: " + skuId + " tier: " + targetTier);
            launchSubscriptionFlow(skuId, targetTier);
        }
    }

    public class AndroidAdMobBridge {
        @JavascriptInterface
        public void showRewardedAd(String adUnitId) {
            Log.i(TAG, "AndroidAdMobBridge showRewardedAd requested: " + adUnitId);
            MainActivity.this.showRewardedAd(adUnitId);
        }
    }

    public class AndroidAppBridge {
        @JavascriptInterface
        public boolean isAndroid() {
            return true;
        }

        @JavascriptInterface
        public void showToast(String msg) {
            MainActivity.this.showToast(msg);
        }
    }

    @Override
    protected void onDestroy() {
        if (billingClient != null) {
            billingClient.endConnection();
        }
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
