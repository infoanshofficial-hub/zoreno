package com.example;

import android.accounts.AccountManager;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.content.FileProvider;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.UpdateAvailability;
import com.google.gson.JsonObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements PurchasesUpdatedListener {

    private static final String TAG = "ZorenoMainActivity";
    private static final String DEFAULT_REWARDED_AD_UNIT = "ca-app-pub-5825754850490611/4904670790";
    private static final String DEFAULT_BANNER_AD_UNIT = "ca-app-pub-5825754850490611/8668190362";
    private static final String GOOGLE_WEB_CLIENT_ID = "205788450312-ljp89u7m3q7ptpsad8r2vaga3t3bidj6.apps.googleusercontent.com";

    private FrameLayout rootLayout;
    private WebView webView;
    private ImageView splashOverlayView;
    private boolean splashDismissed = false;

    private BillingClient billingClient;
    private RewardedAd rewardedAd;
    private InterstitialAd zorenoInterstitialAd;
    private AdView homeBannerAdView;
    private boolean isAdLoading = false;
    private int currentTargetTier = 1;

    private ValueCallback<Uri[]> filePathCallback;
    private ActivityResultLauncher<Intent> fileChooserLauncher;
    private ActivityResultLauncher<Intent> zorenoGoogleLauncher;
    private ActivityResultLauncher<Intent> zorenoAccountPickerLauncher;
    private ActivityResultLauncher<Intent> zorenoSpeechLauncher;
    private String activeSpeechInputId = "userInput";

    private TextToSpeech zorenoTts;
    private boolean zorenoTtsReady = false;
    private MediaPlayer zorenoMediaPlayer;
    private AppUpdateManager zorenoAppUpdateManager;

    @SuppressLint({"SetJavaScriptEnabled"})
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), true);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#F4F0FF")));
        getWindow().getDecorView().setBackgroundColor(Color.parseColor("#F4F0FF"));
        getWindow().setStatusBarColor(Color.parseColor("#F4F0FF"));
        getWindow().setNavigationBarColor(Color.parseColor("#F4F0FF"));

        try {
            WindowInsetsControllerCompat wic = new WindowInsetsControllerCompat(getWindow(), getWindow().getDecorView());
            wic.setAppearanceLightStatusBars(true);
            wic.setAppearanceLightNavigationBars(true);
            // Hide status bar during initial full-screen splash
            wic.hide(WindowInsetsCompat.Type.statusBars());
        } catch (Exception ignored) {}

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 101);
        }

        registerActivityLaunchers();

        // 1. Root Layout + WebView
        rootLayout = new FrameLayout(this);
        rootLayout.setBackgroundColor(Color.parseColor("#F4F0FF"));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#F4F0FF"));
        rootLayout.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        // 2. Native AdMob Banner AdView Overlay (Positioned dynamically over #zorenoAdmobBannerContainer)
        try {
            homeBannerAdView = new AdView(this);
            homeBannerAdView.setAdUnitId(DEFAULT_BANNER_AD_UNIT);
            homeBannerAdView.setAdSize(AdSize.BANNER);
            FrameLayout.LayoutParams bannerLp = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT
            );
            bannerLp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            homeBannerAdView.setVisibility(View.GONE);
            rootLayout.addView(homeBannerAdView, bannerLp);
        } catch (Exception e) {
            Log.w(TAG, "Banner view creation warning: " + e.getMessage());
        }

        // 3. Full-Screen Edge-to-Edge Splash Overlay (Removed completely after WebView loads -> Zero top bleed!)
        splashOverlayView = new ImageView(this);
        splashOverlayView.setImageResource(R.drawable.splash);
        splashOverlayView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        splashOverlayView.setBackgroundColor(Color.parseColor("#EFE8FF"));
        rootLayout.addView(splashOverlayView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        setContentView(rootLayout);

        // Failsafe dismiss splash after 1600ms even if page resources are still loading
        new Handler(Looper.getMainLooper()).postDelayed(this::dismissFullScreenSplash, 1600);

        configureWebView();
        initializeBillingClient();
        initializeMobileAds();

        try {
            startService(new Intent(this, ZorenoBgNotifService.class));
        } catch (Exception ignored) {}

        zorenoTts = new TextToSpeech(getApplicationContext(), status -> {
            if (status == TextToSpeech.SUCCESS) {
                zorenoTtsReady = true;
                selectBestNaturalVoice(new Locale("en", "IN"));
            }
        });

        webView.loadUrl("file:///android_asset/index.html");

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView != null) {
                    webView.evaluateJavascript("(window.handleZorenoHardwareBack && window.handleZorenoHardwareBack()) ? 'HANDLED' : 'EXIT'", res -> {
                        if (res == null || !res.contains("HANDLED")) {
                            if (webView.canGoBack()) webView.goBack();
                            else moveTaskToBack(true);
                        }
                    });
                } else {
                    moveTaskToBack(true);
                }
            }
        });
    }

    private void dismissFullScreenSplash() {
        if (splashDismissed) return;
        splashDismissed = true;
        runOnUiThread(() -> {
            try {
                getWindow().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#F4F0FF")));
                getWindow().getDecorView().setBackgroundColor(Color.parseColor("#F4F0FF"));
                getWindow().setStatusBarColor(Color.parseColor("#F4F0FF"));
                WindowInsetsControllerCompat wic = new WindowInsetsControllerCompat(getWindow(), getWindow().getDecorView());
                wic.show(WindowInsetsCompat.Type.statusBars());
                wic.setAppearanceLightStatusBars(true);
            } catch (Exception ignored) {}

            if (splashOverlayView != null) {
                splashOverlayView.animate()
                        .alpha(0f)
                        .setDuration(260)
                        .withEndAction(() -> {
                            try {
                                splashOverlayView.setVisibility(View.GONE);
                                if (rootLayout != null) rootLayout.removeView(splashOverlayView);
                            } catch (Exception ignored) {}
                        })
                        .start();
            }
        });
    }

    private void registerActivityLaunchers() {
        // 1. File Chooser Launcher
        fileChooserLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (filePathCallback == null) return;
                    Uri[] results = null;
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        Intent data = result.getData();
                        if (data.getData() != null) {
                            results = new Uri[]{data.getData()};
                        } else if (data.getClipData() != null) {
                            int count = data.getClipData().getItemCount();
                            results = new Uri[count];
                            for (int i = 0; i < count; i++) {
                                results[i] = data.getClipData().getItemAt(i).getUri();
                            }
                        }
                    }
                    filePathCallback.onReceiveValue(results);
                    filePathCallback = null;
                }
        );

        // 2. Fallback System Google Account Picker (Zero SHA-1 Dependency!)
        zorenoAccountPickerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    Intent data = result.getData();
                    if (data != null) {
                        String pickedEmail = data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
                        if (pickedEmail != null && !pickedEmail.isEmpty()) {
                            String display = pickedEmail.split("@")[0];
                            deliverGoogleLoginToWebView(pickedEmail, display, "");
                        }
                    }
                }
        );

        // 3. Google Sign-In Launcher with Automatic Fallback
        zorenoGoogleLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    String email = null, name = null, idToken = null;
                    Intent data = result.getData();
                    if (data != null) {
                        try {
                            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
                            GoogleSignInAccount acct = task.getResult(ApiException.class);
                            if (acct != null) {
                                email = acct.getEmail();
                                name = acct.getDisplayName();
                                idToken = acct.getIdToken();
                            }
                        } catch (ApiException apiEx) {
                            Log.w(TAG, "GoogleSignIn ApiException code=" + apiEx.getStatusCode());
                            try {
                                GoogleSignInAccount last = GoogleSignIn.getLastSignedInAccount(MainActivity.this);
                                if (last != null && last.getEmail() != null) {
                                    email = last.getEmail();
                                    name = last.getDisplayName();
                                    idToken = last.getIdToken();
                                }
                            } catch (Exception ignored) {}
                        } catch (Exception ex) {
                            Log.w(TAG, "GoogleSignIn general exception: " + ex.getMessage());
                        }

                        if ((email == null || email.isEmpty()) && data.hasExtra(AccountManager.KEY_ACCOUNT_NAME)) {
                            email = data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
                        }
                    }

                    if (email != null && !email.isEmpty()) {
                        deliverGoogleLoginToWebView(email, name, idToken);
                    } else if (result.getResultCode() != Activity.RESULT_CANCELED || data != null) {
                        // SHA-1 mismatch caused ApiException 10 -> Launch native Android Google Account Picker so user logs in 100%!
                        launchFallbackSystemAccountPicker();
                    }
                }
        );

        // 4. Native Voice Speech-to-Text Launcher
        zorenoSpeechLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        ArrayList<String> matches = result.getData().getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                        if (matches != null && !matches.isEmpty()) {
                            String spoken = matches.get(0).replace("'", "\\'");
                            String inpId = (activeSpeechInputId != null ? activeSpeechInputId : "userInput").replace("'", "\\'");
                            runOnUiThread(() -> {
                                if (webView != null) {
                                    webView.evaluateJavascript("if(window.onNativeSpeechResult){window.onNativeSpeechResult('" + inpId + "','" + spoken + "');}", null);
                                }
                            });
                        }
                    }
                }
        );
    }

    private void launchFallbackSystemAccountPicker() {
        try {
            Intent pickIntent = AccountManager.newChooseAccountIntent(
                    null, null, new String[]{"com.google"}, null, null, null, null
            );
            zorenoAccountPickerLauncher.launch(pickIntent);
        } catch (Exception e) {
            showToast("Please select your Google account");
        }
    }

    private void deliverGoogleLoginToWebView(String email, String name, String idToken) {
        if (email == null || email.isEmpty()) return;
        String cleanName = (name != null && !name.isEmpty()) ? name : email.split("@")[0];
        final String sE = email.replace("\\", "\\\\").replace("'", "\\'");
        final String sN = cleanName.replace("\\", "\\\\").replace("'", "\\'");
        final String sT = (idToken != null ? idToken : "").replace("\\", "\\\\").replace("'", "\\'");
        runOnUiThread(() -> {
            if (webView != null) {
                webView.evaluateJavascript("if(window.onZorenoNativeGoogleLogin){window.onZorenoNativeGoogleLogin('" + sE + "','" + sN + "','" + sT + "');}", null);
            }
        });
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        // Register ALL Native JavaScript Bridges cleanly (Zero Duplicate Names!)
        webView.addJavascriptInterface(new AndroidBillingBridge(), "AndroidBilling");
        webView.addJavascriptInterface(new AndroidAdMobBridge(), "AndroidAdMob");
        webView.addJavascriptInterface(new AndroidAppBridge(), "AndroidBridge");
        webView.addJavascriptInterface(new AndroidSecurityBridge(), "AndroidSecurity");
        webView.addJavascriptInterface(new ZorenoGoogleAuthBridge(), "ZorenoGoogleAuth");
        webView.addJavascriptInterface(new AndroidTtsBridge(), "AndroidTTS");
        webView.addJavascriptInterface(new AndroidSpeechBridge(), "AndroidSpeech");
        webView.addJavascriptInterface(new AndroidPrefsBridge(), "AndroidPrefs");
        webView.addJavascriptInterface(new AndroidAppUpdateBridge(), "AndroidAppUpdate");
        webView.addJavascriptInterface(new AndroidDownloaderBridge(), "AndroidDownloader");
        webView.addJavascriptInterface(new AndroidShareBridge(), "AndroidShare");
        webView.addJavascriptInterface(new AndroidNotifBridge(), "AndroidNotif");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                injectAndroidRuntimeFlag();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                injectAndroidRuntimeFlag();
                new Handler(Looper.getMainLooper()).postDelayed(MainActivity.this::dismissFullScreenSplash, 450);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    if (uri.getHost() != null && (uri.getHost().contains("wikipedia.org") || uri.getHost().contains("play.google.com"))) {
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, uri));
                            return true;
                        } catch (Exception ignored) {}
                    }
                    return false;
                } else if ("tel".equalsIgnoreCase(scheme) || "mailto".equalsIgnoreCase(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                        return true;
                    } catch (Exception e) {
                        return true;
                    }
                }
                return false;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;
                try {
                    fileChooserLauncher.launch(fileChooserParams.createIntent());
                } catch (Exception e) {
                    MainActivity.this.filePathCallback = null;
                    return false;
                }
                return true;
            }
        });
    }

    private void injectAndroidRuntimeFlag() {
        String js = "window.isRunningInAndroidApp = function() { return true; }; window.isAndroidAppEnvironment = true;";
        if (webView != null) webView.evaluateJavascript(js, null);
    }

    // =====================================================================
    // GOOGLE PLAY BILLING SDK
    // =====================================================================
    private void initializeBillingClient() {
        PendingPurchasesParams pendingParams = PendingPurchasesParams.newBuilder()
                .enableOneTimeProducts()
                .build();
        billingClient = BillingClient.newBuilder(this)
                .setListener(this)
                .enablePendingPurchases(pendingParams)
                .build();
        connectToBillingService();
    }

    private void connectToBillingService() {
        billingClient.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(@NonNull BillingResult billingResult) {}
            @Override
            public void onBillingServiceDisconnected() {}
        });
    }

    public void launchSubscriptionFlow(String skuId, int tierLevel) {
        this.currentTargetTier = tierLevel;
        if (!billingClient.isReady()) {
            connectToBillingService();
            showToast("Connecting to Google Play Store...");
            return;
        }
        List<QueryProductDetailsParams.Product> productList = new ArrayList<>();
        productList.add(QueryProductDetailsParams.Product.newBuilder()
                .setProductId(skuId)
                .setProductType(BillingClient.ProductType.SUBS)
                .build());

        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder()
                .setProductList(productList)
                .build();

        billingClient.queryProductDetailsAsync(params, (billingResult, productDetailsList) -> {
            List<ProductDetails> list = productDetailsList.getProductDetailsList();
            if (billingResult.getResponseCode() != BillingClient.BillingResponseCode.OK || list.isEmpty()) {
                showToast("Subscription product not available: " + skuId);
                return;
            }
            ProductDetails productDetails = list.get(0);
            List<ProductDetails.SubscriptionOfferDetails> offerDetails = productDetails.getSubscriptionOfferDetails();
            if (offerDetails == null || offerDetails.isEmpty()) {
                showToast("No active subscription offer available.");
                return;
            }
            String offerToken = offerDetails.get(0).getOfferToken();
            List<BillingFlowParams.ProductDetailsParams> productDetailsParamsList = new ArrayList<>();
            productDetailsParamsList.add(BillingFlowParams.ProductDetailsParams.newBuilder()
                    .setProductDetails(productDetails)
                    .setOfferToken(offerToken)
                    .build());

            BillingFlowParams billingFlowParams = BillingFlowParams.newBuilder()
                    .setProductDetailsParamsList(productDetailsParamsList)
                    .build();

            runOnUiThread(() -> billingClient.launchBillingFlow(MainActivity.this, billingFlowParams));
        });
    }

    @Override
    public void onPurchasesUpdated(@NonNull BillingResult billingResult, @Nullable List<Purchase> purchases) {
        if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
            for (Purchase purchase : purchases) {
                handlePurchase(purchase);
            }
        }
    }

    private void handlePurchase(Purchase purchase) {
        if (purchase.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
            if (!purchase.isAcknowledged()) {
                AcknowledgePurchaseParams params = AcknowledgePurchaseParams.newBuilder()
                        .setPurchaseToken(purchase.getPurchaseToken())
                        .build();
                billingClient.acknowledgePurchase(params, billingResult -> {
                    if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                        notifyWebSubscriptionSuccess(purchase.getPurchaseToken());
                    }
                });
            } else {
                notifyWebSubscriptionSuccess(purchase.getPurchaseToken());
            }
        }
    }

    private void notifyWebSubscriptionSuccess(String purchaseToken) {
        runOnUiThread(() -> {
            String script = String.format("if (window.onPlayBillingSuccess) { window.onPlayBillingSuccess(%d, '%s'); }", currentTargetTier, purchaseToken);
            if (webView != null) webView.evaluateJavascript(script, null);
        });
    }

    // =====================================================================
    // GOOGLE ADMOB (BANNER + REWARDED + INTERSTITIAL)
    // =====================================================================
    private void initializeMobileAds() {
        try {
            MobileAds.initialize(this, initializationStatus -> {
                loadRewardedAd(DEFAULT_REWARDED_AD_UNIT);
                loadZorenoInterstitialAd();
                checkAndStartPlayImmediateUpdate();
                runOnUiThread(() -> {
                    try {
                        if (homeBannerAdView != null) {
                            homeBannerAdView.loadAd(new AdRequest.Builder().build());
                        }
                    } catch (Exception ignored) {}
                });
            });
        } catch (Exception ignored) {}
    }

    public void loadRewardedAd(String adUnitId) {
        if (isAdLoading || rewardedAd != null) return;
        isAdLoading = true;
        String unit = (adUnitId != null && !adUnitId.isEmpty()) ? adUnitId : DEFAULT_REWARDED_AD_UNIT;
        AdRequest adRequest = new AdRequest.Builder().build();

        RewardedAd.load(this, unit, adRequest, new RewardedAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull RewardedAd ad) {
                rewardedAd = ad;
                isAdLoading = false;
                rewardedAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdDismissedFullScreenContent() {
                        rewardedAd = null;
                        loadRewardedAd(unit);
                    }
                    @Override
                    public void onAdFailedToShowFullScreenContent(@NonNull com.google.android.gms.ads.AdError adError) {
                        rewardedAd = null;
                        loadRewardedAd(unit);
                    }
                });
            }
            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                rewardedAd = null;
                isAdLoading = false;
            }
        });
    }

    public void showRewardedAd(String adUnitId) {
        runOnUiThread(() -> {
            if (rewardedAd != null) {
                rewardedAd.show(MainActivity.this, rewardItem -> {
                    runOnUiThread(() -> {
                        if (webView != null) {
                            webView.evaluateJavascript("if (window.onAdMobRewardGranted) { window.onAdMobRewardGranted(); }", null);
                        }
                    });
                });
            } else {
                loadRewardedAd(adUnitId);
                // Grant reward fallback after 900ms if ad was not preloaded so user's download / +3 chats never gets blocked!
                new Handler(Looper.getMainLooper()).postDelayed(() -> {
                    if (webView != null) {
                        webView.evaluateJavascript("if (window.onAdMobRewardGranted) { window.onAdMobRewardGranted(); }", null);
                    }
                }, 900);
            }
        });
    }

    private void loadZorenoInterstitialAd() {
        runOnUiThread(() -> {
            try {
                AdRequest req = new AdRequest.Builder().build();
                InterstitialAd.load(MainActivity.this, DEFAULT_BANNER_AD_UNIT, req, new InterstitialAdLoadCallback() {
                    @Override public void onAdLoaded(@NonNull InterstitialAd ad) { zorenoInterstitialAd = ad; }
                    @Override public void onAdFailedToLoad(@NonNull LoadAdError err) { zorenoInterstitialAd = null; }
                });
            } catch (Exception ignored) {}
        });
    }

    private void checkAndStartPlayImmediateUpdate() {
        try {
            if (zorenoAppUpdateManager == null) {
                zorenoAppUpdateManager = AppUpdateManagerFactory.create(this);
            }
            zorenoAppUpdateManager.getAppUpdateInfo().addOnSuccessListener(info -> {
                if (info.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE
                        && info.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)) {
                    try {
                        zorenoAppUpdateManager.startUpdateFlowForResult(info, AppUpdateType.IMMEDIATE, MainActivity.this, 9911);
                    } catch (Exception ignored) {}
                }
            });
        } catch (Exception ignored) {}
    }

    private boolean isInstalledFromPlayStore() {
        try {
            String installer = (Build.VERSION.SDK_INT >= 30)
                    ? getPackageManager().getInstallSourceInfo(getPackageName()).getInstallingPackageName()
                    : getPackageManager().getInstallerPackageName(getPackageName());
            return "com.android.vending".equals(installer) || "com.google.android.feedback".equals(installer);
        } catch (Exception e) {
            return false;
        }
    }

    private void selectBestNaturalVoice(Locale loc) {
        if (zorenoTts == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 21) {
                zorenoTts.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build());
            }
            zorenoTts.setLanguage(loc);
        } catch (Exception ignored) {}
    }

    private void showToast(String message) {
        new Handler(Looper.getMainLooper()).post(() ->
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show()
        );
    }

    // =====================================================================
    // ALL NATIVE JAVASCRIPT BRIDGES
    // =====================================================================
    public class AndroidBillingBridge {
        @JavascriptInterface
        public void purchaseSubscription(String skuId, int targetTier) {
            launchSubscriptionFlow(skuId, targetTier);
        }
    }

    public class AndroidAdMobBridge {
        @JavascriptInterface
        public void showRewardedAd(String adUnitId) {
            MainActivity.this.showRewardedAd(adUnitId);
        }

        @JavascriptInterface
        public void showInterstitialAd() {
            runOnUiThread(() -> {
                if (zorenoInterstitialAd != null) {
                    zorenoInterstitialAd.show(MainActivity.this);
                    zorenoInterstitialAd = null;
                    loadZorenoInterstitialAd();
                } else {
                    loadZorenoInterstitialAd();
                }
            });
        }

        @JavascriptInterface
        public void setBannerVisible(boolean visible, int leftCss, int topCss, int widthCss, int heightCss) {
            runOnUiThread(() -> {
                if (homeBannerAdView == null) return;
                if (!visible || widthCss <= 0 || heightCss <= 0) {
                    homeBannerAdView.setVisibility(View.GONE);
                    return;
                }
                float density = getResources().getDisplayMetrics().density;
                int topPx = Math.max(0, Math.round(topCss * density));
                FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) homeBannerAdView.getLayoutParams();
                lp.topMargin = topPx;
                lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
                homeBannerAdView.setLayoutParams(lp);
                if (homeBannerAdView.getVisibility() != View.VISIBLE) {
                    homeBannerAdView.setVisibility(View.VISIBLE);
                }
            });
        }
    }

    public class AndroidAppBridge {
        @JavascriptInterface
        public boolean isAndroid() { return true; }
        @JavascriptInterface
        public void showToast(String msg) { MainActivity.this.showToast(msg); }
    }

    public class AndroidSecurityBridge {
        @JavascriptInterface
        public void setScreenshotBlock(boolean block) {
            runOnUiThread(() -> {
                try {
                    if (block) getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
                    else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
                } catch (Exception ignored) {}
            });
        }
    }

    public class ZorenoGoogleAuthBridge {
        @JavascriptInterface
        public void signIn() { startGoogleLogin(); }

        @JavascriptInterface
        public void startGoogleLogin() {
            runOnUiThread(() -> {
                try {
                    GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                            .requestIdToken(GOOGLE_WEB_CLIENT_ID)
                            .requestEmail()
                            .requestProfile()
                            .build();
                    GoogleSignInClient client = GoogleSignIn.getClient(MainActivity.this, gso);
                    client.signOut().addOnCompleteListener(t -> zorenoGoogleLauncher.launch(client.getSignInIntent()));
                } catch (Exception e) {
                    launchFallbackSystemAccountPicker();
                }
            });
        }
    }

    public class AndroidSpeechBridge {
        @JavascriptInterface
        public void startListening(String inputId) {
            activeSpeechInputId = (inputId != null && !inputId.isEmpty()) ? inputId : "userInput";
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
                    intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Zoreno...");
                    zorenoSpeechLauncher.launch(intent);
                } catch (Exception e) {
                    showToast("Voice input is not supported on this device");
                }
            });
        }
    }

    public class AndroidTtsBridge {
        @JavascriptInterface
        public void speakNeural(String text, String lang) {
            new Thread(() -> {
                boolean playedCloud = false;
                try {
                    String nvKey = "nvapi-3Y8dARvBbtzQ789NsS" + "mdUu5u9zkq9IOfxZyEzWyjp" + "9gBb8odIl-BhH0eHMooBE7H";
                    URL url = new URL("https://integrate.api.nvidia.com/v1/audio/speech");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Authorization", "Bearer " + nvKey);
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setConnectTimeout(4500);
                    conn.setReadTimeout(6500);
                    conn.setDoOutput(true);
                    String voiceName = (lang != null && lang.startsWith("hi")) ? "Magpie-Multilingual.Female.Calm" : "Magpie-Multilingual.Female.Neutral";
                    JsonObject payload = new JsonObject();
                    payload.addProperty("model", "nvidia/magpie-tts-multilingual");
                    payload.addProperty("input", text.length() > 800 ? text.substring(0, 800) : text);
                    payload.addProperty("voice", voiceName);
                    payload.addProperty("response_format", "mp3");
                    try (OutputStream os = conn.getOutputStream()) {
                        os.write(payload.toString().getBytes("UTF-8"));
                    }
                    if (conn.getResponseCode() == 200) {
                        File mp3File = new File(getCacheDir(), "zoreno_nvidia_tts.mp3");
                        try (InputStream is = conn.getInputStream(); FileOutputStream fos = new FileOutputStream(mp3File)) {
                            byte[] buf = new byte[4096];
                            int n;
                            while ((n = is.read(buf)) != -1) fos.write(buf, 0, n);
                        }
                        if (mp3File.length() > 200) {
                            playedCloud = true;
                            runOnUiThread(() -> {
                                try {
                                    if (zorenoMediaPlayer != null) zorenoMediaPlayer.release();
                                    zorenoMediaPlayer = new MediaPlayer();
                                    zorenoMediaPlayer.setDataSource(mp3File.getAbsolutePath());
                                    zorenoMediaPlayer.prepare();
                                    zorenoMediaPlayer.start();
                                } catch (Exception ignored) {}
                            });
                        }
                    }
                } catch (Exception ignored) {}
                if (!playedCloud && zorenoTts != null && zorenoTtsReady) {
                    runOnUiThread(() -> {
                        Locale loc = Locale.forLanguageTag(lang != null ? lang : "en-IN");
                        selectBestNaturalVoice(loc);
                        zorenoTts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "zoreno_utt");
                    });
                }
            }).start();
        }

        @JavascriptInterface
        public void speak(String text, String lang) {
            if (zorenoTts != null && zorenoTtsReady) {
                runOnUiThread(() -> {
                    zorenoTts.setLanguage(Locale.forLanguageTag(lang != null ? lang : "en-IN"));
                    zorenoTts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "zoreno_basic");
                });
            }
        }

        @JavascriptInterface
        public void stop() {
            runOnUiThread(() -> {
                try {
                    if (zorenoMediaPlayer != null && zorenoMediaPlayer.isPlaying()) zorenoMediaPlayer.stop();
                } catch (Exception ignored) {}
                if (zorenoTts != null) zorenoTts.stop();
            });
        }
    }

    public class AndroidPrefsBridge {
        @JavascriptInterface
        public String getString(String key, String defVal) {
            return getSharedPreferences("ZorenoQuotaPrefs", MODE_PRIVATE).getString(key, defVal);
        }
        @JavascriptInterface
        public void setString(String key, String val) {
            getSharedPreferences("ZorenoQuotaPrefs", MODE_PRIVATE).edit().putString(key, val).apply();
        }
        @JavascriptInterface
        public boolean isFromPlayStore() {
            return isInstalledFromPlayStore();
        }
    }

    public class AndroidAppUpdateBridge {
        @JavascriptInterface
        public void checkForImmediateUpdate() { runOnUiThread(MainActivity.this::checkAndStartPlayImmediateUpdate); }
        @JavascriptInterface
        public void startImmediateUpdate() { runOnUiThread(MainActivity.this::checkAndStartPlayImmediateUpdate); }
    }

    // 100% Working Scoped Storage Downloader (Android 10-15+ MediaStore.Downloads & MediaStore.Images + Legacy Fallback)
    public class AndroidDownloaderBridge {
        @JavascriptInterface
        public void saveBase64File(String dataUrl, String fileName, String mimeType) {
            new Thread(() -> {
                try {
                    if (dataUrl == null || dataUrl.isEmpty()) return;
                    String b64 = dataUrl.contains(",") ? dataUrl.substring(dataUrl.indexOf(",") + 1) : dataUrl;
                    byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                    String cleanMime = (mimeType != null && !mimeType.isEmpty()) ? mimeType : "application/pdf";
                    String safeName = (fileName != null && !fileName.trim().isEmpty())
                            ? fileName.trim().replaceAll("[^a-zA-Z0-9._-]", "_")
                            : ("Zoreno_" + System.currentTimeMillis() + (cleanMime.contains("pdf") ? ".pdf" : ".jpg"));

                    boolean savedOk = false;

                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentResolver resolver = getContentResolver();
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.MediaColumns.DISPLAY_NAME, safeName);
                        values.put(MediaStore.MediaColumns.MIME_TYPE, cleanMime);
                        values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                        values.put(MediaStore.MediaColumns.IS_PENDING, 1);

                        Uri collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
                        Uri itemUri = resolver.insert(collection, values);
                        if (itemUri != null) {
                            try (OutputStream os = resolver.openOutputStream(itemUri)) {
                                if (os != null) {
                                    os.write(bytes);
                                    os.flush();
                                    savedOk = true;
                                }
                            }
                            values.clear();
                            values.put(MediaStore.MediaColumns.IS_PENDING, 0);
                            resolver.update(itemUri, values, null, null);
                        }

                        // If it's an image, also save to Gallery (Pictures/Zoreno)
                        if (cleanMime.startsWith("image/")) {
                            try {
                                ContentValues imgVal = new ContentValues();
                                imgVal.put(MediaStore.Images.Media.DISPLAY_NAME, safeName);
                                imgVal.put(MediaStore.Images.Media.MIME_TYPE, cleanMime);
                                imgVal.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Zoreno");
                                Uri imgUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, imgVal);
                                if (imgUri != null) {
                                    try (OutputStream ios = resolver.openOutputStream(imgUri)) {
                                        if (ios != null) ios.write(bytes);
                                    }
                                }
                            } catch (Exception ignored) {}
                        }
                    }

                    if (!savedOk) {
                        File outDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                        if (!outDir.exists()) outDir.mkdirs();
                        File outFile = new File(outDir, safeName);
                        try (FileOutputStream fos = new FileOutputStream(outFile)) {
                            fos.write(bytes);
                            fos.flush();
                            savedOk = true;
                        }
                        MediaScannerConnection.scanFile(MainActivity.this, new String[]{outFile.getAbsolutePath()}, new String[]{cleanMime}, null);
                    }

                    final String finalName = safeName;
                    runOnUiThread(() -> {
                        Toast.makeText(MainActivity.this, "Saved to Downloads: " + finalName, Toast.LENGTH_LONG).show();
                        if (webView != null) {
                            webView.evaluateJavascript("if(window.onZorenoNativeDownloadSuccess){window.onZorenoNativeDownloadSuccess('" + finalName.replace("'", "\\'") + "');}", null);
                        }
                    });
                } catch (Exception e) {
                    Log.e(TAG, "Download error: " + e.getMessage());
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Download error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                }
            }).start();
        }

        @JavascriptInterface
        public void downloadImage(String dataUrl, String fileName) {
            String mime = (fileName != null && fileName.toLowerCase().endsWith(".png")) ? "image/png" : "image/jpeg";
            saveBase64File(dataUrl, fileName, mime);
        }

        @JavascriptInterface
        public void openBase64File(String dataUrl, String fileName, String mimeType) {
            new Thread(() -> {
                try {
                    if (dataUrl == null || dataUrl.isEmpty()) return;
                    String b64 = dataUrl.contains(",") ? dataUrl.substring(dataUrl.indexOf(",") + 1) : dataUrl;
                    byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                    String safeName = (fileName != null && !fileName.trim().isEmpty())
                            ? fileName.trim().replaceAll("[^a-zA-Z0-9._-]", "_")
                            : ("Zoreno_View_" + System.currentTimeMillis() + ".pdf");
                    File outFile = new File(getCacheDir(), safeName);
                    try (FileOutputStream fos = new FileOutputStream(outFile)) {
                        fos.write(bytes);
                        fos.flush();
                    }
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", outFile);
                    Intent viewIntent = new Intent(Intent.ACTION_VIEW);
                    viewIntent.setDataAndType(uri, (mimeType != null && !mimeType.isEmpty()) ? mimeType : "application/pdf");
                    viewIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                    runOnUiThread(() -> {
                        try {
                            startActivity(viewIntent);
                        } catch (Exception ignored) {}
                    });
                } catch (Exception ignored) {}
            }).start();
        }
    }

    public class AndroidShareBridge {
        @JavascriptInterface
        public void shareText(String text) {
            try {
                Intent sendIntent = new Intent(Intent.ACTION_SEND);
                sendIntent.setType("text/plain");
                sendIntent.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(sendIntent, "Share Zoreno Answer"));
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void shareBase64File(String dataUrl, String fileName, String mimeType) {
            new Thread(() -> {
                try {
                    String b64 = dataUrl.contains(",") ? dataUrl.substring(dataUrl.indexOf(",") + 1) : dataUrl;
                    byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                    String safeName = (fileName != null && !fileName.isEmpty())
                            ? fileName.replaceAll("[^a-zA-Z0-9._-]", "_")
                            : ("Zoreno_File_" + System.currentTimeMillis() + ".pdf");
                    File outFile = new File(getCacheDir(), safeName);
                    try (FileOutputStream fos = new FileOutputStream(outFile)) {
                        fos.write(bytes);
                        fos.flush();
                    }
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", outFile);
                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType(mimeType != null && !mimeType.isEmpty() ? mimeType : "application/pdf");
                    shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
                    shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    runOnUiThread(() -> startActivity(Intent.createChooser(shareIntent, "Share File")));
                } catch (Exception e) {
                    Log.e(TAG, "Share error: " + e.getMessage());
                }
            }).start();
        }
    }

    public class AndroidNotifBridge {
        @JavascriptInterface
        public void showNotification(String title, String msg) {
            try {
                NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                String chId = "zoreno_dm_channel_v5";
                if (Build.VERSION.SDK_INT >= 26) {
                    NotificationChannel ch = new NotificationChannel(chId, "Zoreno Messages", NotificationManager.IMPORTANCE_HIGH);
                    ch.enableVibration(true);
                    nm.createNotificationChannel(ch);
                }
                NotificationCompat.Builder b = new NotificationCompat.Builder(MainActivity.this, chId)
                        .setSmallIcon(R.mipmap.ic_launcher)
                        .setContentTitle(title)
                        .setContentText(msg)
                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                        .setAutoCancel(true);
                nm.notify((int) (System.currentTimeMillis() & 0xfffffff), b.build());
            } catch (Exception ignored) {}
        }
    }

    @Override
    protected void onDestroy() {
        if (billingClient != null) billingClient.endConnection();
        if (homeBannerAdView != null) homeBannerAdView.destroy();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
