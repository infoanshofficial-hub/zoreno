plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.zoreno.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.zoreno.app"
        minSdk = 24
        targetSdk = 36
        versionCode = 11
        versionName = "1.1.0"
    }

    signingConfigs {
        create("release") {
            storeFile = file("zoreno-release-key.jks")
            storePassword = "Zoreno@2026"
            keyAlias = "zoreno"
            keyPassword = "Zoreno@2026"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.constraintlayout:constraintlayout:2.2.0")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("com.google.android.gms:play-services-ads:23.6.0")
    implementation("com.google.android.gms:play-services-auth:21.2.0")
    implementation("com.google.firebase:firebase-messaging:24.1.0")
    implementation("com.android.billingclient:billing:8.0.0")
    implementation("com.google.android.play:app-update:2.1.0")
    implementation("com.google.code.gson:gson:2.11.0")
    implementation("androidx.browser:browser:1.8.0")
}
